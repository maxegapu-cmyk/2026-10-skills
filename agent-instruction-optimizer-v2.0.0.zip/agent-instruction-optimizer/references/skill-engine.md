# Skill optimization and consolidation route

Optimize the skill's **discovery → loading → decision → execution → stop** path. An aggressive line-count reduction that breaks routing or discards operational invariants is a regression.

## Discovery: pay for only what the agent needs to choose

A Skill frontmatter `name` identifies one capability; its `description` should convey (1) specialized output, (2) precise trigger, (3) nearest exclusion only when useful. Keep it short. Avoid broad topic claims, marketing adjectives, examples, version history, tool commands and long enumerations in description. Never optimize names by making historical backup folders active or creating duplicate names.

For catalogs, inspect overlap pairs, differing trigger conditions and real consumers. Collapse overlapping skills only when they genuinely share the same user intent, inputs and success condition; otherwise sharpen their descriptions. Changes to installed configuration or archive discovery are separate authorized operations.

## Root `SKILL.md`: a small router, not a textbook

Keep only invariant goals, scope/permission boundaries, mode selection, conditional reference links, source-of-truth, and done condition. Make supporting references task-specific. Promote stable deterministic transforms to executable scripts only where the model frequently fails or mechanical verification is valuable. Do not split a 30-line working Skill just to manufacture a directory tree.

One root entry is canonical. Secondary references should not repeat the same top-level policy. Move host-specific behavior into a conditional file, or keep it only if all intended models need it. An OpenAI/Codex optimization does not imply identical behavior for Claude or other hosts: test shared bundles on their actual consumers.

## Execution contract

- For audit requests, leave the original untouched. For explicit optimize/upgrade/build requests, produce revised files and run applicable checks.
- Preserve user-owned methods, licensed material boundaries, source-of-truth rules, interface contracts, invocations, requirements and tests; ask only where removing a rule would change these in a way that cannot be safely inferred.
- Do not generate a new platform, orchestration layer, prompt compiler, multi-agent bureaucracy, or unconditional release ritual.
- Distinguish prose review from functional changes to scripts. Code changes need targeted execution tests; text-only edits need syntax/link/discovery checks plus representative behavior tests when the rule matters.
- Make routing failures visible: if an instruction blocks authorized progress, identify the precise file/rule and whether it is binding or merely a local convention.

## Three upgrade passes

**Pass A — route:** Check exact trigger, wrong-skill activation, duplicate canonical names, long descriptions, unconditional loading.

**Pass B — act:** Check source truth, permissions, safe autonomous continuation, decision thresholds, output schema and stop condition. For short tasks, do not demand approval after a first draft.

**Pass C — prove:** Parse frontmatter, verify links, check internal files, exercise one normal and one failure route, plus other cases *only* when a concrete contract needs coverage. For publishable packages, unpack into a fresh directory and check the actual zip contents and public entrypoint.

Use [assets/skill-mini-template.md](../assets/skill-mini-template.md) only when creating or rebuilding a Skill. For terminal checks see [references/evaluation.md](evaluation.md).
