# Verified public basis (checked October 15, 2026)

This is an original, implementation-focused adaptation, not an official OpenAI Skill or a reproduction of its articles.

- OpenAI Developers, Eric Provencher, *Rethinking skills and prompts for GPT-6 Astra* (2026-09-11): https://developers.openai.com/blog/rethinking-skills-and-prompts-for-gpt-6-astra — narrow skill discovery, progressive disclosure, contextual AGENTS.md reads, bounded autonomous testing, completion guidance.
- OpenAI, *A model guide for the GPT-6 family* (2026-10-02): https://openai.com/index/practical-guide-building-gpt-6/ — model/effort tradeoffs, cacheable stable prefixes, workload-specific instruction and validation, authorization thresholds, long-work steering.
- OpenAI Developers, *Using GPT-6*: https://developers.openai.com/api/docs/guides/latest-model?model=gpt-6-astra — reduce duplicated instructions; align authority; tune premature questions, over-testing, verbosity. Internal sample reports roughly 10–15% relative eval score gain and 41–66% fewer tokens for certain leaner coding-agent configurations, **not a general promise**.
- OpenAI Developers, *Build skills*: https://developers.openai.com/plugins/build/skills — required `SKILL.md` frontmatter, focused triggers, optional references/scripts, and explicit workflow boundaries.
- OpenAI Developers, *Prompting*: https://developers.openai.com/api/docs/guides/prompting — prompt versioning, test coverage and stable context reuse.

**Operational interpretation:** shorten discovery and universal context first; preserve contracts; route detail conditionally; prove quality with task-level evaluations. Do not claim GPT-6 will automatically improve any particular user project by official percentages. Platform-specific features such as caching, reasoning level, subagents or tools are optional and host-dependent, not capabilities this Skill installs.
