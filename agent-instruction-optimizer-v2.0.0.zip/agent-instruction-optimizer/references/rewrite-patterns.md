# Targeted rewrite patterns

These are illustrative; preserve tested invariants and user-specific needs.

## Skill discovery
Before: `Use for databases, storage, schemas, queries, analytics, anything about data.`
After: `Create or review relational database migrations when schema definitions or rollout steps change.`
Why: precise activation, fewer false triggers.

## Blanket context load
Before: `Before any edit read every architecture, database, test and deployment file.`
After: `Read architecture notes for boundary changes, schema docs for data migrations, and deployment notes for releases.`
Why: contextual relevance without discarding critical documents.

## Overblocking approvals
Before: `Always ask permission before editing anything or running any test.`
After: `Make reversible requested local edits and run tests against disposable fixtures; ask before external writes, production access, destructive actions or unapproved scope changes.`
Why: grants bounded autonomy while keeping real red lines.

## Endless or premature completion
Before: `Do a first pass, request approval, then continually improve until perfect.`
After: `Deliver the requested implementation, verify affected behavior and repair failures caused by the change. Stop when the stated acceptance passes; ask only for a blocked material decision.`
Why: completion without infinite self-justification.

## Over-testing
Before: `Run the full unit, integration, end-to-end, deployment and package suites after every typo.`
After: `Validate the directly affected behavior; run integration/release gates if a reachable consumer or formal release claim requires them.`
Why: tests proportional to risk. Keep all mandatory contractual release gates.

## Prompt bloat
Before: `You are the best engineer. Think deeply. Use 12 agents. Plan. Analyze. Plan again. Be comprehensive. Never stop ...`
After: `Implement [deliverable] from [source], preserve [constraints], validate [affected acceptance], and stop when [observable condition].`
Why: clear success contract, no forced theatre.
