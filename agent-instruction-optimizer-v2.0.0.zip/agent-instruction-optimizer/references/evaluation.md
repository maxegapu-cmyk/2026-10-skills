# Evaluation: evidence before efficiency claims

Three evidence tiers:

1. **Structural** — instructions parse, refs resolve, discovery isn't duplicated, no detected secrets. Proves package hygiene, not model performance.
2. **Contract regression** — protected phrases/anchors still present and representative scenarios yield authorized completion/approval/stop decisions. Literal anchors are a *review signal*, not semantic equivalence proof.
3. **Behavioral** — run baseline and candidate on the **same representative tasks**, same model snapshot/effort/tools/context limits where possible, grade independently by the task outcome; record completion, critical breaches, latency, tokens and real cost if available. This is the only evidence for claims like “faster” or “better”.

## Minimal test panel

From [assets/eval-cases.jsonl](../assets/eval-cases.jsonl), pick 4–8 cases that match the target workflow, and add at least one real previous failure. For system prompts include: small edit, non-blocking ambiguity, safe continuation, destructive approval, secret exposure, scope creep, missing data, termination. For Skills add: correct trigger, adjacent false trigger, selective references, invalid input, success and failure recovery. Do not automatically run 100 synthetic cases for a trivial one-line rewrite.

Grade outputs **by observable actions and artifacts**, not by flattering self-assessment, fluency or similarity of words. Keep P0/critical case failures as a separate gate. If the baseline wins a material case, don't adopt the rewrite simply because it is shorter.

## Included offline tools

From the unpacked skill folder:

```bash
python scripts/instruction_lab.py scan PATH --format json
python scripts/instruction_lab.py validate PATH --format json
python scripts/instruction_lab.py compare BEFORE_PATH AFTER_PATH --contracts assets/contract-example.json
python scripts/instruction_lab.py score results-after.jsonl --baseline results-before.jsonl
```

- `scan` inventories `SKILL.md`, `AGENTS.md`, duplicates, link/security indicators, and cost proxies.
- `validate` fails on broken Skill structure, dangling relative links, duplicate names and detected raw secret patterns. It performs no writes.
- `compare` reports structural cost deltas and checks literal protected anchors supplied by the caller. Review paraphrases manually.
- `score` reads **external** pass/fail measurements; it does not run a model or grade semantics. JSONL per case: `{"case_id":"small-edit","passed":true,"critical_breach":false,"input_tokens":350,"output_tokens":75,"latency_ms":2500}`. Missing metrics stay missing, not zero.

No external dependency or model API key is required. `scan` findings are heuristics, and `score` results are only as trustworthy as their graders. For a live model improvement claim, someone must actually execute A/B runs.

## Acceptance

At minimum: no critical-boundary regression, artifact/links valid, completion and failure paths retained. Prefer lower measured token/latency/cost **at equal or better task success**, but do not force a numeric compression threshold. A significant quality gain can justify more tokens. A specific verified consumer can justify extra engineering.
