#!/usr/bin/env python3
"""Inventory agent instruction assets without third-party dependencies.

The script reports deterministic indicators. It does not decide whether an
instruction is necessary, safe, or effective.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any


LIFECYCLE_SEGMENTS = {
    "archive",
    "archives",
    "backup",
    "backups",
    "candidate",
    "heritage",
    "install-test",
    "rejected",
    "snapshot",
    "staging",
    "testroot",
    "work",
}

PRIVATE_PATTERNS = {
    "windows_user_path": re.compile(r"[A-Za-z]:[\\/]Users[\\/][^\\/\s]+", re.I),
    "mac_user_path": re.compile("/" + "Users/" + r"[^/\s]+"),
    "linux_home_path": re.compile("/" + "home/" + r"[^/\s]+"),
    "api_key_assignment": re.compile(
        r"\b(?:api[_-]?key|access[_-]?token|secret)\b\s*[:=]\s*[^\s#]+", re.I
    ),
    "openai_style_secret": re.compile(r"\bsk-[A-Za-z0-9_-]{16,}\b"),
    "private_key_block": re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----"),
}

NEGATIVE_DIRECTIVES = re.compile(
    r"\b(?:do not|don't|never|must not|forbidden|禁止|不得|不要|绝不)\b", re.I
)
ABSOLUTE_PATH = re.compile(r"(?:[A-Za-z]:[\\/]|/(?:Users|home|opt|srv|var)/)")


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8-sig", errors="replace")


def parse_frontmatter(text: str) -> dict[str, str]:
    if not text.startswith("---"):
        return {}
    match = re.match(r"^---\s*\n(.*?)\n---(?:\s*\n|$)", text, re.S)
    if not match:
        return {}
    values: dict[str, str] = {}
    for line in match.group(1).splitlines():
        field = re.match(r"^([A-Za-z0-9_-]+):\s*(.*)$", line)
        if not field:
            continue
        key, value = field.groups()
        values[key] = value.strip().strip('"').strip("'")
    return values


def lifecycle_markers(path: Path) -> list[str]:
    markers: set[str] = set()
    for part in path.parts:
        lower = part.lower()
        tokens = set(re.split(r"[^a-z0-9]+", lower))
        for marker in LIFECYCLE_SEGMENTS:
            if marker in tokens or lower == marker or lower.startswith(f"{marker}-"):
                markers.add(marker)
    return sorted(markers)


def privacy_findings(path: Path, text: str) -> list[dict[str, Any]]:
    # Compatibility scanner skips source code to avoid matches on its own regex literals.
    # Use instruction_lab.py for code-inclusive privacy heuristics.
    if path.suffix.lower() == '.py':
        return []
    findings: list[dict[str, Any]] = []
    for line_number, line in enumerate(text.splitlines(), start=1):
        if path.name == 'instruction_lab.py' and line.strip().startswith('SECRET = re.compile('):
            continue
        for kind, pattern in PRIVATE_PATTERNS.items():
            if pattern.search(line):
                findings.append(
                    {
                        "file": str(path),
                        "line": line_number,
                        "kind": kind,
                        "preview": "[REDACTED: privacy indicator]",
                    }
                )
    return findings


def skill_record(path: Path, root: Path) -> dict[str, Any]:
    text = read_text(path)
    frontmatter = parse_frontmatter(text)
    name = frontmatter.get("name", "")
    description = frontmatter.get("description", "")
    warnings: list[str] = []
    if not name:
        warnings.append("missing frontmatter name")
    if not description:
        warnings.append("missing frontmatter description")
    if "TODO" in text:
        warnings.append("unfinished TODO marker")
    if len(description) > 240:
        warnings.append("description exceeds 240 characters")
    if len(description.split()) > 45:
        warnings.append("description exceeds 45 words")
    markers = lifecycle_markers(path.relative_to(root))
    if markers:
        warnings.append(f"path contains lifecycle marker(s): {', '.join(markers)}")
    return {
        "path": str(path.relative_to(root)),
        "name": name,
        "description": description,
        "descriptionCharacters": len(description),
        "descriptionWords": len(description.split()),
        "lifecycleMarkers": markers,
        "warnings": warnings,
    }


def agents_record(path: Path, root: Path) -> dict[str, Any]:
    text = read_text(path)
    lines = text.splitlines()
    normalized = [re.sub(r"\s+", " ", line.strip().lower()) for line in lines]
    repeated = [
        {"text": value[:160], "count": count}
        for value, count in Counter(value for value in normalized if len(value) >= 40).items()
        if count > 1
    ]
    return {
        "path": str(path.relative_to(root)),
        "lines": len(lines),
        "words": len(re.findall(r"\S+", text)),
        "characters": len(text),
        "negativeDirectiveCount": len(NEGATIVE_DIRECTIVES.findall(text)),
        "absolutePathCount": len(ABSOLUTE_PATH.findall(text)),
        "repeatedLongLines": sorted(repeated, key=lambda item: (-item["count"], item["text"])),
    }


def collect(root: Path) -> dict[str, Any]:
    skills = [skill_record(path, root) for path in sorted(root.rglob("SKILL.md"))]
    agents = [agents_record(path, root) for path in sorted(root.rglob("AGENTS.md"))]

    names: dict[str, list[str]] = defaultdict(list)
    descriptions: dict[str, list[str]] = defaultdict(list)
    for skill in skills:
        if skill["name"]:
            names[skill["name"]].append(skill["path"])
        if skill["description"]:
            descriptions[skill["description"]].append(skill["path"])

    duplicates = [
        {"name": name, "paths": paths}
        for name, paths in sorted(names.items())
        if len(paths) > 1
    ]
    duplicate_descriptions = [
        {"description": description, "paths": paths}
        for description, paths in descriptions.items()
        if len(paths) > 1
    ]

    text_files: list[Path] = []
    allowed_suffixes = {".md", ".yaml", ".yml", ".json", ".toml", ".txt", ".py"}
    for path in root.rglob("*"):
        if path.is_file() and path.suffix.lower() in allowed_suffixes:
            text_files.append(path)

    privacy: list[dict[str, Any]] = []
    unreadable: list[dict[str, str]] = []
    for path in sorted(text_files):
        try:
            privacy.extend(privacy_findings(path.relative_to(root), read_text(path)))
        except OSError as exc:
            unreadable.append({"file": str(path.relative_to(root)), "error": str(exc)})

    warning_count = sum(len(skill["warnings"]) for skill in skills)
    return {
        "schemaVersion": 1,
        "root": str(root),
        "summary": {
            "skillEntrypoints": len(skills),
            "agentsFiles": len(agents),
            "duplicateSkillNames": len(duplicates),
            "duplicateDescriptions": len(duplicate_descriptions),
            "skillWarnings": warning_count,
            "privacyIndicators": len(privacy),
            "unreadableFiles": len(unreadable),
        },
        "duplicateSkillNames": duplicates,
        "duplicateDescriptions": duplicate_descriptions,
        "skills": skills,
        "agentsFiles": agents,
        "privacyIndicators": privacy,
        "unreadableFiles": unreadable,
        "limitations": [
            "Indicators require human review and may contain false positives.",
            "No static scan proves instruction quality, privacy, or future model behavior.",
            "Lifecycle markers do not prove that a path is actively discoverable by a host.",
        ],
    }


def markdown_report(report: dict[str, Any]) -> str:
    summary = report["summary"]
    lines = [
        "# Agent instruction inventory",
        "",
        f"Root: `{report['root']}`",
        "",
        "## Summary",
        "",
    ]
    for key, value in summary.items():
        lines.append(f"- {key}: {value}")

    lines.extend(["", "## Duplicate Skill names", ""])
    if report["duplicateSkillNames"]:
        for item in report["duplicateSkillNames"]:
            lines.append(f"- `{item['name']}`")
            for path in item["paths"]:
                lines.append(f"  - `{path}`")
    else:
        lines.append("- None detected.")

    lines.extend(["", "## Skill warnings", ""])
    warned = False
    for skill in report["skills"]:
        if not skill["warnings"]:
            continue
        warned = True
        lines.append(f"- `{skill['path']}`")
        for warning in skill["warnings"]:
            lines.append(f"  - {warning}")
    if not warned:
        lines.append("- None detected.")

    lines.extend(["", "## AGENTS.md metrics", ""])
    if report["agentsFiles"]:
        for item in report["agentsFiles"]:
            lines.append(
                f"- `{item['path']}`: {item['lines']} lines, {item['words']} words, "
                f"{item['negativeDirectiveCount']} negative directives, "
                f"{item['absolutePathCount']} absolute-path indicators"
            )
    else:
        lines.append("- No AGENTS.md files detected.")

    lines.extend(["", "## Privacy and portability indicators", ""])
    if report["privacyIndicators"]:
        for item in report["privacyIndicators"]:
            lines.append(
                f"- `{item['file']}:{item['line']}` — {item['kind']}: "
                f"`{item['preview']}`"
            )
    else:
        lines.append("- None detected by the included patterns.")

    lines.extend(["", "## Limitations", ""])
    for limitation in report["limitations"]:
        lines.append(f"- {limitation}")
    return "\n".join(lines) + "\n"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Inventory AGENTS.md and SKILL.md assets for optimization leads."
    )
    parser.add_argument("root", type=Path, help="Directory to scan")
    parser.add_argument(
        "--format",
        choices=("markdown", "json"),
        default="markdown",
        help="Output format (default: markdown)",
    )
    parser.add_argument("--output", type=Path, help="Optional output file")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    root = args.root.expanduser().resolve()
    if not root.is_dir():
        print(f"error: not a directory: {root}", file=sys.stderr)
        return 2

    report = collect(root)
    if args.format == "json":
        rendered = json.dumps(report, ensure_ascii=False, indent=2) + "\n"
    else:
        rendered = markdown_report(report)

    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(rendered, encoding="utf-8")
    else:
        sys.stdout.write(rendered)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
