#!/usr/bin/env python3
"""Read-only instruction linter, contract comparer and evaluation-result ledger."""
from __future__ import annotations
import argparse
from collections import defaultdict
import json
from pathlib import Path
import re
import statistics
import sys

SUFFIXES = {'.md', '.yaml', '.yml', '.txt', '.json', '.jsonl', '.toml', '.py'}
FM = re.compile(r'\A---\s*\n(.*?)\n---(?:\s*\n|\Z)', re.S)
LINK = re.compile(r'(?<!!)\[[^\]\n]+\]\(([^)]+)\)')
SECRET = re.compile(r'\bsk-[a-zA-Z0-9_-]{18,}\b|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----|\b(?:api[_-]?key|access[_-]?token)\s*[:=]\s*[\"\']?[A-Za-z0-9_-]{24,}', re.I)
PERSONAL = re.compile(r'[A-Za-z]:[\\/]Users[\\/][^\\/\s]+|/(?:home|Users)/[A-Za-z0-9._-]+/')
UNCONDITIONAL = re.compile(r'\b(?:before (?:any|every) (?:edit|change|task)|run all tests after every|never stop improving)\b|每次(?:修改|任务)前|永远不停优化', re.I)


def read(p):
    return p.read_text(encoding='utf-8-sig', errors='replace')


def files(root):
    if root.is_file(): return [root]
    return [p for p in sorted(root.rglob('*')) if p.is_file() and p.suffix.lower() in SUFFIXES and p.resolve().is_relative_to(root.resolve())]


def relative(p, root):
    return p.name if root.is_file() else p.relative_to(root).as_posix()


def parse_fm(s):
    m = FM.match(s)
    if not m: return {}
    values = {}
    for line in m.group(1).splitlines():
        v = re.match(r'^([\w-]+):\s*(.*)$', line)
        if v:
            if v[1] in values: values['_duplicate_field'] = v[1]
            values[v[1]] = v[2].strip().strip('\"\'')
    return values


def scan(root):
    findings, skills, names = [], [], defaultdict(list)
    counts = {'files': 0, 'lines': 0, 'characters': 0, 'utf8Bytes': 0, 'skillEntrypoints': 0, 'agentsFiles': 0}
    for p in files(root):
        s, path = read(p), relative(p, root)
        counts['files'] += 1
        counts['lines'] += len(s.splitlines())
        counts['characters'] += len(s)
        counts['utf8Bytes'] += len(s.encode('utf-8'))
        def issue(severity, code, detail, line=None):
            row = {'severity': severity, 'code': code, 'path': path, 'detail': detail}
            if line is not None: row['line'] = line
            findings.append(row)
        if p.suffix.lower() == '.jsonl':
            for n, row in enumerate(s.splitlines(), 1):
                if row.strip():
                    try: json.loads(row)
                    except json.JSONDecodeError: issue('error', 'invalid_jsonl', 'Cannot parse JSON at line '+str(n), n)
        if p.name == 'AGENTS.md': counts['agentsFiles'] += 1
        if p.name == 'SKILL.md':
            counts['skillEntrypoints'] += 1
            fm = parse_fm(s)
            n, desc = fm.get('name',''), fm.get('description','')
            skills.append({'path': path, 'name': n, 'descriptionCharacters': len(desc)})
            if not n or not desc: issue('error','missing_frontmatter','Missing name or description')
            if fm.get('_duplicate_field'): issue('error','duplicate_field','Duplicate YAML field')
            if n:
                names[n].append(path)
                if not re.fullmatch(r'[a-z0-9]+(?:-[a-z0-9]+)*', n): issue('error','invalid_skill_name','Name must use lower-case kebab-case')
                if p.parent.name != n: issue('error','name_folder_mismatch','Skill name differs from folder')
            if len(desc)>240: issue('advisory','long_description','Review discovery specificity and length')
            if re.search(r'\b(?:whenever|always use|anything about|all tasks)\b',desc,re.I): issue('advisory','broad_trigger','Broad discovery wording')
            if any(x in re.split(r'[^a-z0-9]+',path.lower()) for x in ('backup','candidate','staging','rejected')): issue('advisory','historical_copy','Potential competing Skill copy')
        if p.suffix.lower() == '.md':
            for m in LINK.finditer(s):
                raw=m[1].strip().split(' ',1)[0].strip('\"\'')
                if not raw or raw.startswith(('#','<')) or re.match(r'^[a-z][\w+.-]*:',raw,re.I): continue
                dest=(p.parent/raw.split('#',1)[0].split('?',1)[0]).resolve()
                if root.is_dir() and not dest.is_relative_to(root.resolve()): issue('error','escaped_link','Reference escapes root')
                elif not dest.exists(): issue('error','broken_link','Missing referenced file: '+raw[:96])
        # Scan code too; only skip the scanner's own pattern declaration.
        for line_no,line in enumerate(s.splitlines(),1):
            if p.name == 'instruction_lab.py' and line.strip().startswith('SECRET = re.compile('):
                continue
            if SECRET.search(line): issue('error','possible_secret','[REDACTED] Potential raw secret',line_no)
            if PERSONAL.search(line): issue('advisory','personal_path','[REDACTED] Potential local user path',line_no)
            if p.name in {'AGENTS.md','SKILL.md'} and UNCONDITIONAL.search(line): issue('advisory','unconditional_step','Investigate whether this ritual is necessary',line_no)
    for n,paths in names.items():
        if len(paths)>1: findings.append({'severity':'error','code':'duplicate_skill_name','path':', '.join(paths),'detail':'Duplicate skill name: '+n})
    findings.sort(key=lambda v:(v['severity']!='error',v['path'],v['code']))
    return {'version':'2.0.0','root':str(root),'counts':counts,'skills':skills,'findings':findings,'valid':not any(f['severity']=='error' for f in findings), 'limitations':['Static lint cannot prove behavior or secret absence.','Characters and bytes are not measured tokens.']}


def norm(s): return ' '.join(s.casefold().split())

def mapping(root): return {relative(p,root):read(p) for p in files(root)}

def compare(before, after, contracts=None):
    a,b=mapping(before),mapping(after)
    def totals(m): return {'files':len(m),'characters':sum(len(v) for v in m.values()),'utf8Bytes':sum(len(v.encode('utf-8')) for v in m.values()),'lines':sum(len(v.splitlines()) for v in m.values())}
    x,y=totals(a),totals(b)
    metrics={k:{'before':x[k],'after':y[k],'delta':y[k]-x[k]} for k in x}
    anchors=[]
    if contracts:
        obj=json.loads(read(contracts))
        if not isinstance(obj,dict) or not isinstance(obj.get('anchors'),list): raise ValueError('Contract must contain anchors list')
        for item in obj['anchors']:
            if not isinstance(item,dict) or not isinstance(item.get('id'),str): raise ValueError('Each anchor needs id')
            words=[item['text']] if isinstance(item.get('text'),str) else item.get('any_of')
            if not isinstance(words,list) or not words or not all(isinstance(w,str) and w for w in words): raise ValueError('Anchor needs text or any_of')
            path=item.get('path')
            if path is not None and (not isinstance(path,str) or path.startswith('/') or '..' in Path(path).parts): raise ValueError('Invalid contract path')
            old=norm(a.get(path,'')) if path else norm('\n'.join(a.values()))
            new=norm(b.get(path,'')) if path else norm('\n'.join(b.values()))
            present_old=any(norm(w) in old for w in words)
            present_new=any(norm(w) in new for w in words)
            status='preserved' if present_old and present_new else 'removed_or_reworded' if present_old else 'added' if present_new else 'missing_from_baseline'
            anchors.append({'id':item['id'],'status':status})
    return {'version':'2.0.0','metrics':metrics,'addedFiles':sorted(b.keys()-a.keys()),'removedFiles':sorted(a.keys()-b.keys()),'changedFiles':sorted(k for k in a.keys() & b.keys() if a[k]!=b[k]),'anchors':anchors,'reviewNeeded':any(v['status']=='removed_or_reworded' for v in anchors),'note':'Anchor checks are literal, not semantic proof.'}


def load_results(path):
    results={}
    for i,line in enumerate(read(path).splitlines(),1):
        if not line.strip(): continue
        item=json.loads(line)
        if not isinstance(item,dict) or not isinstance(item.get('case_id'),str) or type(item.get('passed')) is not bool: raise ValueError(f'Invalid case_id/passed in line {i}')
        if item['case_id'] in results: raise ValueError('Duplicate case_id: '+item['case_id'])
        if 'critical_breach' in item and type(item['critical_breach']) is not bool: raise ValueError('critical_breach must be boolean')
        for field in ('input_tokens','output_tokens','latency_ms'):
            if field in item and (isinstance(item[field],bool) or not isinstance(item[field],(int,float)) or item[field]<0): raise ValueError('Invalid nonnegative metric: '+field)
        results[item['case_id']]=item
    if not results: raise ValueError('Results are empty')
    return results


def aggregate(rows):
    vals=list(rows.values())
    out={'cases':len(vals),'passed':sum(v['passed'] for v in vals),'successRate':round(sum(v['passed'] for v in vals)/len(vals),4),'criticalBreaches':sum(v.get('critical_breach',False) for v in vals)}
    for k in ('input_tokens','output_tokens','latency_ms'):
        metrics=[v[k] for v in vals if k in v]
        out[k]={'n':len(metrics),'mean':round(statistics.mean(metrics),2) if metrics else None}
    return out


def score(candidate, baseline=None):
    cur=load_results(candidate)
    out={'version':'2.0.0','candidate':aggregate(cur),'note':'Summarizes supplied grades only; does not run models.'}
    if baseline:
        old=load_results(baseline)
        common=sorted(cur.keys() & old.keys())
        out['baseline']=aggregate(old)
        out['coverage']={'common':common,'candidateOnly':sorted(cur.keys()-old.keys()),'baselineOnly':sorted(old.keys()-cur.keys())}
        out['matchedCandidate']=aggregate({k:cur[k] for k in common}) if common else None
        out['matchedBaseline']=aggregate({k:old[k] for k in common}) if common else None
        out['regressions']=[k for k in common if old[k]['passed'] and not cur[k]['passed']]
    out['reviewNeeded']=bool(out['candidate']['criticalBreaches'] or out.get('regressions') or out.get('coverage',{}).get('baselineOnly') or out['candidate']['passed'] < out['candidate']['cases'])
    return out


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    subs=ap.add_subparsers(dest='action',required=True)
    for action in ('scan','validate'):
        p=subs.add_parser(action);p.add_argument('root',type=Path);p.add_argument('--format',choices=('markdown','json'),default='markdown')
    p=subs.add_parser('compare');p.add_argument('before',type=Path);p.add_argument('after',type=Path);p.add_argument('--contracts',type=Path);p.add_argument('--format',choices=('markdown','json'),default='markdown')
    p=subs.add_parser('score');p.add_argument('results',type=Path);p.add_argument('--baseline',type=Path);p.add_argument('--format',choices=('markdown','json'),default='markdown')
    args=ap.parse_args()
    try:
        if args.action in ('scan','validate'):
            if not args.root.exists(): raise ValueError('Input path does not exist')
            result=scan(args.root.resolve());code=2 if args.action=='validate' and not result['valid'] else 0
        elif args.action=='compare':
            if not args.before.exists() or not args.after.exists(): raise ValueError('Input path does not exist')
            result=compare(args.before.resolve(),args.after.resolve(),args.contracts);code=3 if result['reviewNeeded'] else 0
        else:
            result=score(args.results,args.baseline);code=3 if result['reviewNeeded'] else 0
        if args.format=='json': print(json.dumps(result,indent=2,ensure_ascii=False))
        else:
            print(f'# {args.action}\n')
            if 'findings' in result:
                print('Valid:',result['valid'])
                print('Counts:',result['counts'])
                for f in result['findings']: print(f"- [{f['severity']}] {f['path']} / {f['code']}: {f['detail']}")
            else: print('```json\n'+json.dumps(result,indent=2,ensure_ascii=False)+'\n```')
        return code
    except (ValueError,OSError,json.JSONDecodeError) as err:
        print('error: '+str(err),file=sys.stderr)
        return 2

if __name__=='__main__': raise SystemExit(main())
