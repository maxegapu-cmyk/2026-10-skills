"""Offline release smoke + adverse-input tests (stdlib only)."""
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

BASE = Path(__file__).resolve().parents[1]
LAB = BASE / 'scripts' / 'instruction_lab.py'
LEGACY = BASE / 'scripts' / 'audit_instruction_assets.py'
spec = importlib.util.spec_from_file_location('instruction_lab', LAB)
lab = importlib.util.module_from_spec(spec)
spec.loader.exec_module(lab)


def valid_skill(root, name='example-capability', body='Read [guide](references/guide.md).'):
    p = root/name
    (p/'references').mkdir(parents=True)
    (p/'SKILL.md').write_text(f'---\nname: {name}\ndescription: Fix exactly this artifact when requested.\n---\n\n{body}\n',encoding='utf-8')
    (p/'references'/'guide.md').write_text('Guide.\n',encoding='utf-8')
    return p


class LabTests(unittest.TestCase):
    def test_actual_artifact(self):
        doc=lab.scan(BASE)
        self.assertTrue(doc['valid'],doc['findings'])
        self.assertEqual(doc['counts']['skillEntrypoints'],1)
        self.assertEqual(doc['skills'][0]['name'],'agent-instruction-optimizer')

    def test_valid_structure(self):
        with tempfile.TemporaryDirectory() as d:
            self.assertTrue(lab.scan(valid_skill(Path(d)))['valid'])

    def test_broken_link_is_blocker(self):
        with tempfile.TemporaryDirectory() as d:
            path=valid_skill(Path(d))
            (path/'references'/'guide.md').unlink()
            report=lab.scan(Path(d))
            self.assertFalse(report['valid'])
            self.assertIn('broken_link',[x['code'] for x in report['findings']])

    def test_wrong_folder_is_blocker(self):
        with tempfile.TemporaryDirectory() as d:
            valid_skill(Path(d),'incorrect-folder')
            p=Path(d)/'incorrect-folder'/'SKILL.md'
            p.write_text(p.read_text().replace('incorrect-folder','some-other-name'),encoding='utf-8')
            self.assertIn('name_folder_mismatch',[x['code'] for x in lab.scan(Path(d))['findings']])

    def test_duplicate_names(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            valid_skill(root,'example-capability')
            p=root/'backup'/'example-capability'
            p.mkdir(parents=True)
            (p/'SKILL.md').write_text('---\nname: example-capability\ndescription: Another.\n---\n',encoding='utf-8')
            report=lab.scan(root)
            self.assertIn('duplicate_skill_name',[x['code'] for x in report['findings']])

    def test_secret_not_reproduced(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);key='sk-'+('Abc123def_'*3)
            (root/'AGENTS.md').write_text('Store '+key+' here.\n',encoding='utf-8')
            report=json.dumps(lab.scan(root))
            self.assertIn('possible_secret',report)
            self.assertNotIn(key,report)

    def test_secret_in_code_is_scanned_without_echo(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);token='sk-'+('Xy9123_'*4)
            (root/'worker.py').write_text('token = "'+token+'"',encoding='utf-8')
            report=json.dumps(lab.scan(root))
            self.assertIn('possible_secret',report)
            self.assertNotIn(token,report)

    def test_local_personal_path(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            (root/'AGENTS.md').write_text('Use /home/' + 'person/private/test.md',encoding='utf-8')
            report=lab.scan(root)
            self.assertTrue(any(x['code']=='personal_path' for x in report['findings']))
            self.assertTrue(report['valid'])

    def test_escaped_link_is_blocker(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)/'repo';root.mkdir()
            (root/'SKILL.md').write_text('---\nname: repo\ndescription: Valid.\n---\n[bad](../../secret.txt)',encoding='utf-8')
            self.assertIn('escaped_link',[x['code'] for x in lab.scan(root)['findings']])

    def test_contract_preserved(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);(root/'a').mkdir();(root/'b').mkdir()
            (root/'a'/'AGENTS.md').write_text('preserve user data\nverbose verbose',encoding='utf-8')
            (root/'b'/'AGENTS.md').write_text('preserve user data',encoding='utf-8')
            c=root/'contract.json';c.write_text(json.dumps({'anchors':[{'id':'keep-data','text':'preserve user data','path':'AGENTS.md'}]}))
            result=lab.compare(root/'a',root/'b',c)
            self.assertEqual(result['anchors'][0]['status'],'preserved')
            self.assertFalse(result['reviewNeeded'])
            self.assertLess(result['metrics']['characters']['delta'],0)

    def test_contract_removed_stops(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);(root/'a').mkdir();(root/'b').mkdir()
            (root/'a'/'AGENTS.md').write_text('ask before production deployment',encoding='utf-8')
            (root/'b'/'AGENTS.md').write_text('Do anything.',encoding='utf-8')
            c=root/'contract.json';c.write_text(json.dumps({'anchors':[{'id':'prod','text':'ask before production deployment','path':'AGENTS.md'}]}))
            self.assertTrue(lab.compare(root/'a',root/'b',c)['reviewNeeded'])
            cmd=subprocess.run([sys.executable,str(LAB),'compare',str(root/'a'),str(root/'b'),'--contracts',str(c),'--format','json'],capture_output=True,text=True)
            self.assertEqual(cmd.returncode,3)

    def test_invalid_contract_path(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);(root/'a').write_text('a')
            c=root/'contract.json';c.write_text(json.dumps({'anchors':[{'id':'bad','text':'a','path':'../outside'}]}))
            with self.assertRaises(ValueError): lab.compare(root/'a',root/'a',c)

    def test_score_detects_regression(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            a=root/'before.jsonl';b=root/'after.jsonl'
            a.write_text('{"case_id":"a","passed":true,"input_tokens":300}\n{"case_id":"b","passed":true}\n',encoding='utf-8')
            b.write_text('{"case_id":"a","passed":false,"input_tokens":100}\n{"case_id":"b","passed":true,"critical_breach":true}\n',encoding='utf-8')
            report=lab.score(b,a)
            self.assertTrue(report['reviewNeeded'])
            self.assertEqual(report['regressions'],['a'])
            self.assertEqual(report['candidate']['criticalBreaches'],1)

    def test_score_no_metrics_are_null(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'rows.jsonl';p.write_text('{"case_id":"a","passed":true}',encoding='utf-8')
            self.assertIsNone(lab.score(p)['candidate']['input_tokens']['mean'])

    def test_missing_baseline_cases_requires_review(self):
        with tempfile.TemporaryDirectory() as d:
            a=Path(d)/'old.jsonl';b=Path(d)/'new.jsonl'
            a.write_text('{"case_id":"a","passed":true}\n{"case_id":"b","passed":true}',encoding='utf-8')
            b.write_text('{"case_id":"a","passed":true}',encoding='utf-8')
            report=lab.score(b,a)
            self.assertTrue(report['reviewNeeded'])
            self.assertEqual(report['coverage']['baselineOnly'],['b'])

    def test_invalid_jsonl_is_blocker(self):
        with tempfile.TemporaryDirectory() as d:
            (Path(d)/'cases.jsonl').write_text('{broken json}',encoding='utf-8')
            self.assertIn('invalid_jsonl',[x['code'] for x in lab.scan(Path(d))['findings']])

    def test_invalid_duplicate_score(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'rows.jsonl';p.write_text('{"case_id":"x","passed":true}\n{"case_id":"x","passed":false}',encoding='utf-8')
            with self.assertRaises(ValueError): lab.score(p)

    def test_cli_validate_bad_structure(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'SKILL.md';p.write_text('missing frontmatter',encoding='utf-8')
            cmd=subprocess.run([sys.executable,str(LAB),'validate',d,'--format','json'],capture_output=True,text=True)
            self.assertEqual(cmd.returncode,2)
            self.assertFalse(json.loads(cmd.stdout)['valid'])

    def test_legacy_cli_compatibility(self):
        cmd=subprocess.run([sys.executable,str(LEGACY),str(BASE),'--format','json'],capture_output=True,text=True)
        self.assertEqual(cmd.returncode,0,cmd.stderr)
        self.assertIn('skillEntrypoints',json.loads(cmd.stdout)['summary'])

if __name__=='__main__': unittest.main()
