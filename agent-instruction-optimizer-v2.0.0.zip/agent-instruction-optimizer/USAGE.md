# How to use / 使用方法

## Install / 安装

Unzip the package; keep the `agent-instruction-optimizer/` directory intact and place it in the Skills folder supported by your host (ChatGPT Skills, Codex Skills or a compatible agent loader). A correct installation exposes `agent-instruction-optimizer` with one `SKILL.md` at the directory root. Host installation paths differ; this bundle does not modify them automatically.

## Call it / 调用

- `用 $agent-instruction-optimizer 优化下面这段系统指令：... 需要完整成品，别删安全与权限边界。`
- `用 $agent-instruction-optimizer 升级这个 Skill，改好文件，减少不必要的读取和测试，保留原有功能并检查。`
- `用 $agent-instruction-optimizer 审查当前 AGENTS.md，只出报告，不修改。`
- `对比改造前后同一批真实案例的成功率与消耗，判断是否值得替换旧版。`

The Skill is an *instruction workflow*, not an autonomous API service. It only edits files when the host agent has access and user authorization. It does not silently overwrite ChatGPT system prompts or installed Skills.

## Offline commands / 离线命令

Run from the unpacked directory:

```bash
python scripts/instruction_lab.py scan . --format json
python scripts/instruction_lab.py validate . --format json
python scripts/instruction_lab.py compare path/to/before path/to/after --contracts your-contracts.json
python scripts/instruction_lab.py score results-after.jsonl --baseline results-before.jsonl
python -m unittest discover -s tests -v
```

`scan` only reports heuristics. `compare` anchors are literal markers, so rewording them can raise a false alarm. `score` summarizes user-provided evaluation outcomes, never fabricates a live model run.

## Upgrade from 1.x / 升级

The published Skill name and `scripts/audit_instruction_assets.py ROOT --format json|markdown` interface remain available. For richer checks use `instruction_lab.py`. Don't keep v1 and v2 with identical Skill names in the same active discovery directory. Back up the active v1 directory before replacing it; avoid putting an active backup underneath auto-discovered Skills.
