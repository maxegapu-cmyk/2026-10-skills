# Agent Instruction Optimizer 2.0.0

Built on the concepts and public-interface intent of 1.0.0.

- Replaced a universal manual-style audit route with Quick/System/Skill/Evidence decision branches; a concise primary entrypoint loads only relevant references.
- Added system instruction layer assignment and a ready-to-adapt compact system baseline.
- Added a dedicated skill optimization route for discovery, progressive disclosure, execution, and completion.
- Added protected-contract anchoring, offline directory validation, before/after measurements, benchmark scoring, and tests via `instruction_lab.py`.
- Added representative regression scenarios and explicit separation between structural checks and live behavioral evidence.
- Refreshed 2026-10-15 official source mapping and qualified any numerical gain claims.
- Retained legacy `audit_instruction_assets.py` CLI for users of 1.0.0; redacted detected secret previews in reports.
- No automatic edits to a user's globally installed instructions. Install and model evaluations are deliberately separate.
