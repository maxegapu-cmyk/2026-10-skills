---
name: example-capability
# Replace name/description with the actual specialized result and precise user trigger.
description: Produce [specific result] when [specific request or artifact] is supplied.
---

# Example capability

Create [concrete output] from [inputs]. Preserve [critical invariant].

## Route

- If [condition A], consult [relevant reference] only when present.
- If [condition B], run [tool/script] only when it exists and is needed.

## Completion

Deliver [artifact] and confirm [observable test]. Ask only before [material authorization boundary].
