# storyboard.json 数据契约 v1.0

完整样本：`examples/demo-project/storyboard.json`。`schema_version` 必须为 `1.0`。

## 根字段

`project`: `title`、`logline`、`genre`、`format`、`target_duration_sec`（正数）、`aspect_ratio`，可选 `audience`、`tone`、`status`。

`story`: `protagonist`（谁）、`want`（欲望）、`obstacle`（阻力）、`stakes`（失败损失）、`turning_point`（关键抉择）、`ending`（事实结局）、`ending_change`（前后变化），可选 `boundaries` 数组。

`world`: `look`、`lighting`、`screen_axis`（统一地理坐标 / 镜头轴线）、`character_anchors` 和 `prop_anchors`（字典：ID→不可随镜漂移的细节）。

`scenes[]`：`id`、`location`、`time`、`purpose`、`entry_state`、`exit_state`。

`beats[]`：`id`、`kind`、`scene_id`、`turn`（可见事件）、`change`（明确局势变化）、`evidence_shots`（至少一个实际属于这个 beat 的镜头 ID）。

`shots[]`（数组**顺序就是播放顺序**）：

| 字段 | 用途 |
|---|---|
| id / scene_id / beat_id | 唯一镜头 ID + 合法的场景/情节节拍引用 |
| duration_sec | 数字，大于零；总时长接近 target，脚本容忍 max(1 秒, 3%) |
| shot_size | 远景/全景/中景/近景/特写等，有视觉理由 |
| angle | 平视 / 俯视 / 仰视 / 斜角等 |
| camera_move | 固定 / 缓推 / 跟拍 / 横移 / 摇镜等；没有必要时写固定 |
| framing | 主体在画面的位置、前中后景、视线落点 |
| visual_action | 主体的可见具体动作；不要只有气氛 |
| story_information | 观众新知道/意识到/期待的事情 |
| sound | 台词以外音效/音乐/空白的落点 |
| dialogue | 可选，直接写可录台词；空字串表示无台词 |
| start_state / end_state | 本镜真实起止状态；为衔接服务 |
| screen_direction | `L2R` 左到右、`R2L` 右到左、`STILL` 静止、`AXIS_CHANGE` 有明确越轴/重定向 |
| continuity | 对象：`characters` 数组、`props` 数组；`wardrobe_state`、`location_state`、`lighting_state` 文本 |
| transition_out | cut / match cut / hard cut / fade / 具体视觉或音频桥 |
| image_prompt | 独立可用的单帧图像提示（身份、空间、相机、风格、状态） |
| video_prompt | 运动镜头提示（时长、起点、行动步骤、终点、声音、镜头路径） |
| negative_prompt | 针对这镜最可能的身份/几何/画面失败，而不是万能口号 |
| production_notes | 预算/素材/执行关键点 |
| fallback | 本镜 AI 视频失败后的成本较低的可视化替换 |
| reference_image | 可选，null 或项目目录相对路径，如 `media/SH001.png` |
| status | `planned` / `approved` / `needs_revision` |

注意：程序能确认字段、ID、时间与某些轴线冲突，**不能自动评判**剧作好坏、画面审美、模型是否能稳定生成、AI 图的实际连续性。以上要 Agent/人工复核。

## 数据处理

- `python scripts/boardtool.py init --idea '...' -o PROJECT` 只生成未完成脚手架，不能直接 `export`。
- `python scripts/boardtool.py validate PROJECT/storyboard.json --strict` 发现结构性错误返回码 1；读取/文件错误返回码 2；通过为 0。
- `python scripts/boardtool.py export PROJECT/storyboard.json` 仅对合格 JSON 产生衍生文件。
- CSV 为 Excel 友好 UTF-8 BOM；HTML 无外部依赖可双击打开；`preview.html` 默认在 `output/`，图片路径按项目根目录相对填写。
- 每次更新 JSON 重新 export，避免派生文件过时。
