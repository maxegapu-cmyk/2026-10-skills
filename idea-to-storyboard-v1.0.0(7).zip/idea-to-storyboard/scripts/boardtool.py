#!/usr/bin/env python3
"""Idea-to-Storyboard local quality gate and exporter. Python 3.9+, stdlib only."""
from __future__ import annotations

import argparse
import csv
import html
import json
import math
import re
import sys
from collections import defaultdict
from pathlib import Path

SCHEMA_VERSION = "1.0"
SHOT_KEYS = (
    "id", "scene_id", "beat_id", "duration_sec", "shot_size", "angle",
    "camera_move", "framing", "visual_action", "story_information",
    "sound", "start_state", "end_state", "screen_direction", "continuity",
    "transition_out", "image_prompt", "video_prompt", "negative_prompt",
    "production_notes", "fallback", "status"
)
REQUIRED_PROJECT = ("title", "logline", "genre", "format", "target_duration_sec", "aspect_ratio")
REQUIRED_STORY = ("protagonist", "want", "obstacle", "stakes", "turning_point", "ending", "ending_change")
REQUIRED_SCENE = ("id", "location", "time", "purpose", "entry_state", "exit_state")
REQUIRED_BEAT = ("id", "kind", "scene_id", "turn", "change", "evidence_shots")
VALID_DIRECTIONS = {"L2R", "R2L", "STILL", "AXIS_CHANGE"}
VALID_STATUSES = {"planned", "approved", "needs_revision"}


def load_json(path: Path):
    with path.open(encoding="utf-8") as fh:
        return json.load(fh)


def save_json(path: Path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def nonempty(value):
    return isinstance(value, str) and bool(value.strip())


def validate(doc: dict) -> tuple[list[str], list[str]]:
    errors, warnings = [], []
    if not isinstance(doc, dict):
        return ["Root must be JSON object"], warnings
    if doc.get("schema_version") != SCHEMA_VERSION:
        errors.append(f"schema_version must be '{SCHEMA_VERSION}'")
    project, story, world = doc.get("project"), doc.get("story"), doc.get("world")
    if not isinstance(project, dict):
        project = {}; errors.append("project must be object")
    if not isinstance(story, dict):
        story = {}; errors.append("story must be object")
    if not isinstance(world, dict):
        world = {}; errors.append("world must be object")
    for k in REQUIRED_PROJECT:
        if k == "target_duration_sec":
            target = project.get(k)
            if not isinstance(target, (int, float)) or isinstance(target, bool) or not math.isfinite(target) or target <= 0:
                errors.append("project.target_duration_sec must be positive finite number")
        elif not nonempty(project.get(k)):
            errors.append(f"project.{k} is required")
    for k in REQUIRED_STORY:
        if not nonempty(story.get(k)):
            errors.append(f"story.{k} is required")
    for k in ("look", "lighting", "screen_axis"):
        if not nonempty(world.get(k)):
            errors.append(f"world.{k} is required")
    for k in ("character_anchors", "prop_anchors"):
        if not isinstance(world.get(k), dict):
            errors.append(f"world.{k} must be object")
    scenes, beats, shots = (doc.get(k) for k in ("scenes", "beats", "shots"))
    if not isinstance(scenes, list) or not scenes:
        errors.append("scenes must be non-empty list"); scenes = []
    if not isinstance(beats, list) or not beats:
        errors.append("beats must be non-empty list"); beats = []
    if not isinstance(shots, list) or not shots:
        errors.append("shots must be non-empty list"); shots = []
    scene_ids, beat_ids, shot_ids = [], [], []
    for idx, scene in enumerate(scenes):
        if not isinstance(scene, dict):
            errors.append(f"scenes[{idx}] must be object"); continue
        for key in REQUIRED_SCENE:
            if not nonempty(scene.get(key)):
                errors.append(f"scenes[{idx}].{key} is required")
        if nonempty(scene.get("id")):
            if not re.fullmatch(r"[A-Za-z][A-Za-z0-9_-]{1,63}", scene["id"]):
                errors.append(f"scenes[{idx}].id must be a 2-64 char safe identifier")
            scene_ids.append(scene["id"])
    for idx, beat in enumerate(beats):
        if not isinstance(beat, dict):
            errors.append(f"beats[{idx}] must be object"); continue
        for key in REQUIRED_BEAT:
            if key == "evidence_shots":
                if not isinstance(beat.get(key), list) or not beat.get(key):
                    errors.append(f"beats[{idx}].evidence_shots must be non-empty list")
            elif not nonempty(beat.get(key)):
                errors.append(f"beats[{idx}].{key} is required")
        if nonempty(beat.get("id")):
            if not re.fullmatch(r"[A-Za-z][A-Za-z0-9_-]{1,63}", beat["id"]):
                errors.append(f"beats[{idx}].id must be a 2-64 char safe identifier")
            beat_ids.append(beat["id"])
        if beat.get("scene_id") not in scene_ids:
            errors.append(f"beats[{idx}] has unknown scene_id {beat.get('scene_id')!r}")
    scene_seen = []
    elapsed = 0.0
    for idx, shot in enumerate(shots):
        if not isinstance(shot, dict):
            errors.append(f"shots[{idx}] must be object"); continue
        for key in SHOT_KEYS:
            if key == "duration_sec":
                val = shot.get(key)
                if not isinstance(val, (int, float)) or isinstance(val, bool) or not math.isfinite(val) or val <= 0:
                    errors.append(f"shots[{idx}].duration_sec must be positive finite number")
                else:
                    elapsed += val
                    if val > 30:
                        warnings.append(f"shots[{idx}] >30s; consider splitting for generative video")
            elif key == "continuity":
                cont = shot.get(key)
                if not isinstance(cont, dict):
                    errors.append(f"shots[{idx}].continuity must be object")
                else:
                    for ck in ("characters", "props"):
                        if not isinstance(cont.get(ck), list) or not all(nonempty(x) for x in cont.get(ck, []) if isinstance(cont.get(ck), list)):
                            errors.append(f"shots[{idx}].continuity.{ck} must be list of string IDs")
                    for ck in ("wardrobe_state", "location_state", "lighting_state"):
                        if not nonempty(cont.get(ck)):
                            errors.append(f"shots[{idx}].continuity.{ck} is required")
                    for c in cont.get("characters", []) if isinstance(cont.get("characters"), list) else []:
                        if c not in world.get("character_anchors", {}):
                            errors.append(f"shots[{idx}] unknown character {c!r}")
                    for p in cont.get("props", []) if isinstance(cont.get("props"), list) else []:
                        if p not in world.get("prop_anchors", {}):
                            errors.append(f"shots[{idx}] unknown prop {p!r}")
            elif not nonempty(shot.get(key)):
                errors.append(f"shots[{idx}].{key} is required")
        sid = shot.get("id")
        if nonempty(sid):
            if not re.fullmatch(r"[A-Za-z][A-Za-z0-9_-]{1,63}", sid):
                errors.append(f"shots[{idx}].id must be a 2-64 char safe identifier")
            shot_ids.append(sid)
        scene_id = shot.get("scene_id")
        beat_id = shot.get("beat_id")
        if scene_id not in scene_ids:
            errors.append(f"shots[{idx}] unknown scene_id {scene_id!r}")
        elif not scene_seen or scene_seen[-1] != scene_id:
            scene_seen.append(scene_id)
        if beat_id not in beat_ids:
            errors.append(f"shots[{idx}] unknown beat_id {beat_id!r}")
        else:
            matching = next((b for b in beats if isinstance(b, dict) and b.get("id") == beat_id), None)
            if matching is not None and matching.get("scene_id") != scene_id:
                errors.append(f"shots[{idx}] beat {beat_id} belongs to scene {matching.get('scene_id')}, not {scene_id}")
        if shot.get("screen_direction") not in VALID_DIRECTIONS:
            errors.append(f"shots[{idx}] invalid screen_direction")
        if shot.get("status") not in VALID_STATUSES:
            errors.append(f"shots[{idx}] invalid status")
        media_path = shot.get("reference_image")
        if media_path is not None:
            if not isinstance(media_path, str) or not media_path.strip():
                errors.append(f"shots[{idx}].reference_image must be relative path or null")
            else:
                p = Path(media_path)
                if p.is_absolute() or '..' in p.parts or '\\' in media_path or ':' in media_path or media_path.startswith(('/', '~')):
                    errors.append(f"shots[{idx}].reference_image unsafe path")
        if idx and isinstance(shots[idx-1], dict):
            before = shots[idx-1]
            if (shot.get('scene_id') == before.get('scene_id')
                and {before.get('screen_direction'), shot.get('screen_direction')} == {'L2R', 'R2L'}
                and not any(x in (str(before.get('transition_out', '')) + str(shot.get('production_notes', ''))).lower()
                            for x in ('axis', '轴线', '反打', 'cross'))):
                warnings.append(f"{before.get('id')}->{sid}: opposite screen direction with no axis bridge note")
    for label, ids in (("scene", scene_ids), ("beat", beat_ids), ("shot", shot_ids)):
        if len(ids) != len(set(ids)):
            errors.append(f"duplicate {label} IDs")
    if len(scene_seen) != len(set(scene_seen)):
        warnings.append("scene blocks are interleaved; review timeline")
    if len(shots) and not any(s.get("story_information", "").strip() for s in shots if isinstance(s, dict)):
        errors.append("no story information delivered in shots")
    for idx, beat in enumerate(beats):
        if not isinstance(beat, dict):
            continue
        linked = [s for s in shots if isinstance(s, dict) and s.get("beat_id") == beat.get("id")]
        if not linked:
            errors.append(f"beat {beat.get('id')} has no shots")
        for shotid in beat.get("evidence_shots", []) if isinstance(beat.get("evidence_shots"), list) else []:
            if shotid not in shot_ids:
                errors.append(f"beat {beat.get('id')} evidence_shot {shotid!r} missing")
            elif shotid not in [s.get("id") for s in linked]:
                errors.append(f"beat {beat.get('id')} evidence_shot {shotid!r} belongs to another beat")
    for idx, scene in enumerate(scenes):
        if not isinstance(scene, dict):
            continue
        if not any(isinstance(s, dict) and s.get("scene_id") == scene.get("id") for s in shots):
            errors.append(f"scene {scene.get('id')} has no shots")
    target = project.get("target_duration_sec")
    if isinstance(target, (int, float)) and not isinstance(target, bool) and math.isfinite(target) and target > 0:
        tolerance = max(1.0, target * 0.03)
        if abs(elapsed - target) > tolerance:
            errors.append(f"shot durations total {elapsed:g}s != target {target:g}s (tolerance {tolerance:g}s)")
    return errors, warnings


def report(doc: dict) -> dict:
    errors, warnings = validate(doc)
    return {
        "schema_version": SCHEMA_VERSION,
        "pass": not errors,
        "errors": errors,
        "warnings": warnings,
        "stats": {
            "scenes": len(doc.get("scenes", [])) if isinstance(doc, dict) and isinstance(doc.get("scenes"), list) else 0,
            "beats": len(doc.get("beats", [])) if isinstance(doc, dict) and isinstance(doc.get("beats"), list) else 0,
            "shots": len(doc.get("shots", [])) if isinstance(doc, dict) and isinstance(doc.get("shots"), list) else 0,
            "total_duration_sec": round(sum(s.get("duration_sec", 0) for s in doc.get("shots", []) if isinstance(s, dict) and isinstance(s.get("duration_sec"), (int, float)) and math.isfinite(s["duration_sec"])), 2) if isinstance(doc, dict) and isinstance(doc.get("shots"), list) else 0
        }
    }


def write_csv(path: Path, rows: list[dict], fields: list[str]):
    with path.open("w", newline="", encoding="utf-8-sig") as fh:
        writer = csv.DictWriter(fh, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def to_md(doc: dict) -> str:
    project = doc["project"]
    total = 0.0
    lines = [f'# {project["title"]}｜可执行分镜表', "", f'**一句话故事**：{project["logline"]}',
             f'**规格**：{project["target_duration_sec"]}秒 · {project["aspect_ratio"]} · {project["format"]}', "",
             "| 镜头 | 时间线 | 时长 | 景别/运镜 | 看见什么 | 叙事变化 | 台词/声音 |", "|---|---:|---:|---|---|---|---|"]
    def compact(x):
        return str(x).replace('|', '｜').replace('\n', ' ')
    for shot in doc["shots"]:
        start = total; total += shot["duration_sec"]
        lines.append(f'| {compact(shot["id"])} | {start:g}–{total:g}s | {shot["duration_sec"]:g}s | '
                     f'{compact(shot["shot_size"])} / {compact(shot["camera_move"])} | '
                     f'{compact(shot["visual_action"])} | {compact(shot["story_information"])} | '
                     f'{compact(shot.get("dialogue", "—") or "—")} · {compact(shot["sound"])} |')
    lines += ["", "## 逐镜制作说明", ""]
    for shot in doc["shots"]:
        lines += [f'### {shot["id"]} · {shot["scene_id"]} · {shot["beat_id"]}',
                  f'- 起止状态：{shot["start_state"]} → {shot["end_state"]}',
                  f'- 构图/机位：{shot["framing"]} / {shot["angle"]}',
                  f'- 屏幕方向：{shot["screen_direction"]}；出镜转场：{shot["transition_out"]}',
                  f'- 连续性：{json.dumps(shot["continuity"], ensure_ascii=False)}',
                  f'- 执行：{shot["production_notes"]}', f'- 失败备选：{shot["fallback"]}', ""]
    return '\n'.join(lines) + '\n'


def to_html(doc: dict, output_dir: Path) -> str:
    esc = lambda x: html.escape(str(x), quote=True)
    project = doc["project"]
    stats = f'{len(doc["scenes"])} 场 · {len(doc["shots"])} 镜 · {project["target_duration_sec"]:g} 秒'
    scene_options = ''.join(f'<option value="{esc(sc["id"])}">{esc(sc["id"])} · {esc(sc["location"])}</option>' for sc in doc["scenes"])
    beat_rows = ''.join(f'<div class="beat"><b>{esc(b["id"])} · {esc(b["kind"])}</b><span>{esc(b["turn"])}<br><em>变化：{esc(b["change"])}</em></span></div>' for b in doc["beats"])
    cards = []
    elapsed = 0.0
    for s in doc["shots"]:
        start, elapsed = elapsed, elapsed+s["duration_sec"]
        ref = s.get("reference_image")
        if ref:
            # The HTML is inside project/output/ and relative media are relative to project root.
            img_path = '../' + ref
            visual = f'<img src="{esc(img_path)}" alt="{esc(s["id"])} 参考画面" loading="lazy" onerror="this.style.display=\'none\';this.nextElementSibling.style.display=\'grid\'">'
            visual += f'<div class="placeholder" style="display:none"><span>{esc(s["shot_size"])}</span><small>图片尚未放入：{esc(ref)}</small></div>'
        else:
            visual = f'<div class="placeholder"><span>{esc(s["shot_size"])}</span><small>{esc(s["framing"])}</small></div>'
        cards.append(f'''<article class="card" data-scene="{esc(s["scene_id"])}" data-state="{esc(s["status"])}" data-search="{esc(' '.join(str(s.get(k,'')) for k in ('id','visual_action','story_information','dialogue','scene_id'))).lower()}">
<div class="poster">{visual}<div class="time">{start:g}–{elapsed:g}s · {s["duration_sec"]:g}s</div></div>
<div class="body"><div class="eyebrow"><span>{esc(s["id"])} / {esc(s["beat_id"])}</span><span class="pill {esc(s["status"])}">{esc(s["status"])}</span></div>
<h3>{esc(s["visual_action"])}</h3><p class="purpose">{esc(s["story_information"])}</p>
<div class="tags"><span>{esc(s["shot_size"])}</span><span>{esc(s["angle"])}</span><span>{esc(s["camera_move"])}</span><span>{esc(s["screen_direction"])}</span></div>
<details><summary>展开：对白 / 首尾 / 提示词 / 备选</summary><div class="detail"><b>对白：</b> {esc(s.get('dialogue','') or '无')}<br><b>声音：</b> {esc(s['sound'])}<br><b>镜头首尾：</b> {esc(s['start_state'])} → {esc(s['end_state'])}<br><b>转场：</b> {esc(s['transition_out'])}<br><b>图像提示：</b><p>{esc(s['image_prompt'])}</p><b>视频提示：</b><p>{esc(s['video_prompt'])}</p><b>制作：</b> {esc(s['production_notes'])}<br><b>备选：</b> {esc(s['fallback'])}</div></details>
</div></article>''')
    return '''<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>''' + esc(project["title"]) + ''' | 分镜工作台</title><style>
:root{color-scheme:dark;font-family:"Microsoft YaHei",Inter,system-ui,sans-serif;background:#090c16;color:#eaf0ff}*{box-sizing:border-box}body{margin:0;background:radial-gradient(circle at 10% 0%,#132541 0%,#090c16 42%)}.wrap{max-width:1500px;margin:auto;padding:38px 30px 90px}.kicker{letter-spacing:.3em;font-size:11px;color:#8da5df;font-weight:700}h1{font-size:clamp(28px,3vw,48px);margin:12px 0 8px;letter-spacing:-.025em}header p{color:#a9b7d3;max-width:900px;line-height:1.8}.head{display:flex;align-items:flex-end;justify-content:space-between;gap:22px;flex-wrap:wrap}.stats{border:1px solid #2c4269;background:#142039;padding:15px 22px;border-radius:14px;color:#c3d8ff}.main{display:grid;grid-template-columns:280px minmax(0,1fr);gap:25px;margin-top:30px}.side{background:#101728;border:1px solid #25334e;padding:24px;border-radius:16px;align-self:start;position:sticky;top:20px}.side h2{font-size:14px;color:#9aa9c7;text-transform:uppercase;letter-spacing:.08em;margin:0 0 20px}.beat{border-left:2px solid #4668bc;padding:0 0 23px 15px;display:grid;gap:8px;font-size:12px;line-height:1.7}.beat b{color:#9ec3ff}.beat span{color:#c1c9dc}.beat em{font-style:normal;color:#8196b9}.tools{display:flex;gap:10px;flex-wrap:wrap;margin-bottom:18px}input,select,button{border-radius:10px;border:1px solid #31415e;background:#141e31;color:#f2f5ff;padding:12px;font-size:13px}input{flex:1;min-width:170px}button{cursor:pointer;background:#2347a2;border-color:#5070bd}button:hover{background:#315dc8}.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:18px}.card{min-width:0;border:1px solid #263651;background:#11192a;border-radius:15px;overflow:hidden;box-shadow:0 12px 25px #0003}.poster{aspect-ratio:16/9;position:relative;background:linear-gradient(145deg,#1b2a4a,#253a52 45%,#0d162e);overflow:hidden}.poster img{display:block;object-fit:cover;width:100%;height:100%}.placeholder{width:100%;height:100%;display:grid;place-content:center;text-align:center;padding:18px;gap:10px;color:#bbd4ff}.placeholder span{font-size:29px;letter-spacing:.02em;font-weight:800}.placeholder small{font-size:12px;color:#94a9d5}.time{position:absolute;bottom:10px;right:10px;padding:5px 9px;background:#0c163ad9;font-size:11px;border-radius:6px}.body{padding:18px}.eyebrow{display:flex;justify-content:space-between;gap:10px;font-size:11px;color:#86a9df;font-weight:700}.pill{padding:3px 8px;border-radius:6px;color:#fbd89f;background:#5c3a22}.pill.approved{color:#7cf5ce;background:#1d5044}.pill.needs_revision{color:#ffaaa8;background:#56252a}h3{font-size:15px;line-height:1.6;margin:13px 0 8px}.purpose{font-size:12px;color:#aab8cf;line-height:1.8;min-height:42px}.tags{display:flex;gap:6px;flex-wrap:wrap;margin:15px 0}.tags span{background:#1b2d49;color:#b7cdf2;border:1px solid #2c4770;border-radius:5px;padding:4px 7px;font-size:11px}details{border-top:1px solid #2b3b54;padding-top:13px;color:#adbbd4;font-size:12px;line-height:1.8;overflow-wrap:anywhere}summary{cursor:pointer;color:#acc8ff}.detail{padding-top:12px}.detail b{color:#b7dcff}.detail p{background:#0c1524;border:1px solid #23354d;border-radius:8px;padding:10px;white-space:pre-wrap}footer{padding:30px 0;color:#667797;font-size:12px}@media(max-width:850px){.main{grid-template-columns:1fr}.side{position:static}.wrap{padding:24px 16px}.grid{grid-template-columns:repeat(auto-fill,minmax(245px,1fr))}}@media print{.side,.tools,button{display:none!important}.main{display:block}.grid{grid-template-columns:repeat(2,1fr)}body{background:white;color:black}.card{break-inside:avoid;color:black;background:white}}
</style></head><body><div class="wrap"><div class="head"><header><div class="kicker">IDEA → STORY → SHOT · PRODUCTION BOARD</div><h1>''' + esc(project["title"]) + '''</h1><p>''' + esc(project["logline"]) + '''</p></header><div class="stats">''' + esc(stats) + '''<br>''' + esc(project["aspect_ratio"]) + ''' · ''' + esc(project["genre"]) + '''</div></div><div class="main"><aside class="side"><h2>Story Beat Map / 情节骨架</h2>''' + beat_rows + '''</aside><section><div class="tools"><input id="q" type="search" placeholder="搜索镜头、动作、信息、台词…" aria-label="搜索镜头"><select id="scene"><option value="">全部场景</option>''' + scene_options + '''</select><select id="state"><option value="">全部状态</option><option value="planned">planned</option><option value="approved">approved</option><option value="needs_revision">needs_revision</option></select><button id="print" type="button">打印 / PDF</button></div><div id="count" style="margin:0 0 15px;color:#8da4c8;font-size:12px"></div><div class="grid" id="grid">''' + ''.join(cards) + '''</div></section></div><footer>本地静态 HTML · 可离线打开 · 图像可选，不包含实际 AI 生图或视频生成 · Idea-to-Storyboard v1.0.0</footer></div><script>
const q=document.querySelector('#q'),scene=document.querySelector('#scene'),state=document.querySelector('#state'),cards=[...document.querySelectorAll('.card')];function filter(){let n=0;for(const c of cards){const show=(!q.value||c.dataset.search.includes(q.value.toLowerCase()))&&(!scene.value||c.dataset.scene===scene.value)&&(!state.value||c.dataset.state===state.value);c.hidden=!show;n+=show?1:0;}document.querySelector('#count').textContent=`显示 ${n} / ${cards.length} 个镜头`;}[q,scene,state].forEach(x=>x.addEventListener('input',filter));document.querySelector('#print').addEventListener('click',()=>window.print());filter();
</script></body></html>'''


def do_export(doc: dict, output_dir: Path):
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "storyboard.md").write_text(to_md(doc), encoding="utf-8")
    (output_dir / "preview.html").write_text(to_html(doc, output_dir), encoding="utf-8")
    shot_rows, prompt_rows = [], []
    current = 0.0
    prompts_dir = output_dir / 'prompts'
    prompts_dir.mkdir(exist_ok=True)
    for s in doc['shots']:
        shot_rows.append({"shot_id":s["id"], "scene_id":s["scene_id"], "beat_id":s["beat_id"], "start_sec":round(current, 3), "end_sec":round(current+s['duration_sec'], 3), "duration_sec":s['duration_sec'], "shot_size":s['shot_size'], "angle":s['angle'], "camera_move":s['camera_move'], "framing":s['framing'], "visual_action":s['visual_action'], "story_information":s['story_information'], "dialogue":s.get('dialogue',''), "sound":s['sound'], "reference_image":s.get('reference_image') or '', "status":s['status']})
        current += s['duration_sec']
        prompt_rows.append({"shot_id":s['id'], "image_prompt":s['image_prompt'], "video_prompt":s['video_prompt'], "negative_prompt":s['negative_prompt'], "fallback":s['fallback']})
        # only allow slug-ish shot IDs as filenames (validation checks filename separately)
        safe_id = re.sub(r'[^A-Za-z0-9_-]', '_', s['id'])
        (prompts_dir / f'{safe_id}.md').write_text(f'# {s["id"]}\n\n## 生图提示词\n{s["image_prompt"]}\n\n## 图生视频/视频提示词\n{s["video_prompt"]}\n\n## 避免项\n{s["negative_prompt"]}\n\n## 降级方案\n{s["fallback"]}\n', encoding='utf-8')
    write_csv(output_dir/'shotlist.csv', shot_rows, list(shot_rows[0]))
    write_csv(output_dir/'prompts.csv', prompt_rows, list(prompt_rows[0]))
    assets = ([{'asset_type':'character','asset_id':k,'description':v} for k,v in doc['world']['character_anchors'].items()] + [{'asset_type':'prop','asset_id':k,'description':v} for k,v in doc['world']['prop_anchors'].items()])
    write_csv(output_dir/'assets_manifest.csv', assets, ['asset_type','asset_id','description'])
    save_json(output_dir/'qa_report.json', report(doc))


def init_project(args):
    destination = Path(args.output).resolve()
    if destination.exists() and (not destination.is_dir() or any(destination.iterdir())):
        raise ValueError(f"Refusing to overwrite existing destination: {destination}")
    destination.mkdir(parents=True, exist_ok=True)
    (destination/'idea.txt').write_text(args.idea.strip()+'\n', encoding='utf-8')
    document = {
        "schema_version": SCHEMA_VERSION,
        "project": {"title": "待命名", "logline": args.idea.strip(), "genre": "待设定", "format": args.format, "target_duration_sec": args.seconds, "aspect_ratio": args.aspect},
        "story": {}, "world": {"look":"", "lighting":"", "screen_axis":"", "character_anchors":{}, "prop_anchors":{}},
        "scenes": [], "beats": [], "shots": []
    }
    save_json(destination/'storyboard.json', document)
    (destination/'AGENT_BRIEF.md').write_text(
        f'# 故事任务简报\n\n**原始想法（不得丢失）**\n\n{args.idea.strip()}\n\n**时长**：{args.seconds} 秒；**画幅**：{args.aspect}；**形式**：{args.format}\n\n'
        '此 JSON 是等待 Agent 创作的脚手架，不是完成品。将整个项目交给已安装的 idea-to-storyboard Skill 所在的 Agent，要求：先完成故事因果与结局，再生成逐镜 JSON；运行 validate、export；修正错误并交付 output/preview.html。\n', encoding='utf-8')
    print(f"Initialized draft: {destination}\nNot validated yet. Pass this project folder to your coding agent to complete the story.")


def main(argv=None):
    ap = argparse.ArgumentParser(description='Idea-to-Storyboard validator and offline exporter; Python 3.9+ stdlib only')
    sub = ap.add_subparsers(dest='command', required=True)
    p = sub.add_parser('init', help='Create idea brief + empty storyboard scaffold (agent fills story)')
    p.add_argument('--idea', required=True)
    p.add_argument('--output', '-o', required=True)
    p.add_argument('--seconds', type=int, default=60)
    p.add_argument('--aspect', default='16:9')
    p.add_argument('--format', default='AI cinematic short')
    p.set_defaults(func=init_project)
    for command in ('validate', 'export'):
        p = sub.add_parser(command)
        p.add_argument('file', help='Path to storyboard.json')
        if command == 'validate':
            p.add_argument('--strict', action='store_true', help='Warnings also count as failed exit code')
        else:
            p.add_argument('--output', '-o', help='Output folder, default PROJECT/output')
        p.set_defaults(func=None)
    args = ap.parse_args(argv)
    if args.command == 'init':
        if not args.idea.strip() or not math.isfinite(args.seconds) or args.seconds < 5 or args.seconds > 7200:
            ap.error('idea must be non-empty and seconds must be between 5 and 7200')
        try:
            args.func(args)
        except (OSError, ValueError) as exc:
            print(f"ERROR initializing project: {exc}", file=sys.stderr)
            return 2
        return 0
    path = Path(args.file)
    try:
        doc = load_json(path)
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        print(f"ERROR reading {path}: {exc}", file=sys.stderr)
        return 2
    result = report(doc)
    for err in result['errors']:
        print('ERROR:', err)
    for warning in result['warnings']:
        print('WARN:', warning)
    print('STATS:', json.dumps(result['stats'], ensure_ascii=False))
    if result['errors']:
        print('FAILED; outputs not written.')
        return 1
    if args.command == 'validate':
        if args.strict and result['warnings']:
            print('FAILED STRICT: review warnings')
            return 1
        print('PASS')
        return 0
    output = Path(args.output) if args.output else path.parent/'output'
    try:
        do_export(doc, output)
    except OSError as exc:
        print(f"ERROR writing output: {exc}", file=sys.stderr)
        return 2
    print(f'EXPORT PASS: {output} (HTML, Markdown, CSV, prompt files, QA JSON)')
    return 0


if __name__ == '__main__':
    sys.exit(main())
