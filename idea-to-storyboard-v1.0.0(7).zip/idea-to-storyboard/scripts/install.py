#!/usr/bin/env python3
"""Copy this skill to a local user's or project's Agent Skills folder; no overwrites."""
from __future__ import annotations
import argparse
import shutil
import sys
from pathlib import Path


def main(argv=None):
    p = argparse.ArgumentParser(description='Install idea-to-storyboard for Codex or Claude Code')
    p.add_argument('--client', required=True, choices=('codex', 'claude'))
    p.add_argument('--scope', choices=('user', 'project'), default='user')
    p.add_argument('--project', default='.', help='Project root for --scope project')
    args = p.parse_args(argv)
    source = Path(__file__).resolve().parent.parent
    root = Path.home() if args.scope == 'user' else Path(args.project).resolve()
    base = root/('.agents' if args.client == 'codex' else '.claude')/'skills'
    target = base/'idea-to-storyboard'
    if target.exists() or target.is_symlink():
        print(f'NOT INSTALLED: {target} already exists; no existing files were overwritten.', file=sys.stderr)
        return 1
    try:
        base.mkdir(parents=True, exist_ok=True)
        shutil.copytree(source, target, ignore=shutil.ignore_patterns('__pycache__', '*.pyc', '.DS_Store'))
    except OSError as exc:
        print(f'INSTALL FAILED: {exc}', file=sys.stderr)
        return 2
    print(f'INSTALLED to {target}\nStart a new {args.client} session and ask: 使用 idea-to-storyboard 把我的想法做成故事分镜，并落盘出 HTML。')
    return 0

if __name__ == '__main__':
    sys.exit(main())
