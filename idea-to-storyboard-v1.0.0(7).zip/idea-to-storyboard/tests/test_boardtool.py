"""Contract and negative regression tests; Python 3.9+ stdlib only."""
from __future__ import annotations
import copy
import importlib.util
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TOOL = ROOT/'scripts'/'boardtool.py'
DEMO = ROOT/'examples'/'demo-project'/'storyboard.json'
spec = importlib.util.spec_from_file_location('boardtool', TOOL)
boardtool = importlib.util.module_from_spec(spec)
spec.loader.exec_module(boardtool)


def demo():
    return json.loads(DEMO.read_text(encoding='utf-8'))


class BoardtoolTest(unittest.TestCase):
    def test_demo_valid(self):
        errors, warnings = boardtool.validate(demo())
        self.assertEqual(errors, [])
        self.assertEqual(warnings, [])
        self.assertEqual(boardtool.report(demo())['stats']['total_duration_sec'], 60)

    def test_missing_shot_field_fails(self):
        doc = demo(); del doc['shots'][0]['video_prompt']
        self.assertTrue(any('video_prompt' in err for err in boardtool.validate(doc)[0]))

    def test_duplicate_ids_fails(self):
        doc = demo(); doc['shots'][1]['id'] = doc['shots'][0]['id']
        self.assertTrue(any('duplicate shot' in err for err in boardtool.validate(doc)[0]))

    def test_unsafe_shot_id_fails(self):
        doc = demo(); doc['shots'][0]['id']='../../bad'
        self.assertTrue(any('safe identifier' in err for err in boardtool.validate(doc)[0]))

    def test_orphan_evidence_fails(self):
        doc = demo(); doc['beats'][0]['evidence_shots']=['SH999']
        self.assertTrue(any('evidence_shot' in err for err in boardtool.validate(doc)[0]))

    def test_beat_wrong_scene_fails(self):
        doc = demo(); doc['shots'][-1]['scene_id']='SC01'
        self.assertTrue(any('belongs to scene' in err for err in boardtool.validate(doc)[0]))

    def test_missing_character_anchor_fails(self):
        doc = demo(); doc['shots'][0]['continuity']['characters']=['UNKNOWN']
        self.assertTrue(any('unknown character' in err for err in boardtool.validate(doc)[0]))

    def test_duration_mismatch_fails(self):
        doc = demo(); doc['shots'][0]['duration_sec'] += 10
        self.assertTrue(any('durations total' in err for err in boardtool.validate(doc)[0]))

    def test_infinite_duration_fails(self):
        doc = demo(); doc['shots'][0]['duration_sec'] = float('inf')
        self.assertTrue(any('positive finite' in err for err in boardtool.validate(doc)[0]))

    def test_bool_duration_fails(self):
        doc = demo(); doc['shots'][0]['duration_sec'] = True
        self.assertTrue(any('positive finite' in err for err in boardtool.validate(doc)[0]))

    def test_path_traversal_fails(self):
        for path in ('../outside.png', '/tmp/outside.png', 'C:\\Windows\\win.ini', 'https://evil.example/a.png'):
            doc = demo(); doc['shots'][0]['reference_image']=path
            self.assertTrue(any('unsafe path' in err for err in boardtool.validate(doc)[0]), path)

    def test_good_relative_media_accepted(self):
        doc = demo(); doc['shots'][0]['reference_image']='media/SH001.png'
        self.assertEqual(boardtool.validate(doc)[0], [])

    def test_axis_reverse_warning(self):
        doc = demo(); doc['shots'][0]['screen_direction']='L2R'; doc['shots'][1]['screen_direction']='R2L'
        self.assertTrue(any('opposite screen direction' in x for x in boardtool.validate(doc)[1]))

    def test_invalid_root_fails_cleanly(self):
        errors, warnings = boardtool.validate([])
        self.assertTrue(errors)

    def test_export_roundtrip_no_network(self):
        with tempfile.TemporaryDirectory() as temp:
            dst=Path(temp)/'output'
            boardtool.do_export(demo(),dst)
            self.assertEqual(len(list((dst/'prompts').glob('SH*.md'))),9)
            self.assertIn('风暴最后一束光',(dst/'preview.html').read_text(encoding='utf-8'))
            self.assertIn('显示 ${n}',(dst/'preview.html').read_text(encoding='utf-8'))
            self.assertIn('SH009',(dst/'shotlist.csv').read_text(encoding='utf-8-sig'))
            self.assertEqual(json.loads((dst/'qa_report.json').read_text(encoding='utf8'))['pass'], True)

    def test_html_escapes_adversarial_text(self):
        doc=demo(); doc['project']['title']='</title><script>alert(1)</script>'
        doc['shots'][0]['visual_action']='" onclick="alert(1) <script>bad</script>'
        with tempfile.TemporaryDirectory() as temp:
            boardtool.do_export(doc, Path(temp))
            body=(Path(temp)/'preview.html').read_text(encoding='utf8')
            self.assertNotIn('</title><script>alert(1)</script>',body)
            self.assertNotIn('" onclick="alert(1)',body)

    def test_cli_init_and_unsafe_export(self):
        with tempfile.TemporaryDirectory() as temp:
            d=Path(temp)/'project'
            cmd=[sys.executable,str(TOOL),'init','--idea','最后的火种','-o',str(d)]
            self.assertEqual(subprocess.run(cmd,capture_output=True).returncode,0)
            self.assertTrue((d/'storyboard.json').exists())
            self.assertNotEqual(subprocess.run([sys.executable,str(TOOL),'export',str(d/'storyboard.json')],capture_output=True).returncode,0)
            self.assertFalse((d/'output').exists())
            self.assertNotEqual(subprocess.run(cmd,capture_output=True).returncode,0)

    def test_cli_demo_end_to_end(self):
        with tempfile.TemporaryDirectory() as temp:
            output=Path(temp)/'output'
            checks=subprocess.run([sys.executable,str(TOOL),'validate',str(DEMO),'--strict'],capture_output=True,text=True)
            export=subprocess.run([sys.executable,str(TOOL),'export',str(DEMO),'-o',str(output)],capture_output=True,text=True)
            self.assertEqual(checks.returncode,0,checks.stdout)
            self.assertEqual(export.returncode,0,export.stdout)
            self.assertTrue((output/'preview.html').stat().st_size>5000)


if __name__=='__main__':
    unittest.main()
