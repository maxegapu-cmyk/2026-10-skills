# Idea-to-Storyboard v1.0.0 · 一句话变成可拍的分镜故事

把一句想法交给 Claude Code / Codex，Agent 先完成故事因果、场景、节拍和镜头，再把结构化镜头交给 Python 本地校验导出，得到**分镜工作台 HTML + 剧本 + 镜头表 + AI 生图/视频提示词**。

**这是 Skill + 本地工具，不是一个可脱离 AI 模型自行写故事的全自动程序。** Python 仅负责检测与导出，创意生成由载入 Skill 的 AI Agent 完成。

## 安装（Windows / macOS / Linux）

解压后把**整个 `idea-to-storyboard` 文件夹**复制到以下对应目录之一，保留 `SKILL.md` 和子文件夹层级：

- Claude Code：当前项目 `.claude/skills/idea-to-storyboard/`，或用户目录 `~/.claude/skills/idea-to-storyboard/`。
- Codex：当前项目 `.agents/skills/idea-to-storyboard/`。在支持用户级 skills 的环境，可放入其对应用户 skills 目录。

重新开启一个 Claude Code / Codex 会话，对 Agent 说：

> 使用 idea-to-storyboard：我有个想法，深海灯塔快熄灭了，一个老旧机器人要救远方的小船。拍成 60 秒 16:9 无对白科幻短片。请完成完整故事、可执行分镜，并输出 HTML 预览与镜头表。**不要只给建议，直接写到项目文件，校验后交付。**

Agent 应读取 SKILL.md，按流程建立项目并运行脚本。建议指定一个空文件夹作工作目录。

## 本地工具独立试用

需要 Python 3.9+，**无 pip 安装，无 API Key**。

```bash
# 从用户想法建立空脚手架（不能自动生成完整故事）
python idea-to-storyboard/scripts/boardtool.py init --idea "有个机器人要在暴风雨里救人" --seconds 60 --output my-film

# 把 my-film 给已安装 Skill 的 Agent 完成剧本和 storyboard.json 后：
python idea-to-storyboard/scripts/boardtool.py validate my-film/storyboard.json --strict
python idea-to-storyboard/scripts/boardtool.py export my-film/storyboard.json
```

双击 `my-film/output/preview.html`，可按场景筛选、搜索镜头、展开提示词、打印/PDF。镜头里的可选图像用 `reference_image` 字段连接项目内部 `media/` 文件。预览页面不会联网，也不会自行生成图片。

## 随包完整样本

`examples/demo-project/` 包含一段 60 秒原创科幻小故事的完成样例及导出页面，用来检查安装是否正确。`tests/` 包含结构和失败案例测试。

## 已知边界

- Agent 可能写出剧情、物理、设定错误；脚本自动校验不等于电影质量通过。
- 图片/视频生成不在本包内：可拿每镜提示词调用你实际拥有的影像工具；工具差异需要少量调整。
- 生成时若使用真实影视 IP，请依赖用户给出的设定与可核实参考，不凭空新增正史事实。
- `output/` 是派生文件，每次修改 `storyboard.json` 后重跑 `export`。

### 可选：一条命令安装到当前用户

```bash
python idea-to-storyboard/scripts/install.py --client claude --scope user
python idea-to-storyboard/scripts/install.py --client codex --scope user
```

仅运行你选用的客户端那条命令。若目录已存在，安装器**拒绝覆盖**，可先备份旧版再自行处理。若要仅当前项目生效，把 `--scope user` 换成 `--scope project --project 你的项目目录`。
