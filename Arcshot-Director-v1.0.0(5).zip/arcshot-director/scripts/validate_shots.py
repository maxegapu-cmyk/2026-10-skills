#!/usr/bin/env python3
"""Offline Arcshot shot-plan checker. Does not inspect rendered video."""
import json, math, sys
from pathlib import Path
PKEY=('id','title','duration_s','aspect_ratio','style','audience_goal')
WKEY=('place','axis','light','locked')
SKEY=('id','start','end','purpose','frame','subject','blocking','action','camera','camera_reason','light','sound','transition','entry_state','exit_state')

def num(x): return type(x) in (int,float) and math.isfinite(x)
def validtext(x): return isinstance(x,str) and bool(x.strip())
def validate(obj):
    errors=[]
    if not isinstance(obj,dict):return ['root object missing']
    proj=obj.get('project',{});world=obj.get('world',{});shots=obj.get('shots')
    if not isinstance(proj,dict):errors.append('project invalid');proj={}
    if not isinstance(world,dict):errors.append('world invalid');world={}
    for k in PKEY:
        if k not in proj:errors.append('project missing '+k)
    for k in WKEY:
        if k not in world:errors.append('world missing '+k)
    for k in PKEY:
        if k in proj and k!='duration_s' and not validtext(proj[k]):errors.append('project.'+k+' invalid')
    if 'duration_s' in proj and (not num(proj['duration_s']) or proj['duration_s']<=0):errors.append('duration_s invalid')
    for k in ('place','axis','light'):
        if k in world and not validtext(world[k]):errors.append('world.'+k+' invalid')
    if 'locked' in world and (not isinstance(world['locked'],list) or not world['locked'] or not all(map(validtext,world['locked']))):errors.append('world.locked invalid')
    for k in ('soundscape','music'):
        if not validtext(obj.get(k)):errors.append(k+' missing or invalid')
    if not isinstance(shots,list) or not shots:
        errors.append('shots must be a nonempty list');return errors
    prev=0;last_state=None;ids=set()
    for n,s in enumerate(shots):
        p=f'shots[{n}]'
        if not isinstance(s,dict):errors.append(p+' invalid');continue
        for k in SKEY:
            if k not in s:errors.append(p+' missing '+k)
        for k in SKEY:
            if k in s and k not in ('start','end','entry_state','exit_state') and not validtext(s[k]):errors.append(p+'.'+k+' invalid')
        sid=s.get('id')
        if isinstance(sid,str) and sid in ids:errors.append(p+' duplicate id')
        if isinstance(sid,str):ids.add(sid)
        start=s.get('start');end=s.get('end')
        if not num(start) or not num(end): errors.append(p+' time must be finite numbers')
        else:
            if start<0 or end<=start:errors.append(p+' invalid time interval')
            if abs(start-prev)>0.001:errors.append(p+' time discontinuity')
            prev=end
        for key in ('entry_state','exit_state'):
            state=s.get(key)
            if not isinstance(state,dict) or not state or any(not validtext(k) or not validtext(v) for k,v in state.items()):errors.append(p+'.'+key+' invalid state')
        if isinstance(last_state,dict) and s.get('entry_state')!=last_state:errors.append(p+' entry_state does not inherit previous exit_state')
        last_state=s.get('exit_state')
        for k in ('dialogue','voice'):
            if k in s and not isinstance(s[k],str):errors.append(p+'.'+k+' invalid')
    if num(proj.get('duration_s')) and abs(prev-proj['duration_s'])>0.001:errors.append('last shot end does not match duration_s')
    return errors

def main(argv=None):
    a=list(sys.argv[1:] if argv is None else argv)
    if len(a)!=1:print('Usage: python scripts/validate_shots.py SHOT_PLAN.json',file=sys.stderr);return 2
    try: obj=json.loads(Path(a[0]).read_text(encoding='utf-8'))
    except (OSError,UnicodeError,json.JSONDecodeError) as e:print('Cannot load:',e,file=sys.stderr);return 2
    errors=validate(obj)
    if errors:
        for e in errors:print('FAIL',e,file=sys.stderr)
        return 1
    print(f'PASS structural validation: {len(obj["shots"])} shots, {obj["project"]["duration_s"]}s. Not a rendered-video test.')
    return 0
if __name__=='__main__':sys.exit(main())
