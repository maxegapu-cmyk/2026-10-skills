#!/usr/bin/env python3
"""Validating offline compiler for platform-neutral plans and MiniMax H3 T2VA drafts."""
import argparse,json,sys
from pathlib import Path
from validate_shots import validate

def h3(data):
    chunks=[]
    for index,shot in enumerate(data['shots'],1):
        if index==1:head=f'[Shot 1] {data["project"]["style"]}. '
        else:
            m=int(shot['start']//60);s=shot['start']-m*60
            head=f'[Shot {index}] At {m:02}:{s:06.3f}, the camera cuts to '
        desc=(head+f'{shot["frame"]}. {shot["subject"]}. {shot["blocking"]}. '
              f'Action: {shot["action"]}. Camera: {shot["camera"]}. '
              f'Lighting: {shot["light"]}. Diegetic sound: {shot["sound"]}.')
        if shot.get('dialogue'):
            voice=shot.get('voice','A clear adult (S1)')
            desc+=f' {voice} says: <d>[Chinese] {shot["dialogue"]}</d>'
        chunks.append(desc)
    return ('integrated_multimodal_description: '+'\n'.join(chunks)+
            '\n\noverall_soundscape: '+data['soundscape']+
            '\n\nnon_diegetic_music: '+data['music']+'\n')

def generic(data):
    p=data['project']; w=data['world']
    lines=[f'# {p["title"]} | {p["duration_s"]}s | {p["aspect_ratio"]}',
           f'Audience goal: {p["audience_goal"]}',f'Visual: {p["style"]}',
           f'World: {w["place"]}; camera axis: {w["axis"]}; light: {w["light"]}',
           'Locked facts: '+'; '.join(w['locked'])]
    for sh in data['shots']:
        lines += [f'\n[{sh["id"]} | {sh["start"]}-{sh["end"]}s] {sh["purpose"]}',
                  f'Starting frame: {sh["frame"]}; subject: {sh["subject"]}; blocking: {sh["blocking"]}',
                  f'Action: {sh["action"]}',
                  f'Camera: {sh["camera"]}; WHY: {sh["camera_reason"]}',
                  f'Lighting: {sh["light"]}; sound: {sh["sound"]}; cut: {sh["transition"]}',
                  'Entry: '+json.dumps(sh['entry_state'],ensure_ascii=False,sort_keys=True),
                  'Exit: '+json.dumps(sh['exit_state'],ensure_ascii=False,sort_keys=True)]
        if sh.get('dialogue'):lines.append('Dialogue: '+sh['dialogue'])
    lines += ['\nRoom tone/foley: '+data['soundscape'],'Non-diegetic music: '+data['music']]
    return '\n'.join(lines)+'\n'

def main(argv=None):
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('shot_plan');ap.add_argument('--target',choices=['generic','h3-t2v'],default='generic')
    ap.add_argument('--output')
    a=ap.parse_args(argv)
    try:data=json.loads(Path(a.shot_plan).read_text(encoding='utf-8'))
    except (OSError,UnicodeError,json.JSONDecodeError) as e:print('Cannot load:',e,file=sys.stderr);return 2
    issues=validate(data)
    if issues:
        for i in issues:print('FAIL',i,file=sys.stderr)
        return 1
    result=h3(data) if a.target=='h3-t2v' else generic(data)
    if a.output:
        try:Path(a.output).write_text(result,encoding='utf-8')
        except OSError as e:print('Cannot write:',e,file=sys.stderr);return 2
    else:sys.stdout.write(result)
    return 0
if __name__=='__main__':sys.exit(main())
