# Arcshot Director v1.0.0 · 通用导演分镜师

一个独立、可外发、中文优先的 Agent Skill。将故事／台词／广告创意转换成**可拍摄、可AI生成、可剪辑**的镜头决策；也能诊断原有视频提示词。包含平台中立输出与 MiniMax H3 文生视频（T2VA）适配。

**能力**：导演意图 → 情节点 → 空间调度 → 分镜表 → 连续性账本 → 分镜提示词 → 声音剪辑 → 问题定位/修复。

**安装（手动，不需要额外依赖）**：把完整 `arcshot-director/` 文件夹复制到项目 `.agents/skills/`（Codex 常用的项目发现路径）或 `.claude/skills/`（Claude Code 技能目录），重新加载项目。兼容性以使用的 Agent 对 Agent Skills 的支持为准。也可直接让 AI 阅读 `SKILL.md` 与指定参考文件。

**最快使用**：告诉 AI：“调用 arcshot-director，把这段故事做成12秒、16:9、真人电影风、MiniMax H3文生视频的导演分镜与可复制提示词：[故事]。”未指定平台则生成平台中立提示词。复杂戏份建议每镜单独生成再剪。

**可选命令**（Python 3.9+，标准库，无联网）：

```bash
python scripts/validate_shots.py examples/scene-dialogue.json
python scripts/compile_prompts.py examples/scene-dialogue.json --target generic
python scripts/compile_prompts.py examples/scene-dialogue.json --target h3-t2v
python -m unittest discover -s tests -v
```

**设计取舍**：本 Skill 故意不设通用的“12秒必3镜”或“某个焦距一定高级”。动态使用镜头密度，以信息和动作主导。H3 适配遵循其官方 T2VA 三字段格式，不对 I2V / FL2V / Ref2V 乱套语法；其他平台需重新核验模式和当前能力。文本脚本离线校验 ≠ 平台视频生成实测。

**外发内容**：仅原创说明、示例、模板、离线脚本与公开资料网址。没有第三方完整仓库、缓存、Token、用户素材或安装后远程调用逻辑。

完整索引：`SKILL.md`、`references/`、`examples/`、`assets/`、`scripts/`、`tests/`、`SOURCES.md`、`RELEASE_NOTES.md`。
