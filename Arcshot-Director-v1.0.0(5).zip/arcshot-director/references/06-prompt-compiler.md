# 模型提示词编译器：先镜头后语言

镜头卡是**唯一剧场事实源**，提示词只把既有决定翻译成模型可执行描述。不得凭空增加人物、事件、雨、烟尘、道具或对白。

## 平台中立描述次序
`镜头身份/类型 → 起始主体和站位 → 一条主要动作链（可观察） → 摄影机位置与小幅运动 → 光源材质 → 可继承末状态 → 同步音效`。

- 一次视频生成 ≠ 一场戏 ≠ 一个镜头；需要多镜时明确剪辑，模型不支持高可靠内部多镜则按镜头拆成独立生成。
- 消除“超真实8K、大师拍摄、完美电影质感”这类无法执行的堆叠词；要的是机位、动作和可拍细节。
- 负面词少且针对性强。避免将前面要求的人物动作又写成禁止。
- “锁定”仅能提高提示明确度，不能保证模型从不漂移。

## H3 T2VA 文生视频专用
**只针对文生视频**，以 MiniMax H3 官方 `h3-prompt-writing/references/base-en.txt` 的三字段顺序为依据：

```text
integrated_multimodal_description: [Shot 1] ... [Shot 2] At 00:05.000, ...

overall_soundscape: ...

non_diegetic_music: N/A
```

要求：
1. 文生视频不使用图生模式的 Picture 对齐前缀；首镜开头定义可见风格、构图及主体；后续镜头用 `[Shot N]` 与时间/镜头变化表达。
2. **对白属于第一字段**，按官方形式 `声线描写 (S1) says: <d>[Chinese] 你来了。</d>`，不要把对白塞入整体环境声。
3. `overall_soundscape` 写持续环境声、动作拟音、呼吸等，避免重复对白和配乐；`non_diegetic_music` 只写角色听不到的配乐，确实不要配乐写 `N/A`。
4. 官方建议音景和配乐用英语描述；带中文对白时保留 `[Chinese]` 和中文原文。独立 JSON 编译器不提供机器翻译，输入应已准备好适当英语镜头/声景文字。
5. 生成文本为 H3 **候选提示词**，不能保证所有模型调用参数、时长、画幅或收费方式；具体运行平台另查 API/界面。

## 源数据路径
`assets/shot-plan.schema-guide.md` → 写 `scene.json` → `python scripts/validate_shots.py scene.json` → `python scripts/compile_prompts.py scene.json --target h3-t2v`。JSON检查范围仅结构、相邻时长与状态，语义镜头审核需导演本人或另行审片。
