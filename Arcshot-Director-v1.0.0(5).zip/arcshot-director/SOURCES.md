# 公开资料与设计依据（2026-10-21 核对）

本项目采用独立写作与独立实现，没有复制或再分发所列仓库的源文件。

1. **DirectorSKILL** — https://github.com/wuwangzhang1216/DirectorSKILL ; 公开完整的导演工作分类，包括导演分析、分镜、连续性、视频提示词、声音与修复。用作功能覆盖面的对标。其仓库自述采用 MIT 协议；不内嵌其内容。
2. **visual-skills / video** — https://github.com/smixs/visual-skills/tree/main/video ; 强调戏剧行动优先于提示词修饰，以及有动机的运镜和分镜细节核验。用作质量审核的对标，不复制模板。
3. **fal-ai cinematography Skill** — https://github.com/fal-ai-community/skills/tree/main/skills/cinematography ; 摄影术语、机位与平台端点分离的对标。
4. **MiniMax H3 官方** — https://github.com/MiniMax-AI/MiniMax-H3/tree/main/skills/h3-prompt-writing ; T2VA 三字段的规范依据。API和可用模式随时间变化，使用前应复核官方说明。
5. **Agent Skills 开放规范** — https://github.com/agentskills/agentskills/blob/main/docs/specification.mdx ; `SKILL.md` 元数据、渐进披露与可选 `scripts/` `references/` 的目录格式依据。

这里的“对标”仅指参考公开问题定义、互操作格式与质量维度，不声称任何仓库作者认可本项目。本项目不是上述项目的镜像、fork或官方插件。
