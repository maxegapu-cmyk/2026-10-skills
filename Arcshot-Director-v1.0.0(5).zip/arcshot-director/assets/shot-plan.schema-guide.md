# 镜头 JSON 数据契约（机器可读）

读取 `examples/scene-dialogue.json` 作为最小合法示例。以下字段应完整保留：

- `project` 必须含 `id`、`title`、`duration_s`(数字>0)、`aspect_ratio`、`style`、`audience_goal`。
- `world` 必须含 `place`、`axis`、`light`、`locked`（非空字符串列表），作为本场固定条件。
- `shots` 是非空数组。每镜必须有 `id`、`start`、`end`、`purpose`、`frame`、`subject`、`blocking`、`action`、`camera`、`camera_reason`、`light`、`sound`、`transition`、`entry_state` 与 `exit_state`；可额外写 `dialogue`（字符串，供H3 `<d>` 标签）、`voice`（说话人描述）等。
- `entry_state` 和 `exit_state` 是“物件或人物世界状态”的键值对象，所有值为非空字符串。下一镜 `entry_state` **必须完整等于**上一镜 `exit_state`（注意不应意外丢字段）；同一镜内的改变可体现在本镜 `exit_state`。
- `soundscape` 是场景持续环境拟音的英语段落（H3）；`music` 为英语配乐描述或 `N/A`。
- 第一个镜头 `start=0`，相邻 `shots[i].start = shots[i-1].end`，最后 `end=project.duration_s`。容忍秒值 0.001 的浮点误差。
- 严格校验只是阻挡明显错误。`axis` 等语义字段是否逻辑上正确不能靠此脚本确定。
- 如用户把场景拍成多个单独生成片段，可为每镜另建一个 JSON，重新设定该生成的本地秒轴，项目时间轴单独保存。
