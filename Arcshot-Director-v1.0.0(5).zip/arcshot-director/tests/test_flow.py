"""Offline structural regression and negative tests. No external model calls."""
import copy,json,subprocess,sys,unittest
from pathlib import Path
BASE=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(BASE/'scripts'))
from validate_shots import validate
from compile_prompts import generic,h3

class TestArcshot(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.data=json.loads((BASE/'examples'/'scene-dialogue.json').read_text(encoding='utf-8'))

    def bad(self,fn,needle):
        d=copy.deepcopy(self.data);fn(d)
        errs=validate(d)
        self.assertTrue(any(needle in e for e in errs),(needle,errs))

    def test_three_example_plans(self):
        self.assertEqual(len(list((BASE/'examples').glob('*.json'))),3)
        for f in sorted((BASE/'examples').glob('*.json')):
            with self.subTest(file=f.name):self.assertEqual(validate(json.loads(f.read_text(encoding='utf-8'))),[])
    def test_duplicate_id(self): self.bad(lambda d:d['shots'][1].update(id=d['shots'][0]['id']),'duplicate id')
    def test_missing_camera_reason(self): self.bad(lambda d:d['shots'][0].pop('camera_reason'),'camera_reason')
    def test_missing_world_axis(self): self.bad(lambda d:d['world'].pop('axis'),'world missing axis')
    def test_bad_duration(self): self.bad(lambda d:d['project'].update(duration_s=0),'duration_s invalid')
    def test_nan(self): self.bad(lambda d:d['shots'][0].update(start=float('nan')),'finite numbers')
    def test_true_as_time(self): self.bad(lambda d:d['shots'][0].update(end=True),'finite numbers')
    def test_gap(self): self.bad(lambda d:d['shots'][1].update(start=5),'time discontinuity')
    def test_overlap(self): self.bad(lambda d:d['shots'][1].update(start=3.5),'time discontinuity')
    def test_reverse_interval(self): self.bad(lambda d:d['shots'][0].update(end=-1),'invalid time interval')
    def test_missing_last_second(self): self.bad(lambda d:d['shots'][-1].update(end=11),'last shot end')
    def test_empty_state(self): self.bad(lambda d:d['shots'][0].update(entry_state={}),'invalid state')
    def test_inherited_prop_jump(self): self.bad(lambda d:d['shots'][1]['entry_state'].update(letter='hidden'),'entry_state does not inherit')
    def test_world_locks_missing(self): self.bad(lambda d:d['world'].update(locked=[]),'world.locked invalid')
    def test_shots_empty(self): self.bad(lambda d:d.update(shots=[]),'nonempty')
    def test_soundscape_missing(self): self.bad(lambda d:d.pop('soundscape'),'soundscape')
    def test_dialogue_wrong_type(self): self.bad(lambda d:d['shots'][2].update(dialogue=['wrong']),'dialogue invalid')
    def test_root_wrong_type(self): self.assertTrue(validate([]))
    def test_generic_output_preserves_state(self):
        o=generic(self.data)
        for s in self.data['shots']:
            self.assertIn(s['id'],o);self.assertIn(s['camera_reason'],o)
        self.assertIn('Entry:',o);self.assertIn('Exit:',o)
    def test_h3_three_fields_order(self):
        o=h3(self.data)
        fields=['integrated_multimodal_description:','overall_soundscape:','non_diegetic_music:']
        self.assertEqual([o.index(v) for v in fields],sorted(o.index(v) for v in fields))
        self.assertTrue(o.startswith(fields[0]))
        self.assertIn('[Shot 1]',o);self.assertIn('[Shot 2] At 00:04.000',o)
        self.assertIn('<d>[Chinese] 你一直在外面？</d>',o)
        self.assertNotIn('<Picture ',o)
    def test_cli_run_success(self):
        p=subprocess.run([sys.executable,str(BASE/'scripts'/'validate_shots.py'),str(BASE/'examples'/'scene-dialogue.json')],capture_output=True,text=True)
        self.assertEqual(p.returncode,0,p.stderr)
        self.assertIn('Not a rendered-video test',p.stdout)
    def test_cli_h3_run_success(self):
        p=subprocess.run([sys.executable,str(BASE/'scripts'/'compile_prompts.py'),str(BASE/'examples'/'tattoo-detail.json'),'--target','h3-t2v'],capture_output=True,text=True)
        self.assertEqual(p.returncode,0,p.stderr)
        self.assertIn('LEFT',p.stdout)
    def test_cli_reject_bad_json(self):
        p=subprocess.run([sys.executable,str(BASE/'scripts'/'compile_prompts.py'),str(BASE/'README.md')],capture_output=True,text=True)
        self.assertEqual(p.returncode,2)
    def test_skill_frontmatter(self):
        s=(BASE/'SKILL.md').read_text(encoding='utf-8')
        self.assertTrue(s.startswith('---\n'))
        meta=s.split('---',2)[1]
        self.assertIn('name: arcshot-director',meta)
        self.assertIn('description:',meta)
    def test_refs_present(self):
        import re
        s=(BASE/'SKILL.md').read_text(encoding='utf-8')
        self.assertEqual(len(list((BASE/'references').glob('*.md'))),8)
        for ref in re.findall(r'\b(?:references/)?\d\d-[\w-]+\.md',s):
            p=BASE/'references'/Path(ref).name
            self.assertTrue(p.exists(),str(p))

if __name__=='__main__':unittest.main()
