# 击帧导演 3.0 · HitFrame Studio

**为 AI 打斗、漫剧、动画和影视镜头设计真正有力量的关键一击。** 一句需求就能得到可复制的冲击帧生图提示词、动作视频提示词、连招分镜和击点表；已有视频还能按帧精准加上顿帧、闪白、墨色、负片、色散、震屏和推近。

## 3.0 新在哪

- **冲击档位 L1–L5**：说"再狠一点"就升一档，每档有明确的构图、透视、效果和色彩写法；一场戏的档位曲线自动拉开落差。
- **力的五种结构**：爆心、压境、切线、对冲、崩解，配帧型对照、汇聚点放法、碎片与介质写法，以及中英文现成句。
- **透视与尺度工具**：贴地机位、线条收向一点、巨物只露局部、熟悉物当刻度、近景与中景各自的透视做法。
- **六个画风包**：赛璐璐漫剧、写实电影、刮痕干笔、美漫硬阴影、3D 游戏 CG、水墨武侠，外加三色法、六组配色和对冲双力配色。
- **平台适配（截至 2026-10）**：Midjourney V8、Nano Banana Pro、即梦/Seedream 5.0、Seedance 2.0/2.5、可灵 3.0、Veo 3.1 的具体写法。
- **参考图拆解与连招多镜**：参考图分职责、拆出可迁移的冲击语法；多镜交接卡直通后期击点表。
- **成品范例 12 条**：单张冲击帧 7 条、视频 4 条、修复前后 1 条。
- **后期工具 framecraft 3.0**：8 个配方、9 种可自由组合的图层、多击点击点表、自动找候选击点、连帧图、光敏闪烁预算与安全扫描；44 项测试。

## 30 秒上手

解压 ZIP，保留完整的 `hitframe-studio` 文件夹（不要只复制 `SKILL.md`），放进 Claude Code 的 `~/.claude/skills/` 或 Codex 的 `~/.codex/skills/`。Windows 对应 `C:\Users\你的用户名\.claude\skills\`。然后直接说：

- `用击帧导演：机甲一拳把钢闸门打凹，L4，给我 Midjourney 提示词。`
- `用击帧导演：两名剑客在雨夜碰刀，接触那一下做黑白冲击，给我 Seedance 的 8 秒视频提示词。`
- `用击帧导演：照这张参考图的感觉，给我的角色做一张冲击帧。`（附图）
- `用击帧导演：这段视频拳头明明打中了却没重量，只修有问题的部分。`

新手先看 `START-HERE.md`。

## 本地视频加工

需要 Python 3.9+、FFmpeg、FFprobe，无需安装任何 Python 库。原视频永远不会被覆盖。

```bash
python scripts/framecraft.py menu
python scripts/framecraft.py detect --input fight.mp4
python scripts/framecraft.py apply --input fight.mp4 --at 3.4 --recipe heavy --focus 0.58,0.42 --output fight_hit.mp4
python scripts/framecraft.py apply --input fight.mp4 --cues examples/cues-example.json --output fight_all.mp4
```

全部参数见 `references/post-production.md`。

## 项目结构

- `SKILL.md`：智能体入口与自动分流
- `START-HERE.md`：第一次使用看这页
- `references/`：档位、力的结构、透视尺度、构图、效果词汇、画风包、节奏、连续性、三联卡、平台适配、参考图拆解、故障树、后期、场面构思
- `examples/`：成品提示词范例、击点表示例
- `scripts/framecraft.py`：本地视频工具
- `tests/`：可运行的测试
- `CHANGELOG.md`：版本记录

## 注意

各生成平台对时长、颜色变化、运动轨迹的执行能力不同；本 Skill 输出方案和提示词，真正的生成结果取决于你用的平台、素材和模型。后期工具只对现有视频做画面滤镜、定格、镜头运动或整帧替换，不会修复已经失败的肢体动作。

闪烁效果可能让部分观众不适。工具会拦截每秒超过 3 次的闪烁类效果并做近似扫描；公开播出前请用专业工具复检，并考虑提供柔和版本。

## 运行检查

```bash
python -m unittest discover -s tests -v
```

许可证：MIT。
