from __future__ import annotations

import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "scripts" / "framecraft.py"
_spec = importlib.util.spec_from_file_location("framecraft", SOURCE)
fc = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(fc)

W, H = 160, 96


def call(*args):
    return subprocess.run([str(x) for x in args], capture_output=True, text=True, timeout=90)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def make(path, *lavfi_and_args):
    r = call("ffmpeg", "-hide_banner", "-loglevel", "error", *lavfi_and_args, "-y", path)
    if r.returncode:
        raise RuntimeError(r.stderr)


class LogicTests(unittest.TestCase):
    def test_01_rates(self):
        self.assertEqual(fc.parse_rate("30000/1001"), fc.Fraction(30000, 1001))

    def test_02_invalid_rates(self):
        for fps in ("0", "999", "NaN", "24/0", "abc", "-1"):
            with self.subTest(fps=fps), self.assertRaises(fc.FramecraftError):
                fc.parse_rate(fps)

    def test_03_frames_at_second(self):
        self.assertEqual(fc.plan_frames(1.0, 2, fc.Fraction(24), 2.0), (24, 25))

    def test_04_frame_count_one(self):
        self.assertEqual(fc.plan_frames(0, 1, fc.Fraction(24), 1.0), (0, 0))

    def test_05_reject_past_end(self):
        with self.assertRaises(fc.FramecraftError):
            fc.plan_frames(2, 1, fc.Fraction(24), 2)

    def test_06_reject_partial_past_end(self):
        with self.assertRaises(fc.FramecraftError):
            fc.plan_frames(1.95, 10, fc.Fraction(24), 2)

    def test_07_reject_negative_and_nan(self):
        for at in (-0.2, float("nan")):
            with self.subTest(at=at), self.assertRaises(fc.FramecraftError):
                fc.plan_frames(at, 2, fc.Fraction(24), 2)

    def test_08_ms_to_frames(self):
        self.assertEqual(fc.ms_to_frames(90, fc.Fraction(24)), 2)
        self.assertEqual(fc.ms_to_frames(90, fc.Fraction(60)), 5)
        self.assertEqual(fc.ms_to_frames(5, fc.Fraction(24)), 1)

    def test_09_recipes_resolve_everywhere(self):
        for name in fc.RECIPES:
            for fps in (fc.Fraction(24), fc.Fraction(30000, 1001), fc.Fraction(60)):
                with self.subTest(recipe=name, fps=fps):
                    cues = fc.resolve_cues([{"at": 1.0, "recipe": name}], fps, 3.0, 1920)
                    self.assertTrue(cues[0]["layers"])
                    graph = fc.build_graph(cues, fps, 1920, 1080, {})
                    self.assertIn("[vout]", graph)

    def test_10_after_hold_offset(self):
        cues = fc.resolve_cues([{"at": 1.0, "recipe": "blackout"}], fc.Fraction(24), 3.0, 640)
        hold = next(l for l in cues[0]["layers"] if l["type"] == "hitstop")
        dark = next(l for l in cues[0]["layers"] if l["type"] == "flash")
        self.assertEqual(dark["first"], hold["first"] + hold["frames"])

    def test_11_layers_clip_at_end(self):
        cues = fc.resolve_cues([{"at": 2.95, "recipe": "crit"}], fc.Fraction(24), 3.0, 640)
        for layer in cues[0]["layers"]:
            self.assertLessEqual(layer["last"], 71)

    def test_12_bad_inputs(self):
        bad = [
            [{"at": 1, "recipe": "nope"}],
            [{"at": 1, "layers": [{"type": "laser"}]}],
            [{"at": 1, "layers": [{"type": "flash", "color": "white;drop"}]}],
            [{"at": 1, "layers": [{"type": "shake", "amp": 5}]}],
            [{"at": 1, "layers": [{"type": "shake", "direction": "diagonal"}]}],
            [{"at": 1, "layers": [{"type": "zoom", "focus": [2, 0]}]}],
            [{"at": 99, "recipe": "heavy"}],
            [{"recipe": "heavy"}],
            [],
        ]
        for cues in bad:
            with self.subTest(cues=cues), self.assertRaises(fc.FramecraftError):
                fc.resolve_cues(cues, fc.Fraction(24), 3.0, 640)

    def test_13_flash_budget_counting(self):
        cues = fc.resolve_cues([{"at": t, "recipe": "crit"} for t in (0.2, 0.6)], fc.Fraction(24), 3.0, 640)
        times = fc.flash_events(cues, fc.Fraction(24))
        self.assertEqual(len(times), 4)
        self.assertEqual(fc.max_in_window(times)[0], 4)
        soft = fc.resolve_cues([{"at": t, "recipe": "heavy"} for t in (0.2, 0.4, 0.6, 0.8)], fc.Fraction(24), 3.0, 640)
        self.assertEqual(fc.flash_events(soft, fc.Fraction(24)), [])

    def test_14_docs_present(self):
        names = ["SKILL.md", "README.md", "START-HERE.md", "CHANGELOG.md", "LICENSE",
                 "examples/ready-prompts.md", "examples/cues-example.json", "scripts/framecraft.py"]
        names += [f"references/{p.name}" for p in (ROOT / "references").glob("*.md")]
        self.assertGreaterEqual(len(names), 18)
        for name in names:
            with self.subTest(name=name):
                self.assertGreater((ROOT / name).stat().st_size, 150)

    def test_15_skill_links_resolve(self):
        text = (ROOT / "SKILL.md").read_text(encoding="utf-8")
        self.assertIn("name: hitframe-studio", text)
        import re
        for ref in set(re.findall(r"`((?:references|examples|scripts)/[\w./-]+)`", text)):
            with self.subTest(ref=ref):
                self.assertTrue((ROOT / ref).is_file(), ref)

    def test_16_example_cues_valid(self):
        cues = fc.load_cues(ROOT / "examples" / "cues-example.json")
        resolved = fc.resolve_cues(cues, fc.Fraction(24), 10.0, 1280)
        self.assertEqual(len(resolved), len(cues))


@unittest.skipUnless(shutil.which("ffmpeg") and shutil.which("ffprobe"), "needs ffmpeg and ffprobe")
class RenderTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory(prefix="hitframe-tests-")
        cls.base = Path(cls.temp.name)
        cls.video = cls.base / "source.mp4"
        cls.image = cls.base / "art.png"
        make(cls.video, "-f", "lavfi", "-i", f"testsrc2=size={W}x{H}:rate=24:duration=2",
             "-f", "lavfi", "-i", "sine=frequency=500:sample_rate=44100:duration=2",
             "-c:v", "libx264", "-pix_fmt", "yuv420p", "-c:a", "aac", "-shortest")
        make(cls.image, "-f", "lavfi", "-i", f"color=c=red:s={W}x{H}:d=1", "-frames:v", "1")
        cls.before = digest(cls.video)

    @classmethod
    def tearDownClass(cls):
        cls.temp.cleanup()

    def out(self, label, suffix=".mp4"):
        return self.base / f"out-{label}{suffix}"

    def frame(self, src, index):
        r = subprocess.run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-i", str(src),
                            "-vf", f"select=eq(n\\,{index})", "-frames:v", "1", "-f", "rawvideo",
                            "-pix_fmt", "rgb24", "-"], capture_output=True, timeout=30)
        self.assertEqual(r.returncode, 0, r.stderr.decode(errors="replace"))
        self.assertEqual(len(r.stdout), W * H * 3)
        return r.stdout

    def mean(self, src, index):
        data = self.frame(src, index)
        return sum(data) / len(data)

    def diff(self, a, b):
        return sum(abs(x - y) for x, y in zip(a, b)) / len(a)

    # -- legacy single styles (1.x API stays working)
    def test_20_white_exact_and_restored(self):
        out = self.out("white")
        d = fc.apply(self.video, out, 1.0, 2, "white")
        self.assertEqual((d["frame_start"], d["frame_end"]), (24, 25))
        self.assertGreater(self.mean(out, 24), 235)
        self.assertGreater(self.mean(out, 25), 235)
        self.assertLess(self.mean(out, 23), 170)
        self.assertLess(self.mean(out, 26), 170)

    def test_21_black_exact_and_restored(self):
        out = self.out("dark")
        fc.apply(self.video, out, 1.0, 2, "dark")
        self.assertLess(self.mean(out, 24), 12)
        self.assertGreater(self.mean(out, 26), 40)

    def test_22_tone_styles(self):
        for style in ("invert", "ink", "punch"):
            with self.subTest(style=style):
                out = self.out(style)
                fc.apply(self.video, out, 0.8, 2, style)
                self.assertTrue(out.is_file())

    def test_23_still_image(self):
        out = self.out("still")
        fc.apply(self.video, out, 1, 2, "still", image=self.image)
        self.assertTrue(fc.read_media(out)["has_audio"])
        px = self.frame(out, 24)
        self.assertGreater(sum(px[::3]) / len(px[::3]), 160)
        self.assertLess(sum(px[1::3]) / len(px[1::3]), 90)

    # -- 3.0 layers
    def test_24_hitstop_holds_contact_frame(self):
        out = self.out("hold")
        fc.render(self.video, out, [{"at": 1.0, "layers": [{"type": "hitstop", "frames": 3}]}], safety_scan=False)
        contact = self.frame(out, 24)
        for n in (25, 26, 27):
            self.assertLess(self.diff(contact, self.frame(out, n)), 2.0, n)
        self.assertGreater(self.diff(contact, self.frame(out, 28)), 4.0)
        self.assertAlmostEqual(fc.read_media(out)["duration"], fc.read_media(self.video)["duration"], delta=0.1)

    def test_25_shake_only_inside_window(self):
        out = self.out("shake")
        fc.render(self.video, out, [{"at": 1.0, "layers": [{"type": "shake", "frames": 4, "amp": 0.05}]}],
                  safety_scan=False)
        self.assertLess(self.diff(self.frame(self.video, 20), self.frame(out, 20)), 3.0)
        self.assertGreater(self.diff(self.frame(self.video, 25), self.frame(out, 25)), 6.0)
        self.assertLess(self.diff(self.frame(self.video, 32), self.frame(out, 32)), 3.0)

    def test_25b_directional_shake(self):
        for direction in ("h", "v"):
            with self.subTest(direction=direction):
                out = self.out(f"shake-{direction}")
                fc.render(self.video, out, [{"at": 1.0, "layers": [
                    {"type": "shake", "frames": 4, "amp": 0.05, "direction": direction}]}], safety_scan=False)
                self.assertGreater(self.diff(self.frame(self.video, 25), self.frame(out, 25)), 3.0)

    def test_26_zoom_only_inside_window(self):
        out = self.out("zoom")
        fc.render(self.video, out, [{"at": 1.0, "focus": [0.25, 0.5],
                                     "layers": [{"type": "zoom", "frames": 4, "zoom": 1.3}]}], safety_scan=False)
        self.assertLess(self.diff(self.frame(self.video, 20), self.frame(out, 20)), 3.0)
        self.assertGreater(self.diff(self.frame(self.video, 24), self.frame(out, 24)), 6.0)
        self.assertLess(self.diff(self.frame(self.video, 30), self.frame(out, 30)), 3.0)

    def test_27_every_recipe_renders(self):
        src_info = fc.read_media(self.video)
        for name in fc.RECIPES:
            with self.subTest(recipe=name):
                out = self.out(f"recipe-{name}")
                d = fc.render(self.video, out, [{"at": 0.9, "recipe": name}], safety_scan=False)
                info = fc.read_media(out)
                self.assertAlmostEqual(info["duration"], src_info["duration"], delta=0.15)
                self.assertTrue(info["has_audio"])
                self.assertEqual(d["cues"][0]["recipe"], name)

    def test_28_multi_hit_and_budget(self):
        out = self.out("multi")
        d = fc.render(self.video, out, [{"at": 0.3, "recipe": "heavy"}, {"at": 1.2, "recipe": "manga"}])
        self.assertEqual(len(d["cues"]), 2)
        self.assertIn(d["safety_scan"]["verdict"], ("pass", "risk"))
        crowded = [{"at": t, "recipe": "crit"} for t in (0.2, 0.5, 0.8)]
        with self.assertRaises(fc.FramecraftError):
            fc.render(self.video, self.out("crowded"), crowded)
        self.assertFalse(self.out("crowded").exists())
        fc.render(self.video, self.out("crowded-ok"), crowded, allow_intense=True, safety_scan=False)
        self.assertTrue(self.out("crowded-ok").is_file())

    def test_29_flash_scan_detects_strobe(self):
        strobe = self.base / "strobe.mp4"
        make(strobe, "-f", "lavfi", "-i", f"color=black:s={W}x{H}:r=24:d=2",
             "-vf", "geq=lum='if(lt(mod(N,6),3),235,16)':cb=128:cr=128", "-c:v", "libx264", "-pix_fmt", "yuv420p")
        self.assertEqual(fc.flash_scan(strobe)["verdict"], "risk")
        self.assertEqual(fc.flash_scan(self.video)["verdict"], "pass")

    def test_30_detect_finds_cut(self):
        cut = self.base / "cut.mp4"
        make(cut, "-f", "lavfi", "-i", f"color=c=0x202020:s={W}x{H}:r=24:d=1",
             "-f", "lavfi", "-i", f"color=c=0xE0E0E0:s={W}x{H}:r=24:d=1",
             "-filter_complex", "[0:v][1:v]concat=n=2:v=1[v]", "-map", "[v]", "-c:v", "libx264", "-pix_fmt", "yuv420p")
        hits = fc.detect_hits(cut)
        self.assertTrue(hits)
        self.assertTrue(any(abs(h["time"] - 1.0) < 0.1 for h in hits), hits)

    def test_31_contact_sheet(self):
        out = self.out("sheet", ".png")
        d = fc.contact_sheet(self.video, 1.0, out, span=3)
        self.assertTrue(out.is_file())
        self.assertEqual(d["frames"], list(range(21, 28)))
        with self.assertRaises(fc.FramecraftError):
            fc.contact_sheet(self.video, 1.0, out, span=3)

    # -- safety of files
    def test_40_source_unchanged(self):
        self.assertEqual(digest(self.video), self.before)

    def test_41_output_exists_refused(self):
        existing = self.base / "existing.mp4"
        existing.write_bytes(b"NOT_A_VIDEO")
        with self.assertRaises(fc.FramecraftError):
            fc.render(self.video, existing, [{"at": 0.5, "recipe": "light"}])
        self.assertEqual(existing.read_bytes(), b"NOT_A_VIDEO")

    def test_42_same_source_refused(self):
        with self.assertRaises(fc.FramecraftError):
            fc.apply(self.video, self.video, 0.5, 1, "white")
        self.assertEqual(digest(self.video), self.before)

    def test_43_symlink_refused(self):
        alias = self.base / "source-alias.mp4"
        try:
            alias.symlink_to(self.video)
        except (OSError, NotImplementedError):
            self.skipTest("symlink unavailable")
        with self.assertRaises(fc.FramecraftError):
            fc.render(self.video, alias, [{"at": 0.5, "recipe": "light"}])
        self.assertEqual(digest(self.video), self.before)

    def test_44_still_and_image_rules(self):
        with self.assertRaises(fc.FramecraftError):
            fc.apply(self.video, self.out("absent-art"), 0.5, 1, "still")
        with self.assertRaises(fc.FramecraftError):
            fc.apply(self.video, self.out("extra-art"), 0.5, 1, "white", image=self.image)

    def test_45_preview_and_refuse_repeat(self):
        folder = self.base / "preview"
        paths = fc.preview(self.video, 1, folder)
        self.assertEqual(len(paths), 3)
        with self.assertRaises(fc.FramecraftError):
            fc.preview(self.video, 1, folder)

    def test_46_no_audio_input(self):
        source = self.base / "silent.mp4"
        make(source, "-f", "lavfi", "-i", f"color=c=blue:s={W}x{H}:r=24:d=1", "-c:v", "libx264", "-pix_fmt", "yuv420p")
        out = self.out("silent")
        fc.render(source, out, [{"at": 0.2, "recipe": "heavy"}], safety_scan=False)
        self.assertFalse(fc.read_media(out)["has_audio"])

    def test_47_custom_and_fractional_fps(self):
        out = self.out("fps30")
        fc.render(self.video, out, [{"at": 1, "recipe": "light"}], fps_override="30", safety_scan=False)
        self.assertEqual(fc.read_media(out)["fps"], fc.Fraction(30))
        out = self.out("fps2997")
        fc.render(self.video, out, [{"at": 0.5, "recipe": "manga"}], fps_override="30000/1001", safety_scan=False)
        self.assertEqual(fc.read_media(out)["fps"], fc.Fraction(30000, 1001))

    def test_48_unicode_paths_and_missing_dir(self):
        out = self.base / "冲击帧 测试.mp4"
        fc.render(self.video, out, [{"at": 0.5, "recipe": "cinema"}], safety_scan=False)
        self.assertTrue(out.is_file())
        with self.assertRaises(fc.FramecraftError):
            fc.render(self.video, self.base / "not-created" / "x.mp4", [{"at": 0.5, "recipe": "cinema"}])

    def test_49_no_temp_residue_and_bad_video(self):
        bad = self.base / "bad.mp4"
        bad.write_text("bad", encoding="utf-8")
        with self.assertRaises(fc.FramecraftError):
            fc.read_media(bad)
        self.assertEqual(list(self.base.glob(".hitframe-*")), [])

    # -- CLI
    def test_50_cli_inspect_recipes_version(self):
        r = call(sys.executable, "-I", SOURCE, "inspect", "--input", self.video)
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertTrue(json.loads(r.stdout)["has_audio"])
        r = call(sys.executable, "-I", SOURCE, "recipes")
        self.assertIn("heavy", json.loads(r.stdout))
        r = call(sys.executable, "-I", SOURCE, "--version")
        self.assertIn("3.0.0", r.stdout)

    def test_51_cli_apply_recipe_multi(self):
        out = self.out("cli-multi")
        r = call(sys.executable, "-I", SOURCE, "apply", "--input", self.video, "--output", out,
                 "--at", "0.4,1.3", "--recipe", "anime", "--focus", "0.6,0.4")
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertEqual(len(json.loads(r.stdout)["cues"]), 2)

    def test_52_cli_cues_file(self):
        cues = self.base / "cues.json"
        cues.write_text(json.dumps({"cues": [{"at": 0.5, "recipe": "light"},
                                             {"at": 1.4, "layers": [{"type": "flash", "color": "#FFC21A",
                                                                     "strength": 0.6, "frames": 1}]}]}), encoding="utf-8")
        out = self.out("cli-cues")
        r = call(sys.executable, "-I", SOURCE, "apply", "--input", self.video, "--output", out, "--cues", cues)
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertTrue(out.is_file())

    def test_53_cli_invalid_time_and_conflicts(self):
        r = call(sys.executable, "-I", SOURCE, "apply", "--input", self.video,
                 "--output", self.out("bad-time"), "--at", "999", "--style", "punch")
        self.assertEqual(r.returncode, 2)
        self.assertFalse(self.out("bad-time").exists())
        r = call(sys.executable, "-I", SOURCE, "apply", "--input", self.video,
                 "--output", self.out("conflict"), "--at", "1", "--style", "punch", "--recipe", "heavy")
        self.assertEqual(r.returncode, 2)

    def test_54_cli_detect_safety_sheet(self):
        r = call(sys.executable, "-I", SOURCE, "detect", "--input", self.video)
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertIsInstance(json.loads(r.stdout), list)
        r = call(sys.executable, "-I", SOURCE, "safety", "--input", self.video)
        self.assertEqual(json.loads(r.stdout)["verdict"], "pass")
        r = call(sys.executable, "-I", SOURCE, "sheet", "--input", self.video, "--at", "1",
                 "--output", self.out("cli-sheet", ".png"))
        self.assertEqual(r.returncode, 0, r.stderr)


if __name__ == "__main__":
    unittest.main()
