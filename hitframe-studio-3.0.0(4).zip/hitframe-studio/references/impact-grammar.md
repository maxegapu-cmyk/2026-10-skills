# 冲击语法：力的五种结构、帧型、碎片与介质

## 一、三问

每一帧都要回答：**谁施力、力在哪里相遇、什么因此改变。** 第三问答不上来，画面就只是摆姿势。

## 二、力的五种结构

挑一种，让画面里所有会动的东西都服从它。下面每种结构按同一格式说明：**观众的感受 → 必写的三样东西 → 示范句**。

### 1. 爆心型

- **观众的感受**：一个很小的点，释放出远超它体积的东西。
- **必写**：① 接触点在哪；② 什么东西从那里向外扩散（尘环、裂纹、光、碎屑）；③ 起因和结果的体量对比（一根指头、一整面墙）。
- **加强手法·卡住**：武器或拳头嵌在目标里拔不出来，能量沿着嵌入的边缘往外窜，比四散乱炸更集中、更凶。

> the spear is buried halfway into the iron gate and still trembling; sparks and molten flecks shriek out along both edges of the wound in two tight fans, and the gate bows inward around the shaft

> 长矛扎进铁门一半，还在震颤；火星和熔滴顺着伤口两侧尖啸着喷出，形成两道窄扇，铁门以矛杆为中心向内拱起。

### 2. 压境型

- **观众的感受**：有个巨大的东西在画外，它还没露面，环境已经扛不住了。
- **必写**：① 环境里能"倒"的东西（雨、草、旗、烟、头发）；② 它们统一倒向哪一侧；③ 主体在这片倒伏里的位置（通常正中、孤零零）。
- **蓄势版**：主体保持静止，发梢、衣角、脚边的碎石先有反应。

> every banner on the wall snaps flat toward the east and the rain falls sideways, driven by something far beyond the frame; on the empty courtyard below, the old monk stands with his eyes closed, only the hem of his robe straining toward the east

> 城墙上的旗子全部猛地拍向东边，雨也横着下，推动它们的东西远在画外；空荡的庭院里，老僧闭目而立，只有袍角被扯向东方。

### 3. 切线型

- **观众的感受**：一刀下去，世界被分成两半，事后才反应过来。
- **必写**：① 那道线从哪条边进、哪条边出（两头都出画）；② 被切过的东西怎样错位或滑落；③ 出刀者在线的哪一头。
- **线的画法**：常规画风里用最亮的一道光；高风格化画风里，也可以用一条什么都不画的空隙来表现。

> the cut is a white-hot diagonal from the top-left corner to the bottom-right; on its far side the stone statue's head is already sliding off, and the assassin is a blur at the top-left, sword still level

> 刀痕是一道白热的斜线，从左上角划到右下角；线那头石像的头已经开始滑落，刺客在左上角只剩一道残影，剑还平举着。

### 4. 对冲型

- **观众的感受**：两边都在拼命，胜负悬着。
- **必写**：① 两股力各自的颜色或明暗（冷暖、明暗至少拉开一项）；② 相撞处的样子（被两边挤扁、炸出白光）；③ 各自守住自己那一半。

> two torrents slam together at the centre, electric violet from the left and acid green from the right; where they meet they flatten against each other and flare white, and neither colour gets past the middle

> 左边的电紫和右边的酸绿在中央猛撞，撞在一起的地方被挤扁、炸出白光，两种颜色谁也过不了中线。

### 5. 崩解型

- **观众的感受**：一个本来坚固的东西，在眼前失去形状。
- **必写**：① 被打碎的是什么材质；② 碎片从哪里开始、按什么顺序散开（中心最碎、外圈成块）；③ 有没有碎片朝镜头飞来、冲出画面。
- **材质对照**：石头碎成有棱角的块，金属撕成卷边薄片并崩出铆钉，冰裂成透明尖片，木头断成带纤维的长条。

> the shield is coming apart at the centre of the frame: the finest powder sits right at the point of the blow, larger jagged plates break away around it, a few of them fly past the camera and out of frame, and streaks of motion race between the pieces

## 三、帧型与结构对照

| 帧型 | 画面里有什么 | 结构 | 视线焦点（也是透视汇聚点） |
|---|---|---|---|
| 命中帧 | 攻击打进身体或护具 | 爆心 | 接触点 |
| 斩击帧 | 一刀、一道光贯穿 | 切线 | 线本身，可不设汇聚点 |
| 对轰帧 | 两人／两股能量正面相撞 | 对冲 | 相撞处 |
| 蓄势帧 | 人静止，环境在动 | 压境（蓄势版） | 主体脚下 |
| 威压帧 | 一人承受环境级力量 | 压境 | 主体 |
| 破碎帧 | 盾、墙、兵器碎开 | 崩解 | 碎裂起点 |
| 纯能量帧 | 没有人物，只有能量和碎屑 | 爆心或切线 | 能量源头 |

纯能量帧没有人物当尺子：用碎片的大小和数量分层，越靠近源头碎片越多、越亮。

## 四、碎片

- **能反推来源**：看任何一块碎片的飞行方向，都能找到它是从哪被打出来的。
- **近大远小**：靠近镜头的碎片大，个别冲出画框；远处的成粉。
- **和线条分开写**：碎片、速度线各用一句话描述。
- **数量随档位**：L1–L2 几块，L3–L4 成群，L5 布满画面。

## 五、介质：让冲击在空气里看得见

冲击本身是看不见的，借周围的介质把它显出来。按场景挑一个：

| 介质 | 冲击让它变成什么 | 示范 |
|---|---|---|
| 尘土 | 贴地扩散的一圈尘环，环的边缘清晰 | 一圈尘环从落点贴地推开，把落叶全部掀向外侧 |
| 雨 | 雨幕被打出一个圆形的空洞，雨滴被震成水雾 | 拳风在雨幕里开出一个圆洞，洞的边缘水珠炸成白雾 |
| 水面 | 冲击坑和向外扩散的环形浪 | 水面被砸出一个凹坑，一圈白浪立起 |
| 热浪 | 背景沿着冲击波扭曲、错位 | 爆点周围的空气像玻璃一样扭曲，后面的城墙线条被拧弯 |
| 光线 | 烟尘把光切成一道道光束，光束随冲击波颤动 | 尘雾里的天光被切成数道斜束，冲击波掠过时光束一齐弯折 |
| 碎叶、花瓣、纸片 | 一齐被吹成同一方向的流线 | 满地落叶被吹成一条条指向画外的流线 |

> a ring of dust races outward along the ground from the point of impact, its leading edge sharp as a wall, flipping every fallen leaf to face away from the blow

## 六、证据链：一眼读懂的三层

1. **主动作**占最大面积（拳、刃、巨爪）。
2. **接触区**反差最强（全画最亮或最暗只有这一处）。
3. **飞散与背景**退后，亮度和细节都让位。

缩成手机缩略图后，眼睛第一下落在接触区，就成立了。
