# 成品提示词范例

每条标出：平台、画风、力的结构、档位。按最接近的一条改写人物、场景和画幅，不要整段照搬。平台参数以 `references/model-adapters.md` 为准。

---

## 一、单张冲击帧

### A1｜漫剧命中帧 · 即梦／Seedream · 赛璐璐 · 爆心 · L3

16:9 横构图，赛璐璐动画风格，干净粗描边，平涂双色阴影。黑发少年武者在画面左下，右拳刚刚打进银甲骑士的胸甲中央，拳面压进金属，胸甲以接触点为中心凹陷，裂纹向四周放射。低机位仰拍，拳头和小臂占据前景，骑士上身被打得后仰、披风朝后甩开。接触点是全画最亮的一团硬边白光，碎甲片从接触点向外飞散，近处几片冲出画框。背景在这一刻化为指向接触点的黑白集中线。少年的发型、服装和红色护腕保持参考图设定，两人轮廓分开，只有一只出拳的手。

### A2｜巨兽压镜 · Midjourney V8 · 赛璐璐厚涂 · 爆心 · L4

```text
Anime key frame with painterly cel shading. Worm's-eye view from a lens resting just above a cracked stone plaza: fissures and upturned paving stones sweep from the lower border toward one spot in the middle distance, and on that spot stands a lone swordswoman in a white coat, blade lifted. A colossal armoured fist is coming down from above, so close that it is cropped by the top and both sides of the frame; one rivet on its knuckle plate is taller than she is. A split second before contact, the air under the fist has been squashed into a flat ring that is shoving the dust away from her in every direction. Heavy dust blurs the rear of the gauntlet, and the only strong light is a hot rim along the knuckles. Three colours only: charcoal for everything large, warm white for the rim light and her blade, furnace orange reserved for the flying grit. --ar 16:9 --raw
```

### A3｜居合一闪 · Midjourney V8 · 刮痕干笔 · 切线 · L5

```text
Dry-brush scratch painting in black and white. A bamboo grove at night has just been cut in a single stroke: a white-hot diagonal runs from the lower-left corner to the upper-right corner, and the upper halves of the stalks above it are beginning to slide off. The swordsman kneels at the lower-left, already sheathing his sword, drawn with four or five bold gestural strokes and one glint for the eye. Rough bristle texture inside every stroke, split stroke tails, angular bamboo chips spinning in the air, no gradients, the cut itself is the brightest stroke in the image. --ar 21:9 --raw --no grey
```

### A4｜写实重拳 · Nano Banana Pro · 写实电影 · 爆心 · L3

```text
Use image 1 only for the boxer on the left: keep his face, tattoos, red gloves and black shorts exactly as shown. Use image 2 only for the opponent's look. Photoreal live-action frame, 35mm lens, low angle from ring level, night arena with hard overhead light. The exact instant the left boxer's right glove lands on the opponent's raised forearm guard: the glove leather is visibly compressed, the guard is driven back into the opponent's cheek, his weight is tipping onto his back foot and his front heel has just lifted. Sweat droplets burst off the point of contact in a backward fan, frozen mid-air, each catching the overhead light. The point of contact is the brightest spot in the frame; the crowd behind falls into deep shadow. 16:9.
```

### A5｜能量对轰 · 通用中文 · 赛璐璐 · 对冲 · L4

16:9，赛璐璐动画风格。中景，红衣剑士在左、黑袍术士在右，两人同时把力量推向画面中央：左边是电紫色的雷流，右边是酸绿色的毒焰，两股力在中央相撞，撞在一起的地方被挤扁、炸成全画最亮的白。紫色只在左半，绿色只在右半，谁也过不了中线。地面裂缝从两人脚下一路收向中央交界点，碎石被两股气流掀起、悬在半空。两人的服装与武器保持设定，轮廓清楚分开。

### A6｜蓄势 · 即梦 · 水墨武侠 · 压境（将发未发）· L3

竖构图 9:16，水墨武侠风格，墨色浓淡分层，飞白笔触。白衣剑客独立在断崖正中，剑尚未出鞘，人一动不动。崖上的长草、衣摆、远处的松枝、细雨全部朝画面右侧压倒，像被看不见的力按住；剑客脚边的落叶和浮尘一圈圈向外剥开。四周大面积留白，只在剑客身上和脚下用最重的墨。画面安静，压力在空气里。

### A7｜破盾 · 通用英文 · 3D 游戏 CG · 崩解 · L4

```text
Stylized 3D game cinematic, PBR materials. A knight's tower shield is coming apart at the centre of the frame under a war-hammer blow: the densest burst of fragments sits right at the point of impact, large jagged steel plates fly toward the camera and out of frame, smaller shards spray behind them, and orange spark trails race between the pieces. The knight's arm is thrown wide, the shield strap still hanging from his forearm. A tight bloom of light sits only at the point of impact. Low three-quarter angle, 16:9.
```

---

## 二、视频击点

### B1｜盾反 · Seedance 2.0 · 赛璐璐 · 8 秒

```text
@Image1 只提供铁甲护卫的外观和盾牌；@Image2 只提供持矛掠袭者的外观。8 秒，16:9，硬朗赛璐璐动画，粗描边，平涂阴影。侧面中景，护卫在画面左边，掠袭者从右侧逼近。护卫前脚踏稳、左手持盾，掠袭者水平刺来；护卫把盾面移进刺击路线，矛尖撞上盾面被导向外侧，第一次接触保持正常画面。掠袭者再次前压，护卫顺势用盾缘短促顶向他的胸甲，盾缘真正撞上胸甲的瞬间，画面变成一帧黑白硬轮廓冲击，接触点清楚，背景只在这一下简化成集中线；随即恢复深蓝夜景。掠袭者上身后仰，右脚后撤一步稳住，护卫收盾保持戒备。镜头始终在同一侧，两人不交换左右位置，武器不凭空增减。不要 BGM，不要字幕。
```

后期：剪好后在盾缘撞上胸甲的那一秒用 `heavy`，例如 `--at 5.6 --recipe heavy --focus 0.55,0.45`。

### B2｜三连击 · 可灵 3.0 · 动画 · 多镜头 12 秒

```text
人物：青衣少女刀客（短发、青色短打、右手持直刀）；黑甲巨汉（光头、黑色重甲、双手持狼牙棒）。两人描述在所有镜头里保持一致。赛璐璐动画风格，粗描边。
镜头一（3 秒）：侧面全景，巨汉从右向左横扫狼牙棒，少女后跳半步，棒头擦着她的刀背划过，火花从刀背与棒头相擦处飞出。镜头稳定。
镜头二（3 秒）：低机位，少女落地瞬间前冲，刀从左下向右上斜撩，刀刃砍进巨汉左肩甲，肩甲裂开一道口子；巨汉身体被带得一歪，左脚后滑。镜头跟随少女前冲。
镜头三（4 秒）：近景，巨汉怒吼着双手高举狼牙棒砸下，少女侧身，棒头砸进她身旁的石板，石板以落点为中心碎裂、碎石弹起；镜头在砸中瞬间停住半秒。
镜头四（2 秒）：中景，少女借碎石弹起的一瞬从巨汉身侧穿过，收刀；巨汉胸甲上一道斜线慢慢亮起、裂开，他单膝跪下。镜头静止。
```

后期击点表：镜头二砍中 `light`，镜头三砸地 `heavy`，镜头四胸甲裂开 `crit`（一场只用这一次）。

### B3｜首尾帧保护动画风 · Veo 3.1 · 6 秒

```text
Use the first frame and last frame as provided. 2D hand-drawn anime look throughout: clean line art, flat cel shading, stable character design, no photorealistic texture, no extra movement beyond what is described. From the first frame, the red-haired fighter on the left steps in and drives a straight punch into the masked opponent's raised forearm guard; at the exact moment of contact the whole frame flashes to stark black-and-white for an instant, then returns to the original colours. The opponent slides back half a step on the wet street and ends in the guarded stance shown in the last frame. The camera stays on the same side; the two never swap screen positions.
```

### B4｜写实坍塌 · 通用中文 · 10 秒

```text
10 秒，电影级实拍质感，广角固定机位。前景是桥底两名工人正在撤离，远景桥墩上的裂纹逐渐扩展，混凝土里的钢筋外露。一辆重型卡车撞上桥墩底部：接触区的碎块先弹出，紧接着桥面局部失去支撑开始下沉，粉尘一层层扩散，远处的结构晚半拍才响应。重击用接触点瞬间的局部高亮、真实的混凝土碎裂和低频声压表达，不加动漫速度线。镜头保留桥梁和车辆的尺度关系，烟尘从破坏点逐渐蔓延。结尾桥面已明显下沉，工人仍沿原方向逃离，前面的破坏不复原。
```

后期：撞击那一秒用 `cinema`，桥面下沉开始时再加一次 `light`。

---

## 三、修复前后

**原提示词**："两个剑客激烈打斗，刀光剑影，超级震撼，冲击感拉满，黑白冲击帧。"

**诊断**：没有接触点、没有结构、没有恢复条件，模型只能随机挥舞，黑白可能贯穿全程。

**替换提示词**：

```text
8 秒，16:9，赛璐璐动画，粗描边。雨夜屋顶，侧面中景。白衣剑客在左，黑衣剑客在右，各自双手握刀。黑衣剑客从右上向左下劈砍，白衣剑客横刀格挡，两把刀刃在两人之间相交，火花沿刃面向两侧喷出；刀刃相交的那一瞬画面变成一帧黑白硬剪影，随后恢复雨夜的深蓝色。白衣剑客借格挡的力把对方的刀压向外侧，脚下踩碎一片瓦，黑衣剑客后撤一步稳住。两人始终一左一右，刀不换手，镜头不越轴。不要 BGM，不要字幕。
```

**怎么判断修好了**：缩略图里能看到两把刀相交的位置；黑白只出现一瞬；结尾两人位置和起始时一致。
