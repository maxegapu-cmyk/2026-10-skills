# Camera Storyboard Director v2.1.1

把剧本、片段或已有镜头表写成可执行的导演分镜。保留通用调度、空间、相机与剪辑能力，深化青春心动、暧昧拉扯、成熟关系三个分支。每个项目明确画幅，只交分镜及必要说明。

## 使用

将完整的 `camera-storyboard-director` 文件夹放入目标工具的技能目录。替换前保留旧目录副本，再整体替换，避免旧参考文件残留。本次提供文件夹与ZIP，没有自动安装。

> 用 $camera-storyboard-director，画幅9:16，把下面片段做成青春心动分镜。要有一次有理由的短慢动作，明确进入、观看细节与退出，只给分镜。

> 画幅2.39:1，保留这场对话的全部台词，深化成熟关系。人物保持原位，可以比较固定与轻微靠近的观看差异，最后只交你选中的方案。

> 把这段参考视频拆成镜头，记录实际观察范围和相邻关系；看不清或没覆盖的部分标出来。

## 本次修补

- 纠正证据：撤回v2.1.0“14段完整观看／镜头组分析完成”的结论。旧记录只有局部画面线索，本次没有重新观看视频。
- 改为条件选择：内部先安排空间不代表成片必须先给全景；可先展示人物、后揭示看者，人物静止也可移动相机。
- 补同剧情对照：同样的16:9、20秒归还笔记，分别用5镜、4镜和1镜组织观看，明确哪些变量改变及其限制。
- 补带对白场景：四镜30秒的门厅约定，写出完整对白、画外回答、相机靠近与动作接续。
- 增加观察覆盖和逐镜证据规范；分开参考研究、日常分镜和经授权的技能维护。
- 修正评测状态：历史走查、本轮走查、未运行的独立调用分开记录。

默认交付仍为项目条件与六列分镜表：镜号／成片时长、景别机位构图、人物动作视线、运镜焦点、时间处理、剪辑与必要声音。完整对照、多方案、JSON和详细镜头卡均按需。

## 文件导航

- [主流程](SKILL.md)
- [偶像剧选择方法](references/romance-direction.md)与[时间设计](references/time-design.md)
- [同剧情三版对照](examples/same-scene-camera-variants.md)与[带对白完整走查](examples/dialogue-walkthrough.md)
- [视频证据规范](references/video-evidence.md)与[14项历史线索的当前状态](references/kdrama-case-breakdown.md)
- [15张外部研究线索卡](references/case-library.md)：本轮未重核外部来源，证据边界逐卡保留
- [输出约定](references/output-contract.md)、[自检](references/quality-gates.md)、[验证记录](evals/validation.md)
- [行为走查](evals/walkthrough.md)与[待执行独立调用](evals/runtime-bench.md)

## 可选结构检查

仅需Python 3.10+标准库：

```bash
PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s scripts -p 'test_*.py' -q
python3 scripts/validate_board.py examples/shotlist.json
python3 scripts/validate_board.py assets/shot-schema-example.json
```

JSON仍为v2结构。检查器验证字段、时间轴和部分连续性声明，不证明真实空间、来源事实或情绪效果。普通分镜创作不需要生成工具、视频平台账户或联网。

## 交付状态

这是规则、证据表述与示例的修补版，适合继续试用并收集读镜反馈。真实检查结果见验证记录；独立模型调用、实拍和观众比较未执行。此前要求完整观看14段视频并逐镜拆解的任务仍未完成，不能因为规则已修复就算完成。
