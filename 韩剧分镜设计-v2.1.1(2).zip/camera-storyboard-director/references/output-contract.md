# 分镜输出契约 v2

## 默认交付

1. 一行：本项目画幅、成片总长（用户指定或暂定）、本场观看目标；仅有必要时说明关系假设。
2. 分镜表。
3. 只有执行确实需要时补空间示意、关键镜细化、导演建议或低复杂度替代。

用户只要表格则合并 1、3 到表头和单元格。内部分析、案例研究和质量检查不自动外显。故事板可以包含必要声画衔接，不能扩成配乐方案或提示词包。

## 六列表

| 字段 | 最低内容 |
|---|---|
| 镜号／成片时长 | 保留原编号；写秒数或区间；总和可核对 |
| 景别、机位与画幅构图 | 相机在哪一侧、主体和关系如何落在画面中；关键手部／视线是否看得见 |
| 人物位置、动作与视线 | 演员动作及起止；不是心理形容词 |
| 运镜与焦点 | 固定或起点→路径→终点；触发与节奏；焦点变化单写 |
| 时间处理 | 实时、停留、整镜慢动作、局部变速；非实时写入口、细节、出口 |
| 剪辑与必要声音 | 切口、接向下一镜的动作／视线／声音；对白保留原文 |

心动重点写在对应单元格末尾：“心动点：原本忙碌的人停下来专心看她。”这必须与画面一致，不是额外旁白。

## 详细镜头卡（按需）

- 原文证据／剧情节点；导演新增动作单独标识。
- 观看对象、观看收益、视点及关系变化。
- 构图、轴线、屏幕方向、前中后景。
- 演员位置／动作／视线与摄影机路径分开。
- 起止状态：位置、朝向、手与道具、机位侧。
- 时间处理：动作经过时间、成片时间、倍率（已定时）、进出点。
- 衔接类型及切口；对白或必要声场。
- 难拍处的替代，保留相同观看收益。

## 可选 JSON

只有用户需要结构化交付时输出。`assets/shot-schema-example.json` 是**有效数据样例**，不是完整 JSON Schema；`scripts/validate_board.py` 定义可机检的结构。无 JSON 需求时不让用户承担这些字段。

v2 使用秒数和半开区间 `[start_s, end_s)`；相邻镜头时间紧接，首镜从 0 开始，末镜结束等于总时长。精确性用于剪辑计划，不表示已拍成素材。

顶层只有 `meta` 和 `shots`：

- `meta`：`schema_version: "2.0"`、`title`、`aspect_ratio`（正数冒号比例，如 9:16、2.39:1）、`aspect_ratio_source: "user"`、`duration_s`、`duration_status: "specified" | "provisional"`。
- `shots`：每镜 `id`、`start_s`、`end_s`、`story_beat`、`viewer_gain`、`shot_size`、`composition`、`axis_id`、`axis_reset`、`screen_direction`、`actor_path`、`start_state`、`end_state`、`camera`、`time`、`handoff`。
- 可选：`axis_reset_bridge`、`direction_change_reason`、`dialogue`、`sound`、`director_suggestion`、`fallback`。
- `camera`：`move`、`origin`、`path`、`destination`、`trigger`、`speed`、`purpose`、`depth_layers`、`focus`，均非空文本。固定机位写“固定，无位移”等真实状态。
- `time`：`mode: "realtime" | "hold" | "slow" | "ramp"`，`entry`、`focus_detail`、`exit`、`sound_plan` 均有内容。匀速可选 `playback_rate` 与 `action_duration_s`；若给两者则应与成片时间一致。
- `time.mode: hold` 表示真实时间的延迟剪切，不是冻结帧。
- `time.mode: ramp` 可选 `segments`，每段 `duration_s`＋`playback_rate`，表示分段恒速计划；时长和须等于本镜。真正平滑曲线只在文字进出点说明，数值不确定就不填倍率。
- 可选 `time.capture`：仅 `method: "high_fps_conform"` 时使用，含 `capture_fps`、`timeline_fps`；只配 `slow` 与已定 `playback_rate`。这是拍摄建议而非原片技术事实。
- 景别：`ECU/CU/MCU/MS/MLS/WS/EWS/OTS/POV/INSERT`；屏幕方向：`L2R/R2L/STATIC/DEPTH/NA`。
- 衔接：`cut/cut-on-action/match-cut/continuous/sound-bridge/hold`＋非空 `to_next`。末镜使用 `hold` 说明结束。

`aspect_ratio_source` 只是声明，不证明用户真的确认；行为走查仍要检查输入。工具不能识别自然语言中的所有新增剧情、画幅构图错误或不合理表演。

不接受 v1 的 `model`、`first_frame_prompt`、`video_prompt` 等字段。旧 JSON 需要按 v2 重新导出，不能只删除两条提示词就视为完成迁移。

## 连续性机检边界

- 同轴相邻镜从左向右变右向左，需要写明画内转身、相反方向运动的不同人物、反向视点等 `direction_change_reason`；或声明跨轴并给桥接说明。方向改变不自动等于跳轴。
- 相邻 `axis_id` 变更时用 `axis_reset: true` 与 `axis_reset_bridge` 说明重新建立空间；切换场次也可以在此说明，不能静悄悄换轴。
- `continuous` 是同一拍摄的连续段落，前段 `end_state` 和后段 `start_state` 用相同文本锚点；仍须人工核对摄影机路径真的接得上。
- 不机检“心动是否有效”，不把文字形式完整当作空间、表演或镜头美感已经通过。
