#!/usr/bin/env python3
"""Validate v2 storyboard data with Python 3.10+ standard library.

Checks structure, timeline, timing math and declared continuity anchors.
Does not validate natural-language geometry, source truth or emotional effect.
Exit codes: 0 valid; 1 validation errors; 2 unreadable input/usage.
"""
from __future__ import annotations

import json
import math
import re
import sys
from pathlib import Path

SHOT_SIZES = {"ECU", "CU", "MCU", "MS", "MLS", "WS", "EWS", "OTS", "POV", "INSERT"}
DIRECTIONS = {"L2R", "R2L", "STATIC", "DEPTH", "NA"}
HANDOFFS = {"cut", "cut-on-action", "match-cut", "continuous", "sound-bridge", "hold"}
CAMERA_KEYS = {
    "move", "origin", "path", "destination", "trigger", "speed",
    "purpose", "depth_layers", "focus",
}
TIME_KEYS = {
    "mode", "entry", "focus_detail", "exit", "sound_plan", "playback_rate",
    "action_duration_s", "segments", "capture",
}
SHOT_TEXT = {
    "story_beat", "viewer_gain", "composition", "axis_id", "actor_path",
    "start_state", "end_state",
}
SHOT_OPTIONAL = {
    "axis_reset_bridge", "direction_change_reason", "dialogue",
    "sound", "director_suggestion", "fallback",
}
SHOT_KEYS = SHOT_TEXT | SHOT_OPTIONAL | {
    "id", "start_s", "end_s", "shot_size", "axis_reset",
    "screen_direction", "camera", "time", "handoff",
}
META_KEYS = {
    "schema_version", "title", "aspect_ratio", "aspect_ratio_source",
    "duration_s", "duration_status",
}


def text(value: object) -> bool:
    return isinstance(value, str) and bool(value.strip())


def number(value: object, *, positive: bool = False) -> bool:
    if type(value) not in (int, float):
        return False
    try:
        return math.isfinite(value) and (value > 0 if positive else True)
    except OverflowError:
        return False


def member(value: object, options: set[str]) -> bool:
    return isinstance(value, str) and value in options


def close(a: float, b: float) -> bool:
    return math.isclose(a, b, rel_tol=1e-9, abs_tol=1e-6)


def unknown(obj: dict, allowed: set[str], tag: str, errors: list[str]) -> None:
    for key in obj:
        if key not in allowed:
            errors.append(f"{tag} 未支持字段：{key}；v2 不接受提示词或模型执行字段")


def require_text(obj: dict, keys: set[str], tag: str, errors: list[str]) -> None:
    for key in sorted(keys):
        if not text(obj.get(key)):
            errors.append(f"{tag}.{key} 需要非空文字")


def validate_time(value: object, duration: float | None, tag: str, errors: list[str]) -> None:
    if not isinstance(value, dict):
        errors.append(f"{tag} 必须为对象")
        return
    unknown(value, TIME_KEYS, tag, errors)
    require_text(value, {"entry", "focus_detail", "exit", "sound_plan"}, tag, errors)
    mode = value.get("mode")
    if not member(mode, {"realtime", "hold", "slow", "ramp"}):
        errors.append(f"{tag}.mode 无效")
        return
    rate = value.get("playback_rate")
    rate_ok = number(rate, positive=True)
    if "playback_rate" in value and not rate_ok:
        errors.append(f"{tag}.playback_rate 必须为有限正数")
    if mode in ("realtime", "hold") and rate_ok and not close(rate, 1):
        errors.append(f"{tag} 实时/停留的 playback_rate 必须为 1")
    if mode == "slow" and rate_ok and rate >= 1:
        errors.append(f"{tag} slow 的 playback_rate 必须小于 1")

    action = value.get("action_duration_s")
    if "action_duration_s" in value and not number(action, positive=True):
        errors.append(f"{tag}.action_duration_s 必须为有限正数")
    expected = None
    if mode in ("realtime", "hold") and duration is not None:
        expected = duration
    elif mode == "slow" and rate_ok and duration is not None:
        expected = duration * rate

    if mode == "ramp":
        if "playback_rate" in value:
            errors.append(f"{tag} ramp 不能用单一 playback_rate，使用 segments 或文字曲线")
        if "segments" in value:
            segments = value["segments"]
            if not isinstance(segments, list) or len(segments) < 2:
                errors.append(f"{tag}.segments 至少需要两个恒速段")
            else:
                total, action_total, valid_segments = 0.0, 0.0, True
                for j, segment in enumerate(segments):
                    st = f"{tag}.segments[{j}]"
                    if not isinstance(segment, dict):
                        errors.append(f"{st} 必须为对象")
                        valid_segments = False
                        continue
                    unknown(segment, {"duration_s", "playback_rate"}, st, errors)
                    sd, sr = segment.get("duration_s"), segment.get("playback_rate")
                    if not number(sd, positive=True) or not number(sr, positive=True):
                        errors.append(f"{st} 时长和倍率必须为有限正数")
                        valid_segments = False
                        continue
                    total += sd
                    action_total += sd * sr
                if valid_segments:
                    expected = action_total
                    if duration is not None and not close(total, duration):
                        errors.append(f"{tag}.segments 时长和不等于镜头成片时长")
    elif "segments" in value:
        errors.append(f"{tag}.segments 仅用于 ramp")

    if number(action, positive=True):
        if expected is None:
            errors.append(f"{tag} 动作时间缺少可计算的倍率或分段依据")
        elif not close(action, expected):
            errors.append(f"{tag}.action_duration_s 与成片时长及倍率不符")
    if "capture" in value:
        capture = value["capture"]
        if not isinstance(capture, dict):
            errors.append(f"{tag}.capture 必须为对象")
            return
        unknown(capture, {"method", "capture_fps", "timeline_fps"}, f"{tag}.capture", errors)
        cf, tf = capture.get("capture_fps"), capture.get("timeline_fps")
        if capture.get("method") != "high_fps_conform" or mode != "slow":
            errors.append(f"{tag}.capture 仅用于 slow 的 high_fps_conform")
        if not number(cf, positive=True) or not number(tf, positive=True):
            errors.append(f"{tag}.capture 帧率必须为有限正数")
        elif cf <= tf or not rate_ok or not close(tf / cf, rate):
            errors.append(f"{tag}.capture 采集/时间线帧率与 playback_rate 不符")


def validate(board: object) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    warnings: list[str] = []
    if not isinstance(board, dict):
        return ["顶层必须为 JSON 对象"], warnings
    unknown(board, {"meta", "shots"}, "board", errors)
    meta, shots = board.get("meta"), board.get("shots")
    if not isinstance(meta, dict):
        return errors + ["缺少 meta 对象"], warnings
    unknown(meta, META_KEYS, "meta", errors)
    require_text(meta, {"title"}, "meta", errors)
    if meta.get("schema_version") != "2.0":
        errors.append("meta.schema_version 必须为 2.0；旧数据需迁移")
    ratio = meta.get("aspect_ratio")
    ratio_ok = False
    if isinstance(ratio, str) and re.fullmatch(r"\d+(?:\.\d+)?:\d+(?:\.\d+)?", ratio):
        width, height = (float(x) for x in ratio.split(":"))
        ratio_ok = number(width, positive=True) and number(height, positive=True)
    if not ratio_ok:
        errors.append("meta.aspect_ratio 需要正数比例，例如 9:16 或 2.39:1")
    if meta.get("aspect_ratio_source") != "user":
        errors.append("meta.aspect_ratio_source 必须声明 user；不能自动猜画幅")
    if not member(meta.get("duration_status"), {"specified", "provisional"}):
        errors.append("meta.duration_status 必须为 specified 或 provisional")
    total = meta.get("duration_s")
    if not number(total, positive=True):
        errors.append("meta.duration_s 必须为有限正数")
    if not isinstance(shots, list) or not shots:
        return errors + ["shots 必须为非空数组"], warnings
    ids: set[str] = set()
    previous = None
    for i, shot in enumerate(shots):
        tag = f"shot[{i}]"
        if not isinstance(shot, dict):
            errors.append(f"{tag} 必须为对象")
            previous = None
            continue
        unknown(shot, SHOT_KEYS, tag, errors)
        sid = shot.get("id")
        if not text(sid):
            errors.append(f"{tag}.id 需要非空文字")
        elif sid in ids:
            errors.append(f"{tag}.id 重复：{sid}")
        if text(sid):
            ids.add(sid)
        start, end = shot.get("start_s"), shot.get("end_s")
        valid_interval = number(start) and number(end) and 0 <= start < end
        duration = end - start if valid_interval else None
        if not valid_interval:
            errors.append(f"{tag} 需要有限且有效的区间 [start_s, end_s)")
        if i == 0 and (not number(start) or not close(start, 0)):
            errors.append(f"{tag} 时间线须从 0 秒开始")
        if previous is not None:
            previous_end = previous.get("end_s")
            if number(start) and number(previous_end) and not close(start, previous_end):
                errors.append(f"{tag} 与上一镜时间重叠或空洞")
        require_text(shot, SHOT_TEXT, tag, errors)
        require_text(shot, SHOT_OPTIONAL & shot.keys(), tag, errors)
        if not member(shot.get("shot_size"), SHOT_SIZES):
            errors.append(f"{tag}.shot_size 无效")
        direction = shot.get("screen_direction")
        if not member(direction, DIRECTIONS):
            errors.append(f"{tag}.screen_direction 无效")
        axis, reset = shot.get("axis_id"), shot.get("axis_reset")
        if type(reset) is not bool:
            errors.append(f"{tag}.axis_reset 必须为 boolean")
        if reset is True and not text(shot.get("axis_reset_bridge")):
            errors.append(f"{tag} 跨轴/重新建立空间必须解释桥接")
        if previous is not None:
            prev_direction, prev_axis = previous.get("screen_direction"), previous.get("axis_id")
            if (member(direction, {"L2R", "R2L"}) and member(prev_direction, {"L2R", "R2L"})
                    and direction != prev_direction and axis == prev_axis and reset is False
                    and not text(shot.get("direction_change_reason"))):
                errors.append(f"{tag} 方向逆转须说明人物转身/视点变化或跨轴桥接")
            if text(axis) and text(prev_axis) and axis != prev_axis and reset is False:
                errors.append(f"{tag} axis_id 改变须声明重新建立空间")
            handoff_before = previous.get("handoff")
            if isinstance(handoff_before, dict) and handoff_before.get("type") == "continuous":
                if not text(shot.get("start_state")) or previous.get("end_state") != shot["start_state"]:
                    errors.append(f"{tag} continuous 的前后状态锚点不一致")
        camera = shot.get("camera")
        if not isinstance(camera, dict):
            errors.append(f"{tag}.camera 必须为对象")
        else:
            unknown(camera, CAMERA_KEYS, f"{tag}.camera", errors)
            require_text(camera, CAMERA_KEYS, f"{tag}.camera", errors)
            move = str(camera.get("move", "")).strip().lower()
            if move not in {"locked", "static", "none", "固定"}:
                if camera.get("trigger") in ("无", "none", "无明确触发"):
                    warnings.append(f"{tag} 运镜缺可观察触发，需人工检查")
                if "360" in move:
                    warnings.append(f"{tag} 全周环绕需人工确认空间与观看收益")
        validate_time(shot.get("time"), duration, f"{tag}.time", errors)
        handoff = shot.get("handoff")
        if not isinstance(handoff, dict):
            errors.append(f"{tag}.handoff 必须为对象")
        else:
            unknown(handoff, {"type", "to_next"}, f"{tag}.handoff", errors)
            if not member(handoff.get("type"), HANDOFFS) or not text(handoff.get("to_next")):
                errors.append(f"{tag}.handoff 需要有效 type 与 to_next")
            if i == len(shots) - 1 and handoff.get("type") != "hold":
                errors.append(f"{tag} 末镜 handoff 应为 hold 并说明结束")
        previous = shot
    if isinstance(shots[-1], dict) and number(total, positive=True):
        last_end = shots[-1].get("end_s")
        if not number(last_end) or not close(last_end, total):
            errors.append("末镜结束时间与 meta.duration_s 不符")
    return errors, warnings


def main(args: list[str]) -> int:
    if len(args) != 1:
        print("用法: python scripts/validate_board.py <storyboard.json>", file=sys.stderr)
        return 2
    try:
        board = json.loads(Path(args[0]).read_text(encoding="utf-8"))
    except (OSError, ValueError, UnicodeError) as exc:
        print(f"ERROR 输入不可读：{exc}", file=sys.stderr)
        return 2
    errors, warnings = validate(board)
    for warning in warnings:
        print("WARN:", warning)
    for error in errors:
        print("ERROR:", error)
    print(f"结果: {len(errors)} error(s), {len(warnings)} warning(s)")
    if not errors:
        print("PASS: 结构/时间线/部分声明通过；不证明原文落实、空间真实或心动效果。")
    return 1 if errors else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
