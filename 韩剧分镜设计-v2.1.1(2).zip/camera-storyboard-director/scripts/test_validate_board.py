"""Regression tests for v2 output boundaries and timing/continuity checks."""
import copy
import json
import math
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from validate_board import validate


class StoryboardTests(unittest.TestCase):
    def setUp(self):
        self.board = json.loads((ROOT / "examples/shotlist.json").read_text(encoding="utf-8"))

    def invalid(self, needle):
        errors, _ = validate(self.board)
        self.assertTrue(any(needle in item for item in errors), errors)

    def test_examples_valid(self):
        for path in (ROOT / "examples/shotlist.json", ROOT / "assets/shot-schema-example.json"):
            with self.subTest(path=path.name):
                self.assertEqual(([], []), validate(json.loads(path.read_text(encoding="utf-8"))))

    def test_missing_ratio(self):
        del self.board["meta"]["aspect_ratio"]
        self.invalid("aspect_ratio")

    def test_ratio_not_assumed(self):
        self.board["meta"]["aspect_ratio_source"] = "default"
        self.invalid("不能自动猜画幅")

    def test_bad_ratios(self):
        for ratio in ("竖屏", "0:16", "-1:2", "16/9", {}, "nan:1"):
            with self.subTest(ratio=ratio):
                self.board["meta"]["aspect_ratio"] = ratio
                self.invalid("aspect_ratio")

    def test_decimal_ratio_valid(self):
        self.board["meta"]["aspect_ratio"] = "2.39:1"
        self.assertEqual([], validate(self.board)[0])

    def test_forbidden_prompt_and_model_fields(self):
        for target, key in (
            ("meta", "model"), ("shot", "video_prompt"),
            ("shot", "first_frame_prompt"), ("camera", "negative_prompt"),
        ):
            with self.subTest(key=key):
                board = copy.deepcopy(self.board)
                obj = board["meta"] if target == "meta" else board["shots"][0]
                if target == "camera":
                    obj = obj["camera"]
                obj[key] = "legacy"
                self.assertTrue(any(key in e for e in validate(board)[0]))

    def test_bad_total(self):
        self.board["meta"]["duration_s"] += 1
        self.invalid("末镜结束")

    def test_gap_and_overlap(self):
        for offset in (-0.2, 0.2):
            with self.subTest(offset=offset):
                board = copy.deepcopy(self.board)
                board["shots"][1]["start_s"] += offset
                self.assertTrue(any("重叠或空洞" in e for e in validate(board)[0]))

    def test_finite_numeric_time(self):
        for bad in (True, False, "3", math.nan, math.inf, -1, 10**500):
            with self.subTest(value=str(bad)[:12]):
                self.board["shots"][0]["start_s"] = bad
                self.invalid("区间")

    def test_duplicate_id(self):
        self.board["shots"][1]["id"] = self.board["shots"][0]["id"]
        self.invalid("重复")

    def test_malformed_shapes_do_not_crash(self):
        for bad in (None, [], "x", True, 5):
            with self.subTest(bad=bad):
                self.assertTrue(validate(bad)[0])
                board = copy.deepcopy(self.board)
                board["shots"][0] = bad
                self.assertTrue(validate(board)[0])
        for key in ("id", "shot_size", "screen_direction"):
            board = copy.deepcopy(self.board)
            board["shots"][0][key] = {}
            self.assertTrue(validate(board)[0])
        self.board["shots"][0]["handoff"]["type"] = []
        self.invalid("handoff")

    def test_missing_camera_path(self):
        self.board["shots"][0]["camera"]["path"] = ""
        self.invalid("camera.path")

    def test_direction_reversal_requires_reason(self):
        self.board["shots"][0]["screen_direction"] = "L2R"
        self.board["shots"][1]["screen_direction"] = "R2L"
        self.invalid("方向逆转")

    def test_visible_turn_is_not_automatically_axis_cross(self):
        self.board["shots"][0]["screen_direction"] = "L2R"
        self.board["shots"][1]["screen_direction"] = "R2L"
        self.board["shots"][1]["direction_change_reason"] = "角色在画内转身，开始返回"
        self.assertEqual([], validate(self.board)[0])

    def test_axis_bridge_required_in_first_shot_too(self):
        self.board["shots"][0]["axis_reset"] = True
        self.invalid("解释桥接")

    def test_axis_change_declared(self):
        self.board["shots"][1]["axis_id"] = "NEW_AXIS"
        self.invalid("重新建立空间")

    def test_continuous_state_anchors(self):
        self.board["shots"][0]["handoff"]["type"] = "continuous"
        self.invalid("状态锚点")
        self.board["shots"][1]["start_state"] = self.board["shots"][0]["end_state"]
        self.assertEqual([], validate(self.board)[0])

    def test_slow_rate_must_be_slow(self):
        self.board["shots"][2]["time"]["playback_rate"] = 2
        self.invalid("小于 1")

    def test_slow_action_duration(self):
        self.board["shots"][2]["time"]["action_duration_s"] = 3
        self.invalid("倍率不符")

    def test_unknown_slow_rate_allowed_without_false_precision(self):
        timing = self.board["shots"][2]["time"]
        timing.pop("playback_rate")
        timing.pop("action_duration_s")
        self.assertEqual([], validate(self.board)[0])

    def test_realtime_hold_not_slow_motion(self):
        self.board["shots"][0]["time"].update(mode="hold", playback_rate=0.5)
        self.invalid("必须为 1")

    def test_slow_missing_entry_rejected(self):
        self.board["shots"][2]["time"]["entry"] = ""
        self.invalid("time.entry")

    def test_high_fps_conform_math(self):
        timing = self.board["shots"][2]["time"]
        timing["capture"] = {"method": "high_fps_conform", "capture_fps": 48, "timeline_fps": 24}
        self.assertEqual([], validate(self.board)[0])
        timing["capture"]["capture_fps"] = 60
        self.invalid("采集/时间线帧率")

    def test_ramp_piecewise_time(self):
        timing = self.board["shots"][2]["time"]
        timing.pop("playback_rate")
        timing.update(
            mode="ramp", action_duration_s=2,
            segments=[{"duration_s": 1, "playback_rate": 1}, {"duration_s": 2, "playback_rate": 0.5}],
        )
        self.assertEqual([], validate(self.board)[0])
        timing["segments"][1]["duration_s"] = 3
        self.invalid("时长和")

    def test_invalid_time_objects_do_not_crash(self):
        for field, value in (("mode", {}), ("segments", [None, {}]), ("capture", []), ("playback_rate", {})):
            with self.subTest(field=field):
                board = copy.deepcopy(self.board)
                board["shots"][2]["time"][field] = value
                self.assertTrue(validate(board)[0])

    def test_cli_rejects_unreadable_json(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "broken.json"
            path.write_text("{invalid", encoding="utf-8")
            result = subprocess.run(
                [sys.executable, str(ROOT / "scripts/validate_board.py"), str(path)],
                capture_output=True, text=True,
            )
            self.assertEqual(2, result.returncode)
            self.assertIn("输入不可读", result.stderr)

    def test_empty_and_missing_objects(self):
        for key, value in (("meta", None), ("shots", []), ("shots", {})):
            board = copy.deepcopy(self.board)
            board[key] = value
            self.assertTrue(validate(board)[0])

    def test_end_handoff(self):
        self.board["shots"][-1]["handoff"]["type"] = "continuous"
        self.invalid("末镜 handoff")


if __name__ == "__main__":
    unittest.main()
