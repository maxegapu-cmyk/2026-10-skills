/* PAPERLINE Content Studio — offline workspace. No network calls, dependencies or external assets. */
(function () {
  'use strict';
  const KEY = 'paperline-public-writing-studio-v2';
  const FIELDS = ['topic','reader','readerQuestion','promise','ideaNotes','claim','grounds','objection','scope','sources','headline','outline','draft','tone','cta','tags'];
  const CORE = ['topic','reader','readerQuestion','promise','claim','grounds','outline','draft'];
  const STAGES = ['topic','point','write','adapt'];
  const TITLES = {
    topic:['精准选题','先把选题找准','谁会关心？为什么要看？读完能带走什么？','IDEATION'],
    point:['观点与资料','让观点站得稳','一句能讲清的判断，加上真正有力的依据。','ARGUMENT'],
    write:['开始写作','把想法写成内容','从完整的第一版开始，再处理每一个细节。','DRAFTING'],
    adapt:['平台表达','用合适的方式说出来','同一个核心观点，适配不同阅读场景。','FORMATTING']
  };
  const FORMATS = {
    xiaohongshu:['小红书笔记','小红书','小红书 · 场景与实用信息','首屏明确问题，正文使用可扫描段落。真实个人体验要能追溯来源，标签与内容相关即可。'],
    x:['X / 微博短帖','X / 微博','X · 简短而完整的判断','优先在前面交代中心观点，用一个关键理由支撑。字符数仅是编辑参考，实际发布以平台规则为准。'],
    article:['短文章','短文章','短文章 · 一题一篇','标题准确回应读者问题，每一段补充新信息、解释或实例；不要用重复语句凑篇幅。']
  };
  const EXAMPLE = {
    topic:'下班后，怎样让家里不越住越乱？',
    reader:'工作日通勤、每天回家很累的人',
    readerQuestion:'每次想到要把整间屋子收拾干净，就根本不想开始。',
    promise:'提供一个可以立刻尝试的小做法，而不是要求所有人变得极度自律。',
    ideaNotes:'这是教学示范，第一人称内容是假设情景，发布前请用真实经历替换。',
    claim:'比起每天安排大扫除，先给“进门后的一件小整理”找一个固定时刻，可能更容易开始。',
    grounds:'示例：钥匙放在固定托盘；外套及时挂好；杯子放回水槽附近。\n以上仅是写作示意，不是经研究证实的效果数据。',
    objection:'每天作息不规律的人很难固定同一个时间；共居空间也受其他人习惯影响。',
    scope:'作为可尝试的个人经验思路，而不是适用于所有人的效率公式。',
    sources:'教学案例，没有真实研究来源。',
    headline:'下班后懒得整理？不妨先把目标缩成一件小事',
    outline:'开头：下班后累得不想收拾的场景\n中间：将目标拆成可执行的一个动作\n说明：用具体例子让读者知道怎么做\n结尾：交代方法的适用边界',
    draft:'下班回家，看到桌上堆着东西，却一点也不想动手。\n\n如果一想到“今天得收拾整个房间”，就已经觉得累了，不妨把目标缩得更小一点：进门之后，先把钥匙放回固定位置，外套挂好。做完这两件事就算完成，不必每晚都要求自己大扫除。\n\n这只是一个可以尝试的思路。对作息不固定，或和别人共用空间的人来说，也许得先找到更合适的触发时刻。',
    tone:'friendly', cta:'你有什么能坚持的小习惯？', tags:'#居家日常 #生活习惯'
  };
  const $ = id => document.getElementById(id);
  let stage = 'topic';
  let platform = 'xiaohongshu';
  let toastTimeout = 0;
  let canStore = true;

  function value(key) { const el=$(key); return el ? el.value.trim() : ''; }
  function charCount(str) { return Array.from(str || '').length; }
  function report(message) { const n=$('toast'); n.textContent=message; n.classList.add('show'); clearTimeout(toastTimeout); toastTimeout=setTimeout(()=>n.classList.remove('show'),2800); }

  function persist() {
    const obj={format:'paperline-studio',version:2,platform,stage,fields:{}};
    FIELDS.forEach(k=>{ obj.fields[k]=$(k).value; });
    if (canStore) {
      try {localStorage.setItem(KEY,JSON.stringify(obj));$('saveStatus').textContent='● 已保存到本机';}
      catch(_){canStore=false;$('saveStatus').textContent='● 建议导出项目';}
    }
  }
  function repaint() {
    const filled = CORE.filter(k=>value(k).length>0).length;
    $('filledCount').innerHTML=String(filled)+'<small>/8</small>';
    $('progressFill').style.width=(100*filled/CORE.length)+'%';
    const chars=charCount(value('draft'));
    $('charCount').textContent=chars.toLocaleString();
    $('editorCount').textContent=chars.toLocaleString();
    $('platformMetric').textContent=FORMATS[platform][0];
    $('previewType').textContent=FORMATS[platform][1];
    $('platformHelpTitle').textContent=FORMATS[platform][2];
    $('platformHelp').textContent=FORMATS[platform][3];
    $('previewTitle').textContent=value('headline')||'你的标题将显示在这里';
    $('previewBody').textContent=value('draft')||'正文写好之后，就能在这里看到排版预览。它展示内容，不模拟平台的完整实际界面。';
    $('previewTags').textContent=value('tags');
    document.querySelectorAll('[data-platform]').forEach(b=>{const yes=b.dataset.platform===platform;b.classList.toggle('active',yes);b.setAttribute('aria-pressed', String(yes));});
  }
  function changeStage(next, save=true) {
    if(!STAGES.includes(next)) return;
    stage=next;
    document.querySelectorAll('[data-stage]').forEach(n=>{const active=n.dataset.stage===stage;n.classList.toggle('active',active);n.hidden=!active;});
    document.querySelectorAll('[data-nav]').forEach(b=>{const active=b.dataset.nav===stage;b.classList.toggle('active',active); if(active){b.setAttribute('aria-current','step');}else{b.removeAttribute('aria-current');}});
    const idx=STAGES.indexOf(stage),info=TITLES[stage];
    $('crumbName').textContent=info[0];$('stageCode').textContent='STAGE / 0'+(idx+1);
    $('stageTitle').innerHTML='';$('stageTitle').append(document.createTextNode(info[1]));
    const dot=document.createElement('span');dot.className='h2-accent';dot.textContent='.';$('stageTitle').append(dot);
    $('stageSubtitle').textContent=info[2];$('stageBadge').textContent=info[3];
    $('prevStage').disabled=idx===0;$('nextStage').disabled=idx===STAGES.length-1;
    $('nextStage').textContent=idx===STAGES.length-1?'已到最后一步':'下一步 →';
    $('promptOutput').value=''; $('promptMeta').textContent='不会调用外部 API';
    if(save)persist();
  }
  function block(label,content) {return `【${label}】\n${(content||'（尚未填写）').trim()}\n`;}
  function generatePrompt() {
    const audience=block('目标读者',value('reader'))+block('读者疑问',value('readerQuestion'));
    const material=block('已有素材/备注',value('ideaNotes'))+block('事实与例子',value('grounds'))+block('资料来源',value('sources'));
    const common='任务为中文内容创作。依据下方用户提供的信息作答，未填写的信息不得臆造。事实与意见分清；无法确认的数字、经历、效果请标记待核，不能冒充已经调查过的读者或数据。请优先交付本轮要求的内容，不额外输出一堆套话。\n\n';
    const format=FORMATS[platform][0];
    let task='';
    if(stage==='topic'){
      task=`请协助我进行精准选题，目标载体是「${format}」。基于具体读者、情境和问题，给出至多 3 个差别明显的选题，逐个说明读者为什么会关心、能带走什么、最缺什么材料；最后推荐 1 个题并说明理由。本轮只讨论选题，不写正文。\n\n`+block('话题',value('topic'))+audience+block('文章承诺',value('promise'))+block('想法和材料',value('ideaNotes'));
    } else if(stage==='point'){
      task=`我要检查一篇「${format}」内容的中心观点，请先把我的主张写成清楚、有边界的一句话，判断目前哪些理由能支持它，指出 1 个真正有力的异议；有必要时建议缩小结论。不要直接写正文。\n\n`+block('主题',value('topic'))+audience+block('中心观点',value('claim'))+block('现有理由',value('grounds'))+block('我想到的异议',value('objection'))+block('适用范围',value('scope'))+block('出处',value('sources'));
    } else if(stage==='write'){
      task=`请为「${format}」撰写一版可读、准确、信息密度足够的正文。现有草稿若不为空，优先保留原意并修改；若只有大纲就依照大纲成文；如果资料不足以支持确定事实，请降低断言强度或在正文外提示待核项。语气偏好：${$('tone').selectedOptions[0].text}。不要为了凑字数重复概念，也不要编造第一人称亲历。\n\n`+block('主题',value('topic'))+block('标题',value('headline'))+audience+block('中心观点',value('claim'))+material+block('结构',value('outline'))+block('现有正文',value('draft'));
    } else {
      task=`请把下面的内容整理为「${format}」的最终可发布文本。语气偏好：${$('tone').selectedOptions[0].text}。不改变原意，不添加未证实的新事实；基于所选载体改善段落与阅读节奏。若现稿尚未提供，请指出缺少正文。给我完整稿，不需要编造阅读量或传播结果。\n\n`+block('标题',value('headline'))+block('观点',value('claim'))+block('正文',value('draft'))+block('想要的结尾互动',value('cta'))+block('可能使用的话题标签',value('tags'))+block('边界/待核事项',value('scope'));
    }
    $('promptOutput').value=common+task;
    $('promptMeta').textContent=charCount($('promptOutput').value)+' 字符 · 可直接复制';
    $('promptOutput').scrollTop=0; report('本阶段指令已生成');
  }
  async function copyPrompt() {
    if(!$('promptOutput').value) generatePrompt();
    const s=$('promptOutput').value;
    try { if(!navigator.clipboard || !navigator.clipboard.writeText) throw new Error('clipboard unavailable'); await navigator.clipboard.writeText(s);report('已复制到剪贴板'); }
    catch(_) { $('promptOutput').focus();$('promptOutput').select();try {const ok=document.execCommand('copy'); report(ok?'已复制到剪贴板':'已选中指令，请按 Ctrl+C 复制');} catch(__){report('已选中指令，请按 Ctrl+C 复制');} }
  }
  function download(name,content,mime='text/plain;charset=utf-8') {
    const url=URL.createObjectURL(new Blob([content],{type:mime}));const a=document.createElement('a');a.href=url;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),3000);
  }
  function safeFilename(str) {return (str||'未命名').replace(/[\\/:*?"<>|\x00-\x1f]/g,'_').trim().slice(0,60)||'未命名';}
  function outputDraft() {
    const title=value('headline')||value('topic')||'未命名成稿';
    const body=value('draft');
    if(!body) {report('正文还是空的：请到「开始写作」输入内容');changeStage('write');return;}
    const tag=value('tags'); const cta=value('cta');
    let result='# '+title+'\n\n'+body+'\n';
    if(cta && !body.includes(cta)) result+='\n'+cta+'\n';
    if(tag && !body.includes(tag)) result+='\n'+tag+'\n';
    download(safeFilename(title)+'.md',result);report('成稿 Markdown 已导出');
  }
  function outputProject() {
    const data={format:'paperline-studio',version:2,platform,stage,fields:{}};FIELDS.forEach(k=>data.fields[k]=$(k).value);
    download(safeFilename(value('topic')||'写作项目')+'-项目.json',JSON.stringify(data,null,2)+'\n','application/json;charset=utf-8'); report('可恢复项目 JSON 已导出');
  }
  function loadProject(obj) {
    if(!obj||obj.format!=='paperline-studio'||obj.version!==2||!obj.fields||typeof obj.fields!=='object') throw new Error('不是兼容的 PAPERLINE v2 项目文件');
    for(const k of FIELDS){if(obj.fields[k]!=null&&typeof obj.fields[k]!=='string')throw new Error('字段内容不是文本');}
    FIELDS.forEach(k=>{if(typeof obj.fields[k]==='string')$(k).value=obj.fields[k].slice(0,150000);else $(k).value=k==='tone'?'direct':'';});
    platform=Object.prototype.hasOwnProperty.call(FORMATS,obj.platform)?obj.platform:'xiaohongshu';
    if(!['direct','friendly','analytical','lively'].includes($('tone').value))$('tone').value='direct';
    changeStage(STAGES.includes(obj.stage)?obj.stage:'topic',false);repaint();persist();
  }
  function emptyProject() {
    FIELDS.forEach(k=>$(k).value=k==='tone'?'direct':'');platform='xiaohongshu';changeStage('topic',false);repaint();persist();
  }
  function init() {
    document.querySelectorAll('[data-nav]').forEach(b=>b.addEventListener('click',()=>changeStage(b.dataset.nav)));
    document.querySelectorAll('[data-platform]').forEach(b=>b.addEventListener('click',()=>{platform=b.dataset.platform;repaint();persist();}));
    FIELDS.forEach(k=>$(k).addEventListener('input',()=>{repaint();persist();}));
    $('prevStage').addEventListener('click',()=>changeStage(STAGES[Math.max(0,STAGES.indexOf(stage)-1)]));
    $('nextStage').addEventListener('click',()=>changeStage(STAGES[Math.min(STAGES.length-1,STAGES.indexOf(stage)+1)]));
    ['quickPromptBtn','stagePromptBtn','railPromptBtn'].forEach(k=>$(k).addEventListener('click',()=>{generatePrompt(); if(k==='quickPromptBtn')$('promptOutput').scrollIntoView({behavior:'smooth',block:'center'}); }));
    $('copyPromptBtn').addEventListener('click',copyPrompt);
    $('exportDraftBtn').addEventListener('click',outputDraft);
    $('exportProjectBtn').addEventListener('click',outputProject);
    $('importBtn').addEventListener('click',()=>$('importFile').click());
    $('importFile').addEventListener('change',async e=>{
      const f=e.target.files?.[0];if(!f)return;
      if(f.size>2*1024*1024){report('文件超过 2MB，请确认项目文件');e.target.value='';return;}
      try {const obj=JSON.parse(await f.text());if(!window.confirm('导入项目将替换当前填写的内容。确定继续吗？'))return;loadProject(obj);report('项目已导入');}catch(err){report('导入失败：'+String(err.message||err).slice(0,65));}finally{e.target.value='';}
    });
    $('demoBtn').addEventListener('click',()=>{if(!window.confirm('加载演示案例会覆盖当前填写的内容。要继续吗？'))return;loadProject({format:'paperline-studio',version:2,platform:'xiaohongshu',stage:'topic',fields:EXAMPLE});report('示例内容已载入（情节是教学演示）');});
    $('resetBtn').addEventListener('click',()=>{if(window.confirm('这会清空当前项目，建议先导出 JSON。确定清空吗？')){emptyProject();report('当前项目已清空');}});
    try {const saved=localStorage.getItem(KEY);if(saved)loadProject(JSON.parse(saved));else{emptyProject();$('saveStatus').textContent='● 本地就绪';}}
    catch(_){canStore=false;emptyProject();$('saveStatus').textContent='● 请手动导出备份';}
    repaint();
  }
  document.addEventListener('DOMContentLoaded',init);
})();
