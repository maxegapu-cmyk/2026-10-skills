# PAPERLINE · 通用内容写作工作台 v2.0.0

**从选题到成稿，一套轻量、通用、可直接上手的中文写作工具。**

面向 **小文章 / X 短帖与串帖 / 小红书笔记**，也可用于公众号短文、论坛讨论和知识型内容。适合只有一个模糊想法、观点不够清楚，或有材料却迟迟写不出来的创作者。

## 30 秒开始

**方式一｜打开可视化工作台**

双击 `workbench/index.html`。在本地浏览器填写选题、读者问题、观点与正文；按需要生成阶段 AI 提示词，复制到自己正在用的 AI 助手；完成后导出 Markdown 或 JSON。

**方式二｜直接交给 AI**

将整个文件夹放进支持 Agent Skills 的工具的 skills 目录，入口为 `SKILL.md`；或把 `SKILL.md` 直接发给 AI，输入：

> 使用 public-writing-starter。我要写一篇给普通读者看的短文章，先帮我找准题目和观点，不要马上写全文。

## 使用路线

`选题 → 观点与材料 → 结构与写作 → 平台表达`

- **选题**：把“大话题”缩小成特定读者真正会关心的一件事。
- **观点**：清楚表达判断，标出已有资料、重要缺口和最强异议。
- **写作**：先写出有用的内容，再调语气和节奏；可一口气成稿，也可逐段推进。
- **适配**：同一主张，变成小文章、X 帖子或小红书笔记的不同呈现。

## 工作台可以实际做什么

- 4 个可以切换的写作页面，随输入自动保存到当前浏览器（如浏览器允许）。
- 按阶段自动拼装可复制的 AI 指令；不需要 API Key。
- 实时正文预览和字符数统计（**X 计数仅为简单字符统计，不等于平台官方计数**）。
- 导出**成稿 Markdown**、**可恢复的项目 JSON**；支持重新导入。
- 一键载入示例，便于先体验；载入示例会提示覆盖现有内容。

工作台是一个**本地编辑器与提示词组合器**，不是内置 AI 模型；它不会自动联网搜索、调用模型或替用户发帖。浏览器本地存储不是加密备份，重要内容请及时导出 JSON。

## 文件说明

| 文件 | 用途 |
| --- | --- |
| `SKILL.md` | 给 AI 读取的正式写作 Skill |
| `workbench/index.html` | 本地工作台入口 |
| `workbench/style.css` / `app.js` | 界面样式与离线交互 |
| `references/` | 选题、证据、短文和平台表达参考 |
| `examples/演示.md` | 从模糊想法到完成稿的演示 |
| `tests/check_package.py` | 仅用 Python 标准库运行的结构与离线规则测试 |

在根目录执行 `python tests/check_package.py` 可复查基本文件完整性。可视化功能需要支持现代 JavaScript 的浏览器。

## 公开参考

通用选题与写作流程承接本项目 v1.0.0。参考了公开 GitHub 项目的文字说明与常见能力边界：

- [writing-assistant-skill](https://github.com/Agentchengfeng/writing-assistant-skill)：内容写作助手的应用场景。
- [human-writing](https://github.com/KKKKhazix/human-writing)：用具体资料提高中文可读性的写作实践。
- [anthropics/skills](https://github.com/anthropics/skills)：Skill 的标准目录组织与按需加载参考。
- [WriteFreely](https://github.com/writefreely/writefreely)：专注写作的编辑器设计理念参考。

本项目的 Skill 文字、静态页面与脚本为独立实现，**不包含这些仓库的源码**；它不是上述项目的官方版本。详见 `references/公开来源.md`。
