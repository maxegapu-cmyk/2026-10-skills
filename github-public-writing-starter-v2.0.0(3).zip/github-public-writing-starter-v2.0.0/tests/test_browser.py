"""Optional real-browser checks. Requires playwright and an installed Chromium.

Run: python -m unittest discover -s tests -v
If Playwright is absent these tests skip; the workbench itself needs no packages.
"""
from pathlib import Path
import os
import unittest

ROOT = Path(__file__).resolve().parents[1]
try:
    from playwright.sync_api import sync_playwright
except ImportError:
    sync_playwright = None


@unittest.skipUnless(sync_playwright, 'Playwright is optional and is not installed')
class BrowserChecks(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.playwright = sync_playwright().start()
        executable = os.environ.get('CHROMIUM_PATH','/usr/bin/chromium')
        launch={'headless':True,'args':['--no-sandbox']}
        if Path(executable).exists():launch['executable_path']=executable
        cls.browser=cls.playwright.chromium.launch(**launch)
        cls.template=(ROOT/'workbench/index.html').read_text(encoding='utf-8')
        cls.css=(ROOT/'workbench/style.css').read_text(encoding='utf-8')
        cls.js=(ROOT/'workbench/app.js').read_text(encoding='utf-8')

    @classmethod
    def tearDownClass(cls):
        cls.browser.close()
        cls.playwright.stop()

    def setUp(self):
        self.ctx=self.browser.new_context(accept_downloads=True)
        self.page=self.ctx.new_page()
        self.errors=[]
        self.network=[]
        self.page.on('pageerror',lambda e:self.errors.append(str(e)))
        self.page.on('request',lambda req:self.network.append(req.url) if req.url.startswith(('https://','http://')) and not req.url.startswith('http://127.0.0.1:') else None)
        self.page.on('dialog',lambda d:d.accept())
        self.render()

    def render(self, saved=''):
        # Some locked-down CI browsers deny both file:// and loopback navigation.
        # Load the exact page assets inline instead, with a tiny storage substitute.
        import json
        storage_js="<script>var __store = "+json.dumps({'paperline-public-writing-studio-v2':saved})+"; Object.defineProperty(window,'localStorage',{value:{getItem:k=>__store[k]||null,setItem:(k,v)=>{__store[k]=v;}}});</script>" 
        html=self.template.replace('<link rel="stylesheet" href="style.css">','<style>'+self.css+'</style>')
        html=html.replace('<script src="app.js" defer></script>','')
        html=html.replace('</body>',storage_js+'<script>'+self.js+'</script></body>')
        self.page.set_content(html,wait_until='load')
        self.page.wait_for_selector('#topic')

    def tearDown(self):
        self.assertEqual(self.errors,[],f'JavaScript page errors: {self.errors}')
        self.assertEqual(self.network,[],f'Unexpected requests: {self.network}')
        self.ctx.close()

    def test_stage_navigation(self):
        self.page.locator('[data-nav="point"]').click()
        self.assertTrue(self.page.locator('[data-stage="point"]').is_visible())
        self.assertFalse(self.page.locator('[data-stage="topic"]').is_visible())
        self.page.locator('#nextStage').click()
        self.assertTrue(self.page.locator('#draft').is_visible())

    def test_generate_stage_prompt(self):
        self.page.locator('#topic').fill('如何减少一次性包装')
        self.page.locator('#reader').fill('刚开始独居的人')
        self.page.locator('#stagePromptBtn').click()
        self.assertIn('如何减少一次性包装',self.page.locator('#promptOutput').input_value())
        self.assertIn('本轮只讨论选题',self.page.locator('#promptOutput').input_value())

    def test_live_preview_and_stats(self):
        self.page.locator('[data-nav="write"]').click()
        self.page.locator('#headline').fill('三个小办法')
        self.page.locator('#draft').fill('测试段落。\n第二段。')
        self.assertIn('三个小办法',self.page.locator('#previewTitle').inner_text())
        self.assertIn('第二段',self.page.locator('#previewBody').inner_text())
        self.assertEqual('10',self.page.locator('#charCount').inner_text())

    def test_platform_switch(self):
        self.page.locator('[data-nav="adapt"]').click()
        self.page.locator('[data-platform="x"]').click()
        self.assertIn('X / 微博',self.page.locator('#platformMetric').inner_text())
        self.assertIn('X · 简短',self.page.locator('#platformHelpTitle').inner_text())

    def test_demo_and_project_export_import(self):
        self.page.locator('#demoBtn').click()
        self.assertIn('下班后',self.page.locator('#topic').input_value())
        with self.page.expect_download() as download_info:
            self.page.locator('#exportProjectBtn').click()
        download=download_info.value
        self.assertTrue(download.suggested_filename.endswith('.json'))
        path=download.path()
        self.page.locator('#resetBtn').click()
        self.assertEqual('',self.page.locator('#topic').input_value())
        self.page.locator('#importFile').set_input_files(str(path))
        self.assertIn('下班后',self.page.locator('#topic').input_value())

    def test_draft_download_markdown(self):
        self.page.locator('[data-nav="write"]').click()
        self.page.locator('#headline').fill('我的标题')
        self.page.locator('#draft').fill('我的完整正文。')
        with self.page.expect_download() as download_info:
            self.page.locator('#exportDraftBtn').click()
        d=download_info.value
        self.assertEqual('我的标题.md',d.suggested_filename)
        self.assertIn('我的完整正文',Path(d.path()).read_text(encoding='utf-8'))

    def test_local_persistence_on_reload(self):
        self.page.locator('#topic').fill('保存测试')
        saved=self.page.evaluate("localStorage.getItem('paperline-public-writing-studio-v2')")
        self.render(saved)
        self.assertEqual('保存测试',self.page.locator('#topic').input_value())

    def test_import_rejects_invalid_file(self):
        self.page.locator('#topic').fill('不应丢失')
        self.page.locator('#importFile').set_input_files({'name':'bad.json','mimeType':'application/json','buffer':b'{"format":"bogus"}'})
        self.assertEqual('不应丢失',self.page.locator('#topic').input_value())
        self.assertIn('导入失败',self.page.locator('#toast').inner_text())


if __name__=='__main__':unittest.main(verbosity=2)
