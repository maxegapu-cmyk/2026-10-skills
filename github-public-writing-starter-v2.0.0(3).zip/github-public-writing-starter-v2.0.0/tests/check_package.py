"""Portable structural checks for PAPERLINE. Requires Python 3.9+ standard library."""
from pathlib import Path
import re
import unittest
import json

ROOT = Path(__file__).resolve().parents[1]


class PackageChecks(unittest.TestCase):
    def test_skill_frontmatter(self):
        text=(ROOT/'SKILL.md').read_text(encoding='utf-8')
        self.assertTrue(text.startswith('---\n'))
        self.assertRegex(text,r'(?m)^name: public-writing-starter$')
        self.assertRegex(text,r'(?m)^description:')

    def test_all_files_present(self):
        paths=['README.md','SKILL.md','workbench/index.html','workbench/style.css',
               'workbench/app.js','workbench/README.md','examples/演示.md',
               'references/选题与读者.md','references/观点与资料.md',
               'references/起稿与改稿.md','references/平台适配.md',
               'references/公开来源.md','references/开工卡.md']
        for p in paths:
            with self.subTest(path=p):self.assertTrue((ROOT/p).is_file())

    def test_skill_references_exist(self):
        text=(ROOT/'SKILL.md').read_text(encoding='utf-8')
        refs=set(re.findall(r'`((?:references|workbench)/[^`\n]+\.md|workbench/index\.html)`',text))
        self.assertGreater(len(refs),3)
        for p in refs:self.assertTrue((ROOT/p).is_file(),p)

    def test_html_assets_resolve(self):
        text=(ROOT/'workbench/index.html').read_text(encoding='utf-8')
        self.assertIn('lang="zh-CN"',text)
        self.assertIn('viewport',text)
        for v in ['style.css','app.js']:self.assertTrue((ROOT/'workbench'/v).is_file())
        self.assertNotRegex(text,r'https?://[^\s"\']+\.js')

    def test_field_keys_match_dom(self):
        script=(ROOT/'workbench/app.js').read_text(encoding='utf-8')
        html=(ROOT/'workbench/index.html').read_text(encoding='utf-8')
        m=re.search(r'const FIELDS = \[([^\]]+)\]',script)
        self.assertIsNotNone(m)
        keys=re.findall(r"'([a-zA-Z]+)'",m.group(1))
        self.assertGreaterEqual(len(keys),15)
        for k in keys:self.assertIn('id="'+k+'"',html)
        self.assertEqual(len(keys),len(set(keys)))

    def test_no_external_runtime_dependencies(self):
        html=(ROOT/'workbench/index.html').read_text(encoding='utf-8')
        script=(ROOT/'workbench/app.js').read_text(encoding='utf-8')
        self.assertNotIn('src="https://',html)
        self.assertNotIn('href="https://',html)
        for token in ['fetch(', 'XMLHttpRequest', 'sendBeacon(', 'WebSocket(', 'EventSource(']:
            self.assertNotIn(token,script)

    def test_modes_covered(self):
        script=(ROOT/'workbench/app.js').read_text(encoding='utf-8')
        for stage in ['topic','point','write','adapt']:
            self.assertIn(stage,script)
        for platform in ['xiaohongshu','article',"x:"]:
            self.assertIn(platform,script)

    def test_export_import_versioned_and_validation(self):
        script=(ROOT/'workbench/app.js').read_text(encoding='utf-8')
        for key in ['JSON.stringify','JSON.parse','application/json','download(','loadProject(',"version:2",'window.confirm']:
            self.assertIn(key,script)

    def test_no_unused_external_artifacts(self):
        extensions={f.suffix for f in ROOT.rglob('*') if f.is_file()}
        self.assertFalse(extensions & {'.exe','.dll','.so','.pkl','.db','.sqlite'})


if __name__=='__main__':
    unittest.main(verbosity=2)
