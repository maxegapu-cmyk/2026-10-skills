# Bedrock Agora 1.0.0｜原点议事引擎

**定位**：为管理者做有证据、能反驳、能落地的复杂决策讨论；为各种正当专业工作创建真正可安装的 Agent Skills。单个 Skill 支持 `DECIDE`（决策）、`FORGE`（技能生产）和 `BRIDGE`（决策→流程产品化）。

## 安装（Windows / macOS / Linux）

将 ZIP 解压后，把整个 `bedrock-agora` 目录拷贝至：

- Claude Code 项目级：`项目目录/.claude/skills/bedrock-agora/`
- Codex 项目级：`项目目录/.agents/skills/bedrock-agora/`
- Claude Code 用户级：`~/.claude/skills/bedrock-agora/`
- Codex 用户级：`~/.agents/skills/bedrock-agora/`

请确保目录内直接有 `SKILL.md`，不要多套一层 ZIP 文件名目录。实际识别和触发取决于客户端的 Skill 支持与配置；需要时在新会话中明确点名 `bedrock-agora`。

## 对 AI 说三句话即可开始

**企业决策**：`调用 bedrock-agora，用第一性原理分析我们公司是否应该增加直营渠道。别迎合我，先识别会翻转结论的关键数据，然后给备选方案、试点和止损条件。`

**深入讨论**：`调用 bedrock-agora。我们讨论产品应该面向企业还是个人，先独立判断；有新增证据再辩论，不要空转。`

**定制 Skill**：`调用 bedrock-agora 的 FORGE 模式，为售后客服团队设计一个 Skill。必须可安装，含禁答边界、实际工作步骤、正反例和测试。`

**联动**：`调用 bedrock-agora 的 BRIDGE 模式：先决定客诉处理应该走什么流程，再把通过验证的流程变成一个客服 Skill。`

## 文件与运行

- `SKILL.md`：唯一正式触发入口。
- `references/`：哲学选择器、公司决策、技能设计规则与来源。
- `assets/decision-example.json`：虚构公司决策结构示例，不能视为任何公司的真实数据。
- `assets/skill-brief-example.json`：可运行的 Skill 需求合同。
- `scripts/forge_skill.py`：从结构化合同创建 Agent Skill 文件夹（只写本地文件，不访问网络）。
- `scripts/validate_skill.py`：结构与资源校验。
- `scripts/audit_decision.py`：决策 JSON 覆盖检查（不判断方案正确）。
- `tests/`：自动回归测试。
- `evals/cases.json`：需人工或外部模型实测的语义评测集。
- `examples/generated/customer-service-triage/`：真正用编译脚本生成并验证的示例子 Skill；政策内容仅作示范。

在 `bedrock-agora` 目录里，执行：

```sh
python scripts/forge_skill.py --spec assets/skill-brief-example.json --out /tmp/agora-demo
python scripts/validate_skill.py /tmp/agora-demo/customer-service-triage
python scripts/audit_decision.py assets/decision-example.json
python -m unittest discover -s tests -v
```

Windows PowerShell 把 `/tmp/agora-demo` 替换成 `.\\demo-output`；脚本只依赖 Python 3.9+ 标准库。

## 不会做的事

它不是自动运转的独立多模型委员会，不会偷偷连接企业数据库，不会自己研究出行业事实，不会自动把自然语言生成成可运行代码，也不会替管理层签字。Forge 脚本把**讨论之后填好的需求合同**编译成 Skill；模型质量与专业正确性需要单独验证。`scripts/validate_skill.py` 通过不代表生成内容的业务效果已通过。

发布与修改第三方系统前需要额外授权；涉及医疗、财务、法律或劳动政策时需专业复核。

## 开源来源与权利

本项目内容独立写作，方法论与对标来源见 `references/source-notes.md`，没有打包任何外部仓库代码。原创代码与文字按项目内 `LICENSE` 许可发布；外部引用各自遵循其网站及项目许可。
