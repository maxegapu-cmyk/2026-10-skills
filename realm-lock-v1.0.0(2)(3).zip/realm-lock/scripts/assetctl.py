#!/usr/bin/env python3
"""Local-only, no-network asset contracts for REALM-LOCK. Python >=3.9."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import sys
from datetime import datetime, timezone

DOMAINS = ('identity', 'geometry', 'wardrobe', 'material', 'environment', 'lighting', 'camera', 'state')
ROLES = ('identity', 'body', 'outfit', 'geometry', 'material', 'pose', 'camera', 'lighting', 'color', 'base')
EVIDENCES = ('observed', 'user', 'inferred', 'unknown')
KINDS = ('character', 'prop', 'environment')
LANES = ('generate', 'edit', 'texture', 'reverse')
MODELS = ('generic', 'higgsfield-soul', 'gemini-image', 'other')
NAME_RE = re.compile(r'^[a-zA-Z][a-zA-Z0-9_-]{0,62}$')


def fail(message):
    raise ValueError(message)


def safe_name(text):
    if not NAME_RE.fullmatch(text):
        fail('ID must be 1..63 alphanumeric/underscore/hyphen characters and start with a letter')
    return text


def hash_file(p):
    h = hashlib.sha256()
    with Path(p).open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def read_json(p):
    with Path(p).open(encoding='utf-8') as f:
        return json.load(f)


def atomic_json(path, item):
    path = Path(path)
    tmp = path.with_suffix(path.suffix + '.tmp')
    with tmp.open('w', encoding='utf-8', newline='\n') as f:
        json.dump(item, f, indent=2, ensure_ascii=False, sort_keys=True)
        f.write('\n')
    os.replace(tmp, path)


def locate(root):
    root = Path(root).expanduser().resolve()
    contract = root / 'asset.json'
    shots = root / 'shots.json'
    if not contract.is_file() or not shots.is_file():
        fail('Not an initialized project (missing asset.json or shots.json); run new first')
    return root, read_json(contract), read_json(shots)


def strict_status(root, contract, require_ready=False):
    errors = []
    if contract.get('schema') != 'realm-lock/1':
        errors.append('schema mismatch')
    if contract.get('kind') not in KINDS:
        errors.append('unknown kind')
    if not isinstance(contract.get('anchors'), dict):
        errors.append('anchors is not a dictionary')
        return errors
    for domain in DOMAINS:
        for a in contract['anchors'].get(domain, []):
            if not isinstance(a.get('text'), str) or not a['text'].strip():
                errors.append('blank anchor in domain ' + domain)
            if a.get('evidence') not in EVIDENCES:
                errors.append('invalid evidence in ' + domain)
            if a.get('evidence') == 'observed' and not a.get('ref_id'):
                errors.append('observed anchor missing ref_id')
    refs = contract.get('references', [])
    ids = [r.get('id') for r in refs]
    if len(set(ids)) != len(ids):
        errors.append('duplicate reference IDs')
    for ref in refs:
        if ref.get('role') not in ROLES:
            errors.append('invalid reference role: ' + str(ref.get('role')))
        rel = Path(str(ref.get('path', '')))
        if rel.is_absolute() or '..' in rel.parts or not rel.parts or rel.parts[0] != 'refs':
            errors.append('unsafe reference relative path: ' + str(rel))
            continue
        p = (root / rel).resolve()
        if not p.is_relative_to(root):
            errors.append('unsafe reference path')
        elif not p.is_file():
            errors.append('reference file missing: ' + str(rel))
        elif hash_file(p) != ref.get('sha256'):
            errors.append('reference hash changed: ' + str(rel))
    for domain in DOMAINS:
        for anchor in contract['anchors'].get(domain, []):
            if anchor.get('ref_id') and anchor['ref_id'] not in ids:
                errors.append('anchor references missing ID: ' + anchor['ref_id'])
    if require_ready:
        essentials = ['identity'] if contract['kind'] == 'character' else (
            ['geometry'] if contract['kind'] == 'prop' else ['environment'])
        if not any(contract['anchors'].get(k) for k in essentials):
            errors.append('missing minimum domain anchor (' + '/'.join(essentials) + ')')
    return errors


def new_project(args):
    root = Path(args.root).expanduser().resolve()
    safe_name(args.id)
    if root.exists() and any(root.iterdir()):
        fail('Destination is non-empty; refusing to overwrite: ' + str(root))
    root.mkdir(parents=True, exist_ok=True)
    for dirname in ('refs', 'outputs'):
        (root / dirname).mkdir(exist_ok=True)
    obj = {'schema': 'realm-lock/1', 'id': args.id, 'name': args.name,
           'kind': args.kind, 'anchors': {d: [] for d in DOMAINS},
           'references': [], 'uncertainties': [],
           'notice': 'Only user-approved or visually supported anchors are ground truth; inferred features are not certified.'}
    atomic_json(root / 'asset.json', obj)
    atomic_json(root / 'shots.json', {'schema': 'realm-lock/shots/1', 'shots': []})
    print('CREATED', root)


def add_ref(args):
    root, c, _ = locate(args.root)
    safe_name(args.ref_id)
    source = Path(args.file).expanduser().resolve()
    if not source.is_file():
        fail('Reference does not exist: ' + str(source))
    if any(r['id'] == args.ref_id for r in c['references']):
        fail('Reference ID already exists: ' + args.ref_id)
    if not source.suffix.lower() in ('.png', '.jpg', '.jpeg', '.webp', '.tiff', '.tif', '.bmp'):
        fail('Unsupported image extension (no conversion attempted)')
    dest = root / 'refs' / (args.ref_id + source.suffix.lower())
    if dest.exists():
        fail('Ref filename already exists: ' + str(dest))
    if source == dest.resolve():
        fail('Source image is already the target; refusing to copy on itself')
    shutil.copyfile(source, dest)
    c['references'].append({'id': args.ref_id, 'role': args.role,
                            'path': str(dest.relative_to(root)).replace('\\', '/'),
                            'sha256': hash_file(dest), 'priority': args.priority})
    atomic_json(root / 'asset.json', c)
    print('ADDED', args.ref_id, hash_file(dest))


def add_anchor(args):
    root, c, _ = locate(args.root)
    if args.evidence == 'observed' and not args.ref_id:
        fail('Observed anchor requires --ref-id')
    if args.ref_id and args.ref_id not in {r['id'] for r in c['references']}:
        fail('Anchor ref_id must match an existing reference')
    if not args.text.strip():
        fail('Blank anchor text')
    a = {'text': args.text.strip(), 'evidence': args.evidence}
    if args.ref_id:
        a['ref_id'] = args.ref_id
    c['anchors'][args.domain].append(a)
    atomic_json(root / 'asset.json', c)
    print('ANCHOR', args.domain, args.evidence)


def add_shot(args):
    root, _, s = locate(args.root)
    safe_name(args.id)
    if any(sh['id'] == args.id for sh in s['shots']):
        fail('Shot ID already exists')
    if not args.purpose.strip() or not args.camera.strip():
        fail('Shot requires meaningful purpose and camera')
    sh = {'id': args.id, 'purpose': args.purpose, 'camera': args.camera,
          'lighting': args.lighting, 'state': args.state,
          'preserve': args.preserve, 'change': args.change}
    s['shots'].append(sh)
    atomic_json(root / 'shots.json', s)
    print('SHOT', args.id)


def contract_digest(c):
    baseline = {'id': c['id'], 'kind': c['kind'], 'anchors': c['anchors'],
                'references': c['references'], 'uncertainties': c['uncertainties']}
    b = json.dumps(baseline, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()
    return hashlib.sha256(b).hexdigest()


def freeze(args):
    root, c, _ = locate(args.root)
    errs = strict_status(root, c, require_ready=True)
    if errs:
        fail('Cannot freeze:\n- ' + '\n- '.join(errs))
    lock = root / 'baseline.lock.json'
    if lock.exists() and not args.replace:
        fail('Lock already exists; explicit --replace required after human approval')
    rec = {'schema': 'realm-lock/lock/1', 'id': c['id'],
           'contract_sha256': contract_digest(c),
           'ref_sha256': {r['id']: r['sha256'] for r in c['references']},
           'frozen_utc': datetime.now(timezone.utc).isoformat()}
    atomic_json(lock, rec)
    print('FROZEN', rec['contract_sha256'])


def verify(root, c):
    lock = root / 'baseline.lock.json'
    if not lock.exists():
        return False, 'No baseline.lock.json; freeze first'
    old = read_json(lock)
    if old.get('contract_sha256') != contract_digest(c):
        return False, 'Contract changed since baseline was approved'
    problems = strict_status(root, c, require_ready=True)
    if problems:
        return False, '; '.join(problems)
    return True, old['contract_sha256']


def do_check(args):
    root, c, shots = locate(args.root)
    errs = strict_status(root, c, require_ready=args.strict)
    if shots.get('schema') != 'realm-lock/shots/1':
        errs.append('shots schema mismatch')
    ids = [s.get('id') for s in shots.get('shots', [])]
    if len(ids) != len(set(ids)):
        errs.append('duplicate shot ID')
    if errs:
        fail('CHECK FAILED:\n- ' + '\n- '.join(errs))
    print('CHECK OK', len(c['references']), 'references', len(ids), 'shots')


def do_verify(args):
    root, c, _ = locate(args.root)
    ok, msg = verify(root, c)
    if not ok:
        fail('VERIFY FAILED: ' + msg)
    print('VERIFY OK', msg)


def do_build(args):
    root, c, s = locate(args.root)
    errs = strict_status(root, c, require_ready=True)
    if errs:
        fail('BUILD FAILED: ' + '; '.join(errs))
    match = [sh for sh in s['shots'] if sh['id'] == args.id]
    if not match:
        fail('Unknown shot ID: ' + args.id)
    sh = match[0]
    if args.lane in ('edit', 'texture'):
        if not sh['change'].strip():
            fail('Edit/texture requires a declared --change at shot creation')
        if not any(r['role'] == 'base' for r in c['references']):
            fail('Edit/texture requires a base image reference added with --role base')
    if args.lane == 'reverse' and not c['anchors'].get('environment'):
        fail('Reverse view requires environment/layout anchors')
    lines = []
    lead = {'generate': 'Generate a photographic, physically coherent still.',
            'edit': 'Edit the uploaded approved base image with the smallest necessary localized change.',
            'texture': 'Enhance only the specified physical material texture on the approved base image; do not redesign.',
            'reverse': 'Create a new photographic viewpoint of the same established space; preserve the world layout.'}
    lines.append(lead[args.lane])
    lines.append('Asset: ' + c['name'] + ' (' + c['kind'] + '). Purpose: ' + sh['purpose'] + '.')
    priority_domains = ('identity', 'geometry', 'wardrobe', 'material', 'environment', 'state')
    for domain in priority_domains:
        entries = [a['text'] for a in c['anchors'][domain] if a['evidence'] in ('observed', 'user')]
        if entries:
            lines.append(domain.capitalize() + ' anchors: ' + '; '.join(entries) + '.')
    lines.append('Camera and framing: ' + sh['camera'] + '.')
    if sh['lighting']:
        lines.append('Lighting: ' + sh['lighting'] + '.')
    if sh['state']:
        lines.append('Scene state: ' + sh['state'] + '.')
    if args.lane in ('edit', 'texture'):
        lines.append('CHANGE ONLY: ' + sh['change'] + '.')
        lines.append('PRESERVE: ' + (sh['preserve'] or 'identity, body geometry, garment construction, all unrelated objects and details, camera framing, lighting and color outside the allowed edit region') + '.')
        lines.append('Respect the edit boundary and retain physically consistent local transitions; review for unintended changes outside the allowed region.')
    elif sh['preserve']:
        lines.append('Critical continuity: ' + sh['preserve'] + '.')
    if c['kind'] == 'character':
        lines.append('Preserve natural individual asymmetry, anatomically credible face and hands, hair volume, fabric thickness, and realistic floor contact without artificial beauty smoothing.')
    elif c['kind'] == 'prop':
        lines.append('Preserve functional joints, silhouette, surface-specific roughness and physically credible contact shadows.')
    else:
        lines.append('Preserve believable perspective, scale, surface material response, and lighting direction across the room.')
    notes = [a['text'] for arr in c['anchors'].values() for a in arr if a['evidence'] in ('inferred', 'unknown')]
    if notes:
        lines.append('Unverified designs must remain minimal and must not be described as directly observed from the original: ' + '; '.join(notes) + '.')
    prompt = '\n'.join(lines) + '\n'
    if len(prompt) > 4500:
        print('WARNING: Long prompt; prune non-critical anchors manually without losing identity/geometry', file=sys.stderr)
    hints = {'generic': 'Set aspect/resolution/reference roles in the real platform UI when supported.',
             'higgsfield-soul': 'Use authorized Soul ID (if available) for recurring identity; Soul Cinema for cinematic frames; check current model UI.',
             'gemini-image': 'Supply reference images with role explanations; prefer true image edit/mask controls if exposed by the current app/API.',
             'other': 'Verify model specific capabilities; do not invent seed, mask, negatives, or references limits.'}
    plan = {'asset_id': c['id'], 'shot_id': sh['id'], 'lane': args.lane, 'model': args.model,
            'references': sorted(c['references'], key=lambda x: (x['role'], -x['priority'], x['id'])),
            'source_status': verify(root, c)[0], 'uncertainties': notes + c['uncertainties'],
            'model_note': hints[args.model],
            'acceptance': ['face/body/object construction unchanged except authorized states',
                           'camera and world geometry consistent',
                           'material and lighting physically plausible',
                           'edit regions externally checked when applicable']}
    output = root / 'outputs' / (sh['id'] + '-' + args.lane + '-' + args.model + '.txt')
    output.write_text(prompt, encoding='utf-8')
    atomic_json(output.with_suffix('.plan.json'), plan)
    print('BUILT', output, '| baseline verified:', plan['source_status'])


def make_parser():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command', required=True)
    p = sub.add_parser('new', help='Create non-destructive local asset project')
    p.add_argument('root'); p.add_argument('--id', required=True)
    p.add_argument('--kind', required=True, choices=KINDS); p.add_argument('--name', required=True)
    p.set_defaults(func=new_project)
    p = sub.add_parser('add-ref', help='Copy and hash a reference image into project')
    p.add_argument('root'); p.add_argument('--ref-id', required=True); p.add_argument('--role', required=True, choices=ROLES)
    p.add_argument('--file', required=True); p.add_argument('--priority', type=int, default=10)
    p.set_defaults(func=add_ref)
    p = sub.add_parser('anchor', help='Add explicit evidence-tagged anchor')
    p.add_argument('root'); p.add_argument('--domain', choices=DOMAINS, required=True)
    p.add_argument('--text', required=True); p.add_argument('--evidence', choices=EVIDENCES, required=True)
    p.add_argument('--ref-id'); p.set_defaults(func=add_anchor)
    p = sub.add_parser('shot', help='Add one shot contract without altering baseline')
    p.add_argument('root'); p.add_argument('--id', required=True); p.add_argument('--purpose', required=True)
    p.add_argument('--camera', required=True); p.add_argument('--lighting', default='')
    p.add_argument('--state', default=''); p.add_argument('--preserve', default=''); p.add_argument('--change', default='')
    p.set_defaults(func=add_shot)
    p = sub.add_parser('check', help='Check referential integrity and evidence')
    p.add_argument('root'); p.add_argument('--strict', action='store_true'); p.set_defaults(func=do_check)
    p = sub.add_parser('freeze', help='Freeze approved asset contract and hashes')
    p.add_argument('root'); p.add_argument('--replace', action='store_true', help='Explicitly supersede approved contract')
    p.set_defaults(func=freeze)
    p = sub.add_parser('verify', help='Compare current contract/references against approved baseline')
    p.add_argument('root'); p.set_defaults(func=do_verify)
    p = sub.add_parser('build', help='Generate one prompt and an auditing plan; no model calls')
    p.add_argument('root'); p.add_argument('--id', required=True); p.add_argument('--lane', choices=LANES, required=True)
    p.add_argument('--model', choices=MODELS, default='generic'); p.set_defaults(func=do_build)
    return parser


if __name__ == '__main__':
    try:
        args = make_parser().parse_args()
        args.func(args)
    except (ValueError, OSError, KeyError, json.JSONDecodeError) as e:
        print('ERROR:', e, file=sys.stderr)
        sys.exit(2)
