#!/usr/bin/env python3
"""Optional Pillow pixel-change audit. Not identity/semantic quality evaluation."""
import argparse
import json
import sys
from pathlib import Path


def run(args):
    try:
        from PIL import Image, ImageChops
    except ImportError as e:
        raise RuntimeError('Pillow is required: python -m pip install Pillow') from e
    for name in ('original', 'result'):
        if not Path(getattr(args, name)).is_file():
            raise ValueError('Missing file for --' + name)
    with Image.open(args.original) as raw_a, Image.open(args.result) as raw_b:
        if raw_a.size != raw_b.size:
            raise ValueError('Size mismatch; do not silently resize: %s vs %s' % (raw_a.size, raw_b.size))
        a, b = raw_a.convert('RGB'), raw_b.convert('RGB')
    if args.mask:
        with Image.open(args.mask) as raw_mask:
            if raw_mask.size != a.size:
                raise ValueError('Mask size must exactly match original/result size')
            mask = raw_mask.convert('L')
        mask_pixels = mask.load()
    else:
        mask_pixels = None
    n_total = a.width * a.height
    n_outside = 0
    n_allowed = 0
    changed_outside = 0
    changed_allowed = 0
    total_abs_diff_outside = 0
    a_px, b_px = a.load(), b.load()
    d = ImageChops.difference(a, b)
    diff_px = d.load()
    for y in range(a.height):
        for x in range(a.width):
            delta = diff_px[x, y]
            change = max(delta) > args.threshold
            if mask_pixels is not None and mask_pixels[x, y] > 127:
                n_allowed += 1
                changed_allowed += int(change)
            else:
                n_outside += 1
                changed_outside += int(change)
                total_abs_diff_outside += sum(delta)
    pct = changed_outside * 100.0 / n_outside if n_outside else 0
    mae = total_abs_diff_outside / (n_outside * 3) if n_outside else 0
    passed = (pct <= args.max_outside_change_pct) if n_outside else True
    report = {'width': a.width, 'height': a.height, 'pixels_total': n_total,
              'allowed_pixels': n_allowed, 'outside_pixels': n_outside,
              'changed_allowed_pixels': changed_allowed,
              'changed_outside_pixels': changed_outside,
              'changed_outside_pct': round(pct, 6), 'outside_rgb_mae': round(mae, 6),
              'threshold_max_channel': args.threshold,
              'max_outside_change_pct': args.max_outside_change_pct,
              'pass_pixel_gate': passed,
              'scope': 'Pixel comparison only. Not subject identity or perceptual continuity proof.'}
    if args.difference:
        path = Path(args.difference)
        path.parent.mkdir(parents=True, exist_ok=True)
        d.save(path)
    if args.report:
        path = Path(args.report)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    print(json.dumps(report, indent=2, ensure_ascii=False))
    return 0 if passed or not args.enforce else 3


def parser():
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest='mode', required=True)
    d = sub.add_parser('diff', help='Compare two same-size images with optional edit mask')
    d.add_argument('--original', required=True); d.add_argument('--result', required=True)
    d.add_argument('--mask', help='white=allowed change; outside region audited')
    d.add_argument('--threshold', type=int, default=18)
    d.add_argument('--max-outside-change-pct', type=float, default=0.25)
    d.add_argument('--report'); d.add_argument('--difference'); d.add_argument('--enforce', action='store_true')
    return p


if __name__ == '__main__':
    try:
        args = parser().parse_args()
        if not 0 <= args.threshold <= 255:
            raise ValueError('--threshold must be 0..255')
        if not 0 <= args.max_outside_change_pct <= 100:
            raise ValueError('--max-outside-change-pct must be 0..100')
        sys.exit(run(args))
    except (ValueError, RuntimeError, OSError) as ex:
        print('ERROR:', ex, file=sys.stderr)
        sys.exit(2)
