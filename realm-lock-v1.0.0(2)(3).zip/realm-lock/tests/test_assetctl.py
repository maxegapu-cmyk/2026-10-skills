"""Run: python -m unittest discover -s tests -v (from package root)."""
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import runpy
import io
import contextlib
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / 'scripts' / 'assetctl.py'
VISUAL = ROOT / 'scripts' / 'visual_audit.py'


def cli(*args, script=SCRIPT, expect=0):
    """Test the same __main__ entrypoint in process (fast, no environment assumptions)."""
    old_argv = sys.argv
    sys.argv = [str(script), *map(str, args)]
    stdout, stderr = io.StringIO(), io.StringIO()
    code = 0
    try:
        with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
            try:
                runpy.run_path(str(script), run_name='__main__')
            except SystemExit as error:
                code = error.code if isinstance(error.code, int) else 1
    finally:
        sys.argv = old_argv
    out = type('Result', (), {'stdout': stdout.getvalue(), 'stderr': stderr.getvalue(), 'returncode': code})()
    if expect is not None and code != expect:
        raise AssertionError(f'code={code} expected={expect}\n{out.stdout}\n{out.stderr}')
    return out


class AssetTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name) / 'testproject'
        cli('new', self.root, '--id', 'actor_A', '--kind', 'character', '--name', 'Actor A')
        self.image = Path(self.temp.name) / 'ref.png'
        self.image.write_bytes(b'image stub for filesystem/hash tests')

    def tearDown(self):
        self.temp.cleanup()

    def prep(self):
        cli('add-ref', self.root, '--ref-id', 'face', '--role', 'identity', '--file', self.image)
        cli('anchor', self.root, '--domain', 'identity', '--text', 'natural eyebrows, pointed chin',
            '--evidence', 'observed', '--ref-id', 'face')

    def test_new_contract_and_folders(self):
        d = json.loads((self.root / 'asset.json').read_text())
        self.assertEqual(d['kind'], 'character')
        self.assertTrue((self.root / 'outputs').is_dir())
        self.assertEqual(len(d['anchors']), 8)

    def test_ref_copy_and_sha(self):
        self.prep()
        d = json.loads((self.root / 'asset.json').read_text())
        self.assertEqual(d['references'][0]['sha256'], hashlib.sha256(self.image.read_bytes()).hexdigest())
        self.assertEqual((self.root / 'refs' / 'face.png').read_bytes(), self.image.read_bytes())

    def test_same_ref_not_added_twice(self):
        self.prep()
        p = cli('add-ref', self.root, '--ref-id', 'face', '--role', 'identity', '--file', self.image, expect=2)
        self.assertIn('already exists', p.stderr)

    def test_missing_ref_file(self):
        proc = cli('add-ref', self.root, '--ref-id', 'face', '--role', 'identity', '--file', self.image.with_name('missing.png'), expect=2)
        self.assertIn('does not exist', proc.stderr)

    def test_observed_needs_ref(self):
        proc = cli('anchor', self.root, '--domain', 'identity', '--text', 't', '--evidence', 'observed', expect=2)
        self.assertIn('requires --ref-id', proc.stderr)

    def test_unknown_ref_rejected(self):
        proc = cli('anchor', self.root, '--domain', 'identity', '--text', 't', '--evidence', 'user', '--ref-id', 'missing', expect=2)
        self.assertIn('existing reference', proc.stderr)

    def test_blank_anchor_rejected(self):
        proc = cli('anchor', self.root, '--domain', 'identity', '--text', '   ', '--evidence', 'user', expect=2)
        self.assertIn('Blank anchor', proc.stderr)

    def test_freeze_fails_without_minimum_anchor(self):
        proc = cli('freeze', self.root, expect=2)
        self.assertIn('minimum domain', proc.stderr)

    def test_freeze_verify_shot_mutation_does_not_break_lock(self):
        self.prep()
        cli('freeze', self.root)
        cli('shot', self.root, '--id', 'SH001', '--purpose', 'neutral full body photo', '--camera', 'eye-level frontal')
        self.assertIn('VERIFY OK', cli('verify', self.root).stdout)

    def test_freeze_resists_silent_replace(self):
        self.prep(); cli('freeze', self.root)
        self.assertIn('explicit --replace', cli('freeze', self.root, expect=2).stderr)

    def test_anchor_mutation_breaks_lock(self):
        self.prep(); cli('freeze', self.root)
        cli('anchor', self.root, '--domain', 'wardrobe', '--text', 'blue jacket', '--evidence', 'user')
        self.assertIn('Contract changed', cli('verify', self.root, expect=2).stderr)

    def test_ref_mutation_detected(self):
        self.prep(); cli('freeze', self.root)
        (self.root / 'refs' / 'face.png').write_bytes(b'tampered')
        self.assertIn('reference hash changed', cli('verify', self.root, expect=2).stderr)

    def test_build_writes_prompt_and_plan(self):
        self.prep(); cli('freeze', self.root)
        cli('shot', self.root, '--id', 'SH001', '--purpose', 'neutral full body photo', '--camera', 'frontal', '--lighting', 'softbox from left')
        proc = cli('build', self.root, '--id', 'SH001', '--lane', 'generate')
        self.assertIn('baseline verified: True', proc.stdout)
        out = self.root / 'outputs' / 'SH001-generate-generic.txt'
        self.assertIn('eyebrows', out.read_text())
        plan = json.loads(out.with_suffix('.plan.json').read_text())
        self.assertTrue(plan['source_status'])

    def test_inferred_not_falsely_grounded(self):
        self.prep()
        cli('anchor', self.root, '--domain', 'wardrobe', '--text', 'unknown back seam', '--evidence', 'inferred')
        cli('shot', self.root, '--id', 'SH002', '--purpose', 'back view', '--camera', 'rear')
        cli('build', self.root, '--id', 'SH002', '--lane', 'generate')
        out = (self.root / 'outputs' / 'SH002-generate-generic.txt').read_text()
        self.assertNotIn('Wardrobe anchors: unknown back seam', out)
        self.assertIn('Unverified designs', out)

    def test_edit_must_have_base_and_change(self):
        self.prep()
        cli('shot', self.root, '--id', 'SH003', '--purpose', 'edit cuff', '--camera', 'frontal', '--change', 'repair cuff')
        proc = cli('build', self.root, '--id', 'SH003', '--lane', 'edit', expect=2)
        self.assertIn('base image reference', proc.stderr)
        cli('add-ref', self.root, '--ref-id', 'base', '--role', 'base', '--file', self.image)
        out = cli('build', self.root, '--id', 'SH003', '--lane', 'edit')
        self.assertIn('BUILT', out.stdout)

    def test_edit_with_no_change_rejected(self):
        self.prep()
        cli('add-ref', self.root, '--ref-id', 'base', '--role', 'base', '--file', self.image)
        cli('shot', self.root, '--id', 'SH003', '--purpose', 'edit cuff', '--camera', 'frontal')
        self.assertIn('declared --change', cli('build', self.root, '--id', 'SH003', '--lane', 'edit', expect=2).stderr)

    def test_reverse_needs_environment(self):
        self.prep()
        cli('shot', self.root, '--id', 'SH003', '--purpose', 'reverse view', '--camera', 'northeast')
        self.assertIn('requires environment', cli('build', self.root, '--id', 'SH003', '--lane', 'reverse', expect=2).stderr)

    def test_non_empty_project_not_overwritten(self):
        (self.root / 'myfile.txt').write_text('keep')
        proc = cli('new', self.root, '--id', 'actor_A', '--kind', 'character', '--name', 'Actor A', expect=2)
        self.assertIn('non-empty', proc.stderr)
        self.assertEqual((self.root / 'myfile.txt').read_text(), 'keep')

    def test_invalid_ref_path_manifest_rejected(self):
        self.prep()
        d = json.loads((self.root / 'asset.json').read_text())
        d['references'][0]['path'] = '../../etc/passwd'
        (self.root / 'asset.json').write_text(json.dumps(d))
        self.assertIn('unsafe reference', cli('check', self.root, expect=2).stderr)

    def test_shot_duplicate_rejected(self):
        self.prep()
        cli('shot', self.root, '--id', 'SH003', '--purpose', 'base', '--camera', 'frontal')
        self.assertIn('Shot ID already', cli('shot', self.root, '--id', 'SH003', '--purpose', 'base', '--camera', 'rear', expect=2).stderr)


class VisualAuditTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        try:
            from PIL import Image  # noqa
            cls.available = True
        except ImportError:
            cls.available = False

    def setUp(self):
        if not self.available:
            self.skipTest('Optional Pillow not installed')
        from PIL import Image
        self.temp = tempfile.TemporaryDirectory()
        self.dir = Path(self.temp.name)
        self.a = self.dir / 'a.png'; self.b = self.dir / 'b.png'; self.mask = self.dir / 'mask.png'
        Image.new('RGB', (6, 6), (10, 10, 10)).save(self.a)
        Image.new('RGB', (6, 6), (10, 10, 10)).save(self.b)
        Image.new('L', (6, 6), 0).save(self.mask)

    def tearDown(self):
        if hasattr(self, 'temp'):
            self.temp.cleanup()

    def test_identical_images_pass(self):
        report = self.dir / 'report.json'
        cli('diff', '--original', self.a, '--result', self.b, '--report', report, script=VISUAL)
        self.assertTrue(json.loads(report.read_text())['pass_pixel_gate'])

    def test_edit_outside_mask_fails(self):
        from PIL import Image
        b = Image.open(self.b); b.putpixel((1, 1), (200, 200, 200)); b.save(self.b)
        result = cli('diff', '--original', self.a, '--result', self.b, '--enforce', script=VISUAL, expect=3)
        self.assertIn('"pass_pixel_gate": false', result.stdout)

    def test_inside_mask_passes(self):
        from PIL import Image
        b = Image.open(self.b); b.putpixel((1, 1), (200, 200, 200)); b.save(self.b)
        m = Image.open(self.mask); m.putpixel((1, 1), 255); m.save(self.mask)
        result = cli('diff', '--original', self.a, '--result', self.b, '--mask', self.mask, '--enforce', script=VISUAL)
        self.assertIn('"pass_pixel_gate": true', result.stdout)

    def test_bad_dimensions_rejected(self):
        from PIL import Image
        Image.new('RGB', (5, 6)).save(self.b)
        self.assertIn('Size mismatch', cli('diff', '--original', self.a, '--result', self.b, script=VISUAL, expect=2).stderr)

    def test_mask_dimensions_rejected(self):
        from PIL import Image
        Image.new('L', (7, 6)).save(self.mask)
        self.assertIn('Mask size', cli('diff', '--original', self.a, '--result', self.b, '--mask', self.mask, script=VISUAL, expect=2).stderr)

    def test_bad_threshold_rejected(self):
        self.assertIn('--threshold', cli('diff', '--original', self.a, '--result', self.b, '--threshold', '500', script=VISUAL, expect=2).stderr)

    def test_all_allowed_region(self):
        from PIL import Image
        Image.new('L', (6, 6), 255).save(self.mask)
        cli('diff', '--original', self.a, '--result', self.b, '--mask', self.mask, '--enforce', script=VISUAL)

    def test_difference_file_generated(self):
        difference = self.dir / 'diff.png'
        cli('diff', '--original', self.a, '--result', self.b, '--difference', difference, script=VISUAL)
        self.assertTrue(difference.is_file())


class ScorecardTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.form = Path(self.temp.name) / 'review.json'
        self.tool = ROOT / 'scripts' / 'scorecard.py'
        self.data = json.loads((ROOT / 'assets' / 'example-quality-evaluation.json').read_text(encoding='utf-8'))
        for gate in self.data['hard_gates']:
            self.data['hard_gates'][gate] = 'PASS'
        for dimension in self.data['manual_scores_0_to_5']:
            self.data['manual_scores_0_to_5'][dimension] = 5

    def tearDown(self):
        self.temp.cleanup()

    def run_review(self, expected=0):
        self.form.write_text(json.dumps(self.data), encoding='utf-8')
        return cli(self.form, script=self.tool, expect=expected)

    def test_complete_good_review(self):
        p = self.run_review()
        self.assertIn('"weighted_score": 100.0', p.stdout)

    def test_identity_bad_even_if_other_categories_good(self):
        self.data['manual_scores_0_to_5']['identity'] = 3
        p = self.run_review(expected=3)
        self.assertIn('identity_score_below_4', p.stdout)

    def test_hard_gate_overrides_high_score(self):
        self.data['hard_gates']['integrity'] = 'FAIL'
        p = self.run_review(expected=3)
        self.assertIn('"passed": false', p.stdout)

    def test_missing_human_scores_not_fake_auto_eval(self):
        self.data['manual_scores_0_to_5']['materials'] = None
        p = self.run_review(expected=2)
        self.assertIn('manually assigned', p.stderr)

    def test_edit_scope_can_be_not_applicable(self):
        self.data['hard_gates']['edit_scope'] = 'NOT_APPLICABLE'
        self.run_review()


if __name__ == '__main__':
    unittest.main()
