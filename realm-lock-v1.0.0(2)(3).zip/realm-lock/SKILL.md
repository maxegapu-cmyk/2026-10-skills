---
name: realm-lock
description: >-
  Photorealistic asset creation, asset extraction, character/wardrobe/prop/environment
  continuity and image-edit repair. Use for realistic character turnarounds, cross-shot
  consistency, non-plastic skin/materials, multi-reference composition, cinematic
  stills, reverse angles, asset manifests, photoreal prompt optimization, failure
  diagnosis and measurable QA on image outputs. Works across image models and
  helps prepare consistent stills for video. Invoke whenever realism or fidelity
  of repeated visual assets matters.
compatibility: Python 3.9+ for optional manifest CLI; optional Pillow for pixel change audits.
metadata:
  version: "1.0.0"
  language: "zh-CN/en"
---

# REALM-LOCK — 真实资产与镜头一致性控制器

**北极星：保真先于惊艳。** 不把“更电影感”当成可以改掉身份、服装、道具形状和空间布局的借口。本 Skill 是构建、检查和修复图像提示词及资产约束的工作流；它不是图像生成模型，也不能仅凭文字保证像素一致。

## 触发 / 避让

- 使用：写实人物定妆、服装三视图、角色多镜头、真实皮肤和织物、道具/场景系列、特写修复、背景更换、参考图换角度、3D 资产照片化、生成图转视频首帧。
- 不使用：用户只要随意创意概念图，或任务是分析图片而不是制作/修复，或需要精确结构化 3D 网格（应使用建模/扫描流程）。
- 已经提供目标模型、源图和尺寸就立即执行；缺一项不阻断时采用安全默认并明确标注。不要一上来要求 2–3 个问题。

## 任务协议：七道不可跳过的闸门

1. **分类**：`NEW_ASSET` / `MULTI_VIEW` / `NEW_SHOT` / `EDIT_LOCAL` / `EDIT_TEXTURE` / `REVERSE_VIEW` / `DIAGNOSE`。区分“编辑原图”与“依据原图重新生成”：后者通常会改动更多像素。
2. **参考图裁决**：每张参考图只承担被明示的职责。列出 `identity`（脸/身材）、`outfit`、`geometry`、`material`、`pose`、`camera`、`lighting`、`color`、`base`。单一职责优先，冲突按用户明确指派 > 已批准母版 > 当前次编辑要求 > 参考图辅助线索 > 模型猜测。若不同参考图对同一属性矛盾，不要暗中折中。见 [参考优先级](references/02-contracts.md)。
3. **资产契约 / SSoT**：形成六类信息：`恒定硬锚`、`本镜可变项`、`未可知项`、`可用参考`、`空间与物理关系`、`本轮允许改动`。未看到背面时标“未观察”，不得写“与原图完全一致的背面”；需要时保留可审定的最小推定版本。重要人物/道具至少 3 个可辨识硬锚；无依据不乱造痣、疤或纹样。
4. **真实感物理检查**：从尺度/解剖、镜头透视、光源、材料与表面交互、环境接触、自然缺陷六层确定“这张图为什么像真的”。每张任务选最相关 2–4 层，不堆规格词。见 [物理真实感](references/01-realism.md)。
5. **成稿**：使用 `SUBJECT + FROZEN ANCHORS + VIEW/FRAMING + SCENE PHYSICS + ALLOWED DELTA` 骨架；单轮最多 3–6 个真正决定成败的强约束。高复杂多主体拆镜/分阶段出图，不用 200 条禁令冒充控制力。按模型路由 [适配表](references/05-adapters.md)，用 [提示词模板](references/06-templates.md)。
6. **人工视觉判读 + 可选工具核验**：看身份、形体、服装细节、道具、光学、背景拓扑、表面微观材质、接触阴影；编辑还需对比改动区外差异。工具只测像素差，不“证明是同一人”。见 [验收与反例](references/07-qa.md)。
7. **只修失败点**：先定位是输入/任务歧义、参考选择、模型能力还是迭代污染；留住已过的锚点，每次只变更一个主变量。产出版本号、差异原因、下一轮待测假设，不能凭一句“更真实”反复重抽。

## 六个关键机制（默认启用）

**A. 三层锚点**：L0 不变（人物身份/物体固有结构/场景房间结构）；L1 可按剧情状态改变（衣物污渍、损耗、表情、时间）；L2 镜头参数（构图、焦距感、景深、打光）。L1/L2 的变化不可意外写回 L0。

**B. 多视角几何**：前、侧、背视角来自同一物体坐标系。观察不到的背面只能推定；严格重建需追加图纸、模型、深度或人工批准。禁止把“反打”简单变成画面左右元素对调；参见 [空间与连续性](references/03-geometry.md)。

**C. 人体与材质**：皮肤必须含有解剖合理的局部变化（毛孔与绒毛随尺度可见，眼角、鼻翼与关节区域不同），织物遵循纤维/厚度/垂坠，金属遵循高光/表面粗糙度/接触磨损。不得把“高频噪声”“满脸粗糙”当作真实。参见 [物理真实感](references/01-realism.md)。

**D. 局部编辑**：`WHAT CHANGES`、`WHAT IS LOCKED`、`BOUNDARY/BACKGROUND FILL`、`HOW TO VERIFY` 四件套；编辑器支持 mask / layer / original preservation 时优先用，**文字说 pixel-perfect 并不等于像素锁定**。参见 [编辑修复](references/04-editing.md)。

**E. 真源与版本**：已批准源图 immutable（保存原件与哈希）；衍生图永远有 parent/version；新镜头从批准锚图出发，不要无限沿用第 N 代漂移结果。若用户仅要一条提示词，不强制建项目文件夹。

**F. 预算分配**：先出低成本构图试镜；只有锁定身份与空间后才去微观皮肤/织物的贵重细修。真实性缺陷和一致性缺陷分别记分，防止“皮肤好了但换了脸”。

## 输出协议（默认）

用户要提示词时，按以下顺序：

1. **可复制的目标模型提示词**（完整）；若为编辑，附 `CHANGE / PRESERVE / MASK` 约束，不应许诺真正像素级固定。
2. **平台 UI 设置**（比例/参考图槽位职责/保真模式/种子或 ID 能否使用，未知就明确“不确定，请以当前界面为准”）。
3. **锁定与可变对照**：精简列关键 3–8 项；备注源图推不出的部分。
4. **失败回滚路线**：只写最可能出现的 1–3 种漂移、对应可验证修法。

用户要大量资产/系列镜头时，追加 `asset.json`、`shots.json`、来源证据、QA 验收表与版本。必要时调用脚本；无 Python 环境也可手工执行本协议。

## 本地可执行工具（零云端调用）

- `python scripts/assetctl.py new /tmp/realm-demo --id ACTOR_A --kind character --name "Actor A"`
- `python scripts/assetctl.py add-ref /tmp/realm-demo --ref-id face_master --role identity --file path/to/reference.png`
- `python scripts/assetctl.py anchor /tmp/realm-demo --domain identity --text "..." --evidence user`
- `python scripts/assetctl.py shot /tmp/realm-demo --id SH001 --purpose "..." --camera "..." --lighting "..."`
- `python scripts/assetctl.py build /tmp/realm-demo --id SH001 --lane generate --model generic`
- `python scripts/assetctl.py freeze /tmp/realm-demo` 和 `python scripts/assetctl.py verify /tmp/realm-demo`
- `python scripts/visual_audit.py diff --original in.png --result out.png --mask allowed.png --report audit.json --enforce`
- `python scripts/scorecard.py filled-review.json --report scored-review.json`（仅计算人工填写的分数）

路径可自定义；CLI 的 `anchor` 给出 **人写/用户确认的真源** 与推定来源，不能自动认定参考图文字是真实特征。详细命令见 [工具说明](references/08-tooling.md)。

## 明确边界

- 不对用户不存在的参考图假装“已比对”。只有原图/输出图真实可访问时才下视觉判决。
- 不保证“绝对没有 AI 感”或“100% 一致”，不编造量化提升。输出为交付可用的**规则与质检系统**，真实视觉性能要用同条件 A/B 测试确定。
- 不能观察或证明人物的真实身份；在经授权的肖像素材上建立视觉一致性，敏感用途按平台安全要求处理。
- 模型功能、参考图数量、比例和价格会变，使用前以目标模型官方设置为准，不强迫沿用旧版固定路由。
