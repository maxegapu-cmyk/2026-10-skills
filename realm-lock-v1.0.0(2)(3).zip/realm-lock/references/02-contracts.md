# Asset Contract / 资产真源、证据、优先级

核心原则：将**可观察事实**与**画面缺失处的推测**分开。视频、剧照和 2D 单图不是完整三维资产。

## 参考图表（手工或通过 assetctl）

| ID | 允许承担的角色 | 权威等级 | 覆盖的特征 | 不得迁移的特征 |
|---|---|---|---|---|
| FACE_A | identity | A | 颧骨、鼻梁、眼距、发际线 | 衣服、背景、光色 |
| OUTFIT_B | outfit | A | 领口、口袋、纽扣、层叠 | B 图的脸 |
| POSE_C | pose | B | 关节位置与站姿 | C 图身份/肤色 |
| BASE_D | base | A | 旧图全部像素/构图基线 | 不自动授权新增物体 |

`A` 是对应角色的权威，不代表参考图能回答一切。最终当前用户指令覆盖旧 A 的 **允许改动**，但不能顺手重做未改动的其他域。

### 来源等级

- `observed`：确实可从图中看见，应该有参考文件 ID。
- `user`：由用户直接定义为资产设定（例如背面有一条缝，但此处图没有）。
- `inferred`：根据已有图合理补全，输出需标为猜测，不能宣称精确同一。
- `unknown`：没有证据，按最小方案处理或留下缺口，不生成“100%真实背面”口径。

## 固定和变化分离

```yaml
asset_id: actor_01
L0_identity:
  - medium-width nose bridge; lower eyelid folds; asymmetrical left eyebrow
L0_wardrobe_design:
  - off-white jacket; four matte buttons; left chest seam; dark stitched collar
L0_body_geometry:
  - 7.5 head-to-height ratio (only if measured/confirmed)
L1_scene_state:
  - clean jacket at SH010
  - dust across right shoulder at SH020 (story cause documented)
L2_camera:
  - front neutral at SH010
  - left three-quarter at SH020
unknowns:
  - exact rear stitching hidden from all approved references
```

注意：上面的比例是**示范**，不能给未测量的角色填一个看似精确的数。

## 多参考图投喂规则

1. 每张图编号，附一行“取/不取”说明；图片数量不是越多越好，加入冲突图反而稀释特征。
2. 同一特征如脸部只选择一个主参考，其他只能补充侧面/表情等不冲突信息。若模型支持专业身份/风格锚（Character ID、Reference Element、Moodboard），在真实支持且用户有权限时启用。
3. 人物真实感母版与场景风格参考分离。不要让场景色调参考改写脸型、身高、衣服切口。
4. 参考图角色不能仅靠提示词编号就自动得到模型遵从。检查平台能否针对每图指定权重/人物槽位；不支持时减少图数、分阶段生成或在拼版上直观标明图职责。
5. 新视角结果经人工审核通过才可进入 approved_master，不合格的衍生图不能反过来覆盖主参考。

## 图像可证 / 不可证

可证：特定镜头看得见的脸型轮廓、衣服颜色、局部口袋位置、身后窗户相对方向。
不可证：被遮住的衣服背部所有细节、不可见墙后的门、发型背面、原图人物真实 3D 体型、跨视角的精确光谱。任务要求严格一致时直接报告“参考不足，需要补图/建模”。

## 变更申请

编辑前写一行：`Asset A / source v1 / request Δ = right sleeve becomes torn / allowed: cloth edge, shadow only / forbidden: face, silhouette, camera, jacket base fabric / inspect: before-after with change mask`。

唯一真源设计：`asset.json` 保存锚点与参考图哈希，`shots.json` 只记录镜头要求；`baseline.lock.json` 记录已批准契约指纹。详见 `scripts/assetctl.py`。
