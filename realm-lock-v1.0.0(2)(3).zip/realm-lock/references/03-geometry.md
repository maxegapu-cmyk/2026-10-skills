# Geometry, multi-view and shot continuity / 空间几何

## 多视图不是换一个脸的抽卡游戏

要保持摄像机位置变化而身份稳定，原则上冻结同一个人/物体几何：头宽/深度、眼鼻耳结构、肩宽、手臂比例、衣物分割线、纹样连接、发际线、四肢长度。仅描述镜头相对主体坐标系：

- `front`: camera on subject +front axis; torso squared, face frontal.
- `left profile`: camera at subject's left side; left ear, nose silhouette visible.
- `back`: camera behind same subject; face naturally absent; same clothes silhouette.
- `three-quarter`: camera between front and side (specify subject-relative side).

不能要求“背面镜头还能完整看到正脸”或“头顶角度、正面、背面全保持相同脸部像素”；它们本就不是同一投影。

## 人物/服装三视图（标准）

- 推荐先做**单张中性正面母版**→锁审脸与服装→分别生成左侧/背面；当平台多面板一图稳定时才用三面板；不稳定则单独出片后拼版。
- 标准三栏：左全身正面（头脚完整），中全身背面（头脚完整），右脸部特写（单独验证身份）——或者按照用户明确要求调整。
- 所有面板尽量中性光线、相机高度/正交感统一，背景无干扰；用于资产验收时不能使用戏剧性的强暗影掩盖比例。
- 隐藏区域变化必须记录为推断。只有正面一张时，背部细节是**设计重建**而非“精确提取”。

## 场景坐标

建立统一世界坐标：例如入口门为 (0,0)、窗户为东墙、桌子在中央，人物在桌子南侧。换角前先写世界布局，再从新摄像机投影验证左右遮挡。

常见错误：把原画里“左边的桌子”机械翻转到“右边”就叫反打。在真实空间中桌子的屏幕左右位置由摄像机朝向、距离、物体深度和遮挡关系共同决定，可能仍在左边，也可能出画。

### 反打示例

世界布局：窗在北墙；桌在房间中央；人物站桌南侧；柜子在东墙。
- A：摄像机在南侧朝北，窗在背景，柜子多见于画面右侧。
- B：摄像机在东北角朝西南，窗在右后缘甚至出画，柜子可能近景遮挡，桌子仍居中偏前。需要以 B 的投影关系描写而不是简单“所有左右反过来”。

## 连续性状态机

```text
APPROVED_MASTER(v1)
  -> SH010 clean/neutral [APPROVED]
  -> SH020 rain + wet jacket [APPROVED] (state: WET)
  -> SH030 indoor dry jacket [REQUIRES DRYING EVENT]
```

把不同时间的状态当不同 `L1`，但 `L0` 不变。动作幅度、发丝风向、雨滴路径、光源方向与镜头剪接须能连起来。对视频首帧只提交已批准的图，不拿漂移末帧当长期真源。

## 视角变换能力边界

高精度多视角结构需要 3D 重建、深度图/几何约束、相机标定、人工建模或更多参考图。纯文生图很可能在衣领背部、口袋和纽扣上 hallucinate。逐次生成后审查实物连接件。
