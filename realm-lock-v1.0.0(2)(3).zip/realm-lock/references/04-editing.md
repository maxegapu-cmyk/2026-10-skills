# Surgical Editing / 可验证编辑

## 路径选择，不锁死厂商

- 能在像素层解决的修改（替换背景、物体遮挡、局部修图）优先真图层编辑、mask/inpaint/composite；编辑模型是可选工具。
- 需要保留原图元素的大面积改造：用目标编辑模型的原图/参考输入，高保真模式可用则开启；不要把“100% pixel identical”写在提示词里后就当作锁住。
- 如果用户实际要求换角度/重塑结构，承认这是重生成/新镜头。原图的全局像素不可能保持一致，应检查**结构相容**而不是像素相同。
- 连续编辑多次后每次审查，出现累计身份偏移应从批准母版重新做，不以出问题的上一步为源。

## 编辑任务的四字段

```text
SOURCE: image A (approved master; use this as the image input).
CHANGE: Replace only the damaged right cuff with the original jacket's intact cuff design.
PRESERVE: face and expression, hair, body silhouette, left sleeve, coat seams,
          all other garment regions, visible props, background geometry,
          framing, exposure, color grading, original noise/grain character.
BOUNDARY: transition should follow the cuff seam; match sleeve-fold tension,
          shadow falloff and nearby fabric weave.
VERIFY: compare the original and result side-by-side; inspect beyond the
        right cuff to reject identity, layout and wardrobe changes.
```

变更区以遮罩限定优先于只用语言声明；物理必须联动的变化（物体换了，新接触阴影变化）应在遮罩内留出实际影响范围。

## 修改一个可见瑕疵时

1. 首先定位“是源图错还是编辑模型改坏”；如果源图本就有塑料皮肤，不要假装这是单轮新引入。
2. 仅围绕目标区域修：脸部肤质不是修脸型；牙齿高光不是重塑笑容；鞋的地面阴影不是改变鞋尺寸。
3. 受光情况在修改区内闭合；不要因“更好看”把所有皮肤重新磨平、眼睛放大或服装提亮。
4. 人工 QA 审一次，必要时用 `visual_audit.py diff` 对改动区外差异做客观量化。超过阈值意味着需要复核，不等于作品自动失败（压缩、色彩管理、重新编码都会造成全局像素差异）。

## 纹理增强专项

按面部 T 区/面颊/眼下、织物纬向、皮革拉伸/金属涂层**局部因果**修复。优先对真实的材质差异做分区，不加均匀的 grain 或 pore grid。将 texture pass 和 identity fix 分开进行；若 texture pass 改脸/口袋则拒收或回滚。

## 可逆性

绝不能覆盖批准母版。版本命名 `SH010_v01.png`、`SH010_v02_edit-cuff.png`；记录 source SHA256/提示词/model/参数/评语。无法保真的改动写成新生成版本，不能标作无损编辑。
