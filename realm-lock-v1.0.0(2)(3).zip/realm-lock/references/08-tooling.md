# Local CLI / 命令说明与注意事项

Python 3.9+ 可用：`scripts/assetctl.py` 零第三方依赖；像素审计要求 Pillow（安装命令 `python -m pip install Pillow`）。不需要登录、联网、额外 API 密钥。

```
python scripts/assetctl.py new ./work/actor01 --id actor01 --kind character --name "Actor 01"
python scripts/assetctl.py add-ref ./work/actor01 --ref-id face_master --role identity --file ./source.png
python scripts/assetctl.py anchor ./work/actor01 --domain identity --text "Medium width nose, slightly asymmetrical eyebrows" --evidence observed --ref-id face_master
python scripts/assetctl.py anchor ./work/actor01 --domain wardrobe --text "Four dull brass buttons on a heavy twill jacket" --evidence user
python scripts/assetctl.py shot ./work/actor01 --id S01 --purpose "neutral full-body photo" --camera "eye-level frontal, full-body" --lighting "large softbox upper left"
python scripts/assetctl.py check ./work/actor01 --strict
python scripts/assetctl.py freeze ./work/actor01
python scripts/assetctl.py build ./work/actor01 --id S01 --lane generate --model generic
python scripts/assetctl.py verify ./work/actor01
```

生成文件：`asset.json`（锚点）、`shots.json`（镜头）、`baseline.lock.json`（冻结指纹）、`outputs/S01-generate-generic.txt`（提示词）、同名 `.plan.json`（参考职责/验收）。`add-ref` 会把实际参考图片复制到工程内 `refs/` 并记录 SHA256，避免改变外部原文件。

可用证据类别：`observed`（必须指定参考 ID）、`user`、`inferred`、`unknown`；域：`identity`, `geometry`, `wardrobe`, `material`, `environment`, `lighting`, `camera`, `state`。`freeze` 要求来源文件存在且哈希匹配，冻结后修改资产契约会触发 `verify` 失败；如需正式批准新母版，应由人确认后显式重新 freeze，脚本不会自动批准。

局部编辑需要 `--lane edit` 并在 shot 时指定 `--change`；`--lane texture` 是材质专用更改；反打 `--lane reverse` 应写新摄像机角度并评估空间位置。`build` 生成文本，不会调用模型、不会自动分析图片。

像素差分：

```
python scripts/visual_audit.py diff --original ./approved.png \
  --result ./candidate.png --mask ./allowed-change.png \
  --threshold 18 --max-outside-change-pct 0.25 \
  --report ./pixel-audit.json --difference ./diff.png --enforce
```

白 mask = 允许发生变化；灰度 >127 算允许区；阈值 `18` 表示单个通道 0..255 中 RGB 最大通道差超过 18 就算该像素“改变”。`--max-outside-change-pct 0.25` 表示区域外允许最多 **0.25%** 的像素超阈值，作为初始排错门槛而不是通用验收标准。若没有 mask，默认全画面属于应保留区域。若全局做过重编码、调色、对齐，差分可能产生大量假阳性，此时应先统一尺寸/色彩空间/对齐策略并由人工复核。

为增强可移植性，本工具刻意不自动对齐/重采样图像。错位会直接影响差分结果，应从同尺寸同坐标画面入手。

人工打分表：复制 `assets/example-quality-evaluation.json`，填好八维人工分数（0–5）和六个硬门槛（`PASS`/`FAIL`；不涉及编辑时 `edit_scope` 可为 `NOT_APPLICABLE`），再运行：

```
python scripts/scorecard.py ./filled-review.json --report ./scored-review.json
```

未评分时明确报错，不会伪装自动测过视觉性能。达标建议须满足 ≥85 分、身份和结构 ≥4/5、硬门槛全部通过。三脚本成功退出码 0、错误 2；差分/人工审核未达标准退出码 3，可用于批量质量门禁。
