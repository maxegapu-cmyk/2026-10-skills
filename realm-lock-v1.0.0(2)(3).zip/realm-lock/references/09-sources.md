# Sources & research provenance (verified 2026-10-24)

This skill was newly authored for the user after inspecting the supplied `LIRA SKILL` single-file reference (as a source of task categories and known pitfalls), with a new evidence-aware contract, geometry workflow, physical-realism controls, auditing, and tooling. Original upstream terms/licensing were not provided. We do not redistribute the uploaded third-party original, nor claim an endorsement or license to it.

Official documentation used to verify **capabilities rather than performance claims**:

1. Agent Skills open specification: https://agentskills.io/specification — frontmatter rules; scripts/references optional; progressive disclosure.
2. Claude Code skills documentation: https://code.claude.com/docs/en/skills — skill discovery, project path and command invocation.
3. Higgsfield Soul ID help (Aug 2026): https://higgsfield.ai/creator-hub/help-center/ai-models/how-do-i-create-and-use-a-soul-id-character — authorization and training photo guidance (20–80 images in current official help); actual UI may change.
4. Higgsfield Soul Cinema help (Aug 2026): https://higgsfield.ai/creator-hub/help-center/ai-models/how-do-i-use-soul-cinema — Soul ID / HEX capability, difference from Soul 2.0.
5. Higgsfield Soul family help: https://higgsfield.ai/creator-hub/help-center/ai-models/how-do-i-use-soul-to-generate-images — 2.0 Moodboard, Soul HEX, settings.
6. Google Gemini image-generation guide: https://ai.google.dev/gemini-api/docs/image-generation — image + text editing, prompt precision, model capability details. Check model-specific docs for multi-reference limits.

Known uncertainty: Some provider blogs and help-center articles have conflicting minimum numbers of training images or old model names. Use the dated official help-center instructions for planning, but **check the actual UI**. We don't encode external vendor parameter limits in executable checks because they can change quickly.

Methodology disclaimer: human QA rubric and 85-point threshold are original proposals, not scientifically validated benchmarks. No visual-model renders or side-by-side outcome scores were produced as part of this package's development. CLI tests validate logic/packaging only.
