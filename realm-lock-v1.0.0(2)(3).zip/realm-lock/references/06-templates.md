# Prompt patterns / 生产模板

输出语言可中文/英文；以下英语例句是可替换结构，不可对每个任务硬套。

## A. 单人中性定妆母版（先做这个）

```text
A neutral, real photographic studio capture of [approved character identity].
Keep the face's specific proportions and natural asymmetry from Reference FACE_A:
[3-5 distinguishable visible facial anchors]. [Distinct body ratio and hairstyle].
[Exact clothes construction, materials, color, buttons, seams, wear state].
Standing comfortably in a neutral pose on a plain mid-gray studio background,
full body visible, eye-level camera with restrained perspective and moderately
wide depth of field. One broad soft key from camera left, gentle floor contact
shadow, real fabric weight and naturally varied skin microtexture at the
appropriate image scale. Realistic hair clumps and subtle uneven highlights.
Natural restrained image processing; preserve the person's actual proportions.
```

UI: identity reference assigned; full-body composition; stable aspect; controlled exposure.

## B. 三视图：推荐三张分别出片

**前**：`Use the same approved actor and exact clothes. Neutral head-to-toe frontal full-body photograph, arms loose, neutral floor contact, straight posture. [hard anchors].`

**侧**：`Use the same approved actor and exact clothes. True left-side profile from the subject's left, head-to-toe. Maintain head depth, nose projection, shoulder and torso dimensions, identical garment collar and seam continuity. [anchors].`

**背**：`Use the same approved actor and exact clothes. True rear view, head-to-toe, consistent silhouette, garment material, hem length and visible side seam continuity. Previously unseen rear seam design remains minimal and is a proposed inference, not a verified extracted detail.`

拼版图流程：只有当每一视图单独通过人工检查，才组合成左/中/右。用户指定的“左正面无头、中背面、右头部”应优先，且不得凭被裁掉的头判断身份。

## C. 多角色同框 / 避免串脸

```text
Two distinct adults in a single realistic frame. Left subject = Reference A
for face/body and Reference B for outfit; right subject = Reference C for
face/body and Reference D for outfit. Their facial features, hair, clothing
and body proportions must stay separate. Left subject stands near the window
[spatial coordinate]; right subject sits behind the table [coordinate].
Camera at [height/direction], a single [source] illuminates both, with
occlusion and contact shadows consistent with their blocking. [actual action].
```

需要时先做 A/B 各自母版，合成同框再检验引用关系；避免图序含糊。

## D. 真实环境与反打

```text
A realistic photograph from [new camera position] looking [direction]
through [defined room]. The approved world layout remains fixed: [north wall,
window, east cabinet, central table, doorway]. From this viewpoint the
[near element] partially occludes [far element] and the [window] is
[actually visible / out of view]. The room's surface materials remain
[brick/paint/wood], with a [directional source] casting coherent shadows.
[Selected camera profile and color response; no contradictory optics].
```

## E. 物件/服装资产照片化

```text
A photographic product study of [one object], exact silhouette and
construction from Reference GEO_A: [dimensions if known, joints, seams,
fasteners, panel order]. Physically believable [materials] with
[material-specific roughness and reflectance], subtle wear only at
actual contact edges. Clean neutral support surface, consistent contact
shadow, a large diffused key from upper left, three-quarter viewpoint
showing all critical parts. Keep markings and small parts in their
original location and number.
```

## F. 编辑/局部质感修复

```text
Edit the uploaded original, not a fresh remake.
CHANGE: [one bounded target with final visual state].
PRESERVE: [all identity, construction, room topology, camera, grade and untouched parts].
BOUNDARY: [mask or strictly localized coordinates + light/material interaction].
VERIFY: [specific artifact positions + altered/outside regions to compare].
```

## G. 视频起始关键帧

只输出图像静态状态，锁身份/服装/道具/空间与下一镜过渡需要的画面方位。运动指令应另交视频模块；不要将 `15s`、复杂长动作和图像相机元数据混在图像生图提示词中，除非模型有这种能力。

### Prompt 过度冗长时的缩减顺序

先删除空泛形容词和一切声称“masterpiece, best quality”的词；再删与该镜无关的光学、颜色和微纹理；最后合并重复硬锚。**永远不要为了压缩删掉决定身份、服装结构、物体数目和视角的关键信息。**
