# Model Adapters / 模型能力按可用功能路由

**不要将源稿的“固定模型排行榜”当事实**：模型迭代快，平台接口/Web 版本差异大。执行前检查当前用户选定平台是否支持：reference slots、identity/character ID、mask editing、seed、aspect ratio、native resolution、style / color control。不能确定时不写死数值。

| 任务 | 要优先寻找的平台能力 | 若缺失 |
|---|---|---|
| 身份跨镜头 | 已授权的人脸身份训练/Character ID + 稳定母版图 | 参考图分角色投喂 + 单镜独立 QA |
| 资产多视图 | 多角度参考 + camera/view control | 每视图生成后人工拼版，不虚构背面 |
| 局部编辑 | mask/inpainting + 原图输入 + strength/保真控制 | 降低改动范围，生成后差分检查 |
| 材质真实 | 局部纹理/区域编辑 + 清晰材质参考 | 描述具体表面而不是全图加噪 |
| 室内反打 | 空间布局参考 + 深度/3D 场景 | 明示建筑拓扑，人工验证遮挡关系 |
| 电影剧照 | 受控主光 + 适用构图 + identity/style controls | 优先锁物理和面部，后处理风格 |

## Higgsfield (Soul 2.0 / Soul Cinema / Soul ID)

根据 2026-08 官方帮助页，Soul ID 需多张获授权角色图片，且可跨 Soul 家族用于身份一致性；官方入门说明推荐 20 张或以上，多至 80 张。Soul 2.0 的 Moodboard 与 Soul HEX 可做风格/色彩控制；官方明确 Soul Cinema 可用 Soul ID 和 Soul HEX，但不支持 Soul 2.0 的 Moodboard 功能。详见 `references/09-sources.md`。UI 细节会变化。

操作：角色母版放入 Soul ID（若已训练且用户有使用权）；另用硬锚写衣服/伤痕/身形；环境镜头可用 Soul Cinema，但仍要核对镜头几何。没有 Soul ID 时，使用单张高质量批准母版并在每镜人工验收，不宣称“文字即锁脸”。

## Google/Gemini Image / Nano Banana 系列

官方支持图像+文字编辑及多轮迭代，并在模型特定文档给出多参考图与高分辨率特性。受能力、入口与版本变化影响，**不得假设所有 Nano Banana 版本的图像数量、负面参数、mask 行为完全相同**。使用 user interface/API 真实提供的保真/参考能力；局部编辑仍需对改动区外差分复核。详见 `references/09-sources.md`。

## Other image models

仅填当前产品确实支持的参数。模型仅支持通用文本时采用简洁自然语言描述；有负面提示通道才将明确“不希望出现”的要素放入该通道；没有就写正向期望。是否写比例到提示词取决于目标平台：能在 UI 控制就优先 UI 设置，不能时用构图语言表达但不可保证尺寸。

## 不依赖品牌的生成路线

1. 现实参考/资产身份 -> 锚点与图职责。
2. 中性母版/几何 -> 漂移排查与批准。
3. 单镜构图/灯光 -> 固定锚点下制作镜头。
4. 材质与局部瑕疵 -> 区域精修。
5. QA/重生或回滚 -> 下游视频首帧。

**不要凭厂商宣传语给真实性打分**；品牌报道是功能线索不是你的 A/B 结果。
