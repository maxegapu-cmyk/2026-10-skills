# REALM-LOCK v1.0.0 · Release notes · 2026-10-24

Status: Packaged, functional CLI smoke tested and offline regression suite passed. Visual model performance **not evaluated**; not a guarantee of image-generation outcome.

## New capabilities

1. Evidence-scoped reference roles and uncertainty handling; no unjustified hidden-back reconstruction.
2. L0/L1/L2 asset state control; consistent identity vs scene state vs camera changes.
3. Six-layer photorealism framework: anatomy/scale, optics, light, material response, contact physics, contextual imperfections.
4. Multi-view and reverse-angle world topology consistency; novel projected views are never falsely called pixel-identical.
5. Surgical edit repair with bounded edit scopes, optional masks and irreversible-original avoidance.
6. Offline artifact manager with source checksums, baseline freeze and immutable evidence ledger.
7. Optional Pillow pixel-mask QA plus explicit human-rubric scorer with hard failure gates.
8. Version-neutral model routing; dated capability citations; 10 predefined difficult A/B benchmark tasks.

## Tested

- 33 automated unit/regression tests across CLI happy/negative paths.
- Release ZIP is unpacked into a clean temporary directory, manifest hashes verified, whole test suite re-run, and public CLI image/anchor/freeze/prompt/verify + visual diff/score workflows smoke tested.
- None of the checks test remote image generation models. Only real model-render A/B blind judging can establish empirical visual improvement over the external starting material.

## Requirements

Core Skill: any Agent Skills-compatible host; local tools: Python >=3.9, Pillow only for optional pixel audit. No network/API keys.

## SHA-256

See the outer delivery message for the complete ZIP SHA-256, or compute it locally with `sha256sum realm-lock-v1.0.0.zip`.
