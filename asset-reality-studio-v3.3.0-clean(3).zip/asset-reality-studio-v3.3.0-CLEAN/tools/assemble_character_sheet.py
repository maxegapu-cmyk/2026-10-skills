#!/usr/bin/env python3
"""Deterministically assemble the strict client character-sheet template.

STRICT CLIENT TEMPLATE:
LEFT   = front wardrobe/body, head removed only during assembly
MIDDLE = complete back full body including back of head
RIGHT  = approved close Identity Master portrait

The compositor normalizes source margins before assembly so the final template does
not depend on how much empty studio background each source generation happened to
contain.
"""
from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path
from typing import Optional, Tuple

from PIL import Image, ImageChops, ImageDraw, ImageOps

cv2 = None
np = None

RGB = tuple[int, int, int]
Box = tuple[int, int, int, int]

# Geometry measured from the user-approved client structure, expressed in panel space.
STRICT_FRONT_TARGET = (0.245, 0.045, 0.755, 0.975)  # complete person BEFORE head mask
STRICT_BACK_TARGET = (0.265, 0.035, 0.735, 0.975)
STRICT_PORTRAIT_TARGET = (-0.015, 0.020, 1.015, 1.055)  # shoulders may crop at bottom


def bg_from_edges(im: Image.Image) -> RGB:
    """Robust neutral-backdrop estimate from top/corner regions, avoiding shoulders at lower edges."""
    rgb = im.convert("RGB")
    w, h = rgb.size
    bw = max(6, w // 10)
    bh = max(6, h // 10)
    th = max(4, h // 22)
    patches = [
        rgb.crop((0, 0, bw, bh)),
        rgb.crop((w - bw, 0, w, bh)),
        rgb.crop((0, 0, w, th)),
    ]
    pixels = []
    for patch in patches:
        pixels.extend(patch.get_flattened_data() if hasattr(patch, "get_flattened_data") else list(patch.getdata()))
    chans = []
    for c in range(3):
        vals = sorted(px[c] for px in pixels)
        chans.append(vals[len(vals) // 2])
    return tuple(int(v) for v in chans)  # type: ignore[return-value]


def foreground_bbox(im: Image.Image, bg: RGB, threshold: int = 24) -> Optional[Box]:
    """Estimate the non-background envelope on a neutral seamless backdrop."""
    rgb = im.convert("RGB")
    bg_im = Image.new("RGB", rgb.size, bg)
    diff = ImageChops.difference(rgb, bg_im).convert("L")
    mask = diff.point(lambda p: 255 if p >= threshold else 0)
    return mask.getbbox()


def expand_box(box: Box, size: tuple[int, int], frac: float = 0.015) -> Box:
    x1, y1, x2, y2 = box
    w, h = size
    dx = max(2, int((x2 - x1) * frac))
    dy = max(2, int((y2 - y1) * frac))
    return max(0, x1 - dx), max(0, y1 - dy), min(w, x2 + dx), min(h, y2 + dy)


def place_subject(
    im: Image.Image,
    out_size: tuple[int, int],
    target_norm: tuple[float, float, float, float],
    bg: RGB,
) -> tuple[Image.Image, Box]:
    """Crop to the subject envelope and normalize it into a fixed target box."""
    src = im.convert("RGB")
    sb = foreground_bbox(src, bg)
    if sb is None:
        raise ValueError("Could not detect subject against neutral background")
    sb = expand_box(sb, src.size)
    crop = src.crop(sb)

    ow, oh = out_size
    tx1 = int(round(target_norm[0] * ow))
    ty1 = int(round(target_norm[1] * oh))
    tx2 = int(round(target_norm[2] * ow))
    ty2 = int(round(target_norm[3] * oh))
    tw, th = max(1, tx2 - tx1), max(1, ty2 - ty1)

    is_portrait = target_norm == STRICT_PORTRAIT_TARGET
    if is_portrait:
        scale = max(tw / crop.width, th / crop.height)
    else:
        # Full-body client template is height-anchored: head/feet positions matter more than incidental source margins.
        scale = th / crop.height
        max_body_width = 0.74 * ow
        if crop.width * scale > max_body_width:
            scale = max_body_width / crop.width
    nw = max(1, int(round(crop.width * scale)))
    nh = max(1, int(round(crop.height * scale)))
    resized = crop.resize((nw, nh), Image.Resampling.LANCZOS)

    cx = (tx1 + tx2) // 2
    # Full-body plates sit on the lower target edge; portrait covers its target and is vertically centered.
    x = cx - nw // 2
    y = ((ty1 + ty2) // 2 - nh // 2) if is_portrait else (ty2 - nh)

    canvas = Image.new("RGB", out_size, bg)
    canvas.paste(resized, (x, y))
    placed_box = (x, y, x + nw, y + nh)
    return canvas, placed_box


def auto_face_box(im: Image.Image) -> Optional[Box]:
    global cv2, np
    if cv2 is None or np is None:
        try:
            import cv2 as _cv2  # type: ignore
            import numpy as _np  # type: ignore
            cv2, np = _cv2, _np
        except Exception:
            return None
    arr = cv2.cvtColor(np.array(im.convert("RGB")), cv2.COLOR_RGB2GRAY)
    cascade_path = cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
    cascade = cv2.CascadeClassifier(cascade_path)
    faces = cascade.detectMultiScale(arr, scaleFactor=1.08, minNeighbors=5, minSize=(32, 32))
    if len(faces) == 0:
        return None
    x, y, w, h = max(faces, key=lambda b: b[2] * b[3])
    # Expand from detected internal face to full head, while stopping near neck/collar.
    return int(x - 0.55 * w), int(y - 0.95 * h), int(x + 1.55 * w), int(y + 1.30 * h)


def heuristic_head_box(subject_box: Box) -> Box:
    """Conservative full-body fallback for neutral standing people."""
    x1, y1, x2, y2 = subject_box
    sw, sh = x2 - x1, y2 - y1
    cx = (x1 + x2) / 2
    half = 0.34 * sw
    # Mask through the neck line. The wider box guarantees ears/hair are removed while shoulders remain outside.
    return int(cx - half), y1 - 2, int(cx + half), int(y1 + 0.135 * sh)


def parse_norm_box(s: str, size: tuple[int, int]) -> Box:
    vals = [float(v.strip()) for v in s.split(",")]
    if len(vals) != 4 or any(v < 0 or v > 1 for v in vals):
        raise ValueError("--head-box must be x1,y1,x2,y2 normalized to 0..1")
    w, h = size
    return int(vals[0] * w), int(vals[1] * h), int(vals[2] * w), int(vals[3] * h)


def map_box_from_source_to_strict_front(box: Box, src: Image.Image, panel: Image.Image, bg: RGB) -> Box:
    """Map a manually supplied source-space head box through strict subject normalization."""
    sb = foreground_bbox(src, bg)
    if sb is None:
        raise ValueError("Could not detect front subject for manual head-box mapping")
    sb = expand_box(sb, src.size)
    sx1, sy1, sx2, sy2 = sb
    crop_w, crop_h = sx2 - sx1, sy2 - sy1
    pw, ph = panel.size
    tx1, ty1, tx2, ty2 = STRICT_FRONT_TARGET
    tw, th = (tx2 - tx1) * pw, (ty2 - ty1) * ph
    scale = min(tw / crop_w, th / crop_h)
    nw, nh = crop_w * scale, crop_h * scale
    px = ((tx1 + tx2) * pw / 2) - nw / 2
    py = ty2 * ph - nh
    x1, y1, x2, y2 = box
    return (
        int(px + (x1 - sx1) * scale),
        int(py + (y1 - sy1) * scale),
        int(px + (x2 - sx1) * scale),
        int(py + (y2 - sy1) * scale),
    )


def mask_box_with_background(im: Image.Image, box: Box, bg: RGB) -> Image.Image:
    out = im.convert("RGB").copy()
    w, h = out.size
    x1, y1, x2, y2 = box
    x1, y1 = max(0, x1), max(0, y1)
    x2, y2 = min(w, x2), min(h, y2)
    if x2 <= x1 or y2 <= y1:
        return out
    # Neutral studio output: flat matched background is safer than inventing anatomy/shadow.
    ImageDraw.Draw(out).rectangle((x1, y1, x2, y2), fill=bg)
    return out


def legacy_contain(im: Image.Image, size: tuple[int, int], bg: RGB) -> Image.Image:
    canvas = Image.new("RGB", size, bg)
    tmp = ImageOps.contain(im.convert("RGB"), size, method=Image.Resampling.LANCZOS)
    canvas.paste(tmp, ((size[0] - tmp.width) // 2, (size[1] - tmp.height) // 2))
    return canvas


def legacy_cover(im: Image.Image, size: tuple[int, int]) -> Image.Image:
    return ImageOps.fit(im.convert("RGB"), size, method=Image.Resampling.LANCZOS, centering=(0.5, 0.42))



def assemble_strict(
    front_src: Image.Image,
    back_src: Image.Image,
    portrait_src: Image.Image,
    *,
    panel_width: int = 700,
    height: int = 1172,
    separator: int = 0,
    source_head_box: Optional[Box] = None,
    auto_head_mask: bool = False,
    fourth_src: Optional[Image.Image] = None,
) -> Image.Image:
    """Assemble the canonical strict client template entirely in memory.

    Sources are normalized independently. FRONT must be a complete human; the head is
    masked only here. RIGHT is never regenerated: only deterministic crop/resize is used.
    """
    front_src = front_src.convert("RGB")
    back_src = back_src.convert("RGB")
    portrait_src = portrait_src.convert("RGB")
    size = (panel_width, height)
    bg = bg_from_edges(front_src)

    front_panel, front_subject_box = place_subject(front_src, size, STRICT_FRONT_TARGET, bg)
    back_bg = bg_from_edges(back_src)
    back_panel, _ = place_subject(back_src, size, STRICT_BACK_TARGET, back_bg)
    portrait_bg = bg_from_edges(portrait_src)
    portrait_panel, _ = place_subject(portrait_src, size, STRICT_PORTRAIT_TARGET, portrait_bg)

    if source_head_box is not None:
        head_box = map_box_from_source_to_strict_front(source_head_box, front_src, front_panel, bg)
    else:
        hb = heuristic_head_box(front_subject_box)
        if auto_head_mask:
            fb = auto_face_box(front_panel)
            if fb is not None:
                head_box = (min(hb[0],fb[0]), min(hb[1],fb[1]), max(hb[2],fb[2]), max(hb[3],fb[3]))
            else:
                head_box = hb
        else:
            head_box = hb
    front_panel = mask_box_with_background(front_panel, head_box, bg)
    strict_cut_y = int(round(0.160 * height))
    ImageDraw.Draw(front_panel).rectangle((0, 0, panel_width, strict_cut_y), fill=bg)

    panels = [front_panel, back_panel, portrait_panel]
    if fourth_src is not None:
        panels.append(legacy_cover(fourth_src.convert("RGB"), size))

    sep = max(0, separator)
    total_w = len(panels) * panel_width + (len(panels) - 1) * sep
    sheet = Image.new("RGB", (total_w, height), bg)
    x = 0
    sep_color = tuple(max(0, min(255, c + 18)) for c in bg)
    draw = ImageDraw.Draw(sheet)
    for i, panel in enumerate(panels):
        sheet.paste(panel, (x, 0))
        x += panel_width
        if i < len(panels) - 1 and sep:
            draw.rectangle((x, 0, x + sep - 1, height), fill=sep_color)
            x += sep
    return sheet


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--front", required=True)
    ap.add_argument("--back", required=True)
    ap.add_argument("--portrait", required=True)
    ap.add_argument("--fourth")
    ap.add_argument("--output", required=True)
    ap.add_argument("--panel-width", type=int, default=700)
    ap.add_argument("--height", type=int, default=1172)
    ap.add_argument("--separator", type=int, default=0)
    ap.add_argument("--strict-client-template", action="store_true", help="explicitly select strict client template (also the default)")
    ap.add_argument("--legacy-layout", action="store_true", help="opt out of strict client template")
    ap.add_argument("--validation-report", help="strict-mode layout validation JSON path")
    ap.add_argument("--auto-head-mask", action="store_true")
    ap.add_argument("--head-box", help="manual x1,y1,x2,y2 normalized 0..1 on FRONT SOURCE")
    ap.add_argument("--left-already-headless", action="store_true", help="legacy-only; invalid in strict mode")
    args = ap.parse_args()

    strict_mode = args.strict_client_template or not args.legacy_layout

    if strict_mode and args.left_already_headless:
        raise SystemExit("STRICT CLIENT TEMPLATE requires a complete front source; --left-already-headless is forbidden.")

    front_src = Image.open(args.front).convert("RGB")
    back_src = Image.open(args.back).convert("RGB")
    portrait_src = Image.open(args.portrait).convert("RGB")
    bg = bg_from_edges(front_src)
    size = (args.panel_width, args.height)

    if strict_mode:
        src_head = parse_norm_box(args.head_box, front_src.size) if args.head_box else None
        fourth_src = Image.open(args.fourth).convert("RGB") if args.fourth else None
        sheet = assemble_strict(
            front_src, back_src, portrait_src,
            panel_width=args.panel_width,
            height=args.height,
            separator=args.separator,
            source_head_box=src_head,
            auto_head_mask=args.auto_head_mask,
            fourth_src=fourth_src,
        )
    else:
        front_work = front_src
        if not args.left_already_headless:
            box = None
            if args.head_box:
                box = parse_norm_box(args.head_box, front_src.size)
            elif args.auto_head_mask:
                box = auto_face_box(front_src)
                if box is None:
                    sb = foreground_bbox(front_src, bg)
                    if sb is not None:
                        box = heuristic_head_box(sb)
            if box is None:
                raise SystemExit("Choose --auto-head-mask, --head-box, or --left-already-headless.")
            front_work = mask_box_with_background(front_src, box, bg)
        panels = [legacy_contain(front_work, size, bg), legacy_contain(back_src, size, bg), legacy_cover(portrait_src, size)]
        if args.fourth:
            panels.append(legacy_cover(Image.open(args.fourth).convert("RGB"), size))
        sep = max(0, args.separator)
        total_w = len(panels) * args.panel_width + (len(panels) - 1) * sep
        sheet = Image.new("RGB", (total_w, args.height), bg)
        x = 0
        sep_color = tuple(max(0, min(255, c + 18)) for c in bg)
        draw = ImageDraw.Draw(sheet)
        for i, panel in enumerate(panels):
            sheet.paste(panel, (x, 0))
            x += args.panel_width
            if i < len(panels) - 1 and sep:
                draw.rectangle((x, 0, x + sep - 1, args.height), fill=sep_color)
                x += sep

    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    sheet.save(args.output, quality=96)
    print(f"Wrote {args.output} ({sheet.width}x{sheet.height})")

    # Strict mode is self-validating: an invalid client template is a failed build, not a warning.
    if strict_mode and not args.fourth:
        validator = Path(__file__).with_name("validate_character_sheet.py")
        report = Path(args.validation_report) if args.validation_report else Path(args.output).with_suffix(".layout.json")
        cmd = [sys.executable, str(validator), "--image", str(args.output),
               "--panel-width", str(args.panel_width), "--height", str(args.height),
               "--separator", str(args.separator), "--report", str(report)]
        result = subprocess.run(cmd, text=True, capture_output=True)
        if result.stdout:
            print(result.stdout.strip())
        if result.returncode != 0:
            if result.stderr:
                print(result.stderr.strip(), file=sys.stderr)
            raise SystemExit(result.returncode)


if __name__ == "__main__":
    main()
