#!/usr/bin/env python3
"""Validate the strict client triptych geometry.

Layout/occupancy only. This does not automatically detect all AI artifacts; the visual
Reality Gate remains mandatory.
"""
from __future__ import annotations
import argparse, json
from pathlib import Path
from PIL import Image, ImageChops

RGB=tuple[int,int,int]

def bg_from_edges(im: Image.Image) -> RGB:
    rgb=im.convert('RGB'); w,h=rgb.size
    bw=max(6,w//10); bh=max(6,h//10); th=max(4,h//22)
    patches=[rgb.crop((0,0,bw,bh)),rgb.crop((w-bw,0,w,bh)),rgb.crop((0,0,w,th))]
    px=[]
    for patch in patches: px.extend(patch.get_flattened_data() if hasattr(patch,'get_flattened_data') else list(patch.getdata()))
    out=[]
    for c in range(3):
        vals=sorted(p[c] for p in px); out.append(vals[len(vals)//2])
    return tuple(out)  # type: ignore

def mask_and_bbox(im: Image.Image, threshold=24):
    bg=bg_from_edges(im); diff=ImageChops.difference(im.convert('RGB'),Image.new('RGB',im.size,bg)).convert('L')
    mask=diff.point(lambda p:255 if p>=threshold else 0)
    return mask, mask.getbbox(), bg

def frac(mask: Image.Image, box):
    c=mask.crop(box); data=(c.get_flattened_data() if hasattr(c,'get_flattened_data') else list(c.getdata()))
    return (sum(1 for p in data if p>0)/len(data)) if data else 0.0

def norm_bbox(b,w,h):
    if not b: return None
    return [round(b[0]/w,4),round(b[1]/h,4),round(b[2]/w,4),round(b[3]/h,4)]

def validate_triptych(im: Image.Image, *, panel_width: int|None=None, height: int|None=None, separator: int=0) -> dict:
    im=im.convert('RGB'); W,H=im.size; failures=[]
    if height is not None and H!=height: failures.append(f'height {H} != expected {height}')
    sep=max(0,separator); pw=panel_width or ((W-2*sep)//3)
    expected=3*pw+2*sep
    if W!=expected: failures.append(f'canvas width {W} != strict 3-panel width {expected}')
    if pw<=0: failures.append('invalid panel width')
    panels=[]
    if not failures:
        x=0
        for i in range(3):
            panels.append(im.crop((x,0,x+pw,H))); x+=pw
            if i<2: x+=sep
    report={'size':[W,H],'panel_width':pw,'separator':sep,'checks':{},'failures':failures}
    if panels:
        names=['left','middle','right']; info={}
        for name,p in zip(names,panels):
            m,b,bg=mask_and_bbox(p); info[name]=(m,b,bg); report['checks'][name]={'bbox':norm_bbox(b,pw,H)}
            if b is None: failures.append(f'{name}: no foreground subject detected')
        if all(info[n][1] is not None for n in names):
            lm,lb,_=info['left']; mm,mb,_=info['middle']; rm,rb,_=info['right']
            lx1,ly1,lx2,ly2=lb; mx1,my1,mx2,my2=mb; rx1,ry1,rx2,ry2=rb
            if not (0.150 <= ly1/H <= 0.205): failures.append(f'left: visible body top {ly1/H:.3f} outside 0.150..0.205')
            if ly2/H < 0.92: failures.append(f'left: shoes/body bottom too high {ly2/H:.3f}')
            if not (0.20 <= (lx2-lx1)/pw <= 0.68): failures.append('left: body occupancy width outside plausible strict range')
            if abs(((lx1+lx2)/2)/pw-0.5) > 0.10: failures.append('left: body not centered')
            head_clear=frac(lm,(int(.34*pw),int(.02*H),int(.66*pw),int(.135*H)))
            report['checks']['left']['head_clear_foreground_fraction']=round(head_clear,4)
            if head_clear > 0.035: failures.append(f'left: head-clear zone contains foreground ({head_clear:.3f})')
            if not (0.02 <= my1/H <= 0.095): failures.append(f'middle: back-of-head top {my1/H:.3f} outside 0.02..0.095')
            if my2/H < 0.92: failures.append(f'middle: shoes/body bottom too high {my2/H:.3f}')
            if abs(((mx1+mx2)/2)/pw-0.5) > 0.10: failures.append('middle: body not centered')
            head_present=frac(mm,(int(.39*pw),int(.025*H),int(.61*pw),int(.17*H)))
            report['checks']['middle']['head_zone_foreground_fraction']=round(head_present,4)
            if head_present < 0.01: failures.append('middle: complete back-of-head not detected in head zone')
            if ry1/H > 0.12: failures.append(f'right: portrait subject begins too low {ry1/H:.3f}')
            if ry2/H < 0.85: failures.append(f'right: portrait/shoulders do not fill lower frame {ry2/H:.3f}')
            if (rx2-rx1)/pw < 0.70: failures.append('right: portrait too small for identity slot')
            upper_presence=frac(rm,(int(.18*pw),int(.04*H),int(.82*pw),int(.62*H)))
            report['checks']['right']['upper_identity_foreground_fraction']=round(upper_presence,4)
            if upper_presence < 0.12: failures.append('right: insufficient head/face occupancy')
    report['failures']=failures; report['pass']=not failures
    return report

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--image',required=True); ap.add_argument('--panel-width',type=int); ap.add_argument('--height',type=int); ap.add_argument('--separator',type=int,default=0); ap.add_argument('--report'); args=ap.parse_args()
    im=Image.open(args.image).convert('RGB')
    report=validate_triptych(im,panel_width=args.panel_width,height=args.height,separator=args.separator); report['image']=str(args.image)
    if args.report:
        Path(args.report).parent.mkdir(parents=True,exist_ok=True); Path(args.report).write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    if not report['pass']:
        print('TEMPLATE FAIL'); [print('-',f) for f in report['failures']]; raise SystemExit(2)
    print('TEMPLATE PASS')

if __name__=='__main__': main()
