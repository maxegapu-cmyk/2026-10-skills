#!/usr/bin/env python3
"""Deterministic finalization gate for visually scored human assets.

Scores must come from inspection of the actual generated image (human or trusted vision review),
not from the prompt. This tool makes the acceptance rule non-negotiable; it is not an AI detector.
"""
from __future__ import annotations
import argparse, json
from pathlib import Path

REQUIRED = ('first_impression','identity','skin','hair','eyes','mouth_teeth','body_hands','wardrobe_material','optics','overall')
MIN_EACH=8.5
MIN_AVG=9.0


def evaluate(data: dict) -> tuple[bool,list[str],float]:
    failures=[]
    if data.get('reference_floor_parity') is not True:
        failures.append('reference-floor parity not confirmed')
    veto=data.get('hard_veto') or []
    if veto:
        failures.append('HARD VETO: '+', '.join(map(str,veto)))
    scores=data.get('scores') or {}
    vals=[]
    for k in REQUIRED:
        if k not in scores:
            failures.append(f'missing score: {k}'); continue
        try: v=float(scores[k])
        except Exception:
            failures.append(f'invalid score: {k}'); continue
        if not 0<=v<=10:
            failures.append(f'score out of range: {k}={v}'); continue
        vals.append(v)
        if v<MIN_EACH: failures.append(f'{k} below {MIN_EACH}: {v}')
    avg=(sum(vals)/len(vals)) if vals else 0.0
    if len(vals)==len(REQUIRED) and avg<MIN_AVG:
        failures.append(f'average below {MIN_AVG}: {avg:.2f}')
    return (not failures),failures,avg


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('scorecard')
    ap.add_argument('--report')
    args=ap.parse_args()
    data=json.loads(Path(args.scorecard).read_text(encoding='utf-8'))
    ok,failures,avg=evaluate(data)
    report={'pass':ok,'average':round(avg,3),'minimum_each':MIN_EACH,'minimum_average':MIN_AVG,'failures':failures}
    if args.report: Path(args.report).write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print('REALITY GATE PASS' if ok else 'REALITY GATE FAIL')
    print(f'average: {avg:.2f}')
    for f in failures: print('-',f)
    raise SystemExit(0 if ok else 2)

if __name__=='__main__': main()
