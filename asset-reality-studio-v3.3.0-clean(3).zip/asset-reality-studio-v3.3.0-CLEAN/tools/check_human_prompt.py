#!/usr/bin/env python3
"""Lint a human-source generation prompt for high-risk AI/render language.

This does not judge an output image. It only detects prompt patterns that commonly push
identity assets toward concept-art/digital-human rendering instead of ordinary casting photography.
"""
from __future__ import annotations
import argparse, re
from pathlib import Path

HIGH_RISK = {
    'hyperrealistic': 3,
    'hyper-realistic': 3,
    'ultra detailed': 3,
    'ultra-detailed': 3,
    '8k': 2,
    '16k': 2,
    'masterpiece': 3,
    'best quality': 2,
    'pbr skin': 4,
    'pbr': 2,
    'unreal engine': 4,
    'zbrush': 4,
    'metahuman': 4,
    'octane render': 4,
    'blender render': 4,
    'game character': 4,
    'character concept': 4,
    'concept art': 3,
    'cinematic character': 3,
    'dramatic villain': 3,
    'perfect pores': 4,
    'every pore': 4,
    'individual hair strands': 3,
    'every individual hair': 4,
    'hdr': 2,
    'razor sharp': 2,
    'extreme microdetail': 3,
}
SAFE_ANCHORS = ('casting photograph','wardrobe-continuity','wardrobe continuity','unretouched','ordinary photograph','documentary photograph')


def lint(text: str) -> tuple[int,list[str]]:
    low=text.lower()
    issues=[]; score=0
    for term,w in HIGH_RISK.items():
        if term in low:
            issues.append(f'high-risk phrase: {term} (+{w})'); score+=w
    words=re.findall(r"\b\w+[\w'-]*\b", text)
    if len(words)>190:
        issues.append(f'prompt bloat: {len(words)} words (>190) (+3)'); score+=3
    elif len(words)>140:
        issues.append(f'prompt long: {len(words)} words (>140) (+1)'); score+=1
    # Detect dense negative stacks rather than one targeted exclusion.
    negs=len(re.findall(r'\b(no|not|without|avoid|never)\b',low))
    if negs>=8:
        issues.append(f'negative stack: {negs} negation terms (+3)'); score+=3
    elif negs>=5:
        issues.append(f'negative-heavy prompt: {negs} negation terms (+1)'); score+=1
    if not any(a in low for a in SAFE_ANCHORS):
        issues.append('missing ordinary capture anchor (+1)'); score+=1
    return score,issues


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('prompt_file')
    ap.add_argument('--max-risk',type=int,default=2,help='maximum accepted risk score')
    args=ap.parse_args()
    text=Path(args.prompt_file).read_text(encoding='utf-8')
    score,issues=lint(text)
    print(f'PROMPT RISK SCORE: {score}')
    for x in issues: print('-',x)
    if score>args.max_risk:
        print('PROMPT LINT FAIL')
        raise SystemExit(2)
    print('PROMPT LINT PASS')

if __name__=='__main__': main()
