from pathlib import Path
import importlib.util, sys
root=Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('gate',root/'tools/reality_gate.py'); gate=importlib.util.module_from_spec(spec); spec.loader.exec_module(gate)
base={'reference_floor_parity':True,'hard_veto':[], 'scores':{k:9.2 for k in gate.REQUIRED}}
ok,fail,avg=gate.evaluate(base); assert ok and not fail
# Every dimension individually below the floor must reject.
for k in gate.REQUIRED:
    x={'reference_floor_parity':True,'hard_veto':[], 'scores':dict(base['scores'])}; x['scores'][k]=8.49
    ok,fail,avg=gate.evaluate(x); assert not ok and any(k in f for f in fail), (k,fail)
# Every representative hard veto must reject.
for veto in ['generic digital-human face','uniform PBR skin','CG-groom hair','glassy decorative eyes','identity drift','broken anatomy','wrong triptych layout']:
    x={'reference_floor_parity':True,'hard_veto':[veto],'scores':dict(base['scores'])}; ok,fail,avg=gate.evaluate(x); assert not ok
# Reference floor is absolute.
x={'reference_floor_parity':False,'hard_veto':[],'scores':dict(base['scores'])}; assert gate.evaluate(x)[0] is False
print('reality gate pressure PASS')
