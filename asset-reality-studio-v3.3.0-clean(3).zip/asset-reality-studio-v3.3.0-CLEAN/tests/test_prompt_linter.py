from pathlib import Path
import subprocess, sys, tempfile
root=Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parents[1]; lint=root/'tools/check_human_prompt.py'
with tempfile.TemporaryDirectory() as td:
    td=Path(td)
    good=td/'good.txt'; bad=td/'bad.txt'; bloated=td/'bloated.txt'
    good.write_text('An ordinary unretouched casting photograph of a real middle-aged Chinese working man against neutral grey seamless paper. His face has mild natural asymmetry, regionally varied skin response and quiet low-information skin zones. Plain soft studio light, restrained local contrast, ordinary lens softness.',encoding='utf-8')
    bad.write_text('Hyperrealistic cinematic character sheet, 8K masterpiece, ultra detailed pores, PBR skin, dramatic villain portrait, perfect individual hair strands, HDR, Unreal Engine, ZBrush.',encoding='utf-8')
    bloated.write_text('An ordinary casting photograph. '+'skin pores detailed ' * 100,encoding='utf-8')
    assert subprocess.run([sys.executable,str(lint),str(good)],capture_output=True).returncode==0
    assert subprocess.run([sys.executable,str(lint),str(bad)],capture_output=True).returncode!=0
    assert subprocess.run([sys.executable,str(lint),str(bloated)],capture_output=True).returncode!=0
print('prompt linter PASS')
