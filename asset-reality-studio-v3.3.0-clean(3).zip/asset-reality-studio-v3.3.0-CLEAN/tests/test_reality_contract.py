from pathlib import Path
import sys
root=Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parents[1]
text='\n'.join(p.read_text(encoding='utf-8',errors='ignore') for p in root.rglob('*.md'))
need=[
'STRICT CLIENT TEMPLATE','BIOLOGICAL FINGERPRINT','STRICT REALITY MODE',
'one-shot sheet is a protocol failure','template validator','source plate must be a complete person',
'front visible subject target','back full subject target','Reality Reference is mandatory',
'generic digital-human face','Quiet-region rule','MACRO','MESO','MICRO','OPTICAL',
'90–100 + no HARD VETO','REJECT & REGENERATE','skin-only masked pass','structure branch',
]
missing=[x for x in need if x not in text]
assert not missing, f'missing reality contract terms: {missing}'
print('reality contract PASS')
