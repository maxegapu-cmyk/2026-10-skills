from pathlib import Path
import subprocess, sys

ROOT = Path(__file__).resolve().parents[1]
TESTS = sorted(p for p in (ROOT / 'tests').glob('test_*.py'))
failures = []
for test in TESTS:
    print(f'== {test.name} ==')
    result = subprocess.run([sys.executable, str(test)], cwd=str(ROOT))
    if result.returncode != 0:
        failures.append(test.name)
if failures:
    print('FAILED:', ', '.join(failures))
    raise SystemExit(1)
print(f'ALL PASS: {len(TESTS)}/{len(TESTS)}')
