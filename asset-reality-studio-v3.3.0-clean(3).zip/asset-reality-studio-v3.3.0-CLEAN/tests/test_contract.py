from pathlib import Path
import sys
root=Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parents[1]
req=[
'SKILL.md','references/HUMAN_REALITY_ENGINE.md','references/ASSET_LAYOUT_PROTOCOL.md',
'references/REFERENCE_CONTROL.md','references/REPAIR_ROUTER.md',
'references/SCENE_PROP_REALITY_ENGINE.md','references/QUALITY_GATES.md',
'references/PROMPT_RECIPES.md','references/COMFYUI_REALITY_PLAYBOOK.md',
'references/RESEARCH_NOTES.md','references/STRICT_TRIPTYCH_TEMPLATE.md','references/ANTI_AI_CAPTURE_PROTOCOL.md','references/REALITY_GATE_SCORECARD.json','tools/assemble_character_sheet.py','tools/validate_character_sheet.py','tools/check_human_prompt.py','tools/reality_gate.py']
missing=[x for x in req if not (root/x).exists()]
assert not missing, f'missing: {missing}'
text='\n'.join((root/x).read_text(encoding='utf-8',errors='ignore') for x in req if x.endswith('.md'))
need=['THUMBNAIL','100%','200%','HARD VETO','REFERENCE FLOOR','DETAIL BUDGET',
      'MACRO','MESO','MICRO','OPTICAL','Identity Reference','Reality Reference',
      'Wardrobe Reference','Layout Reference','PORTRAIT-FIRST','BIOLOGICAL FINGERPRINT',
      'STRICT CLIENT TEMPLATE','STRICT REALITY MODE','Never generate the final triptych in one pass',
      'low-denoise','Skin pass','contact wear','gravity','manufacturing','fastener','Optional fourth panel','CLIENT TEMPLATE FINGERPRINT','zero-separator equal thirds','AI-FIRST-IMPRESSION VETO','low-information skin zones','Reality Gate evidence','reference-floor parity']
missing_terms=[x for x in need if x not in text]
assert not missing_terms, f'missing terms: {missing_terms}'
print('contract PASS')
