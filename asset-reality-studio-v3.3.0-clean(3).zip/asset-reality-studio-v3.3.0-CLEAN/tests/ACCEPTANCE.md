# Acceptance scenarios — v3.2

## Failure classes being prevented

- final sheet generated in one AI pass
- wrong left/middle/right semantics
- left source generated anatomically headless
- visible head residue or over-cut shoulders on LEFT
- missing back-of-head/shoes on MIDDLE
- small or regenerated portrait on RIGHT
- generic digital-human / game-character first impression
- uniform PBR-like skin microtexture
- strand-by-strand CG hair
- glassy eyes, cosmetic mouth/teeth, over-clean wardrobe materials
- prompt-side rendering language (`8K`, `masterpiece`, `PBR`, `Unreal`, `hyperrealistic` stacks)
- asset approved without comparison to the user's Reality Reference

## Required strict behavior

1. CLIENT TEMPLATE FINGERPRINT = zero-separator equal thirds; default 2100×1172.
2. PORTRAIT-FIRST. The right-panel portrait becomes the approved Identity Master.
3. Identity Reference and Reality Reference remain separate controls.
4. Reality Reference is the minimum floor, not optional inspiration, whenever supplied/approved.
5. A locked BIOLOGICAL FINGERPRINT prevents generic optimized faces.
6. THUMBNAIL / 100% / 200% inspection precedes approval.
7. AI-FIRST-IMPRESSION VETO rejects a digital-human face before micro-detail repair.
8. Human prompts run through the prompt linter before strict production.
9. Correct identity + local material defect may be repaired conservatively; wrong construction is regenerated.
10. Front source and back source are complete humans generated separately.
11. LEFT becomes headless only during deterministic assembly.
12. MIDDLE contains complete back-of-head and shoes.
13. RIGHT is the approved Identity Master and is never regenerated during assembly.
14. Template validator must PASS.
15. Reality Gate evidence must PASS: reference-floor parity true, no HARD VETO, every dimension ≥8.5, mean ≥9.0.
16. Optional fourth panel never alters the first three semantic slots.
