from pathlib import Path
import importlib.util, sys, random
from PIL import Image, ImageDraw
root=Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parents[1]
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m
asm=load('asm',root/'tools/assemble_character_sheet.py')
val=load('val',root/'tools/validate_character_sheet.py')
assert hasattr(asm,'assemble_strict'), 'assemble_strict API missing'
assert hasattr(val,'validate_triptych'), 'validate_triptych API missing'
rng=random.Random(32092026); bg=(106,106,106)
for i in range(100):
    def mkbody(w,h,box):
        im=Image.new('RGB',(w,h),bg); d=ImageDraw.Draw(im); x1,y1,x2,y2=box; sw=x2-x1; sh=y2-y1; cx=(x1+x2)/2
        d.ellipse((int(cx-.12*sw),y1,int(cx+.12*sw),int(y1+.13*sh)),fill=(174,136,108))
        d.rectangle((int(cx-.30*sw),int(y1+.12*sh),int(cx+.30*sw),int(y1+.70*sh)),fill=(34,42,52))
        d.rectangle((int(cx-.24*sw),int(y1+.68*sh),int(cx-.03*sw),y2),fill=(38,40,45)); d.rectangle((int(cx+.03*sw),int(y1+.68*sh),int(cx+.24*sw),y2),fill=(38,40,45))
        return im
    # Deliberately huge variation in margins, source aspect and body size.
    fw,fh=rng.randint(420,900),rng.randint(700,1300); sh=rng.randint(int(fh*.58),int(fh*.90)); sw=min(int(sh*rng.uniform(.28,.42)),fw-20); fx=rng.randint(5,max(5,fw-sw-5)); fy=rng.randint(5,max(5,fh-sh-5))
    bw,bh=rng.randint(420,900),rng.randint(700,1300); s2h=rng.randint(int(bh*.58),int(bh*.90)); s2w=min(int(s2h*rng.uniform(.28,.42)),bw-20); bx=rng.randint(5,max(5,bw-s2w-5)); by=rng.randint(5,max(5,bh-s2h-5))
    front=mkbody(fw,fh,(fx,fy,fx+sw,fy+sh)); back=mkbody(bw,bh,(bx,by,bx+s2w,by+s2h))
    portrait=Image.new('RGB',(rng.randint(500,900),rng.randint(700,1200)),bg); d=ImageDraw.Draw(portrait); W,H=portrait.size
    d.ellipse((int(.22*W),int(.05*H),int(.78*W),int(.56*H)),fill=(174,136,108)); d.rectangle((int(.05*W),int(.50*H),int(.95*W),H),fill=(34,42,52))
    sheet=asm.assemble_strict(front,back,portrait,panel_width=350,height=586,separator=0)
    rep=val.validate_triptych(sheet,panel_width=350,height=586,separator=0)
    assert rep['pass'], (i,rep)
# Bad layout must be rejected: three full-body panels with no close portrait.
bad=Image.new('RGB',(1050,586),bg); d=ImageDraw.Draw(bad)
for off in (0,350,700):
    d.ellipse((off+160,25,off+190,55),fill=(174,136,108)); d.rectangle((off+125,55,off+225,550),fill=(34,42,52))
badrep=val.validate_triptych(bad,panel_width=350,height=586,separator=0)
assert badrep['pass'] is False and any('right' in f for f in badrep['failures']), badrep
print('FAST TEMPLATE PRESSURE PASS: 100/100 randomized strict assemblies + bad-layout rejection')
