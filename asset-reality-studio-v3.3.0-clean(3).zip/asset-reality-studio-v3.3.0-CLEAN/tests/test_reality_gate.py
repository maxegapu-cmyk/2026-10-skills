from pathlib import Path
import subprocess, sys, tempfile, json
root=Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parents[1]; gate=root/'tools/reality_gate.py'
base={'reference_floor_parity':True,'hard_veto':[], 'scores':{
'first_impression':9.5,'identity':9.3,'skin':9.1,'hair':9.0,'eyes':9.2,
'mouth_teeth':9.0,'body_hands':9.0,'wardrobe_material':9.2,'optics':9.1,'overall':9.2}}
with tempfile.TemporaryDirectory() as td:
    td=Path(td)
    def run(name,data):
        p=td/f'{name}.json'; p.write_text(json.dumps(data),encoding='utf-8')
        return subprocess.run([sys.executable,str(gate),str(p)],capture_output=True,text=True)
    assert run('ok',base).returncode==0
    x=json.loads(json.dumps(base)); x['reference_floor_parity']=False; assert run('badref',x).returncode!=0
    x=json.loads(json.dumps(base)); x['scores']['skin']=8.49; assert run('badskin',x).returncode!=0
    x=json.loads(json.dumps(base)); x['hard_veto']=['generic digital-human face']; assert run('veto',x).returncode!=0
    x=json.loads(json.dumps(base)); x['scores']['overall']=8.5; x['scores']['hair']=8.5; x['scores']['skin']=8.5; assert run('lowavg',x).returncode!=0
print('reality gate PASS')
