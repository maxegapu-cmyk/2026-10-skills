from pathlib import Path
from PIL import Image, ImageDraw
import subprocess, sys, tempfile
root=Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory() as td:
    td=Path(td)
    bg=(110,110,110)
    def body(path, back=False):
        im=Image.new('RGB',(500,900),bg); d=ImageDraw.Draw(im)
        # simple test fixture: head box and body
        d.ellipse((205,55,295,145),fill=(180,140,110))
        d.rectangle((150,145,350,730),fill=(40,45,55))
        d.rectangle((175,730,225,860),fill=(45,45,50)); d.rectangle((275,730,325,860),fill=(45,45,50))
        im.save(path)
    body(td/'front.png'); body(td/'back.png',True)
    portrait=Image.new('RGB',(500,900),bg); d=ImageDraw.Draw(portrait); d.ellipse((80,90,420,520),fill=(180,140,110)); portrait.save(td/'portrait.png')
    out=td/'sheet.png'
    cmd=[sys.executable,str(root/'tools/assemble_character_sheet.py'),'--front',str(td/'front.png'),'--back',str(td/'back.png'),'--portrait',str(td/'portrait.png'),'--output',str(out),'--head-box','0.36,0.03,0.64,0.19','--panel-width','300','--height','600']
    subprocess.check_call(cmd)
    im=Image.open(out)
    assert im.size==(900,600), im.size
    # masked head center on left should equal background-ish, not skin fixture
    p=im.getpixel((150,70))
    assert max(p)-min(p)<8, p
    print('compositor PASS')
