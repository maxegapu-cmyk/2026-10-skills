from pathlib import Path
from PIL import Image, ImageDraw
import subprocess, sys, tempfile, json
root=Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parents[1]; assembler=root/'tools/assemble_character_sheet.py'
with tempfile.TemporaryDirectory() as td:
    td=Path(td); bg=(104,104,104)
    def body(path, box):
        im=Image.new('RGB',(600,1000),bg); d=ImageDraw.Draw(im)
        x1,y1,x2,y2=box; sw=x2-x1; sh=y2-y1; cx=(x1+x2)/2
        d.ellipse((int(cx-.12*sw),y1,int(cx+.12*sw),int(y1+.13*sh)),fill=(175,136,108))
        d.rectangle((int(cx-.30*sw),int(y1+.12*sh),int(cx+.30*sw),int(y1+.70*sh)),fill=(34,42,52))
        d.rectangle((int(cx-.24*sw),int(y1+.68*sh),int(cx-.03*sw),y2),fill=(38,40,45))
        d.rectangle((int(cx+.03*sw),int(y1+.68*sh),int(cx+.24*sw),y2),fill=(38,40,45))
        im.save(path)
    body(td/'front.png',(120,35,480,965)); body(td/'back.png',(210,220,390,800))
    portrait=Image.new('RGB',(700,1000),bg); d=ImageDraw.Draw(portrait)
    d.ellipse((185,55,515,500),fill=(175,136,108)); d.rectangle((65,470,635,1000),fill=(34,42,52)); portrait.save(td/'portrait.png')
    out=td/'sheet.png'; rep=td/'report.json'
    r=subprocess.run([sys.executable,str(assembler),'--front',str(td/'front.png'),'--back',str(td/'back.png'),'--portrait',str(td/'portrait.png'),'--output',str(out),'--strict-client-template','--validation-report',str(rep)],capture_output=True,text=True)
    assert r.returncode==0, r.stdout+r.stderr
    im=Image.open(out); assert im.size==(2100,1172), im.size
    assert json.loads(rep.read_text())['pass'] is True
print('template fingerprint PASS')
