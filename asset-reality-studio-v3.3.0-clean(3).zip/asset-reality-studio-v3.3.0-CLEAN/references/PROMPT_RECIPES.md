# Prompt Recipes

## Strict Identity Master — anti-AI compact recipe

Use 2–6 purposeful sentences. The prompt should sound like an ordinary casting photographer's instruction, not a rendering brief. Run `tools/check_human_prompt.py` before generation.

```text
An ordinary unretouched casting photograph of a real [age] [identity/occupation], head-and-shoulders against neutral grey seamless paper. Preserve [3–6 stable identity anchors] and the locked biological fingerprint, with mild natural asymmetry, regionally varied skin response and quiet low-information skin zones. Plain 85mm portrait perspective, one large soft source slightly above and to one side, modest room fill, restrained local contrast, ordinary eye catchlights and naturally grouped hair edges. The result should feel physically recorded rather than visually designed.
```

Retry rule: add only the single observed failure constraint. Do not append a universal skin/hair/eye defect catalogue.


Recipes are starting structures. Keep them compact and attach clearly assigned references.

## Identity Master — strict documentary/casting capture

```text
An ordinary unretouched casting/wardrobe-continuity photograph of a real [age]-year-old [person], head and shoulders against neutral mid-grey seamless paper. Preserve these stable identity anchors: [3–6 anchors]. Preserve this locked biological fingerprint: [4–7 mild asymmetry/variation anchors]. The face is useful for identity reference but not passport-perfect: a tiny natural yaw/shoulder imbalance, quiet between-takes expression, ordinary eyelid and mouth tension.

Photograph with a normal short-telephoto portrait perspective and one large soft source slightly above and 25–40 degrees to one side with modest room fill. Keep regional skin response, grouped natural hair, ordinary eyes, restrained local contrast and depth softness consistent with the attached Reality Reference. Some facial regions remain visually quiet rather than carrying uniform microtexture.
```

On retries, append **one observed failure correction**, for example:

```text
The previous result looked digitally sculpted because both eyes/brows and cheek texture were too uniform. Preserve identity but make the locked fingerprint visibly natural and keep cheek/forehead texture regionally uneven rather than repeating the same skin frequency.
```

Do not add ten unrelated fixes in one retry.

## Front complete-person source

```text
A straightforward full-body wardrobe-continuity photograph of the exact approved Identity Master, facing camera in a neutral stance on the same mid-grey studio setup. The source plate must be a complete person from the top of the hair through both shoes; preserve the locked face, biological fingerprint, age, body build, hair, wardrobe, footwear and stable marks. Keep body posture, cloth weight, hands, wear and studio light ordinary and physically recorded rather than rendered. This source will be mechanically converted to the client's headless-left panel later; do not remove or crop the head during generation.
```

## Back complete-person source

```text
A straightforward complete full-body back-view continuity photograph of the exact approved person on the same studio setup. The entire back of the head and hair, neck, garment construction, hands, trousers and both shoes are visible. Preserve the same body proportions, hair mass/back hairline, wardrobe, footwear and material wear. Keep the person centered in a neutral stance with ordinary studio capture, not a character render.
```

## Reference assignment

```text
Identity Reference controls who the person is. Reality Reference controls only photographic credibility: biological material response, hair/eye behavior, optical softness, contrast and the minimum non-AI realism floor. Wardrobe Reference controls clothing and footwear. Layout Reference controls only final panel order, crop, spacing and subject scale. Never copy identity from Reality/Layout references.
```

## Local skin refinement

```text
Refine only the selected visible skin region. Preserve exact identity, skull/facial geometry, biological fingerprint, expression, gaze, hair shape, pose, crop, key-light direction and colour relationships. Replace uniform synthetic material response with subtle region-dependent roughness/colour variation and only the microdetail the existing focus/light would reveal. Leave quiet skin regions quiet and keep unaffected pixels unchanged.
```

## Local hair refinement

```text
Refine only the hair rendering while preserving the exact haircut silhouette, hairline, head shape, identity, grey pattern, light and pose. Convert synthetic strand-by-strand rendering into grouped natural masses with uneven density, local clumping, depth-dependent soft edges and only a few irregular flyaways. Keep unaffected pixels unchanged.
```

## Local eye refinement

```text
Refine only the eye/eyelid region while preserving exact gaze direction, iris identity, eyelid geometry, expression and face construction. Make sclera tone, moisture line and catchlights behave like ordinary soft-studio photography; catchlights follow the single real key source rather than decorative mirrored highlights. Keep unaffected pixels unchanged.
```

## Scene

```text
[Plain camera position]. [Specific place/era]. Geometry and construction are physically coherent: [major relationships/material joins]. Use history appears at plausible contact zones, with gravity-driven dust/water paths, directional fading and slight variation among repeated objects while some surfaces remain quiet. Primary light comes from [real source/direction] with plausible bounce/falloff. Add project look only after physical causality is stable.
```

## Prop

```text
A physically manufactured [object] photographed plainly against [setting]. Describe thickness, seams/fasteners/joints, finish, scale and how parts connect. Wear follows handling/force at [contact zones]; separate materials keep different roughness and reflectance. Keep surfaces plausible rather than uniformly perfect or randomly scratched.
```
