# Optional ComfyUI Reality Playbook

Use only when the user actually has a local diffusion/ComfyUI stack. Treat the numbers as starting ranges, not universal guarantees.

## Split conditioning by responsibility

Do not feed a flawed AI body image into a style/identity adapter and expect realism to improve. Separate:
- **identity branch:** PuLID / InstantID / PhotoMaker / FaceID-style conditioning when compatible with the chosen base model;
- **body/pose/wardrobe structure branch:** OpenPose, depth, softedge, lineart or segmentation ControlNet where appropriate;
- **Reality Reference / tonal branch:** photographic reference or original image used only for capture/material behavior;
- **text:** final subject, studio capture, biological fingerprint, clothing/material facts.

Too much identity weight can make the face rigid/synthetic; too much structure weight copies bad anatomy/style. Tune independently.

## Skin vs surface refinement

Specialize passes:
- skin-only masked pass: start around **0.10–0.20 denoise**;
- fabric/hair/environment/detail pass: start around **0.20–0.35 denoise**;
- feather masks; avoid hard seams;
- sharpening stays restrained.

Use dedicated skin-detail logic for skin. Do not apply the same surface-detail process to face, fabric, hair and background.

## Structural + tonal two-anchor route

For refinement models that re-encode and drift:
1. preserve the untouched source;
2. optional edge/Canny/structure control to lock contours;
3. masked low-denoise refinement;
4. original/tile/image anchor to preserve gaze, shadow relationships and tone;
5. feather/composite back.

If gaze, expression, face shape, biological fingerprint or identity changes, denoise/control freedom is too high.

## De-plastic postprocess route

A non-generative or lightly generative de-plastic pass can be useful when geometry is already human:
- attenuate waxy highlight sheen;
- introduce low-amplitude regional mottling, not global freckles;
- add restrained scale-appropriate skin breakup only inside a skin mask;
- add fine luminance grain only enough to unify the treated area.

This route is **not** a substitute for regenerating a generic digital-human face.

## Upscale

Prefer staged 2x/4x enlargement with local refinement over one aggressive giant upscale. Nominal 8K does not equal realism.
