# Quality Gates — Strict Reality

## Gate order

### THUMBNAIL
Ask before zooming:
- Does this read immediately as an ordinary photograph of a real person/object/place?
- Or as an AI character sheet, game asset, digital human, 3D render, concept art, synthetic product render?

If the human reads synthetic at THUMBNAIL, reject the Identity Master. Do not rescue with pores.

### 100%
Inspect identity construction, eyelids/eyes, mouth, skin-region transitions, hair mass/edges, ears/neck/hands, cloth/material behavior, light direction and capture coherence.

### 200%
Inspect only for repeated texture, oversharpening, mask seams, duplicated hair patterns, broken pores/stitches, local edit artifacts. Do not reject natural sensor/compression softness merely because it is not “perfect.”

## HARD VETO

Any one can reject regardless of numeric score:
- unmistakable digital-human/game-character facial construction
- generic optimized AI face that ignores the locked BIOLOGICAL FINGERPRINT
- wrong identity
- impossible anatomy
- CG-groom hair dominating the portrait
- jewel/glass eyes or decorative mirrored catchlights
- uniform PBR skin / same microtexture frequency across the whole face
- beauty-retouched/waxy skin that erases regional material behavior
- impossible scene perspective or prop construction
- one-shot triptych synthesis artifacts in STRICT CLIENT TEMPLATE mode
- left final panel contains a head/face or anatomical decapitation cue
- front SOURCE was generated headless instead of complete
- middle panel lacks complete back of head/hair or shoes
- right panel is not the approved Identity Master in strict mode

## Strict scoring

Human:
- 25 identity + biological facial construction
- 20 regional skin/material variation
- 15 hair/eyes/mouth secondary realism
- 15 optics/light/capture coherence
- 10 wardrobe/body physical behavior
- 10 absence of AI repetition/optimization
- 5 reference/layout compliance

### Acceptance
- **STRICT REALITY MODE:** 90–100 + no HARD VETO + meets/exceeds REFERENCE FLOOR.
- 85–89: repair/retry; not final strict acceptance.
- <85: reject/regenerate or repair according to failure class.

REFERENCE FLOOR always wins. A 94-score image that still looks more synthetic than the approved reference fails.

## Diagnostic comparison to the user's failed sample class

Common severe-AI signature:
- centered, near-bilateral facial construction;
- uniformly smooth/finely textured skin instead of regional variation;
- generic middle-aged face with no stable fingerprint;
- evenly distributed hair noise;
- flat/over-controlled studio exposure;
- every panel reads as one designed sheet rather than separately photographed source assets.

Expected route: reject Identity Master at MACRO/MESO level, rebuild with locked fingerprint + Reality Reference. Do **not** start with a global texture pass.


## Reality Gate evidence

Strict production uses `tools/reality_gate.py` with `references/REALITY_GATE_SCORECARD.json`. Score the **actual output image**, not its prompt. Required dimensions: first impression, identity, skin, hair, eyes, mouth/teeth, body/hands, wardrobe/material, optics, overall.

Acceptance contract:
- reference-floor parity = true
- hard_veto = empty
- every scored dimension ≥ 8.5 / 10
- mean score ≥ 9.0 / 10

These numbers are a strict finalization gate, not a claim that a stochastic generator can guarantee zero detectable AI artifacts on its first attempt.
