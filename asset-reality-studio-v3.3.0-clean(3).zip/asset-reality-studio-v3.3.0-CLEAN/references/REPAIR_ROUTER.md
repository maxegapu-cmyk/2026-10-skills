# Repair / Reject Router

## Principle

Repair only the component that is wrong. Surface tools cannot repair a wrong digital-human construction.

## STRUCTURAL / IDENTITY failure — reject and regenerate
- generic digital-human face/skull
- biological fingerprint absent or changed
- anatomy/body proportions wrong
- wrong hair mass/hairline geometry
- identity drift
- wrong gaze/eye geometry when it changes identity/expression
- impossible room perspective/prop construction
- wrong camera viewpoint

If the current failed image looks AI already at THUMBNAIL, assume structural/identity failure until proven otherwise.

## TONAL / MATERIAL failure — local repair may work
- plastic/waxy skin on otherwise correct identity and geometry
- same pore frequency across zones
- synthetic but correct hair edge/detail
- eye material/catchlight wrong while gaze/geometry remain correct
- mushy cloth weave or synthetic surface roughness

## Local repair protocol
1. preserve pristine approved source
2. mask only failing region
3. use conservative/low-denoise strength first
4. lock identity, biological fingerprint, pose, expression, geometry, lighting direction, and colour relationships
5. change one realism variable per pass
6. composite back without recomputing unaffected pixels when possible

### Skin pass
Regional texture/roughness/colour breakup; restrained pore recovery; reduce waxy sheen; preserve quiet regions. Do not sharpen the full face.

### Hair/surface pass
Material-appropriate fibers/edge breakup/wood/stone/metal/fabric detail. Skin and non-skin surfaces must not share one universal detail recipe.

### Eye pass
Only if geometry/gaze are already correct. Preserve iris/gaze; correct sclera tone, moisture, and key-light-consistent catchlight.

## Two-pass anchoring when the refinement model drifts
- pass/branch A: structure/edge/pose control protects geometry
- pass/branch B: original/tile/image reference protects tonal relationships, gaze, shadow weight
- keep denoise low enough that refinement changes material, not identity

## Stop condition

Two failed local passes on the same dominant defect = return to source generation. Do not keep stacking detailers.
