# Strict Triptych Template — Client Template Fingerprint

## CLIENT TEMPLATE FINGERPRINT

The approved client structure is **zero-separator equal thirds** on one continuous neutral-grey studio field. The geometry is deterministic and is never delegated to the image generator.

Default canvas: **2100 × 1172**. Three equal **700 × 1172** columns. The default separator is **0 px**. The overall ratio and panel ratio are chosen to match the user-approved reference structure closely; callers may scale the whole template proportionally, but the first three semantic slots never change.

### LEFT — front body / wardrobe, head absent only in final assembly
- Source: a normal complete front-facing human, head through shoes.
- Final: head and upper head field replaced by the same neutral background during assembly.
- Visible body begins at approximately **0.160 H** and reaches the shoe line at roughly **0.94–0.98 H**.
- Shoulders, collar/neck base, hands, garment fit, trouser break and shoes remain visible.
- The empty head region is not a wound, stump, decapitation, or generated anatomy. It is a layout mask.

### MIDDLE — complete back full body
- Full back of head/hair is visible.
- Head top approximately **0.02–0.095 H**; shoes approximately **0.94–0.98 H**.
- Neutral centered stance and body scale consistent with LEFT.

### RIGHT — approved Identity Master portrait
- Head-and-shoulders close portrait.
- The **right portrait is never regenerated during assembly**. The approved master is cropped/resized only.
- It is the identity and reality authority for the character.

## Non-negotiable build rule

Generate the three source assets separately, approve them separately, then assemble them mechanically. A final one-shot AI triptych is never a valid strict-template source.
