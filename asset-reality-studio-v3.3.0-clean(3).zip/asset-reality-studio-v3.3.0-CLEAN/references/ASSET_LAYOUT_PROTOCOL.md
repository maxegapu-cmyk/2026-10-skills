# Asset Layout Protocol — STRICT CLIENT TEMPLATE

## Canonical three-panel sheet

This is a fixed production contract, not a loose composition suggestion. The template is derived from the user-approved reference structure: three equal semantic columns, neutral studio background, front wardrobe/body without a head at left, complete back full body in the middle, and a close identity portrait at right.

### Panel 1 — LEFT: headless front wardrobe/body
- FINAL panel: front-facing neutral body/wardrobe view with the head removed cleanly into the same neutral background.
- SOURCE plate must be a complete person from head through shoes.
- source plate must be a complete person; never generate an anatomically headless figure.
- shoulders, collar/neck base, torso, arms, hands, trousers, and shoes remain readable.
- no stump, wound, blood, anatomical cut, or decapitation cue.
- front visible subject target after assembly: approximately centered, visible body begins around **0.16–0.21 H** and ends around **0.94–0.98 H**; visible width is ordinarily about **0.42–0.58 W** depending on body/wardrobe.

### Panel 2 — MIDDLE: complete back
- full-body back view.
- complete back of head, hair, neck, wardrobe, hands, trousers, and both shoes.
- back full subject target: head top around **0.03–0.08 H**, shoes around **0.94–0.98 H**.
- centered neutral stance, body scale visually coherent with the left source before head masking.

### Panel 3 — RIGHT: Identity Master close portrait
- exact approved Identity Master, or a crop made from that approved master.
- complete head + shoulders; head occupies the upper portion naturally, shoulders may exit the lower frame.
- strongest facial information, strongest photographic realism, highest identity authority.
- no re-generated “similar face” is substituted merely to fit the layout.

### Optional fourth panel
Only after the first three immutable slots. It may show a 3/4 face, profile, hands/distinctive mark, or critical wardrobe detail.

## Generation protocol

**Never generate the final triptych in one pass.** A one-shot sheet is a protocol failure in strict mode.

Generate three approved source plates separately, then assemble mechanically.

## Strict compositor

Use:

```bash
python tools/assemble_character_sheet.py \
  --front front.png --back back.png --portrait portrait.png \
  --output sheet.png --strict-client-template --auto-head-mask
```

Strict mode:
- estimates the neutral background;
- detects each full-body subject envelope against that background;
- normalizes front/back source margins to the canonical subject occupancy;
- masks the left head only after normalization;
- keeps three equal panel slots and fixed order;
- uses the approved portrait on the right;
- supports optional fourth only after the canonical three.

## Template validator

Every strict sheet must be checked:

```bash
python tools/validate_character_sheet.py --image sheet.png --report layout-report.json
```

The template validator checks semantic geometry: panel count/widths, left head-clear zone + front-body occupancy, complete middle head/body occupancy, and right portrait occupancy. A failed validator means the sheet is not deliverable, regardless of image beauty.
