# Scene + Prop Reality Engine

## Scene realism = causal evidence

Build in this order:
1. camera position and horizon
2. major geometry and scale
3. construction system
4. functional objects
5. real light sources
6. use history
7. wear / dirt / weather
8. atmosphere only if physically justified
9. look development last

### Physical scene evidence

Use:
- real wall/floor/ceiling materials and joins
- thresholds, trim, mortar, screws, welds, hinges, seals where visible
- contact wear on handles, chair arms, counters, switches, steps
- gravity-driven dust and water paths
- sun-direction fading
- moisture only where water can reach/collect
- repeated objects with slight condition/placement variation
- **quiet regions** with little visual activity

Avoid “random grunge everywhere.” Dirt needs a cause.

### Lighting

Every important light needs a source: window, doorway, fixture, practical, sky, street spill. Let occlusion, bounce, roughness, and falloff follow geometry.

AI-looking scene signals:
- every surface equally detailed
- decorative clutter with no function
- impossible room perspective
- all materials sharing one roughness
- fake cinematic haze/god rays with no physical source
- perfect sterile symmetry in spaces that should be used

## Prop realism = manufacturing + handling

Describe how the object could be made:
- material and thickness
- seam, fastener, hinge, weld, screw, stitch, adhesive, gasket, molding line as appropriate
- plausible tolerances / slight alignment variation
- separate material reflectance (painted metal ≠ rubber ≠ glass ≠ cloth)
- real scale cues

### Wear path

Wear belongs where force/contact occurs:
- grip zones
- edges
- hinges
- feet/base
- pocket contact
- repeated opening/closing points
- heat/water exposure zones

Random scratches and identical roughness across all surfaces fail realism.

## Prompt rule

Write physical causes first. Add cinematic palette/mood only after geometry, materials, and use history are coherent.
