# Anti-AI Capture Protocol

## Principle: human first, detail second

The strongest anti-AI move is not more texture. It is to make the image read as an ordinary photograph of a person who already existed before the camera was raised.

## AI-FIRST-IMPRESSION VETO

At thumbnail size, immediately reject if the subject reads first as any of the following: generic digital human, game/NPC character, beauty-retouched synthetic portrait, sculpted concept-art face, wax figure, or PBR-material demo. Do not attempt pore enhancement first. Regenerate the Identity Master.

## Biological construction

Lock a small **BIOLOGICAL FINGERPRINT** of 4–7 understated irregularities: unequal eyelid openness, slightly different brow density, mild nose-tip deviation, one fold stronger than the other, uneven beard density, asymmetric temple recession, one small pigmentation cluster, or slightly different ear height. Keep them stable across views. Avoid scars or caricature unless the brief requires them.

## Skin: low-frequency before high-frequency

Real skin is regionally unequal. Prioritize slow tonal and roughness variation between forehead, nose, cheeks, eyelids, beard zone, lips, ears, neck and hands. Preserve **low-information skin zones** where little microtexture is visible. Pores and fine lines appear selectively because of angle, focus and light; they do not coat the entire face at one frequency.

## Hair

Hair reads as masses and small clumps first, strands second. Keep uneven density, soft silhouette edges, local clumping, occasional flyaways, imperfect hairline and age-appropriate grey distribution. If every strand is independently sharp, reject or locally refine.

## Eyes and mouth

Eyes are moist tissue under one real key source, not glass marbles. Keep subdued sclera, ordinary catchlights and believable eyelid thickness. Teeth and lips should not become polished cosmetic assets; mouth texture and symmetry stay ordinary.

## Optical reality

Use a plain casting/documentary capture register. One large soft source, modest room fill, normal lens perspective, restrained local contrast, natural depth softness and moderate sharpening. Avoid photographic language that advertises rendering quality.

## Prompt linter

Run `tools/check_human_prompt.py` on Identity Master prompts. Its job is to catch high-risk render language, prompt bloat, character-design phrasing and all-over microdetail instructions before generation. A linter PASS is not a reality PASS; it only removes known prompt-side pressure toward AI imagery.

## Reality Gate evidence

Final approval requires a completed `tools/reality_gate.py` scorecard: no hard veto, **reference-floor parity**, no weak dimension below the minimum, and a strong overall average. The evaluator may be a human or a trusted vision-review step, but scores must be based on the actual output, not the prompt.
