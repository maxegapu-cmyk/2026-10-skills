# Reference Control

## Separate jobs

Every reference has one explicit responsibility.

### Identity Reference
Controls face identity, age, biological fingerprint, hairline/hair mass, facial hair, stable marks, and body identity when available. It does not automatically control wardrobe/layout/lighting/style.

### Reality Reference
Controls photographic credibility only: skin/material regional response, hair softness/edge behavior, ordinary eyes, local contrast, optical softness, light naturalness, and the acceptable AI-artifact floor. It never supplies identity.

**STRICT REALITY MODE:** Reality Reference is mandatory when the user has supplied or approved one. Reattach/reuse it for the Identity Master and critical retries rather than relying on memory or prose alone.

If no approved Reality Reference exists, use the strict capture defaults and say that the hard reference-floor comparison is unavailable; do not claim guaranteed visual parity with an absent reference.

### Wardrobe Reference
Controls garment type/cut/fit/material/colour, closures, seams, repair/wear, footwear/accessories.

### Layout Reference
Controls final panel order, crop, subject scale, spacing, separators, and only layout. The client triptych semantic order is already locked by `ASSET_LAYOUT_PROTOCOL.md`.

## Priority

1. explicit current user instruction
2. approved Identity Master + locked biological fingerprint
3. canonical body/wardrobe references
4. state reference
5. strict client Layout Reference
6. Reality Reference for capture quality
7. prompt defaults

## Source-of-truth rule

Always branch from the approved master/reference set:

**master → each view/state**

not state-1 → state-2 → state-3. Recursive generations compound identity and AI-style drift.

## Bad-reference isolation

If a body/outfit reference has useful structure but ugly AI rendering, do not use it as the Reality Reference. Extract only the structural/wardrobe information. In local-diffusion workflows, route body structure through pose/depth/edge/segmentation controls while identity uses a dedicated identity branch.
