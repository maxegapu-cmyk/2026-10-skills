# Public Research Notes (2026-09-08)

This package borrows **principles**, not copied third-party code or proprietary prompts. Verify upstream licenses before installing or redistributing any external workflow/model.

## Identity / structure separation
- PhotoMaker / PhotoMaker V2: stacked identity embedding and improved ID fidelity; can combine with structural controls.
  https://github.com/TencentARC/PhotoMaker
- InstantID: tuning-free identity-preserving generation from a reference image.
  https://github.com/InstantID/InstantID
- PuLID family: identity conditioning designed to preserve editability; current community implementations exist for multiple base-model families.

Production lesson: identity conditioning and pose/body structure should be separate responsibilities.

## Skin/detail specialization
- Comfyu Image Detailer / Skin Detailer workflows describe separate skin and general-surface detail routes; skin denoise is kept lower than general surface/detail refinement and sharpening is restrained.
  https://github.com/rik-python/Comfyu--Image-detailer-and-skin-detailer-workflows

Production lesson: skin is not “just another surface.” Use a specialized, local, lower-freedom pass.

## Structural + tonal anchoring
- HiDream-O1 Detailer demonstrates a two-pass idea: a structural/edge lock followed by an original/tile tonal anchor to reduce face/gaze/expression drift during refinement.
  https://github.com/biosynthart/comfyui-HiDream-O1-Detailer

Production lesson: structure and tonal/emotional relationships may need separate anchors when a refinement model re-encodes the image.

## De-plastic skin postprocess
- ComfyUI-QwenEditPlusSlots includes a skin-realism/de-plastic node concept using restrained pores, grain, sheen reduction and low-frequency mottling under a skin mask.
  https://github.com/normbarrette-arch/ComfyUI-QwenEditPlusSlots

Production lesson: plastic skin can sometimes be repaired after geometry is correct, but this must remain local and conservative.
