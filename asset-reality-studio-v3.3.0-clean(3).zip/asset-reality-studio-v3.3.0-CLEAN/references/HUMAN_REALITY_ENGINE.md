# Human Reality Engine — Strict Reality Mode

## Target

The image should read as **an ordinary photograph of a person whose physical presence existed before the camera was raised**. The goal is not maximum detail; it is coherent biological + photographic evidence.

## BIOLOGICAL FINGERPRINT

Generic AI faces are often too optimized: bilateral geometry, even brow/eye behavior, uniform age cues, and generalized “handsome/character” proportions. For fictional people, instantiate a small stable fingerprint once, then lock it.

Choose **4–7 mild traits**, never a caricature and never all from one zone:
- one eyelid opens fractionally less or sits heavier;
- brow density/shape differs subtly left-to-right;
- nose tip/bridge has a small natural deviation;
- one nasolabial fold or cheek plane is slightly stronger;
- beard/stubble density differs by side/zone;
- temple recession/grey distribution is uneven;
- one small sun/pigmentation cluster or old minor mark exists asymmetrically;
- ears differ subtly in height/angle;
- resting mouth corners are not perfectly mirrored.

These are identity anchors, not random “imperfections.” Once approved, repeat them in every view/state.

## Four-layer reality model

### MACRO — person before texture
Lock first:
- plausible skull/face proportions rather than sculpted drama;
- mild natural asymmetry from the fingerprint;
- believable age distribution across face, neck, ears, hands;
- ordinary head carriage/posture;
- body mass, shoulder slope, limb proportions, stance consistent with age/occupation.

**Reject** if the person reads like a game character/digital human before zooming in. Texture cannot rescue MACRO failure.

### MESO — regional biological variation
Human skin is not one material. Different regions behave differently:
- central forehead/nose can carry slightly more natural sheen than cheeks;
- under-eye/eyelid tissue is thinner and tonally different;
- beard zone, lips, ears, temples, neck, and cheeks have separate texture/colour behavior;
- pigmentation, sun exposure, dryness, redness, and stubble density are irregular;
- wrinkles/age lines are incomplete, asymmetric, and locally concentrated.

**Quiet-region rule:** some cheek, forehead, neck, and clothing areas remain comparatively low-detail. If every centimeter is equally “interesting,” the result reads synthetic.

### MICRO — selective evidence only
Use only where capture distance, focus, and light reveal it:
- pore visibility and scale vary by zone;
- fine lines fade in/out rather than forming engraved channels;
- beard follicles are uneven;
- small marks are sparse.

Do not ask for a simultaneous checklist of pores + capillaries + flakes + freckles + scars + cracks + dirt merely to force realism.

### OPTICAL — camera agreement
A real capture does not render every plane equally:
- ordinary portrait perspective, not a dramatic character lens;
- frontal asset portrait may have only **~1–4° natural yaw/roll asymmetry**, still useful for identity;
- one large soft key about 25–40° off camera and slightly above eye level, with modest room fill; enough direction to reveal material variation without “cinematic villain” sculpting;
- restrained microcontrast and sharpening;
- eyes can be sharp while ears/rear hair/shoulder planes soften naturally with depth;
- no HDR-like local contrast across every pore, stitch, and hair.

## AI-pattern red flags

### Face construction
- near-perfect mirrored brow/eye/mouth geometry combined with flat centered lighting;
- generic “middle-aged Asian male / model / villain” face with no stable fingerprint;
- exaggerated cheekbones, carved nasolabial folds, or sculpted wrinkle channels used as personality design;
- skin and skull planes that look like ZBrush/PBR material demonstration.

Bilateral symmetry is a **diagnostic signal**, not an automatic rejection by itself. Real people may be symmetric; compare pose and lighting against the approved Reality Reference.

### Skin
- one pore frequency across forehead, nose, cheeks, and neck;
- every area sharpened equally;
- waxy highlight rolloff or uniform matte roughness;
- “imperfections” distributed decoratively/evenly.

### Hair
- every strand individually separated like CG groom;
- perfect dark hair mass with uniform grey distribution;
- razor edge all around the silhouette;
- identical flyaway density around the entire head.

Prefer grouped masses, local clumping, uneven density, depth-dependent softness, and only a few flyaways.

### Eyes
- jewel/glass irises;
- identical mirrored decorative catchlights;
- sclera too white/clean;
- eye openness geometrically identical when the rest of the face is meant to be ordinary.

### Mouth / beard / neck / hands
- overly clean lip edge or uniformly cracked lips;
- beard texture repeating like a brush pattern;
- neck/hands carry the exact same “face texture” recipe;
- hands receive random dirt/callus unrelated to occupation.

## DETAIL BUDGET

Allocate detail in order:
1. identity-defining geometry + biological fingerprint
2. eyelid/eye/mouth behavior
3. regional skin/colour/roughness variation
4. hair mass and edge breakup
5. selective microtexture
6. wardrobe/body material evidence
7. background

If detail is equally strong at every level, reduce it.

## Strict Identity Master capture

The default should feel like mundane professional casting/continuity photography, not a publicity portrait:
- neutral mid-grey paper/seamless background;
- head-and-shoulders framing;
- ordinary resting expression or between-takes attention;
- slight natural asymmetry in shoulders/head instead of passport-perfect centering;
- one soft directional source + modest fill;
- natural colour, restrained contrast, no stylized grade;
- no “cinematic”, “hyperreal”, “8K”, “masterpiece” language unless the user explicitly wants that look later.

## Failure strategy

If a portrait still reads AI at THUMBNAIL, **regenerate the Identity Master**. Do not start by adding pores. If it reads human at THUMBNAIL but fails at 100% because skin/hair/eye material is synthetic, use targeted repair. If two targeted passes fail the same dominant issue, return to the source generation.


## Human first, detail second

Do not use skin detail to manufacture humanity. First establish ordinary biological construction, mild asymmetry, age distribution, hair mass, gaze, posture and unperformed expression. Only then allow selective surface detail.

### Low-information skin zones
At least some cheek, temple, forehead or jaw regions should remain visually quiet under the chosen light/focus. A face with equally explicit pores, cracks, capillaries and wrinkles everywhere is a digital-material failure even when each individual texture looks plausible.

### AI-first-impression veto
If the face reads as a generic digital human, game NPC, wax figure, polished synthetic casting model, or sculpted concept-art face at thumbnail scale, do not send it to a skin detail pass. Return to Identity Master generation with the locked biological fingerprint and the Reality Reference.
