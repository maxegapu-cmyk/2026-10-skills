# Asset Reality Studio v3.3.0 — STRICT

**Plain ZIP Skill package. No ChatGPT plugin or plugin installation is required.** Unzip the folder and use `SKILL.md` from any file-based Skill runtime.

Reality-first film/video asset production with a locked client triptych, anti-AI prompt linting, deterministic layout validation, and an evidence-based final Reality Gate.

## Client triptych contract

Default final sheet: **2100×1172**, three equal **700×1172** panels, **0 px separator**.

1. LEFT — front wardrobe/body; head absent only in final assembly. Source is a complete human.
2. MIDDLE — complete full-body back including back of head/hair and shoes.
3. RIGHT — approved head-and-shoulders Identity Master. The right portrait is never regenerated during assembly.

See `references/STRICT_TRIPTYCH_TEMPLATE.md`.

## Strict human workflow

1. Reality Reference + identity brief
2. lock BIOLOGICAL FINGERPRINT
3. generate Identity Master alone
4. prompt linter + THUMBNAIL / 100% / 200% visual gate
5. reject digital-human construction; repair only local material defects
6. generate complete front source and complete back source separately
7. assemble mechanically
8. template validator PASS
9. Reality Gate evidence PASS with reference-floor parity

## Commands

```bash
python tools/check_human_prompt.py identity_prompt.txt
python tools/assemble_character_sheet.py \
  --front front.png \
  --back back.png \
  --portrait portrait.png \
  --output character_sheet.png \
  --strict-client-template \
  --validation-report layout.json
python tools/reality_gate.py reality-scorecard.json --report reality-report.json
```

## Meaning of “guarantee”

The package can deterministically guarantee the encoded triptych structure and can refuse finalization when the visual Reality Gate fails. No stochastic image generator can truthfully guarantee a perfect first sample or literal zero AI artifacts. The production guarantee is therefore: **wrong layout cannot pass; an asset below the approved Reality Reference floor or with any hard veto cannot be marked final.**

## Self-check

From anywhere on disk, run:

```bash
python /path/to/asset-reality-studio-v3.3.0-CLEAN/tests/run_all.py
```

The tests auto-detect the Skill root; no hidden positional path argument is required.
