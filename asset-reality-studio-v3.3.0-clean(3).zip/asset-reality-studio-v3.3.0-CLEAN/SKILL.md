---
name: asset-reality-studio
description: Use when creating, diagnosing, expanding, repairing, or assembling film/video image assets that must look like physically photographed reality, especially human identity/wardrobe sheets, fixed three-panel client templates, locations, props, state variants, and images with AI/CG/plastic-skin artifacts.
---

# Asset Reality Studio v3.3 — Strict Reality + Locked Client Triptych

## Core principle

A believable asset is **evidence of physical existence**, not a stack of realism adjectives. Identity, biological reality, view/state, layout, and polish are separate responsibilities. A generation below the approved realism floor is rejected; a wrong sheet layout is a protocol failure even if the individual images look good.

## Three hard guarantees


### 0. CLIENT TEMPLATE FINGERPRINT
The strict client layout is a **zero-separator equal thirds** triptych. Default output is 2100×1172: LEFT 700×1172, MIDDLE 700×1172, RIGHT 700×1172. Scale the whole canvas proportionally if needed; do not independently resize, reorder, or restyle the first three slots. Read `references/STRICT_TRIPTYCH_TEMPLATE.md`.

### 1. STRICT CLIENT TEMPLATE
When the user/client requests the canonical three-panel character asset, the semantic order is immutable:

1. **LEFT — front wardrobe/body plate, head absent in the FINAL sheet only**
2. **MIDDLE — complete back full body, including full back of head/hair and shoes**
3. **RIGHT — approved head-and-shoulders Identity Master portrait, the strongest identity + realism authority**

The source plate must be a complete person before assembly. Never ask an image model to invent a headless human. Head removal is a deterministic compositing operation after source approval.

**A one-shot sheet is a protocol failure.** Never accept, request, or deliver a one-pass AI-generated final triptych when strict client-template mode is active.

Use `tools/assemble_character_sheet.py --strict-client-template`, then run `tools/validate_character_sheet.py`. The template validator must PASS before delivery. The right portrait is never regenerated during assembly.

### 2. STRICT REALITY MODE
The user's approved Reality Reference is the minimum visual floor. **Reality Reference is mandatory for strict production whenever the user has supplied or approved one.** It controls only photographic credibility, never identity.

Strict Reality Mode accepts an asset only when:
- no HARD VETO fires;
- the asset reaches the reference floor at THUMBNAIL, 100%, and 200%;
- the face does not read as a generic digital human, beauty-retouched portrait, game character, or PBR skin render;
- identity, hair, eyes, mouth, skin, body, clothing, and optics belong to the same photographic reality.

This does not mean the generator succeeds on the first attempt. It means **failed generations cannot enter the approved asset set**.

### 3. ANTI-AI FINALIZATION GATE
Use `references/ANTI_AI_CAPTURE_PROTOCOL.md`. **human first, detail second**: reject a digital-human construction before attempting microtexture repair. An **AI-FIRST-IMPRESSION VETO** at thumbnail scale is terminal for that Identity Master. Final human assets require **Reality Gate evidence** from the actual output, not the prompt. Run `tools/reality_gate.py` against the completed scorecard; **reference-floor parity** is mandatory in strict mode.

The prompt linter (`tools/check_human_prompt.py`) catches render-language pressure before generation. It is a preventive gate only; a prompt linter PASS never substitutes for visual Reality Gate inspection.

## Mandatory human workflow

1. **DECONSTRUCT** — identity, age, body, era, wardrobe, stable marks, Reality Reference, Layout Reference, model.
2. **BIOLOGICAL FINGERPRINT** — instantiate and lock 4–7 mild, non-dramatic human irregularities for a fictional identity. See `references/HUMAN_REALITY_ENGINE.md`.
3. **PORTRAIT-FIRST** — generate the right-panel Identity Master alone.
4. **REALITY GATE** — compare to the approved Reality Reference at THUMBNAIL / 100% / 200%.
5. **REJECT OR REPAIR** — CG facial construction or generic AI identity → regenerate; correct geometry with local material defect → masked conservative repair.
6. **FRONT SOURCE** — generate a complete front full-body person from the approved master. Do not remove the head during generation.
7. **BACK SOURCE** — generate a complete back full-body person, including back of head/hair.
8. **SOURCE GATES** — identity/body/wardrobe/realism checks on front and back separately.
9. **DETERMINISTIC ASSEMBLY** — strict compositor normalizes subject scale/margins, masks the left head only in assembly, and places the approved portrait at right.
10. **TEMPLATE VALIDATION** — automated geometry/slot check plus visual inspection.
11. **LOOK DEVELOPMENT LAST** — grade/stylize only after reality, identity, and layout are stable.

## Reality routing

**REQUIRED:** read `references/HUMAN_REALITY_ENGINE.md`, `references/ANTI_AI_CAPTURE_PROTOCOL.md`, `references/REFERENCE_CONTROL.md`, `references/QUALITY_GATES.md`, `references/STRICT_TRIPTYCH_TEMPLATE.md`, and `references/PROMPT_RECIPES.md` for non-trivial humans.

The realism hierarchy is:

**MACRO → MESO → MICRO → OPTICAL**

- MACRO: biological construction, proportions, mild asymmetry, posture, age distribution.
- MESO: regional skin/colour/roughness variation, eyelids, beard zones, hair mass, lips, neck/hands.
- MICRO: selective pores/fine lines only where camera/light reveal them.
- OPTICAL: plain camera perspective, believable directional soft light, depth softness, restrained local contrast.

Do not solve a MACRO digital-human face with a MICRO skin pass.

## Anti-generic-face rule

Before the first Identity Master, lock a **BIOLOGICAL FINGERPRINT**. It is not a list of scars or caricature. Choose a small set of subtle asymmetries/variations consistent with age and brief, for example: slightly different eyelid openness, unequal brow density, mild nose-tip deviation, one nasolabial fold stronger, uneven beard density, asymmetric temple recession, one small pigmentation cluster, or slightly different ear height. Once chosen, these become identity anchors across every later asset.

Do not randomize a new fingerprint in every view.

## Prompt discipline

Identity Master prompts should usually remain compact. Describe:
- the ordinary photograph being taken;
- 3–6 stable identity anchors + locked biological fingerprint;
- one plain studio capture setup;
- regional, non-uniform material behavior;
- one observed failure constraint when retrying.

Do not make “realism” synonymous with `8K`, `masterpiece`, `ultra detailed pores`, or a giant checklist of skin defects. High-frequency detail must obey a DETAIL BUDGET; real photographs contain quiet regions and **low-information skin zones**. Run the prompt linter before strict Identity Master generation.

## Repair / reject

**REQUIRED:** read `references/REPAIR_ROUTER.md` before repairing a failed human.

- generic digital-human skull/face, identity drift, anatomy, hair mass/hairline, wrong camera construction → **REJECT & REGENERATE**
- correct face but waxy/plastic skin → masked low-denoise skin refinement
- correct hair mass but synthetic edge/detail → local hair/surface refinement
- decorative/jewel eyes → local eye-area refinement only if eye geometry/gaze are correct; otherwise regenerate
- never stack repeated detail passes until the face becomes a different synthetic person

## Scene and prop assets

Use `references/SCENE_PROP_REALITY_ENGINE.md`. Scene/prop realism is causal: geometry, construction, joins, gravity, contact wear, dirt/water paths, handling zones, mixed material response, and quiet regions. Do not spread equal microdetail across every surface.

## Optional local-diffusion route

Use `references/COMFYUI_REALITY_PLAYBOOK.md` only if the user's workflow includes ComfyUI/local diffusion. Identity conditioning, structure conditioning, skin refinement, surface refinement, and tonal anchoring are separate branches. Public techniques are summarized in `references/RESEARCH_NOTES.md`; do not copy third-party code blindly and respect upstream licenses.

## Model routing

Honor the user's named model. When none is named:
- new portrait/front/back/location/prop → GPT Image
- ordinary local edit → minimal edit route
- texture-only surface revival → specialized masked detail/texture route
- location view change → new generation from locked scene references

Exact model limits change. Verify current official documentation when quoting current reference counts, sizes, aspect ratios, or version-specific controls.

## Output contract

For a strict three-panel request, do **not** output one monolithic triptych prompt. Deliver/execute in this order:
1. Identity Master prompt/source
2. front complete-person prompt/source
3. back complete-person prompt/source
4. deterministic assembly
5. template validation

For diagnosis: verdict → highest-impact AI signals → structural vs material classification → exact next action.

## Hard rules

- CLIENT TEMPLATE FINGERPRINT: zero-separator equal thirds; first three panel meanings and order never change.
- FINAL LEFT is headless; FRONT SOURCE is never headless.
- MIDDLE always includes complete back of head and shoes.
- RIGHT always uses the approved Identity Master portrait in strict mode.
- one-shot sheet is a protocol failure.
- Reality Reference is mandatory in strict production when supplied/approved.
- REFERENCE FLOOR outranks numeric score.
- AI-FIRST-IMPRESSION VETO and HARD VETO outrank repair convenience.
- DETAIL BUDGET prevents all-over AI microtexture.
- Reality Gate evidence + reference-floor parity are required before final approval.
- LOOK DEVELOPMENT LAST.
