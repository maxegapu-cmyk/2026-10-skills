---
name: commercial-feature-screenwriter
description: Use when developing, breaking, drafting, reviewing, cutting, pitching, or revising a commercial feature screenplay, especially when the premise must sustain feature length, scenes feel inert, causality is weak, dialogue is expositional, runtime is bloated, or an AI-film version must remain producible without weakening the story.
---

# Commercial Feature Screenwriter

## Core Principle

Build features from **audience promise + character pressure + causal escalation + setup/payoff discipline**. Commercial means the audience can quickly want the movie, the story keeps changing, and the ending pays off what the film taught them to care about.

**Route B is mandatory:** screenplay sovereignty comes first. AI-film producibility is a **second-pass** constraint after story function is locked.

## Choose One Mode

| Mode | Use it for | Deliverable |
|---|---|---|
| `CONCEPT` | premise, hook, logline, market fit | premise stress test + stronger concept |
| `BREAK` | feature architecture | sequence map + 45–60 scene spine |
| `TREATMENT` | producer-facing prose development | 5–10 page-equivalent treatment |
| `SCENE` | draft/rebuild screenplay scenes | scene contract + screenplay scene |
| `DIALOGUE` | voice, subtext, punch-up | revised dialogue with function preserved |
| `REVIEW` | coverage and rewrite | root issue + severity-ranked rewrite order |
| `CUT` | runtime, repetition, compression | cut/merge map + protected beats |
| `AI-PRODUCIBILITY` | generative-film feasibility | burden map + story-equivalent staging |
| `FULL` | idea to rewrite-ready feature | concept → break → treatment → scene spine → review → production-risk pass |

Read `references/output-contracts.md` before delivering.

## Operating Rules

1. **Do not draft pages from a weak premise.** Establish protagonist, concrete goal, opposition, stakes, contradiction, audience promise, and a pressure engine that can sustain feature length.
2. **Character creates structure.** Track Want, Need/Principle, Flaw/Misbelief, competence, relationship pressure, and a choice ladder. Major turns must alter what the protagonist knows, risks, believes, or is willing to do.
3. **Architecture is causal, not decorative.** Build sequences and scenes with `BUT / THEREFORE`, not repeated `AND THEN`. A midpoint changes the game; an All Is Lost destroys the old strategy; the climax requires an earned choice.
4. **Every scene changes state.** Objective → obstacle → tactic → turn → changed state → next pressure. If state does not change, merge or cut.
5. **Information is dramatic currency.** Maintain audience knowledge, character knowledge, secrets/leverage, and setup/payoff ledgers.
6. **Dialogue is action.** Characters bargain, evade, test, seduce, threaten, recruit, conceal, provoke, repair, or surrender. Distinguish verbal register; use silence and omission; remove on-the-nose exposition.
7. **Commerciality is not sameness.** Preserve genre promise while protecting specificity, signature situations, moral dilemmas, and memorable reversals. Never promise virality or box office.
8. **Review root cause before polish.** Diagnose premise/agency/causality/escalation before line edits. Rank notes by severity and rewrite order.
9. **Cut story fat, not story identity.** Remove duplicated function, repeated emotional beats, dead travel, and low-leverage characters; protect setups, payoffs, signature turns, and emotional consequences.
10. **AI feasibility cannot silently rewrite the movie.** Run it only after story logic is stable. Preserve equivalent dramatic function before changing scale, geography, cast load, or action design.

## Reference Load Order

- Concept: `references/market-and-concept.md`
- Character: `references/character-and-arc.md`
- Structure: `references/feature-architecture.md`
- Causality/assets: `references/causality-and-payoff.md`
- Treatment/pitch: `references/treatment-and-pitch.md`
- Scenes: `references/scene-writing.md`
- Dialogue: `references/dialogue-and-voice.md`
- Review: `references/rewrite-and-coverage.md`
- Runtime: `references/runtime-and-cutting.md`
- AI film: `references/ai-film-producibility.md`
- Worked feature: `examples/original-feature-blueprint.md`
- Screenplay pages: `examples/original-scene-pack.fountain`

When information is missing but not blocking, make the lowest-risk assumption and label it. Ask only when the missing fact materially changes the movie.
