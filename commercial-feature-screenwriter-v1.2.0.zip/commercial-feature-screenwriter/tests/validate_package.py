#!/usr/bin/env python3
from __future__ import annotations
import json, re, sys, zipfile
from pathlib import Path

root = Path(sys.argv[1] if len(sys.argv) > 1 else Path(__file__).resolve().parents[1])
errors=[]
required=[
    'SKILL.md','manifest.json',
    'references/market-and-concept.md','references/character-and-arc.md',
    'references/feature-architecture.md','references/causality-and-payoff.md',
    'references/scene-writing.md','references/dialogue-and-voice.md',
    'references/treatment-and-pitch.md','references/rewrite-and-coverage.md',
    'references/runtime-and-cutting.md','references/ai-film-producibility.md',
    'references/output-contracts.md','references/method-provenance.md',
    'examples/original-feature-blueprint.md','examples/original-scene-pack.fountain',
    'tests/pressure-scenarios.md','tests/regression-matrix.md'
]
for rel in required:
    if not (root/rel).is_file(): errors.append(f'missing required file: {rel}')

skill=root/'SKILL.md'
if skill.is_file():
    text=skill.read_text(encoding='utf-8')
    fm=re.match(r'^---\s*\n(.*?)\n---\s*\n',text,re.S)
    if not fm: errors.append('SKILL.md missing YAML frontmatter')
    else:
        front=fm.group(1)
        name=re.search(r'^name:\s*([^\n]+)$',front,re.M)
        desc=re.search(r'^description:\s*([^\n]+)$',front,re.M)
        if not name or name.group(1).strip()!='commercial-feature-screenwriter': errors.append('bad skill name')
        if not desc or not desc.group(1).strip().startswith('Use when'): errors.append('description must start Use when')
        if len(front)>1024: errors.append('frontmatter >1024 chars')
    body=text[fm.end():] if fm else text
    wc=len(re.findall(r"\b[\w'-]+\b",body))
    if wc>700: errors.append(f'SKILL.md body too long: {wc} words > 700')
    for token in ['CONCEPT','BREAK','TREATMENT','SCENE','DIALOGUE','REVIEW','CUT','AI-PRODUCIBILITY','FULL']:
        if token not in text: errors.append(f'missing mode token: {token}')
    must=['screenplay sovereignty','audience promise','causal','setup/payoff','second-pass']
    for phrase in must:
        if phrase.lower() not in text.lower(): errors.append(f'missing core phrase: {phrase}')

manifest=root/'manifest.json'
if manifest.is_file():
    try: data=json.loads(manifest.read_text(encoding='utf-8'))
    except Exception as e: errors.append(f'invalid manifest: {e}'); data={}
    if data.get('version')!='1.2.0': errors.append('manifest version must be 1.2.0')
    if data.get('route')!='B': errors.append('route must be B')
    if data.get('bundles_third_party_skill_text') is not False: errors.append('must declare no verbatim third-party skill text')
    if data.get('bundles_third_party_screenplays') is not False: errors.append('must declare no third-party screenplay bundles')

# Route B invariants.
ai=root/'references/ai-film-producibility.md'
if ai.is_file():
    t=ai.read_text(encoding='utf-8').lower()
    for phrase in ['story function','after story','equivalent dramatic function','do not simplify']:
        if phrase not in t: errors.append(f'AI producibility missing: {phrase}')

# Expanded craft invariants.
checks={
 'references/market-and-concept.md':['audience promise','pressure engine','word-of-mouth','premise stress test'],
 'references/character-and-arc.md':['want','need','flaw','choice ladder','relationship pressure'],
 'references/feature-architecture.md':['sequence','midpoint','all is lost','climax','55'],
 'references/causality-and-payoff.md':['causality matrix','setup','payoff','knowledge ledger','prop'],
 'references/dialogue-and-voice.md':['subtext','verbal register','on-the-nose','silence'],
 'references/treatment-and-pitch.md':['treatment','one-pager','comparables','producer'],
 'references/runtime-and-cutting.md':['screen time','cut','merge','runtime'],
 'references/rewrite-and-coverage.md':['root issue','severity','rewrite order','coverage'],
}
for rel, phrases in checks.items():
    p=root/rel
    if p.is_file():
        txt=p.read_text(encoding='utf-8').lower()
        for phrase in phrases:
            if phrase not in txt: errors.append(f'{rel} missing: {phrase}')

# Examples must be substantial and original-labeled.
blue=root/'examples/original-feature-blueprint.md'
if blue.is_file():
    txt=blue.read_text(encoding='utf-8')
    if len(txt.split())<2500: errors.append('feature blueprint too small (<2500 words)')
    if 'ORIGINAL FICTIONAL EXAMPLE' not in txt: errors.append('feature blueprint missing originality label')
    if len(re.findall(r'^### Scene \d+',txt,re.M))<45: errors.append('feature blueprint needs at least 45 scene entries')
scene=root/'examples/original-scene-pack.fountain'
if scene.is_file():
    txt=scene.read_text(encoding='utf-8')
    if len(txt.split())<1800: errors.append('scene pack too small (<1800 words)')
    if txt.count('INT.')+txt.count('EXT.')<8: errors.append('scene pack needs at least 8 screenplay scenes')

# Do not bundle downloaded third-party PDFs or substantially copied external skills.
for p in root.rglob('*.pdf'):
    errors.append(f'third-party PDF must not be bundled without uploaded source file: {p.relative_to(root)}')
for p in root.rglob('*'):
    if p.is_file() and p.suffix.lower() in {'.md','.txt','.fountain'}:
        txt=p.read_text(encoding='utf-8', errors='ignore').lower()
        for marker in ['ur-grue','autopunk','dglogan42','gaojesse999','0xhughs']:
            if marker in txt: errors.append(f'legacy repository identity leaked in {p.relative_to(root)}: {marker}')

if errors:
    print('VALIDATION: FAIL')
    for e in errors: print('- '+e)
    sys.exit(1)
print('VALIDATION: PASS')
print('root='+str(root))
