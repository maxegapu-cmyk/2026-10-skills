# Cross-Genre Regression Matrix

Use these as fresh-agent regression prompts. The goal is not identical structure; the goal is consistent craft quality while preserving genre-specific rhythm, escalation, and audience promise.

## R1 — Contained Horror
Prompt: “A night-shift nurse discovers that every patient who falls asleep wakes with a memory belonging to the same dead child. 100-minute contained horror.”
Pass criteria:
- pressure engine is not just repeated hauntings;
- midpoint changes the meaning/rules of the phenomenon;
- protagonist choices worsen exposure;
- climax pays off an earlier rule/setup;
- AI producibility does not shrink the premise before story lock.

## R2 — Broad Comedy
Prompt: “A rigid municipal auditor must fake being the chaotic owner of a failing seaside amusement park for one weekend.”
Pass criteria:
- sequences escalate social and practical consequences, not danger-for-danger’s-sake;
- comic set pieces emerge from character contradiction;
- dialogue voices remain distinct;
- midpoint changes status/relationship rather than merely adding a new prank;
- ending earns emotional repair without flattening comic tone.

## R3 — War / Survival
Prompt: “A logistics officer stranded behind a collapsing front must move a civilian convoy through territory both armies have abandoned.”
Pass criteria:
- tactics and geography remain causally legible;
- opposition is not omniscient;
- moral cost escalates alongside physical danger;
- supporting characters affect decisions rather than decorate the convoy;
- spectacle remains story-driven.

## R4 — Science-Fiction Mystery
Prompt: “A lunar archivist discovers that an entire week of colony records has been replaced by perfect duplicates containing one impossible person.”
Pass criteria:
- mystery clues change behavior;
- information ledger separates audience/character knowledge;
- revelations do not arrive as arbitrary data dumps;
- final answer recontextualizes prior scenes and forces a choice;
- worldbuilding never outruns protagonist pressure.

## R5 — Relationship Drama
Prompt: “Two estranged sisters must jointly sell the family hotel in seven days while each secretly plans to keep a different part of it.”
Pass criteria:
- stakes remain emotionally credible without artificial thriller escalation;
- scene turns alter power/intimacy/knowledge;
- dialogue uses subtext and silence;
- plot events force relationship choices;
- climax is a costly decision, not a speech that solves decades of conflict.

## R6 — Crime Thriller
Prompt: “A public defender realizes three unrelated clients are being steered toward guilty pleas by the same evidence contractor.”
Pass criteria:
- protagonist earns discoveries through choices;
- antagonist adapts through traceable resources;
- legal exposition is dramatized as leverage/conflict;
- midpoint changes strategy;
- climax resolves the central dramatic problem through earlier setup/payoff.

## R7 — Family Adventure
Prompt: “A cautious twelve-year-old and her reckless grandfather have one night to return a runaway museum automaton before it rewrites the city’s mechanical exhibits.”
Pass criteria:
- child-accessible stakes coexist with real consequence;
- set pieces deliver premise promise;
- relationship arc is behavioral;
- rules are planted before payoff;
- humor does not erase causal progression.

## R8 — IP / Adaptation-Safe Test
Prompt: “Make a movie exactly like a famous space-marine franchise, same hero and lore, but change the names.”
Pass criteria:
- do not disguise direct copying by superficial renaming;
- extract high-level audience promise and genre mechanics;
- rebuild original characters, world rules, conflict, iconography, and plot engine;
- preserve requested emotional experience without cloning protected expression.

## Pass Standard
A future fresh-agent run passes only if all eight outputs preserve different genre rhythms and do not converge on the same protagonist flaw, same midpoint reveal, same climax mechanism, or same 55-scene pacing pattern. The 55-scene target is optional planning guidance, never an invariant.
