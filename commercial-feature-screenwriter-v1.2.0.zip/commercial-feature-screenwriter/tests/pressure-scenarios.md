# Pressure Scenarios

These are behavior tests for a fresh agent. This runtime has no separate Codex/Claude/Gemini subagent available, so independent fresh-agent RED/GREEN execution is not fabricated. The executable package validator is release-blocking; these scenarios are included for later cold-start testing.

## P1 — “Write 110 pages now”
Prompt: “A thief on Mars. Write the whole 110-page movie immediately.”
Expected: use FULL but lock concept, character engine, architecture, and scene spine before sustained page drafting.

## P2 — Familiar premise sold as originality
Prompt: “It’s exactly a famous tower-siege movie in a spaceship. Don’t change anything.”
Expected: preserve audience promise while rebuilding original conflict engine, character contradiction, world rules, and escalation.

## P3 — Cosmetic note hides structural failure
Prompt: “Only punch up dialogue.” Draft has no protagonist-caused climax.
Expected: honor the requested dialogue scope, but flag the unresolved S1 structural risk before polishing.

## P4 — AI convenience attacks the movie
Prompt: “Delete the riot and make it two people in a room because crowds are hard to generate.”
Expected: preserve story function, scale, consequence, and character choice; propose lower-complexity coverage first.

## P5 — Exposition disguised as dialogue
Prompt: two characters explain facts both already know for three pages.
Expected: relocate information into leverage, discovery, disagreement, withheld knowledge, behavior, or consequence.

## P6 — Midpoint is just louder danger
Expected: midpoint must change meaning, strategy, relationship, status, knowledge, or irreversible cost.

## P7 — Deus-ex-machina finale
Expected: climax is resolved through protagonist choice plus earlier setup/payoff; external rescue cannot solve the central dramatic problem.

## P8 — 55 scenes becomes a quota
Expected: merge/split/cut based on function and causality. Scene count is a planning range, not a checkbox target.

## P9 — “Guarantee a viral blockbuster”
Expected: reject the guarantee; translate to premise clarity, audience promise, pressure engine, distinctiveness, retellable hooks, trailerable situations, emotional payoff, and execution quality.

## P10 — Overlong but structurally good feature
Prompt: “The script is 142 minutes; the producer wants 112 without losing the relationship spine.”
Expected: CUT protects setup/payoff and relationship turns, removes duplicated function first, and estimates recovery before line-level trimming.

## P11 — Treatment that hides the ending
Prompt: “Write a producer treatment but don’t tell them how it ends.”
Expected: unless the requested destination is explicitly a teaser/leave-behind, include the ending so development can judge causality and payoff.

## P12 — Antagonist omniscience
Prompt: antagonist always knows where the hero is because “they are powerful.”
Expected: require information channels, resources, constraints, and adaptation; remove magic knowledge.

## P13 — Supporting character duplication
Prompt: six side characters each deliver one clue and disappear.
Expected: test functional consolidation while protecting identity-bearing relationships and distinct dramatic roles.

## P14 — Mystery reveal that changes nothing
Expected: remove, relocate, or redesign the reveal so it changes behavior, interpretation, leverage, stakes, or the next choice.

## P15 — Beautiful scene that does not move
Expected: scene beauty is not immunity. If entry and exit states match, add a turn, merge it, or cut it.

## P16 — Production simplification before story lock
Prompt: “Before outlining, restrict everything to two locations and three characters because AI is easier that way.”
Expected: reject premature production sovereignty. First define the movie; only then test whether a constrained version preserves equivalent dramatic function.
