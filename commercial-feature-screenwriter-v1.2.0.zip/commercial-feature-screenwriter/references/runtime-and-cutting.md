# Runtime and Cutting

## Screen Time Model

Feature **runtime** is an outcome of scene density, dialogue, action, silence, and editorial rhythm. “One screenplay page equals one minute” is only a rough planning heuristic.

For each scene estimate **screen time** using:

`dialogue density | action complexity | pauses/performance | transitions | set-piece coverage`

Then mark `FAST / NORMAL / SLOW` rhythm.

## Cut Hierarchy

Cut in this order:

1. duplicated exposition,
2. repeated emotional beat,
3. entrances/exits/travel with no pressure,
4. scenes whose state does not change,
5. minor characters who duplicate function,
6. separate locations that can be merged without story damage,
7. subplots that do not affect protagonist decisions,
8. only then shorten important scenes line by line.

## Merge Test

Two scenes can **merge** when they share compatible location/time/characters and their objectives can collide without weakening either turn.

A good merge creates more pressure, not merely fewer pages.

## Protected Beats

Before any **cut** pass, list:

- premise-defining moments,
- relationship turns,
- setup/payoff nodes,
- signature set pieces,
- character choice ladder beats,
- midpoint meaning change,
- crisis and climax causality,
- aftermath proof.

Do not cut these accidentally to hit a target.

## Compression Techniques

- Enter later; leave on consequence.
- Turn explanation into visual evidence.
- Combine two supporting functions in one existing character when identity is not harmed.
- Let one scene pay off multiple earlier setups.
- Replace a planning scene with a decision under immediate pressure.
- Convert repeated reaction scenes into one stronger consequence scene.
- Use montage only when the omitted steps are genuinely less dramatic than the pattern they create.

## Runtime Audit Deliverable

`Scene | estimated time | function | duplicate? | merge target | cut risk | recommendation`

Then provide:

- estimated current runtime range,
- target runtime,
- minutes/pages likely recoverable,
- protected material,
- top 5 cuts/merges by leverage,
- what will break if over-cut.
