# AI-Film Producibility — Route B

## Principle

Run this **after story** logic is stable. The screenplay is not a servant of current generation weaknesses.

For every difficult element, preserve **story function** first: what changes in plot, character, stakes, reveal, relationship, or audience expectation because this element exists?

**Do not simplify** a sequence merely because it is expensive or unstable to generate. First search for a staging form with **equivalent dramatic function**.

## Burden Map

Flag each scene `LOW / MEDIUM / HIGH` across:

| Burden | Typical failure |
|---|---|
| Identity | many recurring faces, doubles, age changes |
| Crowd | dozens of independently acting people |
| Spatial | exact geography across many shots |
| Physics | contact, destruction, vehicles, water, animals |
| Prop | persistent hero objects and precise interaction |
| Continuity | wounds, wardrobe, dirt, inventory, time changes |
| Dialogue | long lip-synced exchanges, overlap |
| Location | many one-use environments |
| Temporal | long continuous action without edit points |

HIGH triggers redesign discussion, not an automatic story rewrite.

## Story-Equivalent Substitution

For each HIGH burden element write:

1. Story function.
2. Non-negotiables.
3. Likely generation failure.
4. Same event, different coverage.
5. Implied scale with visible consequence.
6. Concentrated geography with preserved stakes.
7. Asset consolidation only if it strengthens the story.

Choose the least story-destructive option.

## Examples

### Crowd uprising
Preserve city-scale consequence through a controllable POV: locked storefronts, police radio, smoke columns, compressed crowd fragments, overturned barriers, a local confrontation, then aftermath that proves scale. Do not replace mass collapse with two people talking about it.

### Vehicle pursuit
Preserve decisions and geography using interior POV, mirrors, short exterior inserts, road-block choices, consequence shots, and clear state changes. The chase remains a chase.

### Large battle
Preserve tactical objective and sacrifice. Concentrate coverage on a decisive squad corridor while background evidence establishes the larger front. Do not convert the battle into exposition.

## Deliverable

`Scene | Burden | Story function | Risk | Preserve | Staging option | Residual risk`

Then provide top bottlenecks, safe changes, rejected story-damaging changes, and continuity assets to lock before generation.
