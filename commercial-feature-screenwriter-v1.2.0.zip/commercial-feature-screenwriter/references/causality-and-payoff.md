# Causality, Information, and Payoff Ledger

## Causality Matrix

For every scene write:

`Cause from prior scene | Driver | Action | Resistance | Turn | New state | Consequence that creates later pressure`

Then mark the outgoing link `BUT`, `THEREFORE`, or `AND THEN`.

A causality matrix exposes scenes that merely occupy time.

## Knowledge Ledger

Track four information channels separately:

| Ledger | Question |
|---|---|
| Audience knowledge ledger | What does the audience know that the protagonist does not, and what suspense does it create? |
| Character knowledge ledger | Who knows what, and how does asymmetry create leverage? |
| Secret ledger | Which withheld truth will change behavior when exposed? |
| Interpretation ledger | Which known fact means different things to different characters? |

A reveal is useful only if it changes behavior, interpretation, stakes, or the next choice.

## Setup/Payoff Ledger

Record:

`Setup ID | planted element | first meaning | expected payoff window | reload/recontextualization | payoff | consequence`

Useful setups include:

- skills,
- relationships,
- promises/debts,
- locations,
- rules,
- wounds/limitations,
- repeated language,
- **prop** objects,
- false assumptions.

A payoff should not merely prove the writer remembered a detail. It should alter outcome or emotion.

## Prop Mine Method

A hero prop should have a dramatic life:

`introduction → ordinary use → changed meaning → pressure use → payoff / betrayal / sacrifice`

If a prop suddenly solves the climax without prior dramatic life, it feels mechanical.

## Promise Ledger

The premise, genre, trailer-facing hook, and early scenes all create promises. Track:

`Promise | source | expected audience question | delivery window | payoff type | status`

Payoff types: fulfillment, reversal, denial-with-consequence, recontextualization.

A deliberate denial can work; forgetting cannot.

## Motif and Line Returns

Recurring images or lines should evolve. The second use must not mean exactly what the first meant. Prefer:

`plant → variation → inversion → emotional payoff`

## Causality Audit Questions

- Which major turn would still happen if the protagonist did nothing?
- Which reveal arrives by coincidence instead of earned pursuit?
- Which antagonist move requires impossible knowledge?
- Which setup is never paid?
- Which payoff was never planted?
- Which scene removes pressure rather than converting it into a new form?

Fix these before dialogue polish.
