# Rewrite and Coverage

## Verdict First

Use one:

- **READY FOR NEXT DRAFT** — foundation works; targeted changes can improve it.
- **REBREAK BEFORE PAGES** — concept/agency/causality is unstable.
- **SCENE-LEVEL REWRITE** — architecture works; execution is the main problem.
- **RUNTIME REBUILD** — movie works but repetition/structure makes it overlong.
- **PRODUCTION-RISK PASS** — story works; AI-film execution has concentrated burden.

## Root Issue

Name one **root issue** in one sentence before listing notes. Example form:

`The second act stalls because the protagonist receives new problems rather than creating them through choices.`

## Severity

Rank each note:

- `S1 BLOCKER` — premise, agency, causal spine, ending integrity.
- `S2 MAJOR` — sequence, relationship, reveal, escalation, payoff failure.
- `S3 MODERATE` — scene function, voice, exposition, pacing.
- `S4 POLISH` — line, format, small continuity.

## Diagnostic Hierarchy

1. Premise engine.
2. Protagonist agency.
3. Opposition adaptation.
4. Causal structure.
5. Escalation.
6. Climax/ending.
7. Sequence design.
8. Scene function.
9. Character specificity/voice.
10. Line polish.

Never spend the review on level 9–10 when level 1–4 is broken.

## Note Contract

Every major note uses:

`Problem → Evidence → Consequence → Smallest high-leverage fix → Preserve`

## Rewrite Order

1. Premise / character engine.
2. Causal architecture and major turns.
3. Information + setup/payoff ledgers.
4. Sequence goals and escalation.
5. Scene pressure.
6. Character specificity and relationship turns.
7. Dialogue/action compression.
8. Runtime/cutting.
9. AI-film producibility second pass.

Do not rewrite downstream material before its upstream cause is stable.

## Coverage Summary

A practical **coverage** response contains:

`Verdict | Logline diagnosis | Root issue | Strengths worth protecting | S1/S2 notes | S3 notes | Rewrite order | Expected effect`

If the user wants industry-style `PASS / CONSIDER / RECOMMEND`, provide it only after the actual diagnostic work; do not pretend that a label predicts market outcome.

## Kill List

Flag scenes for merge/cut when they:

- repeat information without changing leverage,
- repeat emotion without new cost,
- exist only for transit,
- delay an inevitable decision without pressure,
- introduce a character with duplicated function,
- repeat another set piece’s dramatic question.

## Protect List

Name 3–7 elements that make the project itself before rewriting: core relationship, dilemma, signature set piece, tone contract, protagonist contradiction, ending image, unusual setting/profession. Protect them from generic “improvement.”
