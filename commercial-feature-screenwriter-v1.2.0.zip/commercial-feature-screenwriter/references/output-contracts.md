# Output Contracts

## CONCEPT
`Verdict → logline → audience promise → premise stress test → pressure engine → word-of-mouth hooks → repair priorities`

## BREAK
`13 landmarks → sequence map → 45–60 scene spine → causality audit → setup/payoff ledger → risk list`

## TREATMENT
`Title/format → logline → characters → continuous present-tense story → ending → thematic statement`

## SCENE
`Scene contract → screenplay scene → changed-state check → next pressure`

## DIALOGUE
`Rewritten scene/dialogue → 3–5 change notes → voice/subtext risks`

## REVIEW
`Verdict → root issue → protect list → severity-ranked notes → rewrite order`

## CUT
`Runtime estimate → protected beats → cut/merge table → expected recovery → over-cut risks`

## AI-PRODUCIBILITY
`Burden table → bottlenecks → equivalent dramatic-function options → locked continuity assets`

## FULL
Deliver in development order. Do not generate a polished full screenplay in one uncontrolled pass. Lock concept, architecture, and scene spine before sustained page drafting.
