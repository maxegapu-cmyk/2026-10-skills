# Method Provenance

This package is an independently authored synthesis of commercial feature-screenwriting craft and AI-assisted development practice. It is not presented as an official release, endorsement, or signed publication by any living screenwriter, studio, school, or software repository.

The package intentionally does **not** bundle verbatim third-party skill text, downloaded screenplay PDFs, or third-party worked-example files. Public material was used only to identify recurring professional capabilities worth rebuilding independently: premise testing, logline discipline, treatment writing, scene-state design, dialogue/subtext, coverage, causality, setup/payoff, runtime cutting, and production-layer separation.

A publicly hosted professional screenplay may be used by a user as an external study reference when the user supplies or lawfully accesses it. The skill should analyze structure, scene function, setup/payoff, and revision choices rather than reproduce the screenplay.

All packaged examples under `examples/` are original fictional material created for this skill.

## External Professional Screenplay Study Reference

For users who want to compare this skill against a complete professional feature screenplay, Save the Cat! publicly hosts Matt R. Allen's **SON OF SEAGAL** screenplay PDF at:

`https://savethecat.com/wp-content/uploads/2023/09/Son-of-Seagal.pdf`

It is intentionally linked rather than bundled. If the user supplies that PDF as a local/user-provided file, analyze it through the same ledgers used here: premise promise, character choice ladder, sequence turns, causality matrix, knowledge ledger, setup/payoff, scene-state changes, dialogue tactics, runtime, and rewrite opportunities. Do not treat one screenplay as a universal template.
