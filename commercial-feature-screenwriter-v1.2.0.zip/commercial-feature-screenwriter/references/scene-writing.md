# Scene Writing: Conflict, Turn, Voice, and Cinematic Action

## Scene contract before prose

Before drafting, fill this compact contract:

- **Driver:** who is trying to make something happen?
- **Objective:** what do they want *right now*?
- **Obstacle:** who/what can actively stop them?
- **Hidden agenda:** what is not being said?
- **Tactic:** how does the driver try to win?
- **Turn:** what new fact/action/choice changes the scene?
- **Exit state:** who has more/less power, knowledge, safety, intimacy, or options?
- **Next pressure:** why can the movie not simply stop here?

If the exit state equals the entry state, the scene needs a stronger turn or should be merged/cut.

## Enter late, leave on consequence

Begin near the first point of friction. Omit greetings, travel, setup chatter, and repeated decisions unless they contain conflict. End after the decisive change, before characters explain what the audience already understands.

## Action lines

Write what can be performed, photographed, heard, or inferred from visible behavior. Replace invisible labels with behavior under pressure.

Weak: “She feels betrayed.”

Playable: “She slides his key across the table, keeps her own, and deletes his name from the reservation without looking up.”

Action paragraphs should be easy to scan. Give important reversals white space.

## Dialogue as tactics

Characters rarely speak only to transfer information. Give each line a job:
- obtain,
- deflect,
- test,
- conceal,
- threaten,
- seduce,
- recruit,
- shame,
- buy time,
- force a choice,
- repair or sever a relationship.

### Subtext test

Ask two questions:
1. What does the character need the other person to *do*?
2. What would become dangerous if they said the truth directly?

The difference creates subtext.

### Distinct voices

Differentiate through:
- sentence length and rhythm,
- preferred metaphors/domains,
- tolerance for silence,
- directness vs indirection,
- what each person notices,
- what each person refuses to name,
- humor/aggression style,
- power position.

Do not create “voice” by adding catchphrases to interchangeable thinking.

## Exposition repair

When two characters state facts they both know, move the information into one of these engines:

- **asymmetric knowledge:** one knows, one does not;
- **disputed interpretation:** both know the event but disagree about what it means;
- **leverage:** a fact is used to threaten, bargain, accuse, or seduce;
- **discovery:** information arrives through action, object, environment, or consequence;
- **withholding:** the audience understands from what a character refuses to say.

## Comedy and tension

Both depend on expectation management.

For comedy: establish a pattern, let the audience predict, then violate the prediction in a way that is character-specific and consequential.

For suspense: give the audience a meaningful uncertainty with a clock, vulnerability, or hidden threat. Do not confuse “nothing is explained” with suspense.

## Action and spectacle

A set piece needs a dramatic question, not just motion.

Track:
`goal → geography/rules → first tactic → complication → adaptation → sacrifice/reveal → outcome → new problem`

The physical action should expose character. If the same sequence could be transplanted into another movie without changing anything, it is probably decorative.

## Scene rewrite passes

Run in this order:
1. Function: does the scene change the story?
2. Conflict: is someone actively resisting?
3. Turn: is there a meaningful pivot?
4. Compression: can setup/explanation be removed?
5. Behavior: are emotions externalized into playable action?
6. Voice: could lines be reassigned without noticing?
7. Setup/payoff: does the scene plant, pay, or recontextualize something?
8. Read-aloud rhythm: does speech sound speakable rather than literary?

Polish only after 1–3 pass.
