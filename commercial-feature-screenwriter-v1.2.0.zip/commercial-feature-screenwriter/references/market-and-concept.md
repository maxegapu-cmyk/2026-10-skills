# Market and Concept Engine

## Purpose

Do not confuse “commercial” with formula. A commercially legible feature gives the audience a recognizable **audience promise**, then delivers it through a specific conflict that can keep producing pressure for 90–120 minutes.

## Premise Stress Test

Write the premise in one sentence with: protagonist + concrete goal + active opposition + stakes + contradiction/irony.

Then grade each dimension `GREEN / YELLOW / RED`:

| Dimension | Test |
|---|---|
| Clarity | Can a stranger understand the central movie in one breath? |
| Audience promise | What emotion, fantasy, fear, laughter, wonder, or catharsis are they buying? |
| Pressure engine | Can the core situation naturally generate worsening choices for feature length? |
| Specificity | What is difficult to swap out without turning this into a generic genre story? |
| Escalation yield | Does partial success create a harder or more expensive problem? |
| Character fit | Is this the worst/best possible problem for this protagonist? |
| Word-of-mouth hooks | Which situations, reversals, images, or moral dilemmas are easy to retell? |

A RED pressure engine is not repaired by adding subplots. Repair the engine first.

## Audience Promise Contract

Write three lines before outlining:

1. **Primary promise:** the dominant experience the trailer/poster/logline sells.
2. **Secondary promise:** the emotional or relational experience that makes the spectacle matter.
3. **Non-negotiable payoffs:** 3–7 moments the finished film must earn because the premise makes the audience expect them.

Example form:

`If the film promises X, the audience must eventually witness Y under maximum pressure, and the ending must answer Z.`

## Pressure Engine

A feature engine should repeatedly produce:

`goal → obstacle → tactic → temporary result → new cost/revelation → harder choice`

Prefer problems that mutate because characters act. External coincidence may start the movie; it should not keep solving or generating every major turn.

## Commercial Distinctiveness

Preserve all three layers:

- **Familiar pleasure:** genre expectation the audience actively wants.
- **Specific identity:** profession, relationship, culture, place, rule system, moral conflict, behavior.
- **Surprise mechanism:** reversals that emerge from the story’s own rules.

If a note says “make it more commercial,” diagnose which layer is weak. Do not automatically remove specificity.

## Word-of-Mouth Design

Do not manufacture “viral moments.” Instead identify naturally retellable material:

- a dilemma with no clean answer,
- a reversal that changes the meaning of an earlier scene,
- a visual or behavioral set piece tied to character,
- an emotionally costly choice,
- an earned reveal,
- a payoff to a memorable setup.

A hook that can be described but not dramatized is marketing copy, not screenplay value.

## Premise Failure Patterns

- The antagonist cannot actively adapt.
- Stakes exist only in dialogue.
- The protagonist can quit with little cost.
- Every escalation is simply “more danger.”
- The premise provides one great trailer scene but no second act.
- The concept depends on mystery, but the truth cannot change behavior once known.
- The protagonist is interchangeable with any competent hero.

When two or more are present, rebreak before pages.
