# Treatment and Pitch Documents

## Treatment

A professional feature **treatment** is a present-tense prose version of the movie, typically 5–10 page-equivalent unless the user requests another length.

Recommended order:

1. Title / format / genre.
2. Logline.
3. One-paragraph premise and audience promise.
4. Major character introductions with Want, Flaw, and relationship function.
5. Act/sequence story told as continuous prose.
6. Scene-level specificity at major turns: commitment, midpoint, All Is Lost, crisis, climax.
7. Ending included unless the destination explicitly requires withholding it.
8. Short thematic/emotional statement.

A treatment is not a bullet outline and not a screenplay written without dialogue. It should let a **producer** feel pacing, reversals, and emotional direction quickly.

## One-Pager

Use for a fast producer/financier read:

`Title + format | logline | 2-paragraph story | tone | comparables | distinctiveness | writer/project positioning if supplied`

Aim for roughly 350–500 words. Unlike a full treatment, a sales one-pager may withhold detailed climax if the user wants a leave-behind rather than a full story document.

## Comparables

Use 2–3 **comparables** only when they clarify audience, tone, scale, or distribution position.

For each comp state:

`What this project shares | What this project refuses to copy | Why the audience overlap matters`

“X meets Y” is never the premise itself.

## Pitch Test

A verbal pitch should answer:

- Who are we following?
- What happens that they cannot ignore?
- What are they trying to do?
- What keeps making it worse?
- Why is this emotionally specific?
- What are the 2–4 signature situations only this movie promises?
- What impossible choice does the ending force?

## Treatment Failure Patterns

- Lists beats without making causality readable.
- Hides the ending so aggressively that development cannot judge the story.
- Uses adjectives instead of concrete events.
- Gives every supporting character a biography unrelated to decisions.
- Announces theme rather than dramatizing it.
- Spends pages on worldbuilding before a protagonist has a problem.
