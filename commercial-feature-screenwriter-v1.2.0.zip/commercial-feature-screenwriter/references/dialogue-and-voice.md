# Dialogue and Voice Engine

## Dialogue Is Action

Every exchange should have a tactical purpose. Characters use language to obtain, evade, test, conceal, threaten, recruit, seduce, shame, stall, repair, provoke, or surrender.

If a line only communicates a fact both characters already know, convert the fact into conflict, leverage, discovery, disagreement, or omission.

## Subtext

For each speaker ask:

1. What do they need the other person to do?
2. What truth would become dangerous if stated directly?
3. What social mask are they trying to keep intact?

The gap creates **subtext**.

## Verbal Register

Give each recurring character a distinct **verbal register**:

- vocabulary range,
- sentence length,
- directness vs indirection,
- metaphor domain,
- tolerance for silence,
- humor/aggression pattern,
- formality,
- what they never say,
- how they speak when losing power.

Voice is not catchphrases pasted onto interchangeable thinking.

## On-the-Nose Test

Flag **on-the-nose** dialogue when a character directly states emotion, motive, theme, or information the scene already dramatizes.

Repair with:

- oblique request,
- changed subject,
- behavior contradicting words,
- leverage,
- misdirection,
- incomplete sentence,
- silence,
- a concrete task performed while speaking.

## Silence

**Silence** is dialogue when it changes power. Specify the behavior around it rather than writing abstract emotion.

Weak: `She is devastated.`

Playable: `She folds his jacket once, leaves it on the chair, and answers the next question without looking at him.`

## Exposition Repair

Move information into one of these engines:

- one character knows, one does not;
- both know but disagree about meaning;
- a fact is used as threat or bargain;
- a discovery is made through action/object/environment;
- a speaker deliberately withholds the final piece;
- the audience understands through consequence before anyone explains it.

## Dialogue Polish Pass

Run in this order:

1. Preserve scene objective and turn.
2. Mark explicit emotion/motive statements.
3. Mark interchangeable voices.
4. Cut repeated information.
5. Replace explanation with tactics.
6. Use pauses/silence only where power shifts.
7. Read aloud for speakability.
8. Protect indispensable lines only if they still serve action.

Do not improve dialogue by restructuring the entire scene unless asked.
