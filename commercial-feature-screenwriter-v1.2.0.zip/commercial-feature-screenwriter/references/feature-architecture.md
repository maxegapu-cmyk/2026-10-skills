# Feature Architecture

## Beats Are Stress Points, Not Boxes

Use structural landmarks to test causal progression. Do not force page numbers when the film’s rhythm demands otherwise.

A practical feature often lands around **45–60 scenes; ~55 is a planning target, not a quota**.

## Thirteen Functional Landmarks

1. Opening condition — protagonist’s current operating system.
2. Disruption — old equilibrium becomes impossible.
3. Refusal/containment — attempt to solve without truly entering the movie.
4. Commitment — protagonist chooses the central arena.
5. Promise delivery — early premise pleasures arrive.
6. First real cost — success exposes a price or stronger opposition.
7. Pressure convergence — plot and relationship/internal problem feed each other.
8. Midpoint — new truth, relationship, strategy, status, or irreversible cost changes the game.
9. Counterattack — opposition exploits what the protagonist revealed.
10. All Is Lost / strategy collapse — the old way cannot solve the movie.
11. Crisis choice — competing values force commitment.
12. Climax — the final plan uses earned setups, abilities, relationships, and changed choices.
13. Aftermath — new equilibrium proves what changed.

A midpoint that is only “the explosion is bigger” is weak. It must alter meaning or available strategy.

## Sequence Architecture

Break the film into 8–12 sequences of roughly 8–15 minutes. For every sequence answer:

`local goal | sequence obstacle | dominant tactic | new complication | gain | loss | irreversible change | handoff pressure`

Two consecutive sequences with the same goal/tactic/result pattern indicate drift.

## 55-Scene Spine

For each scene record:

`ID | sequence | driver | immediate objective | obstacle | tactic | turn | changed state | setup/payoff | next pressure | estimated screen time`

Do not write a scene merely because an outline “needs” one. Scene count is a planning aid.

## Causal Link Test

Between adjacent scenes, prefer:

- **THEREFORE:** consequence forces next action.
- **BUT:** resistance forces adaptation.

Repeated **AND THEN** usually means episodic plotting. One montage or breath scene can intentionally loosen causality, but the movie cannot live there.

## Escalation Ladder

Across sequences, intensify one or more meaningful dimensions:

- cost of failure,
- personal exposure,
- opposition intelligence,
- time compression,
- moral compromise,
- ally/resource loss,
- irreversible consequences,
- uncertainty about the true problem.

Do not max every dimension simultaneously. Alternation creates rhythm.

## Set-Piece Architecture

A set piece is a mini-story:

`dramatic question → geography/rules → first tactic → complication → adaptation → sacrifice/reveal → outcome → new problem`

It must expose character or alter strategy. Decorative spectacle is expendable.

## Ending Integrity

The climax must satisfy four tests:

1. It resolves the central external problem.
2. It forces the protagonist’s most expensive choice.
3. It pays off earlier setups rather than introducing a random solution.
4. Its consequence survives into aftermath.

If another character could make the same final choice with no loss of meaning, the movie has not fully fused plot and character.
