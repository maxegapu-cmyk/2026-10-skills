# Character and Arc Engine

## Character Core

Track each major character through six fields:

1. **Want** — conscious external pursuit.
2. **Need / tested principle** — the internal change required, or the principle a flat-arc hero must defend under pressure.
3. **Flaw / misbelief** — the shortcut that protects the character from a feared cost.
4. **Competence** — why following this person is pleasurable.
5. **Pressure behavior** — what they do when cornered that creates new trouble.
6. **Relationship pressure** — which relationship makes success emotionally expensive.

A usable character generates plot through choices. A passive character forces the writer to invent machinery around them.

## Choice Ladder

For the protagonist, build at least five increasingly costly choices:

`easy compromise → visible sacrifice → relationship damage → identity-threatening choice → climax choice`

Each choice should reveal more about the character than a speech could.

The climax is strongest when the protagonist cannot keep both the external goal and the old self-protective strategy.

## Arc Test

For change arcs:

`opening behavior → pressure exposes flaw → success reinforces wrong strategy → cost makes strategy untenable → crisis choice → changed behavior in climax → aftermath proof`

For flat arcs:

`opening principle → world challenges principle → isolation/cost → temptation to abandon it → renewed commitment → principle changes others/world → aftermath proof`

Do not confuse “learning information” with an arc. Arc is changed behavior under pressure.

## Opposition Design

The antagonist or opposing system needs:

- a concrete goal,
- leverage/resources,
- a coherent worldview or operating logic,
- adaptation when the protagonist changes tactics,
- the ability to attack both plan and weakness.

Do not make opposition omniscient solely to force plot turns. Give it information channels and constraints.

## Relationship Engine

For every central relationship, define:

`mutual need | unresolved wound | power imbalance | secret/leverage | recurring disagreement | potential break | potential repair`

Then make plot turns alter the relationship. A relationship subplot that can be removed without changing decisions is decorative.

## Voice Before Dialogue

Voice comes from thinking, not catchphrases. Define:

- what the character notices first,
- what they refuse to name,
- directness vs indirection,
- sentence length/rhythm,
- favorite domains/metaphors,
- humor/aggression style,
- tolerance for silence,
- behavior when losing status.

If lines can be reassigned between two characters without obvious damage, their voices are not yet distinct.

## Character Bible Minimum

For recurring characters record:

`Role | Want | Need/Principle | Flaw | Competence | Fear | Secret | Relationship map | Choice ladder | Voice rules | Opening state | Ending state`

Only add biography when it changes behavior in the movie.
