# ORIGINAL FICTIONAL EXAMPLE — BLACK SIGNAL

This is an **ORIGINAL FICTIONAL EXAMPLE** created for this skill. It is not based on or adapted from an existing screenplay. It demonstrates a complete feature-development pass rather than claiming to be a finished production draft.

## Concept Lock

**Genre:** infrastructure thriller / conspiracy drama  
**Target runtime:** 105–115 minutes  
**Audience promise:** a technically legible citywide blackout thriller where every “correct” operational choice has human consequences, and the conspiracy is defeated through earned competence rather than a magic hack.

**Logline:** During a historic solar storm, a disgraced grid dispatcher has six hours to stop a coastal city from cascading into permanent blackout while proving the private emergency-power company rescuing the city engineered the collapse to seize control of the grid.

**Pressure engine:** every stabilization decision preserves one critical system by exposing another, while the antagonist converts each visible failure into political leverage. The protagonist’s instinct to control everything initially makes her effective, then isolates her, and finally must evolve into delegated trust.

## Character Engine

- **Mara Venn — Want:** keep the city alive and prove she still belongs in the control room. **Need:** accept that leadership is not personal control. **Flaw:** hoards responsibility because she equates delegation with failure. **Competence:** elite grid intuition under unstable conditions.
- **Eli Venn — Want:** protect port workers and stop Mara from treating people like load values. **Pressure function:** forces human consequences into every technical decision. **Arc:** moves from moral accusation to informed partnership without becoming uncritical.
- **Adrian Vale — Want:** trigger emergency privatization and lock the city into Helix infrastructure. **Worldview:** public systems are politically incapable of making ugly decisions; therefore controlled failure is legitimate if it produces “resilience.” **Adaptation:** software leverage → narrative leverage → physical site control → legal seizure.
- **Jun Park — Want:** prove the hidden certificate trail. **Function:** investigation and information payoff. **Arc:** stops waiting for permission and learns to publish evidence independently rather than merely supply Mara with facts.

## Promise / Setup-Payoff Ledger

- Manual analog relays: planted as obsolete infrastructure → becomes the only path outside Helix software → burns at All Is Lost → restored through the portable transformer.
- Mara’s refusal to delegate: planted in opening operation → causes team friction → challenged when another operator catches an unsafe step → paid when the climax succeeds because she trusts distributed crews.
- Eli’s accusation that Mara “chooses systems over people”: planted as wound → mirrored by his port evacuation/substation choice → reframed at crisis → paid through shared sacrifice.
- Helix emergency containers: introduced as miraculous response assets → serials reveal pre-positioning → become evidence of engineered dependence.
- Father’s multimeter: mentioned in family conflict → held by Eli → returned in aftermath as a behavioral reconciliation object, not a sentimental speech.

## 55-Scene Spine

### Scene 01 — Night Shift
**Dramatic drive:** Mara keeps a failing coastal grid stable during a routine storm warning.
**Turn:** She refuses a supervisor’s suggestion to shed an affluent district because she remembers the blackout that ruined her career.
**Changed state / next pressure:** Her instinct to personally control every variable is established.

### Scene 02 — The Pulse
**Dramatic drive:** A solar flare warning jumps from advisory to severe.
**Turn:** Satellite timing glitches make automated balancing unreliable.
**Changed state / next pressure:** Mara chooses manual control and locks herself into responsibility.

### Scene 03 — Private Backup
**Dramatic drive:** Helix Power offers emergency battery capacity at an impossible discount.
**Turn:** Mara distrusts Helix but the city manager orders acceptance.
**Changed state / next pressure:** The movie’s central dependency is created.

### Scene 04 — Old Wound
**Dramatic drive:** Mara’s estranged brother Eli arrives at the control center as a port emergency liaison.
**Turn:** He blames her for choosing the grid over family during their father’s death.
**Changed state / next pressure:** The external crisis is tied to a relationship wound.

### Scene 05 — First Drop
**Dramatic drive:** Three substations trip simultaneously.
**Turn:** The failure pattern is too coordinated for solar noise alone.
**Changed state / next pressure:** Mara suspects an active hand instead of random disaster.

### Scene 06 — Hospital Clock
**Dramatic drive:** A children’s hospital reports eighteen minutes of generator fuel due to a maintenance error.
**Turn:** Helix can save it only if Mara reroutes power away from the port.
**Changed state / next pressure:** She chooses the hospital, creating port exposure.

### Scene 07 — Port Consequence
**Dramatic drive:** The port loses crane brakes and a container ship grounds in the channel.
**Turn:** Eli must evacuate workers while defending Mara’s decision.
**Changed state / next pressure:** Her “correct” choice creates a visible new cost.

### Scene 08 — The Offer
**Dramatic drive:** Helix executive Vale proposes taking operational control of the whole grid for six hours.
**Turn:** He frames it as the only way to prevent cascade collapse.
**Changed state / next pressure:** Mara refuses, making Vale an active opponent.

### Scene 09 — Manual Island
**Dramatic drive:** Mara isolates two neighborhoods into a microgrid.
**Turn:** The maneuver works, buying trust from exhausted operators.
**Changed state / next pressure:** Competence delivers the premise’s early pleasure.

### Scene 10 — Ghost Command
**Dramatic drive:** A breaker opens despite being physically locked.
**Turn:** Only a privileged maintenance certificate could authorize it.
**Changed state / next pressure:** Mara realizes the attack is inside the control chain.

### Scene 11 — Certificate Trail
**Dramatic drive:** Operator Jun traces the certificate to a retired Helix contractor account.
**Turn:** The account was supposedly deleted after a merger.
**Changed state / next pressure:** The conspiracy becomes specific and investigable.

### Scene 12 — Family Leverage
**Dramatic drive:** Eli asks Mara to prioritize the flooded port clinic now housing evacuees.
**Turn:** She cannot do it without dropping power to a water plant.
**Changed state / next pressure:** Relationship pressure begins to distort operational choices.

### Scene 13 — Water Gamble
**Dramatic drive:** Mara delays the clinic request and stabilizes the water plant.
**Turn:** Eli calls it another case of her choosing systems over people.
**Changed state / next pressure:** Her flaw is reinforced by a decision that is rational but emotionally costly.

### Scene 14 — First Proof
**Dramatic drive:** Jun finds identical trip signatures in a Helix test archive.
**Turn:** The signature looks like a staged cascade used to sell resilience contracts.
**Changed state / next pressure:** Mara gains proof that Helix can simulate this disaster.

### Scene 15 — Cut Off
**Dramatic drive:** City leadership orders Jun to stop digging and accept Helix control.
**Turn:** Vale has already briefed officials that Mara is unstable after her old scandal.
**Changed state / next pressure:** Opposition attacks both plan and credibility.

### Scene 16 — Unauthorized Route
**Dramatic drive:** Mara secretly sends Jun a copy of the archive before security revokes his access.
**Turn:** Jun must leave the center and continue from a public library uplink.
**Changed state / next pressure:** The investigation splits into two arenas.

### Scene 17 — Battery Miracle
**Dramatic drive:** Helix restores power to a wealthy medical district in minutes.
**Turn:** News coverage praises the company and questions public-grid competence.
**Changed state / next pressure:** Vale wins the public narrative.

### Scene 18 — False Recovery
**Dramatic drive:** Grid frequency stabilizes after Helix’s intervention.
**Turn:** Mara notices stability depends on a hidden reserve she cannot see in the official dashboard.
**Changed state / next pressure:** A seeming solution becomes a new mystery.

### Scene 19 — Eli’s Discovery
**Dramatic drive:** At the port, Eli finds emergency Helix containers installed weeks before the storm.
**Turn:** Their serials match equipment supposedly delivered that morning.
**Changed state / next pressure:** The disaster appears pre-positioned.

### Scene 20 — The Price
**Dramatic drive:** Vale privately tells Mara that the city will survive if she signs an emergency privatization protocol.
**Turn:** He offers to clear her old disciplinary record in return.
**Changed state / next pressure:** The antagonist makes a personal bargain, not just a threat.

### Scene 21 — Refusal
**Dramatic drive:** Mara rejects the deal and records part of the conversation.
**Turn:** Vale remotely locks her out of several Helix-controlled nodes.
**Changed state / next pressure:** Her moral choice immediately worsens the practical crisis.

### Scene 22 — Midpoint Blackout
**Dramatic drive:** A synchronized trip takes down the central hospital corridor and the port at once.
**Turn:** The hidden reserve was never reserve power; it was capacity Helix had withheld to manufacture dependence.
**Changed state / next pressure:** The midpoint changes the meaning of every earlier “rescue.”

### Scene 23 — Public Enemy
**Dramatic drive:** Vale releases a clip blaming Mara’s manual interventions for the collapse.
**Turn:** Police are dispatched to remove her from the control center.
**Changed state / next pressure:** Mara loses institutional authority while the city needs her most.

### Scene 24 — Operator Mutiny
**Dramatic drive:** Two operators obey the removal order; one quietly keeps Mara’s console alive.
**Turn:** Mara must decide whether to endanger colleagues by staying.
**Changed state / next pressure:** Her control instinct collides with responsibility for others.

### Scene 25 — Exit Through Maintenance
**Dramatic drive:** Mara leaves the main room but enters an old analog relay corridor beneath the building.
**Turn:** She can influence only a handful of circuits manually.
**Changed state / next pressure:** The story strips her resources while preserving agency.

### Scene 26 — Jun’s Leak
**Dramatic drive:** Jun uploads the Helix test archive to a journalist.
**Turn:** The files are dismissed as old simulations without a live link to tonight’s failures.
**Changed state / next pressure:** Evidence exists but is not yet persuasive enough.

### Scene 27 — Port Fire
**Dramatic drive:** A grounded container catches fire near fuel storage.
**Turn:** Eli can evacuate civilians or protect a substation needed for city recovery, not both.
**Changed state / next pressure:** He finally faces Mara’s kind of impossible choice.

### Scene 28 — Brother’s Choice
**Dramatic drive:** Eli evacuates civilians and lets the substation flood.
**Turn:** He understands why Mara’s decisions look cruel from outside.
**Changed state / next pressure:** The relationship arc begins to turn through action.

### Scene 29 — Analog Map
**Dramatic drive:** Mara discovers the old relay corridor bypasses Helix’s software certificates.
**Turn:** The route can reconnect three critical islands but requires technicians at remote sites.
**Changed state / next pressure:** A possible final strategy is planted.

### Scene 30 — Recruitment
**Dramatic drive:** Mara uses emergency radio to recruit retired grid workers and city electricians.
**Turn:** Officials threaten arrests for unauthorized switching.
**Changed state / next pressure:** Her leadership shifts from control to trust.

### Scene 31 — Vale Adapts
**Dramatic drive:** Vale orders Helix crews to physically secure two substations.
**Turn:** The conflict moves from software to geography.
**Changed state / next pressure:** Opposition adapts to Mara’s new tactic.

### Scene 32 — Clinic Run
**Dramatic drive:** Eli leads evacuees through dark streets toward a powered school.
**Turn:** He sees Helix mobile lights illuminating a media staging area while nearby apartments remain dark.
**Changed state / next pressure:** The public-relations strategy becomes visually undeniable.

### Scene 33 — Journalist Link
**Dramatic drive:** The journalist connects Jun’s archive to tonight’s serial numbers supplied by Eli.
**Turn:** A publishable chain of evidence finally exists.
**Changed state / next pressure:** The investigation earns leverage through combined choices.

### Scene 34 — Clock Compression
**Dramatic drive:** Space-weather forecasts show a second geomagnetic pulse in forty minutes.
**Turn:** If the grid is still fragmented, transformers may be permanently damaged.
**Changed state / next pressure:** The final act receives a hard clock.

### Scene 35 — The Relay Plan
**Dramatic drive:** Mara outlines a manual reconnection sequence using the analog corridor and field crews.
**Turn:** One mistake could energize dead lines and kill technicians.
**Changed state / next pressure:** The final plan carries moral and physical cost.

### Scene 36 — Trust Test
**Dramatic drive:** Mara delegates switching authority to operators she previously micromanaged.
**Turn:** One questions her sequence and proves a step unsafe.
**Changed state / next pressure:** She changes behavior by accepting correction under pressure.

### Scene 37 — Helix Countermove
**Dramatic drive:** Vale cuts communications to the field sites.
**Turn:** Teams must continue from synchronized watches and written orders.
**Changed state / next pressure:** The plan becomes fragile but not impossible.

### Scene 38 — First Reconnect
**Dramatic drive:** A neighborhood, water plant, and emergency radio tower come back together.
**Turn:** The success proves Mara’s method can work without Helix.
**Changed state / next pressure:** Hope appears, increasing what can now be lost.

### Scene 39 — Exposure
**Dramatic drive:** The journalist publishes evidence of pre-positioned Helix equipment and withheld reserve capacity.
**Turn:** Vale denounces the story as fabricated and announces a final “rescue” activation.
**Changed state / next pressure:** Public truth arrives before practical victory.

### Scene 40 — All Is Lost
**Dramatic drive:** Helix’s activation overloads the analog route and burns a key relay bank.
**Turn:** Mara’s final plan appears physically impossible; the second solar pulse is twelve minutes away.
**Changed state / next pressure:** The old strategy is destroyed.

### Scene 41 — Eli Returns
**Dramatic drive:** Eli reaches the control building with a portable port transformer and crew.
**Turn:** Installing it means abandoning the last powered shelter near the port.
**Changed state / next pressure:** The siblings must share an irreversible sacrifice.

### Scene 42 — Crisis Choice
**Dramatic drive:** Mara wants to protect the shelter; Eli insists the transformer can save the entire city grid.
**Turn:** He tells her that choosing the system can also be choosing people when the cost is owned honestly.
**Changed state / next pressure:** Mara’s internal argument is reframed by relationship.

### Scene 43 — Sacrifice
**Dramatic drive:** They move the transformer.
**Turn:** The shelter shifts to buses and battery lights, creating immediate hardship.
**Changed state / next pressure:** The climax plan is paid for before it succeeds.

### Scene 44 — Vale in Person
**Dramatic drive:** Vale arrives with security to seize the control building under emergency authority.
**Turn:** Mara can expose him publicly or spend precious minutes completing the switch.
**Changed state / next pressure:** She chooses the grid over vindication, reversing her need for personal control of the narrative.

### Scene 45 — Jun’s Broadcast
**Dramatic drive:** Jun sends the live evidence package to every local station without waiting for Mara.
**Turn:** Mara trusts him to handle truth while she handles power.
**Changed state / next pressure:** Delegated agency becomes a payoff.

### Scene 46 — Manual Synchronization
**Dramatic drive:** Field crews report by radio as frequencies converge.
**Turn:** One substation drifts and risks a catastrophic out-of-phase close.
**Changed state / next pressure:** The technical climax becomes a choice, not jargon.

### Scene 47 — The Unsafe Shortcut
**Dramatic drive:** Vale offers a Helix automated synchronization that would save time.
**Turn:** Accepting it would restore his hidden control channel.
**Changed state / next pressure:** The antagonist offers the old dependency at maximum temptation.

### Scene 48 — Climax Choice
**Dramatic drive:** Mara rejects automation and orders a slower manual close, even as the solar pulse arrives.
**Turn:** The choice risks visible failure but preserves city control and technician safety.
**Changed state / next pressure:** Her changed operating principle governs the climax.

### Scene 49 — Black Seconds
**Dramatic drive:** The city goes fully dark for nine seconds during transfer.
**Turn:** Mara cannot know if the manual sequence worked.
**Changed state / next pressure:** Maximum uncertainty follows the costly choice.

### Scene 50 — Return
**Dramatic drive:** Emergency islands return in sequence: hospital, water, radio, port pumps.
**Turn:** The grid survives the second pulse without Helix control.
**Changed state / next pressure:** External conflict resolves through earned setups.

### Scene 51 — Vale Loses Leverage
**Dramatic drive:** Police receive the published evidence and city counsel voids the emergency privatization order.
**Turn:** Vale cannot turn narrative control into legal control.
**Changed state / next pressure:** Antagonist power collapses through earlier investigative payoffs.

### Scene 52 — The Port Cost
**Dramatic drive:** Mara reaches the port and sees the shelter damage caused by moving the transformer.
**Turn:** Success has a human bill and is not treated as clean triumph.
**Changed state / next pressure:** Consequence survives the climax.

### Scene 53 — Sibling Repair
**Dramatic drive:** Eli does not forgive the past in a speech; he hands Mara their father’s old multimeter and asks where it is needed next.
**Turn:** The relationship repairs through action.
**Changed state / next pressure:** Emotional payoff avoids on-the-nose resolution.

### Scene 54 — Public Hearing
**Dramatic drive:** Weeks later, Mara testifies but refuses to center her own scandal.
**Turn:** She credits operators, field crews, and the residents who endured intentional outages.
**Changed state / next pressure:** Her leadership change is visible in behavior.

### Scene 55 — Final Image
**Dramatic drive:** At dusk, Mara watches a trainee challenge a dispatch decision and asks her to explain the alternative instead of shutting her down.
**Turn:** The grid hums behind them, imperfect but public.
**Changed state / next pressure:** The opening need for control is paid off by shared authority.

## Sequence Audit

1. **S1 — The Grid Is a Choice Machine (Scenes 1–7):** establish competence, flaw, family pressure, and first consequence. The audience receives the core pleasure immediately: difficult operational choices with visible human cost.
2. **S2 — The Rescue Company (8–14):** Helix appears indispensable while Mara discovers the first signs of artificial failure. Opposition and investigation become active.
3. **S3 — Credibility War (15–21):** Helix attacks Mara’s authority and offers personal rehabilitation in exchange for surrender. Her refusal causes immediate practical loss.
4. **S4 — Midpoint Reversal (22–28):** the “reserve” is revealed as withheld capacity, redefining Helix’s rescues as manufactured dependence. Mara loses institutional power; Eli experiences her dilemma firsthand.
5. **S5 — Distributed Control (29–35):** the analog path creates a new strategy requiring Mara to trust others. The second solar pulse supplies a hard clock.
6. **S6 — Countermove (36–40):** delegation begins working, evidence goes public, and Vale adapts physically. The analog route burns at All Is Lost.
7. **S7 — Costed Final Plan (41–48):** Eli supplies the transformer at real human cost. Vale offers the tempting old dependency. Mara chooses slower shared control over a faster compromised rescue.
8. **S8 — Payoff and Consequence (49–55):** the grid returns, the conspiracy loses leverage, costs remain visible, relationships repair through behavior, and the opening control flaw resolves through shared authority.

## Root-Issue Self-Review

**Main risk:** the conspiracy can become too clean if Vale appears able to control everything. Countermeasure: every Helix move must use a traceable resource—maintenance certificates, pre-positioned equipment, political contracts, or physical crews—so opposition stays powerful without becoming omniscient.

**Secondary risk:** technical material could overwhelm emotion. Countermeasure: every major technical choice must alter a relationship, public belief, or immediate human consequence; no scene exists solely to explain grid mechanics.

**AI-film Route B note:** the city-scale blackout remains non-negotiable. Production can concentrate coverage through control room, port, hospital corridor, street fragments, radio, news screens, and aftermath, but cannot shrink the event into a few characters merely because crowds and city destruction are difficult to generate.
