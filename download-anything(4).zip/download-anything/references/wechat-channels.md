# WeChat Channels (微信视频号) Downloads

Videos and image posts from 视频号, resolved from share links (`weixin.qq.com/sph/...`).

## Quick Use

```bash
# Any 视频号 link — video posts land as mp4, image posts as a folder
scripts/dl-video.sh "https://weixin.qq.com/sph/AbCdEf123"

# Metadata only (agent preview before download)
scripts/sph-resolve.sh "https://weixin.qq.com/sph/AbCdEf123"

# Machine-readable JSON for pipelines
scripts/sph-resolve.sh "https://weixin.qq.com/sph/AbCdEf123" --json | jq -r '.video_url'

# Credential & fallback-site health
scripts/sph-resolve.sh --check
```

Output files are named `[author] first-line-of-description.mp4` plus a
`<name>.meta.json` sidecar (full metadata: stats, cover, urls).

## How It Works (the two-stage chain)

视频号 has **no yt-dlp extractor** and the official web preview API refuses to
return video URLs anonymously (metadata only). The working chain:

```
share link                      resolution layer                WeChat official
weixin.qq.com/sph/<id>  ──→  (see layers below)  ──→  POST channels.weixin.qq.com/finder-preview/api/feed/get_feed_info
                                                          body: {"baseReq":{"generalToken":<token>},"exportId":<eid>}
                                                                │
                              ┌─────────────────────────────── ┘
                              ▼
                 data.feedInfo.h264VideoInfo.videoUrl
                 = https://finder.video.qq.com/<...>/stodownload?encfilekey=..&token=..&sign=..
                   (time-limited direct URL; supports HTTP Range → multi-thread OK)
```

The missing `<token>`/`<eid>` are what the resolution layers produce.

## Resolution Layers

Tried in order; first hit wins (`resolved_by` field in JSON output says which).

| Layer | Mechanism | Needs | Reliability |
|-------|-----------|-------|-------------|
| 1. yuanbao | Your own Tencent Yuanbao cookie → `yuanbao.tencent.com/api/weixin/get_parse_result` returns `playable_url` (token/eid) → official feed API | `YUANBAO_COOKIE` env, ~monthly refresh | Highest (self-owned) |
| 2. public sites | `sph.allconning.com` → `v.mtotech.com` → `wxchannel.solua.one` → `sph.litao.workers.dev` — their backend accounts do the resolving | Nothing | Varies; check with `--check` |

### yuanbao-cookie setup (Layer 1)

**Recommended — guided setup (works from any agent session):**

```bash
scripts/sph-resolve.sh --set-cookie          # paste cookie, Ctrl-D
scripts/sph-resolve.sh --set-cookie "$URL" < cookie.txt   # + immediate validation
```

Stored at `~/.config/download-anything/yuanbao-cookie` (mode 600). Takes
priority: env `YUANBAO_COOKIE` > config file.

**Getting the cookie (2 minutes, once a month):**

1. Visit https://yuanbao.tencent.com and log in (WeChat QR scan; a **small /
   spare account** is recommended — see Risks).
2. DevTools (F12) → Network → refresh the page → click any request to
   `yuanbao.tencent.com` → Request Headers → copy the **entire** `Cookie:`
   value.
3. Run `scripts/sph-resolve.sh --set-cookie`, paste, Ctrl-D.
4. Verify: resolve any link — JSON `resolved_by` should say `yuanbao`.

Cookie lifetime ≈ 1 month. When `resolved_by` starts showing a public-site
name instead of `yuanbao`, the cookie expired — repeat the steps above.

### agent-setup flow (how an agent should guide the user)

When a 视频号 download task arrives and Layer 1 is not active, the agent
should **offer** (not silently fall back) the guided setup:

1. Detect state: `sph-resolve.sh --check` → `yuanbao cookie: NOT set`, or a
   resolve returns `resolved_by != "yuanbao"`.
2. Tell the user: download still works via public sites, but a self-owned
   Layer 1 is more reliable; setup takes ~2 min, cookie lasts ~1 month,
   recommend a spare Tencent account (small ban risk, see Risks).
3. If the user agrees, walk them through the 4 steps above, then run:
   ```bash
   sph-resolve.sh --set-cookie "$URL"   # paste at the prompt
   ```
   and confirm `resolved_by: yuanbao` in the output.
4. If the user declines, proceed with Layer 2 and don't ask again this session.

Re-offer only when: `--check` shows the cookie missing/expired again, or a
resolve falls back to public sites while downloading a batch.

**Risks (be aware):** the Yuanbao chain uses your Tencent account at some
automation rate. Public services running the same chain have had accounts
banned. Mitigations: spare account, low frequency, personal use, never share
the cookie. Zero-risk alternatives: Layer 2, or §local-capture below.

## Direct-URL Characteristics (stodownload)

- Domain `finder.video.qq.com/.../stodownload?encfilekey=...&token=...&sign=...`
- **Time-limited**: tokens expire (hours); download soon after resolving,
  don't archive the URL.
- Requires `Referer: https://channels.weixin.qq.com/` + a browser UA or the
  CDN refuses.
- Supports `Range` → aria2c 16-connection works (curl fallback is automatic
  when aria2 is absent).
- Choose codec: default h264 (max compatibility); `dl-video.sh URL h265` for
  the h265 variant when present.

## Image Posts (图文帖)

Posts with `mediaType != 4` carry a `picInfo` array instead of video.
`sph-resolve.sh` normalizes them to `image_urls[]` (largest size per image),
and `dl-video.sh` downloads them into a `[author] description/` folder as
`01.jpg 02.jpg ...`. The same JSON feeds other pipelines:

```bash
scripts/sph-resolve.sh "$URL" --json | jq -r '.image_urls[]' | aria2c -i -
```

## local-capture fallback (no third-party at all)

When every layer is down, capture from your own WeChat client:

- [lecepin/WeChatVideoDownloader](https://github.com/lecepin/WeChatVideoDownloader) —
  desktop app + local mitmproxy; play the video in WeChat PC/Mac, it grabs the
  `stodownload` URL from the client's own traffic. Most stable (your session,
  no external account), but requires desktop WeChat and manual play-through.
- Manual HAR: DevTools on the finder-preview page while a logged-in session
  plays the video.

## Troubleshooting

| Symptom | Cause | Fix |
|---------|-------|-----|
| `resolved_by` shows a public site, not `yuanbao` | Cookie missing/expired | Re-run `--set-cookie` (see § agent-setup flow) |
| All layers failed | Public sites down + no cookie | `--check`; `--set-cookie`; §local-capture |
| 403 on download | Missing Referer/UA or token expired | Re-resolve (scripts handle headers; re-run for fresh token) |
| `not a WeChat Channels link` | URL didn't normalize to `weixin.qq.com/sph/<id>` | Use the link from 分享 → 复制链接 |
| Resolved but `media_type: unknown` | Post deleted / live replay / non-media | Nothing to download |
| 元宝 401 `code 20000` | Cookie invalid | Re-login and re-run `--set-cookie` |

## Agent Patterns

```bash
# preview → confirm → download
sph-resolve.sh "$URL" --json | jq '{author, media_type, stats}'

# batch: resolve list of links, save sidecars, download sequentially
while read -r url; do dl-video.sh "$url" best ~/channels/; done < links.txt
```

Field reference (`--json`): `ok, resolved_by, media_type(video|images),
video_url, video_h265_url, image_urls[], author, author_avatar, description,
cover_url, stats{likeCountFmt,favCountFmt,forwardCountFmt,commentCountFmt},
download_headers`.
