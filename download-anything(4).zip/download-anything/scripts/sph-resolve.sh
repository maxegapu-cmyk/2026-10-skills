#!/usr/bin/env bash
# sph-resolve.sh — WeChat Channels (视频号) share-link resolver.
# Turns a 视频号 share link into direct media URLs + metadata.
#
# Usage:
#   sph-resolve.sh URL              # human-readable summary (default)
#   sph-resolve.sh URL --json       # machine JSON (agent pipelines)
#   sph-resolve.sh --check          # credential & public-site health
#   sph-resolve.sh --set-cookie [URL] < cookie   # interactive Layer-1 setup:
#                                  paste the yuanbao cookie (Ctrl-D to finish),
#                                  saved to ~/.config/download-anything/yuanbao-cookie (600).
#                                  With URL: validates end-to-end immediately.
#
# Resolution layers (tried in order, first hit wins):
#   1. yuanbao   — your own Tencent Yuanbao cookie (env YUANBAO_COOKIE or
#                  config file via --set-cookie). Most reliable, self-owned.
#                  Cookie lasts ~1 month. Setup: references/wechat-channels.md
#   2. public sites — zero-config fallback chain:
#                  allconning -> mtotech -> solua -> litao
#                  (their backend accounts do the resolving; availability varies)
#
# Supports video posts (mediaType 4 -> mp4 direct URL) and image posts
# (图集 -> image_urls array).
#
# Exit codes: 0 ok | 1 all layers failed | 2 bad input
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

UA="Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
FINDER_REFERER="https://channels.weixin.qq.com/"

# --- arg parsing -----------------------------------------------------------

MODE="info"
RAW_INPUT=""
for arg in "$@"; do
    case "$arg" in
        --json)       MODE="json" ;;
        --info)       MODE="info" ;;
        --check)      MODE="check" ;;
        --set-cookie) MODE="setcookie" ;;
        -h|--help) sed -n '2,28p' "$0" | sed 's/^# \{0,1\}//'; exit 0 ;;
        *) RAW_INPUT="$arg" ;;
    esac
done

# --- Layer-1 credential loading ---------------------------------------------
# Priority: env YUANBAO_COOKIE > config file (written by --set-cookie).
COOKIE_FILE="${SPH_COOKIE_FILE:-$HOME/.config/download-anything/yuanbao-cookie}"
YB_COOKIE=""
load_yuanbao_cookie() {
    if [[ -n "${YUANBAO_COOKIE:-}" ]]; then
        YB_COOKIE="$YUANBAO_COOKIE"
        YB_COOKIE_SRC="env"
    elif [[ -s "$COOKIE_FILE" ]]; then
        YB_COOKIE=$(head -1 "$COOKIE_FILE" | tr -d '\r\n')
        YB_COOKIE_SRC="file"
    fi
}
load_yuanbao_cookie

# --- URL extraction & normalization ----------------------------------------
# Share text often arrives as "标题 https://weixin.qq.com/sph/XXXX 复制此条消息"
normalize_url() {
    local url
    url=$(printf '%s' "$1" | grep -oE 'https?://[^ "「」]+' | head -1)
    [[ -n "$url" ]] || return 1
    # Follow redirects so short links / canonical forms become weixin.qq.com/sph/<id>
    if ! [[ "$url" =~ weixin\.qq\.com/sph/|channels\.weixin\.qq\.com ]]; then
        url=$(curl -s -o /dev/null -w '%{url_effective}' -L --max-time 15 \
              -A "$UA" "$url" 2>/dev/null || true)
    fi
    printf '%s' "$url"
}

sph_id_from_url() {
    local url="$1"
    local re_sph='weixin\.qq\.com/sph/([A-Za-z0-9_-]+)'
    local re_id='[?&]id=([A-Za-z0-9_-]+)'
    if [[ "$url" =~ $re_sph ]]; then
        printf '%s' "${BASH_REMATCH[1]}"
    elif [[ "$url" =~ $re_id ]]; then
        printf '%s' "${BASH_REMATCH[1]}"
    else
        return 1
    fi
}

# --- health check -----------------------------------------------------------

check_health() {
    printf '%s\n' "=== sph-resolve health check ==="
    if [[ -n "$YB_COOKIE" ]]; then
        printf '  %-22s %s\n' "yuanbao cookie" "configured ($YB_COOKIE_SRC)"
    else
        printf '  %-22s %s\n' "yuanbao cookie" "NOT set — Layer 1 disabled"
        printf '  %-22s %s\n'  "" "setup: sph-resolve.sh --set-cookie  (guided: references/wechat-channels.md)"
    fi
    local site host status
    for site in \
        "sph.allconning.com" \
        "v.mtotech.com" \
        "wxchannel.solua.one" \
        "sph.litao.workers.dev"; do
        status=$(curl -s -o /dev/null -w '%{http_code}' --max-time 10 \
                 -A "$UA" "https://$site/" 2>/dev/null || echo 000)
        if [[ "$status" == [234]* ]]; then
            printf '  %-22s %s\n' "$site" "alive (HTTP $status)"
        else
            printf '  %-22s %s\n' "$site" "down (HTTP $status)"
        fi
    done
}

[[ "$MODE" == "check" ]] && { check_health; exit 0; }

# --- --set-cookie: guided Layer-1 setup --------------------------------------
# Reads the pasted cookie from stdin, stores it (0600), optionally validates
# end-to-end when an sph URL argument was also given.
set_cookie() {
    echo "Paste the full yuanbao Cookie request header, then press Ctrl-D:" >&2
    local cookie
    cookie=$(cat | tr -d '\r\n' | sed 's/^ *//;s/ *$//')
    if [[ ${#cookie} -lt 50 ]] || [[ "$cookie" != *=* ]]; then
        echo "error: that doesn't look like a cookie string (expected name=value; name2=value2; ...)" >&2
        exit 1
    fi
    mkdir -p "$(dirname "$COOKIE_FILE")"
    ( umask 177; printf '%s\n' "$cookie" > "$COOKIE_FILE" )
    echo "saved → $COOKIE_FILE (mode 600)" >&2
    echo "run sph-resolve.sh --check to confirm, or just resolve a link — resolved_by will say 'yuanbao'." >&2
}

if [[ "$MODE" == "setcookie" ]]; then
    set_cookie
    # Optional immediate validation: sph-resolve.sh --set-cookie URL < cookie
    if [[ -n "$RAW_INPUT" ]] && SHARE_URL=$(normalize_url "$RAW_INPUT" 2>/dev/null) \
       && SPH_ID=$(sph_id_from_url "$SHARE_URL" 2>/dev/null) && [[ -n "$SPH_ID" ]]; then
        load_yuanbao_cookie
        echo "" >&2
        echo "validating with $SHARE_URL ..." >&2
    else
        exit 0
    fi
fi

if [[ "$MODE" != "setcookie" ]] && [[ -z "$RAW_INPUT" ]]; then
    echo "Usage: sph-resolve.sh URL [--json|--info] | --check | --set-cookie [URL] < cookie" >&2
    exit 2
fi

SHARE_URL=$(normalize_url "$RAW_INPUT") || { echo "error: no URL found in input" >&2; exit 2; }
SPH_ID=$(sph_id_from_url "$SHARE_URL" || true)
if [[ -z "$SPH_ID" ]]; then
    echo "error: not a WeChat Channels link (expected weixin.qq.com/sph/<id>): $SHARE_URL" >&2
    exit 2
fi
[[ "$SHARE_URL" =~ ^https://weixin\.qq\.com/sph/ ]] || SHARE_URL="https://weixin.qq.com/sph/$SPH_ID"

# --- Layer 1: yuanbao -> official feed API ----------------------------------
# Stage 1: POST yuanbao.tencent.com/api/weixin/get_parse_result
#          -> data.playable_url (token & eid in query) + data.wx_export_id
# Stage 2: POST channels.weixin.qq.com/finder-preview/api/feed/get_feed_info
#          -> data.feedInfo.h264VideoInfo.videoUrl etc.
resolve_yuanbao() {
    [[ -n "$YB_COOKIE" ]] || return 1

    # Cookie goes via temp header file, not the command line.
    local hdr; hdr=$(mktemp); trap 'rm -f "$hdr"' RETURN
    printf 'Cookie: %s\n' "$YB_COOKIE" >"$hdr"

    local stage1
    stage1=$(curl -s --max-time 40 -X POST "https://yuanbao.tencent.com/api/weixin/get_parse_result" \
        -H "Content-Type: application/json" \
        -H "Origin: https://yuanbao.tencent.com" \
        -H "Referer: https://yuanbao.tencent.com/chat" \
        -H @"$hdr" \
        -A "$UA" \
        -d "{\"type\":\"video_channel_url\",\"url\":\"$SHARE_URL\",\"scene\":1}") || return 1

    YB_STAGE1_JSON="$stage1"

    local stage2
    stage2=$(YB_JSON="$stage1" python3 - <<'PY' || return 1
import json, os, urllib.parse, urllib.request, sys

stage1 = json.loads(os.environ["YB_JSON"])
data = stage1.get("data") or {}
playable = data.get("playable_url") or ""
wx_export_id = data.get("wx_export_id") or ""

q = urllib.parse.parse_qs(urllib.parse.urlparse(playable).query)
token = (q.get("token") or [""])[0]
eid = (q.get("eid") or q.get("export_id") or [""])[0] or wx_export_id
if not eid:
    sys.exit(1)

req = urllib.request.Request(
    "https://channels.weixin.qq.com/finder-preview/api/feed/get_feed_info",
    data=json.dumps({"baseReq": {"generalToken": token}, "exportId": eid}).encode(),
    headers={
        "Content-Type": "application/json",
        "Origin": "https://channels.weixin.qq.com",
        "Referer": "https://channels.weixin.qq.com/finder-preview/pages/sph?id=" + eid,
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
    },
    method="POST",
)
with urllib.request.urlopen(req, timeout=40) as r:
    sys.stdout.write(r.read().decode())
PY
    ) || return 1

    OFFICIAL_JSON="$stage2"
    printf 'yuanbao'
}

# --- Layer 2: public site chain ----------------------------------------------
# Each resolver prints the site's raw JSON on stdout, or fails.
# Shapes:
#   allconning/solua/litao: {"data":{"feedInfo":{...},"authorInfo":{...}}}
#   mtotech:                {"ok":true,"data":{"h264_url":...,"cover_url":...}}

resolve_site_allconning() { resolve_fetch_video_profile "https://sph.allconning.com/api/fetch_video_profile" allconning; }
resolve_site_solua()      { resolve_fetch_video_profile "https://wxchannel.solua.one/api/fetch_video_profile" solua; }
resolve_site_litao()      { resolve_fetch_video_profile "https://sph.litao.workers.dev/api/fetch_video_profile" litao; }

resolve_fetch_video_profile() {  # $1 endpoint $2 name
    curl -s --max-time 90 -X POST "$1" \
        -H "Content-Type: application/json" \
        -H "Origin: ${1%%/api*}" \
        -H "Referer: ${1%%/api*}/" \
        -A "$UA" \
        -d "{\"url\":\"$SHARE_URL\"}" || return 1
    printf '\n%s' "$2"
}

resolve_site_mtotech() {
    curl -s --max-time 90 -X POST "https://v.mtotech.com/api/resolve" \
        -H "Content-Type: application/json" \
        -H "Origin: https://v.mtotech.com" \
        -H "Referer: https://v.mtotech.com/" \
        -A "$UA" \
        -d "{\"url\":\"$SHARE_URL\"}" || return 1
    printf '\nmtotech'
}

# --- normalize any successful layer into the canonical JSON ------------------
# Canonical shape consumed by dl-video.sh / agents:
# { ok, resolved_by, media_type: video|images, video_url, video_h265_url,
#   image_urls[], author, description, cover_url, stats{}, source_page }
emit_canonical() {  # $1 raw json  $2 resolved_by  $3 out: "json"|"info"
    RAW="$1" BY="$2" MODE_OUT="$3" python3 - <<'PY'
import json, os, re, sys

raw = json.loads(os.environ["RAW"])
by = os.environ["BY"]
mode = os.environ["MODE_OUT"]

fi, ai = {}, {}
if by in ("allconning", "solua", "litao", "yuanbao"):
    d = raw.get("data") or {}
    fi = d.get("feedInfo") or {}
    ai = d.get("authorInfo") or {}
    if raw.get("errCode") not in (0, None) or not fi:
        print(f"error: upstream errCode={raw.get('errCode')}", file=sys.stderr); sys.exit(1)
else:  # mtotech
    d = raw.get("data") or {}
    if not raw.get("ok") or not (d.get("h264_url") or d.get("cover_url")):
        print(f"error: mtothek not ok", file=sys.stderr); sys.exit(1)
    fi = {
        "h264VideoInfo": {"videoUrl": d.get("h264_url", "")},
        "coverUrl": d.get("cover_url", ""),
        "description": d.get("description", ""),
        "mediaType": d.get("media_type"),
    }
    ai = {"nickname": d.get("author", ""), "headImgUrl": d.get("author_icon", "")}

def img_from_item(item):
    # picInfo items: imgUrl1/2/3 (small/mid/large)
    best = ""
    for k in sorted([k for k in item if re.fullmatch(r"imgUrl\d+", k)],
                    key=lambda k: int(k[6:]), reverse=True):
        v = item.get(k)
        if isinstance(v, str) and v.startswith("http"):
            best = v; break
    if not best:
        for v in item.values():
            if isinstance(v, str) and v.startswith("http") and "finder" in v:
                best = v; break
    return best

image_urls = [u for u in (img_from_item(it) for it in (fi.get("picInfo") or [])
                          if isinstance(it, dict)) if u]
h264 = ((fi.get("h264VideoInfo") or {}).get("videoUrl")
        or (fi.get("h264Videoinfo") or {}).get("videoUrl") or "")
h265 = ((fi.get("h265VideoInfo") or {}).get("videoUrl")
        or (fi.get("h265Videoinfo") or {}).get("videoUrl") or "")
fallback = fi.get("videoUrl") or ""
video_url = h264 or fallback
media_type = "video" if (video_url or h265) else ("images" if image_urls else "unknown")

stats = {k: fi.get(k, "") for k in
         ("likeCountFmt", "favCountFmt", "forwardCountFmt", "commentCountFmt")
         if fi.get(k)}

out = {
    "ok": media_type != "unknown",
    "resolved_by": by,
    "media_type": media_type,
    "video_url": video_url,
    "video_h265_url": h265,
    "image_urls": image_urls,
    "author": ai.get("nickname", ""),
    "author_avatar": ai.get("headImgUrl", ""),
    "description": fi.get("description", ""),
    "cover_url": fi.get("coverUrl", ""),
    "stats": stats,
    "download_headers": {"Referer": "https://channels.weixin.qq.com/"},
}

if mode == "json":
    print(json.dumps(out, ensure_ascii=False))
else:
    if not out["ok"]:
        print("error: resolved but no video/images found (deleted or non-media post?)")
        sys.exit(1)
    print(f"resolved by : {by}")
    print(f"author      : {out['author']}")
    print(f"type        : {media_type}" + (f" ({len(image_urls)} images)" if media_type == "images" else ""))
    print(f"description : {out['description'][:120].replace(chr(10), ' / ')}")
    if media_type == "video":
        print(f"video (h264): {out['video_url'][:100]}...")
        if h265: print(f"video (h265): {out['video_h265_url'][:100]}...")
    for i, u in enumerate(image_urls, 1):
        print(f"image {i:>2}    : {u[:100]}")
    print("note        : direct URLs are time-limited (token); download soon")
sys.exit(0 if out["ok"] else 1)
PY
}

# --- run layers --------------------------------------------------------------

RESOLVED_BY=""
RAW_JSON=""

try_layer() {  # $1 resolver fn
    local out; out=$("$1" 2>/dev/null) || return 1
    [[ -n "$out" ]] || return 1
    RAW_JSON="${out%$'\n'*}"
    RESOLVED_BY="${out##*$'\n'}"
    # validate: canonical emission must succeed
    if emit_canonical "$RAW_JSON" "$RESOLVED_BY" json >/dev/null 2>&1; then
        return 0
    fi
    RAW_JSON=""; RESOLVED_BY=""
    return 1
}

attempted=""
if [[ -n "$YB_COOKIE" ]]; then
    attempted="yuanbao"
    try_layer resolve_yuanbao && done_ok=1 || attempted="yuanbao(failed)"
fi

if [[ -z "$RESOLVED_BY" ]]; then
    for fn in resolve_site_allconning resolve_site_mtotech resolve_site_solua resolve_site_litao; do
        try_layer "$fn" && break
    done
fi

if [[ -z "$RESOLVED_BY" ]]; then
    cat >&2 <<EOF
error: all resolution layers failed
  - yuanbao    : ${YB_COOKIE:+cookie set but failed}${YB_COOKIE:-not configured — run: sph-resolve.sh --set-cookie}
  - public sites: all unreachable or returned no media
next steps:
  - configure Layer 1: sph-resolve.sh --set-cookie   (guided: references/wechat-channels.md)
  - check site health: sph-resolve.sh --check
  - local capture fallback: references/wechat-channels.md § local-capture
EOF
    exit 1
fi

emit_canonical "$RAW_JSON" "$RESOLVED_BY" "$MODE"
