#!/usr/bin/env bash
# Download video from URL.
# Usage: dl-video.sh URL [QUALITY] [OUTPUT_DIR]
#   QUALITY: best (default), 2160, 1080, 720, 480, h265 (Channels only)
#   OUTPUT_DIR: directory to save to (default: current dir)
#   Output: MP4 (H.264/H.265 + AAC) for maximum compatibility
#   Auto-detects Chinese platforms and applies the right strategy:
#     bilibili / douyin / xiaohongshu  -> yt-dlp + browser-cookie probe
#     weixin Channels (视频号)          -> sph-resolve.sh engine + aria2c
#       (video posts -> mp4; image posts -> image folder)
set -e

URL="${1:?Usage: dl-video.sh URL [QUALITY] [OUTPUT_DIR]}"
QUALITY="${2:-best}"
OUTPUT_DIR="${3:-.}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

mkdir -p "$OUTPUT_DIR"

# Prefer H.264/H.265 video + AAC audio for universal playback (QuickTime, iOS, browsers).
# AV1/VP9/Opus won't play on macOS QuickTime. Fallback to any format if preferred codecs unavailable.
case "$QUALITY" in
    best)   FORMAT="bv[vcodec~='^(avc|hev)'][ext=mp4]+ba[acodec~='^(mp4a)'][ext=m4a]/bv[ext=mp4]+ba[ext=m4a]/bv*+ba/b" ;;
    2160)   FORMAT="bv[height<=2160][vcodec~='^(avc|hev)'][ext=mp4]+ba[acodec~='^(mp4a)'][ext=m4a]/bv[height<=2160][ext=mp4]+ba[ext=m4a]/bv[height<=2160]+ba/b" ;;
    1080)   FORMAT="bv[height<=1080][vcodec~='^(avc|hev)'][ext=mp4]+ba[acodec~='^(mp4a)'][ext=m4a]/bv[height<=1080][ext=mp4]+ba[ext=m4a]/bv[height<=1080]+ba/b" ;;
    720)    FORMAT="bv[height<=720][vcodec~='^(avc|hev)'][ext=mp4]+ba[acodec~='^(mp4a)'][ext=m4a]/bv[height<=720][ext=mp4]+ba[ext=m4a]/bv[height<=720]+ba/b" ;;
    480)    FORMAT="bv[height<=480][vcodec~='^(avc|hev)'][ext=mp4]+ba[acodec~='^(mp4a)'][ext=m4a]/bv[height<=480][ext=mp4]+ba[ext=m4a]/bv[height<=480]+ba/b" ;;
    *)      FORMAT="$QUALITY" ;;  # allow raw format string
esac

UA="Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"

# Multi-connection download: aria2c when available, curl fallback otherwise.
dl_file() {  # $1 url  $2 out  [3 concurrency]
    local url="$1" out="$2" conc="${3:-16}"
    if command -v aria2c &>/dev/null; then
        aria2c -x"$conc" -s"$conc" -k1M \
            --header="Referer: https://channels.weixin.qq.com/" \
            --user-agent="$UA" \
            --out="$out" "$url"
    else
        curl -L --retry 3 --retry-delay 2 -C - \
            -H "Referer: https://channels.weixin.qq.com/" \
            -A "$UA" -o "$out" "$url"
    fi
}

# --- platform routing -------------------------------------------------------
# Strategy A (cookie probe + yt-dlp): bilibili / douyin / xiaohongshu
# Strategy B (resolve engine + direct URL): weixin Channels
PLATFORM="generic"
case "$URL" in
    *bilibili.com*|*b23.tv*)                    PLATFORM="bilibili" ;;
    *douyin.com*)                               PLATFORM="douyin" ;;
    *xiaohongshu.com*|*xhslink.com*)            PLATFORM="xhs" ;;
    *weixin.qq.com/sph/*|*channels.weixin.qq.com*|*finder-preview*|*wxdr.cn*)
                                                PLATFORM="sph" ;;
esac

# Shared cookie probe: these sites reject cookie-less requests (bilibili 412,
# douyin "Fresh cookies needed"). Reading the local browser cookie jar is enough
# for bilibili/douyin — no login required, just visit the site once.
probe_browser_cookies() {
    local browser
    for browser in chrome firefox edge; do
        if yt-dlp --cookies-from-browser "$browser" -j "$URL" &>/dev/null; then
            COOKIE_ARGS=(--cookies-from-browser "$browser")
            return 0
        fi
    done
    return 1
}

COOKIE_ARGS=()
case "$PLATFORM" in
    bilibili)
        if ! probe_browser_cookies; then
            echo "⚠ Bilibili requires cookies. Open https://www.bilibili.com once in Chrome/Firefox (no login needed)," >&2
            echo "  or export cookies: yt-dlp --cookies cookies.txt ..." >&2
        fi
        ;;
    douyin)
        if ! probe_browser_cookies; then
            echo "⚠ Douyin needs fresh cookies. Open https://www.douyin.com once in Chrome/Firefox (no login needed), then retry." >&2
            exit 1
        fi
        ;;
    xhs)
        probe_browser_cookies || echo "⚠ Xiaohongshu often needs cookies; trying without. Visit https://www.xiaohongshu.com in your browser if this fails." >&2
        ;;
    sph)
        # WeChat Channels: yt-dlp has no extractor. Resolve via engine, then aria2c.
        RESOLVE_JSON="$("$SCRIPT_DIR/sph-resolve.sh" "$URL" --json)" || exit 1
        export RESOLVE_JSON

        # Build a safe filename: [author] first-line-of-description (first 40 chars)
        BASENAME="$(python3 - <<'PY'
import json, os, re
d = json.loads(os.environ["RESOLVE_JSON"])
author = re.sub(r'[/\\:*?"<>|\r\n]', '', d.get("author", "")).strip()[:20]
desc = (d.get("description") or "").strip().splitlines()
desc = re.sub(r'[/\\:*?"<>|\r\n]', '', desc[0]).strip()[:40] if desc else "video"
name = f"[{author}] {desc}" if author else desc
print(name or "channels_video")
PY
)"
        # Persist metadata sidecar for later reference (title/stats/urls)
        printf '%s' "$RESOLVE_JSON" > "$OUTPUT_DIR/$BASENAME.meta.json"

        if [[ "$QUALITY" == "h265" ]]; then
            VIDEO_URL="$(python3 -c 'import json,os; print(json.loads(os.environ["RESOLVE_JSON"]).get("video_h265_url") or "")')"
        else
            VIDEO_URL="$(python3 -c 'import json,os; print(json.loads(os.environ["RESOLVE_JSON"]).get("video_url") or "")')"
        fi

        if [[ -n "$VIDEO_URL" ]]; then
            echo "→ downloading (via $(python3 -c 'import json,os; print(json.loads(os.environ["RESOLVE_JSON"])["resolved_by"])')): $BASENAME.mp4"
            dl_file "$VIDEO_URL" "$OUTPUT_DIR/$BASENAME.mp4" 16
            exit 0
        fi

        # Image post (图集): download all images into a folder.
        IMG_DIR="$OUTPUT_DIR/$BASENAME"
        IMG_URLS=()
        while IFS= read -r u; do IMG_URLS+=("$u"); done < <(python3 -c 'import json,os; [print(u) for u in json.loads(os.environ["RESOLVE_JSON"]).get("image_urls") or []]')
        if [[ ${#IMG_URLS[@]} -gt 0 ]]; then
            mkdir -p "$IMG_DIR"
            echo "→ image post: ${#IMG_URLS[@]} images -> $IMG_DIR"
            i=1
            for u in "${IMG_URLS[@]}"; do
                dl_file "$u" "$IMG_DIR/$(printf '%02d' "$i").jpg" 8
                i=$((i+1))
            done
            exit 0
        fi

        echo "error: resolved post contains no video or images (deleted / non-media?)" >&2
        exit 1
        ;;
esac

yt-dlp \
    -f "$FORMAT" \
    --merge-output-format mp4 \
    --embed-metadata \
    --embed-thumbnail \
    --write-subs --sub-langs "en,zh" \
    "${COOKIE_ARGS[@]}" \
    -o "$OUTPUT_DIR/%(title)s.%(ext)s" \
    "$URL"
