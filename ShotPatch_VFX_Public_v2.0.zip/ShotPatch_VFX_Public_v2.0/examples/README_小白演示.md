# 例子怎么用？

**本文件夹自带两段已经真实编码出来的视频**（`samples/演示成品_弓上补箭.mp4` 和 `samples/演示成品_动态火焰.mp4`）。它们是本软件本地图层渲染功能的可播放证据，使用的是原创简笔画，并非真人或写实房屋烟火。

## 自己重新跑一次
在安装好Python依赖和FFmpeg后双击根目录 `DEMO_一键试看.bat`，会从 `demo_unedited.mp4` 和 `../assets/demo_arrow.png` 渲染出 `demo_edited.mp4`。再双击根目录 `DEMO2_动态图层.bat`，会从示意PNG序列和mask渲染出 `demo_v2_result.mp4`。

两个 `*.json` 是可编辑任务：`demo_overlay.json` 使用v1兼容模式；`demo_v2_overlay.json` 展示v2的连续动画、灰度遮挡、light_mask和受控发光。输入原片不会被覆盖。若输出文件已经存在，工具拒绝覆盖；重新试验需手动改输出文件名，而不是删除输入素材。

`preview/` 是实际生成的抽帧，供观看原片和结果的局部变化。请不要把这些演示图或演示视频当成逼真烟火或真人跟踪的实拍测试。
