# 手工透明 PNG 合成示例

若你有一个箭矢透明 PNG，原片为 `archer.mp4`，创建 `overlay_job.json`：

```json
{
  "schema": "shotpatch.overlay.v1",
  "video": "archer.mp4",
  "png": "arrow.png",
  "output": "arrow_composited.mp4",
  "visible_from": 0.4,
  "visible_until": 2.5,
  "keyframes": [
    {"t": 0.4, "x": 0.46, "y": 0.57, "width": 0.25, "degrees": 10, "opacity": 1},
    {"t": 1.8, "x": 0.48, "y": 0.54, "width": 0.25, "degrees": 6, "opacity": 1},
    {"t": 2.5, "x": 0.60, "y": 0.48, "width": 0.22, "degrees": 6, "opacity": 0}
  ]
}
```

运行 `python scripts/shotpatch.py render --job overlay_job.json`。这只是平面关键帧合成：不自动识别演员、不会修真实遮挡、不能声称是完整的逼真射箭动画。镜头坐标必须由你或 Agent 根据源片测得。
