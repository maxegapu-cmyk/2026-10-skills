@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo ShotPatch VFX 2.0 | 首次安装
where py >nul 2>nul
if errorlevel 1 (
 echo 没有找到Python启动器py。请从python.org安装Python 3.11或3.12 64位正式版。
 echo 安装时勾选 Add Python to PATH。
 pause
 exit /b 1
)
py -3 -c "import sys; assert sys.version_info >= (3,10)" >nul 2>nul
if errorlevel 1 (
 echo Python版本过旧，请升级到3.11或3.12。
 pause
 exit /b 1
)
if not exist ".venv\Scripts\python.exe" (
 py -3 -m venv .venv
 if errorlevel 1 (
  echo 无法创建Python独立环境，请确认正式版Python包含venv。
  pause
  exit /b 1
 )
)
.venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 (
 echo Python依赖安装失败，请确认互联网连接和pip。
 pause
 exit /b 1
)
where ffmpeg >nul 2>nul
if errorlevel 1 (
 echo [缺少FFmpeg] 需另行安装含ffprobe的FFmpeg并放到PATH。
 echo 查看 README_小白入门.md 或执行 winget search ffmpeg 查找官方分发渠道。
 pause
 exit /b 1
)
where ffprobe >nul 2>nul
if errorlevel 1 (
 echo ffmpeg可用但ffprobe不可用，请安装带完整ffprobe的发行版本。
 pause
 exit /b 1
)
.venv\Scripts\python.exe scripts\shotpatch.py doctor
if errorlevel 1 (
 echo 环境检查失败，请查看上面的提示。
) else (
 echo 安装完成。现在双击 START_双击使用.bat。
)
pause
