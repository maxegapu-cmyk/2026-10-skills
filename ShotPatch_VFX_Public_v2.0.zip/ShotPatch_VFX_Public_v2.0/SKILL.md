---
name: shotpatch-vfx
version: 2.0.0
description: 真实视频局部特效增补与视频原片保护工作流。对已有实拍添加火焰、烟雾、弓箭、手持道具、魔法光效等；先离线体检、进行场景物理/模型路由，必要时跟踪和遮挡合成，结果进行ROI审计与人工复核。云端视频AI默认仅提供可直接操作的模型卡，不假装已接入付费账号。
---

# ShotPatch VFX v2.0 | 实拍增补 / 公开独立版

## 调用条件
用户上传已有视频并要求“别改人物/场景，只给房子加火、给弓补箭、给手补道具或局部添加特效”，使用该 Skill。**核心对象是源片及其真实时间线**，不是从提示词重新生成电影。

## 能力真相（绝不含糊）
- **已经随包实装且测试**：视频预检与抽帧；采样明暗/色调/镜头运动/剪切候选；任务/平台约束路由；Google、Seedance、VACE、本地流程操作卡；简易纹理目标平移跟踪；多图层透明PNG及连续PNG序列、关键帧位置/旋转/缩放、可选前景遮挡灰度mask、限制性局部亮化；音轨处理；ROI变更率审计；带人工锚点的箭矢时序二维约束检查；VFR/旋转素材标准化为新文件；GUI及命令行。
- **没有打通**：Seedance 2.0/2.5、Google Flow、Google Omni Flash API、VACE、SAM 2、复杂3D重建、火焰物理仿真、自动手指遮挡与精确子像素跟踪、真实光流/风场/强反射计算。任何付费上传都必须明确获用户授权并用其官方实际平台/工具执行。
- **禁止宣称**：`模型有官方功能` ⇒ `用户账号开放` ⇒ `本Skill自动调用成功`；不能把提示词/动画示例当作真实电影级成片；不能把统计亮度或二维运动估计宣称为已经掌握拍摄光源、真实3D空间与物理。

## 最重要的状态机
`INPUT_CHECK` → `SCENE_DIAGNOSED` → `ROUTE_SELECTED` → `PREVIEW_PLAN` → `OUTPUT_CREATED` → `MEDIA_AUDIT` → `VISUAL_GATE` → `DELIVER/REVISION_REQUIRED`。
仅生成提示词停在 `PREVIEW_PLAN`，没有完成最终视频；只过媒体/ROI检查停在 `MEDIA_AUDIT`，不能直接进入电影级合格状态。

## 执行协议（对于Agent是必须执行而非仅建议）
1. 原片不可覆盖：仅使用只读输入；生成新项目文件夹，记录路径、时长、fps、尺寸、是否HDR/VFR、时码/音频、源SHA256。不得擅自上传。
2. 自动体检（`prepare`内置，亦可 `analyze`）：亮度、对比、运动、疑似剪切的**启发式**采样，制作 `场景体检`，用户说“电影感”时先服从源片真实材质和机位，不擅自套滤镜。
3. 建立**编辑四锚点**：空间锚点（屋顶/手掌/弓弦）、时间锚点（开始/释放/结束）、前景/背景遮挡、光影/音画约束。缺少真实动作时先判定 `NEEDS_ACTION_REPAIR`，不冒称只贴箭即可。
4. 评风险与路由：原片严格保护优先本地遮罩跟踪合成；无素材时可以让用户用确已开通的视频编辑服务制作候选/特效，再回片合成。光、烟与交互复杂时不必死守一次自动生成；见 `docs/02_模型适配实战.md` 和 `docs/04_物理与遮挡约束.md`。
5. 仅做**有真实能力的操作**。已有PNG/序列/遮挡mask时调用 `render`。本包自动跟踪是简易模板平移：若失锁就停；真实弓弦/手指/深度应改专业追踪和手动复核。无模型权限则输出 `各平台操作卡/`，明确说明“尚未生成视频”。
6. 交付前双轨审计：①`review` 媒体参数 + `audit` 未授权修改区域差异；②逐帧视觉与物理人工审片，尤其射箭搭箭→松弦→箭离弦、房屋火焰→烟流→火光→树木遮挡。见 `docs/03_质量门与验收.md`。
7. 若失败：记录时间码、区域、具体缺陷、修法、重试次数，**同因失败两次即停止整片抽卡**，优先修遮挡/跟踪/原片动作/素材。最后报告未证实项。

## 新手默认模式
Windows首次双击 `INSTALL_安装依赖.bat`，再双击 `START_双击使用.bat` 打开图形界面；导入真实视频，选“房屋着火/射箭补箭/其他道具”，一句话描述目标，按“开始”。得到抽帧、场景体检、路由决策、按平台拆分的操作卡。接下来有模型账号走手工生成；已有真实带alpha素材走本地合成。**默认先预览/不调用付费接口**。

## CLI示例
```bash
python scripts/shotpatch.py doctor
python scripts/shotpatch.py prepare --video "input.mp4" --task arrow --change "1.4秒开始拉弓，2.3秒松弦，补充唯一一支箭" --out "./project_arrow"
python scripts/shotpatch.py analyze --video "input.mp4" --out "./scene.json"
python scripts/shotpatch.py route --task arrow --fidelity strict --access seedance25 --video "input.mp4" --out "./route.json"
python scripts/shotpatch.py normalize --video "iphone.mov" --fps 24 --out "iphone_CFR.mp4"
python scripts/shotpatch.py track --video "CFR.mp4" --box 20,30,50,40 --out "track.json"
python scripts/shotpatch.py render --job "examples/demo_v2_overlay.json" --output "examples/your_copy.mp4"
python scripts/shotpatch.py audit --source "input.mp4" --result "modified.mp4" --allowed-roi 0.25,0.15,0.6,0.7 --out "audit.json"
python scripts/shotpatch.py check-arrow --job "examples/arrow_annotations.json" --out "arrow_check.json"
```

## 八种必须避免的误判
- 画面亮度偏橘 ≠ 已知太阳位置、火光方向；必须观察源片光源与材质。
- 画面有移动 ≠ 知道是摄像机在动还是物体在动；跟踪需实拍锚点。
- 指令写“固定不变” ≠ 真正冻结未编辑区域；必须回片`audit`。
- 透明PNG粘在手上 ≠ 真正贴合手指与弓弦；需要前景遮挡和事件帧。
- 出现烟雾 ≠ 符合风速；优先匹配原片相邻树叶/旗帜/雨雪方向（没有线索时以未知处理）。
- 火焰合成有光晕 ≠ 灯光物理正确；有限局部亮化只是视觉近似。
- ROI差异很小 ≠ 箭矢真的飞出去；还要审接触、速度和身份。
- 模型名称列进Skill ≠ 用户拥有平台能力；需按官网/账号实测。

## 外发许可与隐私
本包提供独立编写的执行规则与测试工具，不附带模型权重、账户凭据、用户原始素材或第三方仓库源代码。第三方技术依赖的必要来源与版权许可不能删除（见 `docs/08_开源许可与外发边界.md`）。实拍火灾/爆炸等合成视频不可冒充新闻事故证据；明确使用合成效果。
