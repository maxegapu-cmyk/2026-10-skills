#!/usr/bin/env python3
"""Verify package file hashes. Local only; not a security signature."""
import hashlib,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
man=ROOT/'release'/'manifest_sha256.json'
if not man.is_file():raise SystemExit('缺少release/manifest_sha256.json')
obj=json.loads(man.read_text(encoding='utf-8'));errors=[]
for name,want in obj['files'].items():
    path=(ROOT/name).resolve()
    if ROOT not in path.parents or not path.is_file():errors.append(name+':不存在或越界');continue
    got=hashlib.sha256(path.read_bytes()).hexdigest()
    if got!=want:errors.append(name+':SHA256不符')
print(f'清单文件数量：{len(obj["files"])}；校验结果：'+('成功' if not errors else '失败'))
for e in errors:print('异常：'+e)
if errors:sys.exit(1)
