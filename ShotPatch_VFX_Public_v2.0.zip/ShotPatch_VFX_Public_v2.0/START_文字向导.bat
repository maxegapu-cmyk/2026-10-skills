@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
 echo 先双击 INSTALL_安装依赖.bat。
 pause
 exit /b 1
)
.venv\Scripts\python.exe scripts\shotpatch.py wizard
pause
