"""Provider-specific offline instruction packages. No cloud requests."""
from __future__ import annotations
from pathlib import Path
import json

PLATFORMS={
 'seedance25':{'title':'Seedance 2.5（ModelArk/API 或已支持 Edit 的平台）',
  'video_edit':'yes_with_access','limit':'官方编辑参考视频单段4~30秒；ratio=adaptive；duration=-1；omni_reference_task_type=edit（仅2.5）',
  'steps':['确认账号拥有2.5实际编辑权限，不等于默认在每个UI中都开放。','使用已有视频编辑 Edit，不要选文生视频。','提交原视频作为 reference_video，视频长度4–30秒；先确认已有镜头动作连续。',
           '若是ModelArk API：固定 omni_reference_task_type=edit、ratio=adaptive、duration=-1；遵守官方参数结构，不直接粘贴成旧版参数。',
           '把本包针对该镜头的局部修改指令粘贴进去；如界面支持涂鸦或编辑区域再标注。','生成低成本预览，下载后逐帧核对。'],
  'risk':'即便指定修改区域也不保证背景像素不变；生成人物或建筑改变时转为原片合成。',
  'reference':'https://docs.byteplus.com/zh-CN/docs/modelark/create-video-generation-task-api'},
 'seedance20':{'title':'Seedance 2.0（有权限的视频参考路线）',
  'video_edit':'depends_on_platform','limit':'各平台开放的编辑能力和输入方式不同；不要套用2.5专有 omni_reference_task_type。',
  'steps':['先在使用平台核实确有“编辑已有视频/上传参考视频”入口。','有编辑入口再上传已有视频；没有则只拿它制作烟火等独立特效素材。',
           '贴入镜头要求并保留原动作锚点。','比对原片和生成结果，人物身份和建筑不能变化。'],
  'risk':'不是一个可跨平台保证存在的统一编辑API，发布前复验UI或API合同。',
  'reference':'https://docs.byteplus.com/en/docs/ModelArk/create-video-generation-task-api'},
 'google_flow':{'title':'Google Flow（网页视频编辑）',
  'video_edit':'yes_with_access','limit':'官方：文件最长60s/1GB，超过30s需剪到30s；一次实际选定编辑片段≤10s；地区权限限制',
  'steps':['进入 Flow 项目，选择 Video / Omni Flash（以当前实际页面为准）。','导入原视频；超过30秒先剪成30秒以内。',
           '在裁剪窗口选中不超过10秒的镜头片段；优先确保射箭释放前后都保留。','粘贴目标物体/动作/保留项，附参考图（功能可用时）。',
           '提交编辑；若漂移、变脸，停止整镜头盲抽卡，改为追踪合成。'],
  'risk':'网页存在地区及账号限制；官方支持可不等于该用户账号开放。',
  'reference':'https://support.google.com/flow/answer/16935718?hl=en'},
 'google_omni_api':{'title':'Gemini Omni Flash（官方 Interactions API）',
  'video_edit':'yes_with_access','limit':'官方提供上传实拍 Files API + Interactions编辑例子；地区/账号/配额有限；本包未实现SDK调用',
  'steps':['拥有可用 Gemini API 权限后，在官方文档的 Interactions API 示例中上传源片（Files API）。',
           '等待文件处理完成；把带视频URI的请求和编辑指令一起传给 gemini-omni-1.1-flash。',
           '下载结果，不能把原始素材上传过程当成“本Skill已经自动执行”。',
           '再次编辑可使用 previous_interaction_id，但会产生新的生成结果。'],
  'risk':'需注意资费和上传隐私；具体可用地区随时变化；本工具默认离线，不读取API密钥。',
  'reference':'https://ai.google.dev/gemini-api/docs/omni'},
 'google_veo':{'title':'Google Veo 3.1（生成素材/首末帧/仅Veo视频延展）',
  'video_edit':'not_generic_source_edit','limit':'官方视频延展只支持之前由Veo生成的视频；不能把任意实拍片直接作为扩展输入',
  'steps':['若只需要逼真火苗/烟雾素材，可用文生/图生视频创作短素材。',
           '不要将 Veo 3.1 的 video extension 当作上传任意实拍改箭/改火的功能。',
           '将生成素材通过授权和遮罩图层合成回实拍源片。'],
  'risk':'4/6/8秒能力、24fps及分辨率依套餐版本而变；制作特效素材后需完成透明分离。',
  'reference':'https://ai.google.dev/gemini-api/docs/veo'},
 'vace':{'title':'VACE（可选本地遮罩视频编辑）',
  'video_edit':'yes_if_deployed','limit':'模型权重、显存/视频长度/采样分辨率以及权重许可证须单独核验',
  'steps':['另行安装 VACE 与选定模型权重（不含在本包）。','按模型要求制作逐帧掩码：需要编辑的区域白色，保护的区域黑色。',
           '裁切视频并确认模型输入帧数/尺寸要求；进入已有视频+遮罩条件的编辑流程。',
           '输出后核对未编辑区域，再用原片合成修复明显漂移。'],
  'risk':'本包没有内置推理管线，不能直接用一个JSON假装可以让VACE自动生成。',
  'reference':'https://github.com/ali-vilab/VACE'},
 'local':{'title':'本地精确合成（真正可执行）','video_edit':'implemented',
  'limit':'需要有真实带Alpha PNG或动画序列；复杂手指遮挡须提供前景遮挡mask；2D跟踪不能保证3D透视',
  'steps':['准备透明 PNG 或逐帧 PNG 序列。','视频运动不明显可手写关键帧；若只有平移、道具纹理明显可试用 track。',
           '遮挡准备同分辨率黑白图；白色代表原片前景在上方，不应被新物盖住。',
           '火焰发光必须提供允许修改的light_mask。','render后运行audit：只在允许区域发生内容变化，人工检查接触/景深/运动模糊。'],
  'risk':'当前支持位置/旋转/缩放/alpha/遮挡/有限照明，非完整3D渲染器。',
  'reference':'docs/06_本地合成操作.md'},
}

def handoff(task,change,keep,scene,out):
    out.mkdir(parents=True,exist_ok=True)
    risk=scene.get('visual_estimates',{})
    extra={'fire':'火焰锚定建筑，烟跟风向和空间透视走；亮度随距离和遮挡衰减；有火光时明确light_mask，不能凭空整画重染。',
           'arrow':'仅一支箭，拉弓前尾部与弓弦搭箭点接触；松弦帧分离；飞出方向与瞄准一致；手指遮挡正确。',
           'object':'物件需要明确原片接触位置、前景遮挡、透视、景深和阴影。'}[task]
    prompt=('你正在编辑用户上传的【真实源视频】，不是重新拍摄/重造一个镜头。\n'
       f'唯一需要修改：{change or extra}\n'
       f'真实约束：{extra}\n'
       f'保留范围：{keep or "镜头运动、人物五官/体型/服装、建筑几何、原音轨、其余背景、源时长"}\n'
       f'环境体检（仅统计性估计）：{risk.get("ambience_hint","未分析")}，亮度{risk.get("median_luma_0_255","? ")} /255。'
       '请让插入物体的曝光、色温、景深、颗粒、快门模糊和光照方向与原片匹配，不要用机械统一电影滤镜。\n'
       '失败条件：浮空、穿模、箭矢重复、时序跳变、建筑改变、脸/手畸形、背景重绘、风格瞬变。'
       '如生成编辑不能可靠完成，请保留原片并输出独立特效素材以供后期合成。')
    for slug,profile in PLATFORMS.items():
        txt=f'# {profile["title"]}\n\n能力状态：{profile["video_edit"]}（与本包是否自动连接无关）\n\n限制：{profile["limit"]}\n\n'
        txt+='## 小白具体步骤\n'+''.join(f'{i}. {s}\n' for i,s in enumerate(profile['steps'],1))
        txt+='\n## 复制到此平台的具体指令\n\n'+prompt+'\n\n## 风险\n'+profile['risk']+'\n\n资料：'+profile['reference']+'\n'
        (out/(slug+'.md')).write_text(txt,encoding='utf-8')
    (out/'平台能力清单.json').write_text(json.dumps(PLATFORMS,ensure_ascii=False,indent=2),encoding='utf-8')
