#!/usr/bin/env python3
"""ShotPatch VFX public helper. Original implementation; no model calls or uploads."""
from __future__ import annotations
import argparse
import datetime as dt
import hashlib
import json
import math
import shutil
import subprocess
import sys
from pathlib import Path

VERSION = '2.0.0'


def err(message: str):
    raise SystemExit('错误：' + message)


def run_json(cmd):
    p = subprocess.run(cmd, capture_output=True, text=True, encoding='utf-8', errors='replace')
    if p.returncode != 0:
        err('命令执行失败: ' + ' '.join(map(str, cmd[:4])) + '\n' + p.stderr[-700:])
    try:
        return json.loads(p.stdout)
    except json.JSONDecodeError:
        err('工具未返回有效 JSON')


def verify_bin(name):
    if not shutil.which(name):
        err(f'找不到 {name}，请先安装并将其加入 PATH。')


def ratio(value):
    try:
        if '/' in str(value):
            a, b = map(float, value.split('/', 1))
            return a / b if b else 0
        return float(value)
    except (ValueError, TypeError):
        return 0


def inspect_video(path: Path):
    verify_bin('ffprobe')
    if not path.is_file():
        err(f'视频文件不存在：{path}')
    meta = run_json(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(path)])
    v = next((x for x in meta.get('streams',[]) if x.get('codec_type') == 'video'), None)
    if not v:
        err('输入文件没有视频轨道')
    a = any(x.get('codec_type') == 'audio' for x in meta.get('streams',[]))
    r, avg = ratio(v.get('r_frame_rate')), ratio(v.get('avg_frame_rate'))
    fps = avg or r
    duration = float(meta.get('format',{}).get('duration') or v.get('duration') or 0)
    w, h = int(v.get('width') or 0), int(v.get('height') or 0)
    if not (w and h and 0 < fps <= 240 and duration > 0):
        err('无法读取有效视频信息。请先将视频转为常规 MP4。')
    rotation = 0
    for d in v.get('side_data_list', []):
        if 'rotation' in d:
            rotation = int(d['rotation'])
    return {
        'path': str(path.resolve()), 'name': path.name,
        'width': w, 'height': h, 'fps': round(fps,4),
        'duration': round(duration,3), 'video_codec': v.get('codec_name'),
        'audio': a, 'rotation_degrees': rotation,
        'vfr_warning': bool(r and avg and abs(r - avg) / max(r, avg) > .02),
        'format': meta.get('format',{}).get('format_name',''),
        'pixel_fmt':v.get('pix_fmt'),'color_transfer':v.get('color_transfer'),
        'color_space':v.get('color_space'),'color_primaries':v.get('color_primaries'),
        'sample_aspect_ratio':v.get('sample_aspect_ratio'),
        'size_bytes': path.stat().st_size,
    }


def readcv():
    try:
        import cv2
        import numpy as np
        return cv2, np
    except ImportError:
        err('缺少 OpenCV / numpy：请运行 python -m pip install -r requirements.txt')


def readpil():
    try:
        from PIL import Image, ImageDraw, ImageFont
        return Image, ImageDraw, ImageFont
    except ImportError:
        err('缺少 Pillow：请运行 python -m pip install -r requirements.txt')


def contact_sheet(video, info, target: Path):
    cv2, np = readcv()
    Image, ImageDraw, ImageFont = readpil()
    cap = cv2.VideoCapture(str(video))
    if not cap.isOpened():
        err('OpenCV 无法读取视频。')
    n = 8
    cw, ch = 360, round(360 * info['height'] / info['width'])
    ch = min(ch, 640)
    sheet = Image.new('RGB', (cw*4, (ch+36)*2), (25,25,28))
    draw = ImageDraw.Draw(sheet)
    count = 0
    for i in range(n):
        t = (i + .3) / n * info['duration']
        cap.set(cv2.CAP_PROP_POS_MSEC, t*1000)
        ok, fr = cap.read()
        if not ok:
            continue
        pil = Image.fromarray(cv2.cvtColor(fr, cv2.COLOR_BGR2RGB))
        pil.thumbnail((cw, ch))
        x = (i % 4) * cw
        y = (i // 4) * (ch+36)
        sheet.paste(pil, (x + (cw-pil.width)//2,y))
        draw.text((x+10,y+ch+9),f'{t:.2f}s',fill='white')
        count += 1
    cap.release()
    if count == 0:
        err('抽帧失败：未生成预览图。')
    target.parent.mkdir(parents=True, exist_ok=True)
    sheet.save(target)
    return count


def make_prompt(task, change, keep, info, fidelity):
    base = {
        'fire': ('在原始房屋的指定屋顶或窗口增加真实火焰、烟雾、余烬与有边界的火光反射。'
                 '燃烧位置必须固定于建筑表面，跟随原相机透视运动；树木、墙体等遮挡关系正确。'
                 '不要擅自改变建筑结构、天空、其他房屋和人。',
                 'Add convincing fire, smoke and limited practical light to the specified roof or window in the SOURCE VIDEO. '
                 'Anchor flames in 3D to the actual building surfaces; obey foreground occlusion, camera motion, smoke direction and shot continuity. '
                 'Preserve the house architecture, people, landscape and original camera move.'),
        'arrow': ('仅为原画面持弓演员添加一支真实箭矢：箭尾与弓弦搭箭点对齐，箭身沿正确瞄准方向。'
                  '箭矢在拉弓期间跟随弓与手；松弦瞬间准确分离并飞出；遵守手指前后遮挡。'
                  '绝不改变演员面部、手指数量、服装、弓的形状和原始动作。'
                  '若实拍动作不足以支持可信射箭，报告需要动作修复，不要凭空重写整段。',
                  'Insert exactly ONE photoreal arrow onto the bow held by the actor in the SOURCE VIDEO. '
                  'Align the nock to the bowstring and the shaft to the aiming direction. Track arrow relative to bow and fingers; '
                  'release it at the actual string-release moment with appropriate motion blur. Correctly occlude with fingers. '
                  'Do not alter face, body anatomy, clothing, bow geometry or camera.'),
        'object': ('只在指定区域增加用户描述的物体，严格跟随接触点、透视、遮挡与镜头运动。'
                   '原场景、人物五官、衣服与背景尽量保持不变。',
                   'Insert only the requested object into the SOURCE VIDEO at the specified location; '
                   'track contact, perspective, occlusion and camera movement. Preserve original actors, faces and environment.'),
    }
    zh, en = base[task]
    extra = str(change).strip()
    keep = str(keep).strip()
    need = '优先保真：仅修改指定 ROI，优先合成原片；不要把“文字指令”误当成像素级锁定。' if fidelity == 'strict' else '允许有限局部重绘，但必须核对原片与结果的主体、镜头和连续性。'
    return (
        '# 编辑提示词与执行手册（自动生成，不会自动调用付费模型）\n\n'
        f'任务：{task}；视频：{info["name"]}；时长 {info["duration"]:.2f}s；尺寸 {info["width"]}×{info["height"]}。\n\n'
        '## 一、可直接用于编辑器的中文指令\n\n'
        f'编辑这个【原视频】。{zh} 用户追加要求：{extra or "无"}。必须保留：{keep or "除所需特效外的原人物、背景、相机、时间线与声音"}。{need}\n\n'
        '## 二、英文编辑指令（适合海外模型）\n\n'
        f'EDIT the uploaded source video. {en} Additional request: {extra or "none"}. Preserve: {keep or "all unmentioned content and source camera/audio"}. '
        'Do not add extra objects, change identity, change shot duration, or invent cuts. Treat these as goals, not guaranteed pixel locks.\n\n'
        '## 三、傻瓜式平台路径\n\n'
        'A. Seedance 2.5（首选生成式试片）：在你实际有权限的平台选择 Edit / 编辑已有视频；导入原视频、粘贴上述指令，若有草图功能先在关键帧标注箭矢/起火范围；先低清试片。' 
        '通过官方 ModelArk API 调用时需配置 edit 任务、reference_video，输入 4–30 秒、ratio=adaptive、duration=-1，且确认账户权限。不要将界面与 API 参数混用。\n\n'
        'B. Seedance 2.0：使用视频参考/重制能力试片，不能默认具备和 2.5 相同的严格 edit API；对箭矢特写优先避开纯重生成。\n\n'
        'C. Google Flow：进入项目→选择视频编辑支持的模型（当前官方指引为 Omni Flash）→上传视频→挑选 ≤10 秒部分→粘贴指令→导出视频。功能有地区和账户限制；此步骤不是 Veo 3.1 API 的视频直接编辑。\n\n'
        'D. VACE 开源：在部署好的 VACE 环境把原视频 + 逐帧遮罩作为 MV2V 输入，白色区域生成、黑色区域保留；模型可能缩放/截断，长视频需分段。此 Skill 不自动安装模型权重。\n\n'
        'E. 精准合成：若有透明 PNG 等真实素材，可复制到项目内，修改 overlay_job.json 的跟踪关键帧，然后运行 render。' 
        '如涉及手指遮挡、复杂三维透视、烟雾运动，请换专用跟踪/遮挡工具，不要假装单层 PNG 就足够。\n\n'
        '## 四、验收\n\n'
        '看原片与结果的同时间点：主体身份、构图、建筑、弓/手动作、遮挡、光照、箭矢唯一性、释放时刻、声音、帧率、镜头连续性。'
        '若一项关键错位，先定位时间段及故障类别，再只修改对应区域或关键帧；不要整片反复抽卡。\n'
    )


def make_job(video: Path, task: str, change: str, keep: str, fidelity: str, out: Path):
    info = inspect_video(video)
    out = out.resolve()
    out.mkdir(parents=True, exist_ok=False)
    # No copies of user's video; reference original by absolute path.
    warnings = []
    if not 4 <= info['duration'] <= 30:
        warnings.append('Seedance 2.5 ModelArk edit API：单段参考视频须 4–30 秒；需要裁剪/重组且不得破坏原动作。')
    if info['duration'] > 10:
        warnings.append('Google Flow 网页编辑：一次实际选中的编辑片段最多 10 秒，请定位最关键局部。')
    if info['vfr_warning']:
        warnings.append('疑似 VFR：精确逐帧合成前建议转成 CFR。')
    if info['rotation_degrees']:
        warnings.append('源视频存在旋转元数据：本地合成需要先规范化方向。')
    job = {
        'schema': 'shotpatch.job.v1', 'version': VERSION,
        'created_at': dt.datetime.now(dt.timezone.utc).isoformat(),
        'source': info, 'task': task, 'change': change, 'keep': keep, 'fidelity': fidelity,
        'model_exec': 'manual_only', 'upload_approved': False,
        'status': 'design_ready_not_rendered', 'preflight_warnings':warnings,
        'quality_gate': ['subject_identity','unrequested_regions','prop_tracking','occlusion',
                         'motion_timing','duration_and_audio'],
    }
    (out/'job.json').write_text(json.dumps(job,ensure_ascii=False,indent=2),encoding='utf-8')
    (out/'编辑指令.md').write_text(make_prompt(task,change,keep,info,fidelity),encoding='utf-8')
    (out/'overlay_job.example.json').write_text(json.dumps({
        'schema':'shotpatch.overlay.v1',
        'video': info['path'],
        'png': '请替换为真实透明PNG素材文件绝对路径',
        'output':'composited.mp4',
        'visible_from': 0.0,
        'visible_until':info['duration'],
        'keyframes':[
            {'t':0,'x':0.5,'y':0.5,'width':0.2,'degrees':0,'opacity':1},
            {'t':info['duration'],'x':0.5,'y':0.5,'width':0.2,'degrees':0,'opacity':1},
        ],
        'notes':'x,y为归一化素材中心位置；width为素材宽占原视频宽比例；角度正值表示逆时针旋转；按关键帧线性插值。'
    }, ensure_ascii=False, indent=2),encoding='utf-8')
    count = contact_sheet(video,info,out/'镜头抽帧.png')
    (out/'使用说明.txt').write_text('1. 打开 镜头抽帧.png 确认原片。\n2. 打开 编辑指令.md，选自己能用的平台上传原视频并粘贴提示词。\n3. 导出后对比检查。\n4. 有透明PNG时可按 overlay_job.example.json 操作本地合成。\n文件不自动上传外网，未自动生成特效视频。\n', encoding='utf-8')
    print(f'完成：已分析视频并生成 {count} 张抽帧、编辑提示词及合成模板。\n目录：{out}')
    for warning in warnings:
        print('适配提醒：'+warning)
    if info['vfr_warning']:
        print('提醒：疑似可变帧率视频（VFR），若追求逐帧精度先转换为固定帧率 CFR。')
    if info['rotation_degrees']:
        print('提醒：含移动设备旋转元数据，合成前检查方向。')
    return out


def wizard(args):
    print('\n=== ShotPatch VFX｜实拍局部编辑向导 ===\n不会自动上传视频或调用收费模型。')
    if not shutil.which('ffprobe'):
        err('先安装 FFmpeg（包含 ffprobe），见 README。')
    raw = input('把视频拖进窗口并回车，或输入视频完整路径：').strip().strip('"').strip("'")
    if not raw:
        err('没有输入视频')
    video = Path(raw).expanduser().resolve()
    print('选择：1 房屋火焰/烟雾；2 人物弓箭/道具；3 任意物体/特效')
    task = {'1':'fire','2':'arrow','3':'object'}.get(input('输入数字[默认3]：').strip() or '3','object')
    change = input('一句话说要改什么（可留空，使用标准模板）：').strip()
    keep = input('哪些内容绝对不希望被改动（回车=原片其他所有内容）：').strip()
    fidelity = 'strict' if (input('最重要的是保留实拍原片？[Y/n]：').strip().lower() not in ('n','no')) else 'flexible'
    parent = Path(args.outdir).expanduser().resolve() if args.outdir else video.parent
    stamp = dt.datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    out = parent / f'ShotPatch_{task}_{stamp}'
    make_job(video,task,change,keep,fidelity,out)
    input('\n按回车结束，查看新生成的目录...')


def validate_overlay(j):
    if j.get('schema') != 'shotpatch.overlay.v1':
        err('overlay_job.json schema 不正确')
    frames = j.get('keyframes')
    if not isinstance(frames,list) or not frames:
        err('keyframes 至少要有1个')
    last = -1
    for k in frames:
        try:
            t = float(k['t']); x = float(k['x']); y = float(k['y'])
            w = float(k['width']); d = float(k['degrees']); op = float(k['opacity'])
        except (KeyError,ValueError,TypeError) as ex:
            err('关键帧字段缺失或不是数字：'+str(ex))
        if not (math.isfinite(t) and t >= 0 and t > last and all(map(math.isfinite,[x,y,w,d,op]))
                and -2 <= x <= 3 and -2 <= y <= 3 and 0 < w <= 3 and 0 <= op <= 1):
            err('非法关键帧时间、位置、尺寸或透明度')
        last = t
    start, end = float(j.get('visible_from',0)),float(j.get('visible_until',float('inf')))
    if start < 0 or end <= start:
        err('visible_from / visible_until 错误')
    return frames,start,end


def interpolate(frames,t):
    if t <= frames[0]['t']:
        return frames[0]
    for i in range(1,len(frames)):
        if t <= frames[i]['t']:
            a,b = frames[i-1],frames[i]
            u = (t-a['t'])/(b['t']-a['t'])
            return {n: a[n]+(b[n]-a[n])*u for n in ('x','y','width','degrees','opacity')}
    return frames[-1]


def overlay_img(frame,asset,params,cv2,np):
    H,W = frame.shape[:2]
    ww = max(1,round(W * float(params['width'])))
    hh = max(1,round(ww * asset.shape[0] / asset.shape[1]))
    # prevent malicious or mistaken huge resizes from using excessive RAM
    if ww > W*3 or hh > H*6 or ww*hh > 30_000_000:
        err('素材缩放过大，调整 width 或素材宽高比')
    obj = cv2.resize(asset,(ww,hh),interpolation=cv2.INTER_AREA if ww < asset.shape[1] else cv2.INTER_LINEAR)
    angle = float(params['degrees'])
    if abs(angle) > .001:
        diag = math.ceil(math.hypot(ww,hh)) + 2
        if diag > 8000:
            err('旋转后的素材尺寸过大')
        rot = cv2.getRotationMatrix2D((ww/2,hh/2),angle,1)
        rot[0,2]+=(diag-ww)/2
        rot[1,2]+=(diag-hh)/2
        obj = cv2.warpAffine(obj,rot,(diag,diag),flags=cv2.INTER_LINEAR,borderMode=cv2.BORDER_CONSTANT,borderValue=(0,0,0,0))
    oh,ow = obj.shape[:2]
    cx, cy = int(round(float(params['x'])*W)), int(round(float(params['y'])*H))
    x0,y0 = cx - ow//2,cy - oh//2
    x1,y1 = max(0,x0),max(0,y0)
    x2,y2 = min(W,x0+ow),min(H,y0+oh)
    if x2<=x1 or y2<=y1:
        return frame
    sl = obj[y1-y0:y2-y0,x1-x0:x2-x0]
    alpha = (sl[:,:,3:4].astype(np.float32)/255.0)*float(params['opacity'])
    bg = frame[y1:y2,x1:x2].astype(np.float32)
    fg = sl[:,:,:3].astype(np.float32)
    frame[y1:y2,x1:x2] = np.clip(bg*(1-alpha)+fg*alpha,0,255).astype(np.uint8)
    return frame


def render(jobpath: Path, output: Path|None):
    cv2,np = readcv()
    verify_bin('ffmpeg')
    jobpath = jobpath.resolve()
    job = json.loads(jobpath.read_text(encoding='utf-8'))
    keys,start,end = validate_overlay(job)
    src = Path(job['video']); png = Path(job['png'])
    if not src.is_absolute(): src = (jobpath.parent/src).resolve()
    if not png.is_absolute(): png = (jobpath.parent/png).resolve()
    info = inspect_video(src)
    if info['rotation_degrees']:
        err('包含旋转元数据。先规范化输出为正向 MP4 再合成，避免转向错误。')
    if info['vfr_warning']:
        err('源视频疑似 VFR，可变帧率时禁止本路径合成；请先转 CFR 再处理。')
    out = output or Path(job.get('output','composited.mp4'))
    if not out.is_absolute(): out=(jobpath.parent/out).resolve()
    if out.resolve() == src.resolve():
        err('输出文件不能覆盖原视频')
    if out.exists():
        err('输出已存在，避免覆盖，请选择其他文件名：'+str(out))
    out.parent.mkdir(parents=True,exist_ok=True)
    if not png.is_file():
        err('没有找到透明 PNG 素材：'+str(png))
    asset = cv2.imread(str(png),cv2.IMREAD_UNCHANGED)
    if asset is None or len(asset.shape)!=3 or asset.shape[2]!=4:
        err('素材必须是真正的 RGBA 透明 PNG')
    cap=cv2.VideoCapture(str(src))
    if not cap.isOpened(): err('OpenCV 无法打开源视频')
    fps=info['fps']; W=info['width']; H=info['height']
    # cv2 returns decoded BGR, feed ffmpeg raw BGR preserving source audio via mux.
    command = ['ffmpeg','-hide_banner','-loglevel','error','-y',
               '-f','rawvideo','-pixel_format','bgr24','-video_size',f'{W}x{H}',
               '-framerate',f'{fps:.6f}','-i','pipe:0','-i',str(src),
               '-map','0:v:0','-map','1:a:0?',
               '-c:v','libx264','-preset','medium','-crf','18','-pix_fmt','yuv420p',
               '-c:a','aac','-b:a','192k','-shortest',str(out)]
    try:
        proc=subprocess.Popen(command,stdin=subprocess.PIPE,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
    except OSError as ex:
        err('无法启动 ffmpeg：'+str(ex))
    i=0
    try:
        while True:
            ok,frame=cap.read()
            if not ok:break
            t=i/fps
            if start <= t < end:
                p=interpolate(keys,t)
                frame=overlay_img(frame,asset,p,cv2,np)
            try:
                proc.stdin.write(frame.tobytes())
            except BrokenPipeError:
                break
            i+=1
        proc.stdin.close()
        proc.stdin=None
        stderr=proc.communicate()[1].decode('utf-8','replace')
        if proc.returncode!=0:
            if out.exists():out.unlink()
            err('ffmpeg 合成失败：'+stderr[-700:])
    finally:
        cap.release()
        if proc.poll() is None:proc.kill();proc.wait()
    if i==0 or not out.is_file() or out.stat().st_size==0:
        err('合成失败，没有有效输出')
    result=inspect_video(out)
    if abs(result['duration']-info['duration']) > max(.2,3/fps):
        print('警告：输出时长与原片存在差异，请检查。')
    print(f'已生成实际合成视频（非AI生成）：{out}\n解码帧数：{i}；输出 {result["duration"]} 秒；音轨：{result["audio"]}')
    print('注意：只完成透明PNG运动合成；手指遮挡、三维跟踪、逼真火焰与动态光照需高级处理。')


def review(source: Path, result: Path, target: Path|None):
    a = inspect_video(source); b = inspect_video(result)
    duration_delta = round(b['duration']-a['duration'],3)
    # This compares metadata only; no fake claim of semantic accuracy.
    checks = {
      'resolution_equal': [a['width'],a['height']]==[b['width'],b['height']],
      'duration_delta_seconds':duration_delta,
      'duration_near': abs(duration_delta)<=max(.25,2/a['fps']),
      'fps_near': abs(b['fps']-a['fps'])<=.1,
      'source_audio_present':a['audio'],
      'result_audio_present':b['audio'],
      'manual_review_required':['人物/建筑身份','新增物体数量','接触与遮挡','逐帧漂移','射箭释放时刻','火焰及光照合理性','原片未要求修改区域'],
      'automated_review_scope':'仅媒体参数；没有自动证明画面真实感或不穿帮',
    }
    rep={'source':a,'result':b,'checks':checks}
    if target:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(json.dumps(rep,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(checks,ensure_ascii=False,indent=2))
    return checks


def doctor():
    print('ShotPatch VFX v'+VERSION+' 环境检查：')
    for name in ('python','ffmpeg','ffprobe'):
        print(f'{name}: {shutil.which(name) or "未找到"}')
    for name in ('cv2','PIL','numpy'):
        try:
            m=__import__(name);print(f'{name}: {getattr(m,"__version__","已安装")}')
        except ImportError:print(f'{name}: 未安装')
    print('Seedance/Flow/VACE 实际权限：无法离线判断，默认人工网页操作；不会自行使用你的付费账户。')


def main(argv=None):
    parser=argparse.ArgumentParser(description='ShotPatch VFX｜外发版 视频编辑编排 + 透明素材合成')
    sub=parser.add_subparsers(dest='cmd',required=True)
    p=sub.add_parser('wizard',help='交互式中文向导');p.add_argument('--outdir')
    p=sub.add_parser('prepare',help='导入素材、生成分镜抽帧和平台提示词')
    p.add_argument('--video',required=True);p.add_argument('--task',choices=['fire','arrow','object'],default='object')
    p.add_argument('--change',default='');p.add_argument('--keep',default='');p.add_argument('--fidelity',choices=['strict','flexible'],default='strict');p.add_argument('--out',required=True)
    p=sub.add_parser('render',help='把真实透明 PNG 按关键帧合成到视频');p.add_argument('--job',required=True);p.add_argument('--output')
    p=sub.add_parser('review',help='对比输出视频与原片的媒体参数（非语义质量保证）')
    p.add_argument('--source',required=True);p.add_argument('--result',required=True);p.add_argument('--out')
    sub.add_parser('doctor',help='检查环境')
    args=parser.parse_args(argv)
    if args.cmd=='doctor':doctor()
    elif args.cmd=='wizard':wizard(args)
    elif args.cmd=='prepare':make_job(Path(args.video),args.task,args.change,args.keep,args.fidelity,Path(args.out))
    elif args.cmd=='render':render(Path(args.job),Path(args.output) if args.output else None)
    elif args.cmd=='review':review(Path(args.source),Path(args.result),Path(args.out) if args.out else None)

if __name__=='__main__':
    main()
