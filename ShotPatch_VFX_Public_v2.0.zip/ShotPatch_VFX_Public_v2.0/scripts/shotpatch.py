#!/usr/bin/env python3
"""ShotPatch VFX 2.0.0 public entry; offline by default."""
from __future__ import annotations
import argparse
import sys
from pathlib import Path
# Treat extracted public packages as immutable; avoid leaving __pycache__ artifacts.
sys.dont_write_bytecode=True
# Resolve shipped sibling modules from the public entry, even under Python -I.
sys.path.insert(0,str(Path(__file__).resolve().parent))
import engine
from vfx_modules import analyze, route, track, composite, audit, validate_arrow, build_release_demo, normalize, validate_fire
from model_handoff import handoff

VERSION = '2.0.0'

def json_obj(path):
    import json
    return json.loads(path.read_text(encoding='utf-8'))

def wizard_v2(outdir=None):
    import datetime
    import subprocess
    print('ShotPatch 2.0 小白向导：以下操作只在本地进行，无自动上传或付费调用。')
    raw=input('拖入/输入原视频路径：').strip().strip('"').strip("'")
    video=Path(raw).expanduser().resolve()
    print('1.房屋着火  2.射箭补箭  3.其他物体')
    task={'1':'fire','2':'arrow','3':'object'}.get(input('选1/2/3 [默认3]：').strip(),'object')
    change=input('一句话描述效果和发生时刻（直接回车使用模板）：').strip()
    keep=input('必须保留什么？[默认全原片保留]：').strip()
    fidelity='strict' if input('保留原片优先[Y/n]：').strip().lower() not in ('n','no') else 'flexible'
    folder=Path(outdir or video.parent).expanduser().resolve()/('ShotPatch2_'+task+'_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f'))
    return main(['prepare','--video',str(video),'--task',task,'--change',change,'--keep',keep,'--fidelity',fidelity,'--out',str(folder)])

LEGACY = {'wizard','prepare','render','review','doctor'}

def main(argv=None):
    args = list(sys.argv[1:] if argv is None else argv)
    if args and args[0] in LEGACY:
        if args[0] == 'render':
            # Back-compatible with 1.x, but use v2 compositor for supported animated / mask layers.
            p=argparse.ArgumentParser(prog='shotpatch.py render')
            p.add_argument('--job',required=True);p.add_argument('--output')
            a=p.parse_args(args[1:]);composite(Path(a.job),Path(a.output) if a.output else None)
            return
        if args[0]=='prepare':
            parser=argparse.ArgumentParser(prog='shotpatch.py prepare');parser.add_argument('--video',required=True)
            parser.add_argument('--task',choices=['fire','arrow','object'],default='object')
            parser.add_argument('--change',default='');parser.add_argument('--keep',default='');parser.add_argument('--fidelity',choices=['strict','flexible'],default='strict');parser.add_argument('--out',required=True)
            a=parser.parse_args(args[1:]);out=engine.make_job(Path(a.video),a.task,a.change,a.keep,a.fidelity,Path(a.out))
            analyze(Path(a.video),out/'场景体检.json',out/'场景体检.md')
            scene=json_obj(out/'场景体检.json')
            route(a.task, a.fidelity, 'unknown', out/'模型路由.json',out/'模型路由.md', video=Path(a.video))
            handoff(a.task,a.change,a.keep,scene,out/'各平台操作卡')
            return
        if args[0]=='wizard':
            # Let prior wizard delegate to public prepare path via engine's established simple prompts.
            parser=argparse.ArgumentParser(prog='shotpatch.py wizard');parser.add_argument('--outdir')
            a=parser.parse_args(args[1:]);wizard_v2(a.outdir);return
        engine.main(args);return
    p=argparse.ArgumentParser(description='ShotPatch VFX 2.0｜实拍增补：环境体检/模型选择/跟踪/动画遮挡合成/真实性审计')
    sub=p.add_subparsers(dest='cmd',required=True)
    q=sub.add_parser('normalize',help='手机VFR/旋转元数据正规化为CFR（输出新文件，原片不改）')
    q.add_argument('--video',required=True);q.add_argument('--out',required=True);q.add_argument('--fps',type=int,default=24)
    q=sub.add_parser('analyze',help='离线分析明暗/色调/镜头运动/剪切；不宣称语义物理已经验证')
    q.add_argument('--video',required=True);q.add_argument('--out',required=True)
    q=sub.add_parser('route',help='按场景、保真度和可用模型输出适配路线')
    q.add_argument('--task',choices=['fire','arrow','object'],required=True)
    q.add_argument('--fidelity',choices=['strict','flexible'],default='strict')
    q.add_argument('--access',choices=['unknown','seedance25','seedance20','flow','omni_api','vace','none'],default='unknown')
    q.add_argument('--video');q.add_argument('--out',required=True)
    q=sub.add_parser('track',help='半自动跟踪方形道具锚点；失败标红而非瞎预测')
    q.add_argument('--video',required=True);q.add_argument('--box',required=True,help='首帧框 x,y,w,h（像素）')
    q.add_argument('--out',required=True);q.add_argument('--threshold',type=float,default=.62)
    q=sub.add_parser('audit',help='按 ROI 计算源片以外区域变化比例、发现整体重绘/漂移')
    q.add_argument('--source',required=True);q.add_argument('--result',required=True)
    q.add_argument('--allowed-roi',help='归一化 x,y,w,h，如 0.3,0.2,0.4,0.5')
    q.add_argument('--out',required=True)
    q=sub.add_parser('check-arrow',help='检验按帧给定的搭箭点、松弦、飞行约束')
    q.add_argument('--job',required=True);q.add_argument('--out',required=True)
    q=sub.add_parser('check-fire',help='检查人工标注的屋顶火焰锚点和烟的连续性（非热流仿真）')
    q.add_argument('--job',required=True);q.add_argument('--out',required=True)
    q=sub.add_parser('make-demo',help='生成测试素材，不是电影级真实特效')
    q.add_argument('--out',required=True)
    a=p.parse_args(args)
    if a.cmd=='normalize':normalize(Path(a.video),Path(a.out),a.fps)
    elif a.cmd=='analyze':analyze(Path(a.video),Path(a.out),Path(a.out).with_suffix('.md'))
    elif a.cmd=='route':route(a.task,a.fidelity,a.access,Path(a.out),Path(a.out).with_suffix('.md'),Path(a.video) if a.video else None)
    elif a.cmd=='track':track(Path(a.video),tuple(map(int,a.box.split(','))),Path(a.out),a.threshold)
    elif a.cmd=='audit':audit(Path(a.source),Path(a.result),Path(a.out),tuple(map(float,a.allowed_roi.split(','))) if a.allowed_roi else None)
    elif a.cmd=='check-arrow':validate_arrow(Path(a.job),Path(a.out))
    elif a.cmd=='check-fire':validate_fire(Path(a.job),Path(a.out))
    elif a.cmd=='make-demo':build_release_demo(Path(a.out))

if __name__=='__main__':main()
