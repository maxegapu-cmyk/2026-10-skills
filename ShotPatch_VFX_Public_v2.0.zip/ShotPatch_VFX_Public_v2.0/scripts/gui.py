"""Optional beginner GUI (Tkinter bundled with most Windows Python installs)."""
from __future__ import annotations
import subprocess
import sys
import threading
from pathlib import Path
try:
    import tkinter as tk
    from tkinter import filedialog,messagebox,ttk
except ImportError:
    raise SystemExit('缺少Tkinter，无法启动图形界面。请安装官方Python完整版，或使用命令行向导。')
ROOT=Path(__file__).resolve().parent
app=tk.Tk();app.title('ShotPatch VFX 2.0｜小白向导｜不会自动上传');app.geometry('730x485');app.resizable(True,True)
video=tk.StringVar();task=tk.StringVar(value='fire');fidelity=tk.StringVar(value='strict');outdir=tk.StringVar();change=tk.StringVar()

def choose():
    f=filedialog.askopenfilename(title='选择已有实拍视频',filetypes=[('视频','*.mp4 *.mov *.avi *.mkv'),('所有','*.*')])
    if f:video.set(f)

def choose_output():
    f=filedialog.askdirectory(title='选择新项目保存文件夹')
    if f:outdir.set(f)

def run():
    p=Path(video.get().strip())
    if not p.is_file():messagebox.showerror('还差一步','请先选择实际存在的视频文件');return
    dest=Path(outdir.get()) if outdir.get() else p.parent
    if not dest.is_dir():messagebox.showerror('目录无效','请选择可用的保存文件夹');return
    import datetime
    target=dest/('ShotPatch2_'+task.get()+'_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f'))
    cmd=[sys.executable,str(ROOT/'shotpatch.py'),'prepare','--video',str(p),'--task',task.get(),'--fidelity',fidelity.get(),
         '--change',change.get(),'--out',str(target)]
    log.insert(tk.END,'正在本地检查并生成项目：'+str(target)+'\n');log.see(tk.END)
    start_btn.state(['disabled'])
    # GUI stays responsive during video analysis. All actual effects are local; no upload.
    def worker():
        r=subprocess.run(cmd,capture_output=True,text=True,encoding='utf-8',errors='replace')
        def done():
            start_btn.state(['!disabled'])
            log.insert(tk.END,('成功：\n'+r.stdout if r.returncode==0 else '失败：\n'+r.stderr)+'\n');log.see(tk.END)
            if r.returncode==0:messagebox.showinfo('完成','已生成分析报告与分平台编辑指令。\n文件夹：'+str(target))
            else:messagebox.showerror('操作失败','请看下方日志；确认视频可正常播放、FFmpeg已安装。')
        app.after(0,done)
    threading.Thread(target=worker,daemon=True).start()

frame=ttk.Frame(app,padding=16);frame.pack(fill='both',expand=True)
ttk.Label(frame,text='ShotPatch VFX 2.0：给实拍视频添加道具/火焰',font=('Segoe UI',15,'bold')).pack(anchor='w')
ttk.Label(frame,text='默认本地分析，绝不自动上传。模型生成需要您自己有权限并确认后手工执行。').pack(anchor='w',pady=8)
top=ttk.Frame(frame);top.pack(fill='x');ttk.Entry(top,textvariable=video).pack(side='left',fill='x',expand=True);ttk.Button(top,text='选择实拍视频',command=choose).pack(side='left',padx=6)
row=ttk.Frame(frame);row.pack(fill='x',pady=9)
ttk.Label(row,text='想做什么：').pack(side='left')
for lab,value in [('房子加火','fire'),('男人射箭补箭','arrow'),('其他道具','object')]:ttk.Radiobutton(row,text=lab,variable=task,value=value).pack(side='left',padx=8)
ttk.Label(frame,text='一句话描述：位置、何时发生、不能改变什么').pack(anchor='w')
ttk.Entry(frame,textvariable=change).pack(fill='x',pady=5)
row=ttk.Frame(frame);row.pack(fill='x')
ttk.Label(row,text='默认模式：').pack(side='left')
ttk.Radiobutton(row,text='极力保护原片（推荐）',variable=fidelity,value='strict').pack(side='left')
ttk.Radiobutton(row,text='允许局部重生成',variable=fidelity,value='flexible').pack(side='left')
row2=ttk.Frame(frame);row2.pack(fill='x',pady=12)
ttk.Entry(row2,textvariable=outdir).pack(side='left',fill='x',expand=True)
ttk.Button(row2,text='选择保存位置（可选）',command=choose_output).pack(side='left',padx=6)
start_btn=ttk.Button(frame,text='开始：场景体检 + 各模型操作卡',command=run);start_btn.pack(fill='x',pady=4)
log=tk.Text(frame,height=11);log.pack(fill='both',expand=True,pady=10)
app.mainloop()
