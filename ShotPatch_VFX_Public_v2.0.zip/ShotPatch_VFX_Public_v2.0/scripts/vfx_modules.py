"""ShotPatch VFX v2 offline CV helpers. No weights, API, data transmission or network."""
from __future__ import annotations
import hashlib
import json
import math
import subprocess
from pathlib import Path
from statistics import median
import engine

VERSION='2.0.0'

def fail(msg): raise SystemExit("错误："+msg)
def cvmods():
    import cv2
    import numpy as np
    return cv2,np

def jwrite(path, data):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')

def unicode_imread(path,flag):
    cv2,np=cvmods()
    try:
        data=np.fromfile(str(path),dtype=np.uint8)
        return cv2.imdecode(data,flag) if data.size else None
    except (OSError,ValueError):return None

def sig(v):
    p=Path(v);h=hashlib.sha256()
    with p.open('rb') as f:
        for ch in iter(lambda:f.read(1024*1024),b''):h.update(ch)
    return h.hexdigest()

def analyze(video, out, md=None):
    cv2,np=cvmods(); info=engine.inspect_video(video)
    cap=cv2.VideoCapture(str(video))
    if not cap.isOpened():fail('无法解码原始视频')
    fps=info['fps'];total=min(120, max(3, math.ceil(info['duration']*2)))
    records=[];prev=None;prev_gray=None
    for k in range(total):
        sec=min(info['duration']-.0001,k*info['duration']/total)
        cap.set(cv2.CAP_PROP_POS_MSEC,sec*1000)
        ok,frame=cap.read()
        if not ok:continue
        small=cv2.resize(frame,(256,144))
        gray=cv2.cvtColor(small,cv2.COLOR_BGR2GRAY)
        hsv=cv2.cvtColor(small,cv2.COLOR_BGR2HSV)
        hist=cv2.calcHist([hsv],[0],None,[32],[0,180]);hist=cv2.normalize(hist,hist).flatten()
        b=float(np.mean(gray)); contrast=float(np.std(gray))
        # A simple content-change proxy, NOT a guaranteed editorial cut detector.
        diff= float(np.mean(cv2.absdiff(gray,prev_gray)))/255 if prev_gray is not None else 0
        cut_candidate = diff > .22 or (prev_gray is not None and abs(b - float(np.mean(prev_gray))) > 45)
        dxdy=0.0; tracked=0
        if prev_gray is not None and not cut_candidate:
            pts=cv2.goodFeaturesToTrack(prev_gray,maxCorners=100,qualityLevel=.02,minDistance=6)
            if pts is not None and len(pts)>=6:
                n,status,_=cv2.calcOpticalFlowPyrLK(prev_gray,gray,pts,None)
                if n is not None and status is not None:
                    valid=status.flatten()>0
                    if valid.sum()>=6:
                        shift=(n[valid]-pts[valid]).reshape(-1,2)
                        dxdy=float(np.median(np.linalg.norm(shift,axis=1)))
                        tracked=int(valid.sum())
        lap=float(cv2.Laplacian(gray,cv2.CV_64F).var())
        records.append({'t':round(sec,3),'brightness':round(b,1),'contrast':round(contrast,1),
          'saturation':round(float(hsv[:,:,1].mean()),1),'warm_hue_fraction':round(float(np.mean(((hsv[:,:,0]<25)|(hsv[:,:,0]>172))&(hsv[:,:,1]>70))),3),
          'blur_proxy':round(lap,1),'frame_change':round(diff,3),'motion_px_256w':round(dxdy,2),
          'tracked_points':tracked,'possible_cut':cut_candidate})
        prev_gray=gray
    cap.release()
    if not records:fail('无法解码帧，体检失败')
    brightness=median(r['brightness'] for r in records)
    contrast=median(r['contrast'] for r in records)
    motion=median(r['motion_px_256w'] for r in records)
    cut_idx=[r['t'] for r in records if r['possible_cut']]
    warnings=[]
    if brightness<65:warnings.append('整体偏暗：新增素材亮度/色温要与低照度匹配，局部火光必须影响附近真实物体。')
    if brightness>190:warnings.append('整体偏亮：检查曝光溢出、火焰高光过曝与新物体阴影方向。')
    if motion>4:warnings.append('镜头/场景运动偏明显：二维静态覆盖易漂移，优先跟踪或生成式局部编辑。')
    if cut_idx:warnings.append('检测到画面大变化候选；可能是剪切、闪光或快速转头，应由人核对，必要时逐镜头处理。')
    if contrast<28:warnings.append('低对比度/雾感环境：插入物必须遵守低反差、空气透视，不可无缘无故锐利。')
    if info.get('color_transfer') in ('smpte2084','arib-std-b67') or '10' in str(info.get('pixel_fmt','')):warnings.append('HDR/10-bit：合成需色彩管理，当前本地引擎拒绝静默降为SDR。')
    if info['vfr_warning']:warnings.append('疑似 VFR。复杂同步与逐帧处理前先转换 CFR，并审查音画对齐。')
    if info['rotation_degrees']:warnings.append('检测到方向元数据，需统一视觉方向后再跟踪/渲染。')
    if info['duration']>30:warnings.append('视频超过部分生成式编辑平台单段限制，应该按镜头剪段，不要直接强行提交。')
    ambience='暗场/夜景倾向' if brightness<65 else ('高照度/室外倾向' if brightness>170 else '中间调/混合光照倾向')
    report={'schema':'shotpatch.scene.v2','source':info,'source_sha256':sig(video),'sampled_frames':len(records),
      'visual_estimates':{'ambience_hint':ambience,'median_luma_0_255':round(brightness,1),'median_contrast':round(contrast,1),
      'median_motion_px_at_256w':round(motion,2),'possible_cut_times_seconds':cut_idx},
      'observations':records,'warnings':warnings,'limitation':'采样视觉统计不等于物体识别、现实三维坐标、火灾模拟、手指遮挡或真实物理验证。物理须结合实拍锚点和人工审核。'}
    jwrite(out,report)
    if md:
        text='# 场景体检（自动采样，仅估计）\n\n'+f'源片：`{info["name"]}`；尺寸 {info["width"]}×{info["height"]}，约 {info["duration"]:.2f} 秒。\n\n'
        text+=f'整体影调：**{ambience}**；亮度中值 {brightness:.1f}/255；运动代理值 {motion:.2f}px（缩至256宽，仅供风险分流）。\n\n'
        text+='## 风险提示\n'+''.join(f'- {w}\n' for w in warnings or ['无明确自动预警；不代表画面已经真实合格。'])
        text+='\n**不自动承诺：**已识别真实太阳方位、世界重力方向、真实光源材质/风速或射箭力学。\n'
        md.write_text(text,encoding='utf-8')
    print(f'体检完成：{out}；抽样={len(records)}，注意：仅启发式而非语义/物理认证')
    return report

CAPABILITIES={
 'local_composite':{'capable':'本地透明PNG/序列及前景遮挡合成','connected':True,'external':False},
 'seedance25':{'capable':'官方视频编辑任务、参考视频；具体权限另核','connected':False,'external':True},
 'seedance20':{'capable':'多模态视频生成及部分编辑用途，不能照搬2.5请求','connected':False,'external':True},
 'flow':{'capable':'网页原视频编辑，现使用Omni Flash','connected':False,'external':True},
 'omni_api':{'capable':'Gemini Omni Flash Interactions API 官方支持上传实拍编辑，地区/账户限定','connected':False,'external':True},
 'veo31':{'capable':'生成/首末帧/参考图/仅Veo视频扩展，不能当任意上传视频局部编辑','connected':False,'external':True},
 'vace':{'capable':'自部署遮罩视频编辑；推理与权重另装','connected':False,'external':True},
}

def route(task,fidelity,access,out,md=None,video=None):
    info=engine.inspect_video(video) if video else None
    camera='unknown'
    if info and info['vfr_warning']: camera='vfr'
    strict=fidelity=='strict'
    if strict:
        first='local_composite' if task in ('arrow','object') else 'local_composite / seeded masked editing'
        why='原片不可重绘；保真任务必须用真实跟踪、遮挡和独立特效层，生成结果只作素材。'
    else:
        first=access if access not in ('unknown','none') else 'seedance25 或 omni_api 或 flow（选择有权限的一个）'
        why='允许有限局部重绘，可先进行低成本编辑试片，但需回片审计。'
    if task=='arrow':
        risk=['箭尾与弓弦搭箭点','手指前景遮挡','松弦事件帧','飞出方向与相机快门模糊','弓与手指不可被重绘']
    elif task=='fire':
        risk=['火焰附着于建筑表面','烟流向与风场一致','火光随距离衰减','前景遮挡及遮罩边缘','原建筑几何保留']
    else:risk=['锚点接触','透视比例','光源/材质','景深/运动模糊','背景未授权变化']
    warnings=[]
    if info and not 4 <= info['duration'] <= 30:warnings.append('Seedance 2.5 edit视频单段长度须4–30秒，先人工选段（不盲截动作）。')
    if info and info['duration']>10:warnings.append('Flow Omni Flash 文档明确一次选取编辑片段≤10秒，需保留前后衔接。')
    if info and info['rotation_degrees']:warnings.append('处理前先规范方向，后期别仅凭元数据判断像素坐标。')
    if camera=='vfr':warnings.append('VFR：先转换为CFR，否则关键帧时间与解码帧索引可能不一致。')
    selected=access if access not in ('none','unknown') else None
    action='manual_platform' if selected else 'no_paid_model_claimed'
    if selected=='seedance25' and info and not 4<=info['duration']<=30:action='blocked_until_trimmed'
    if selected=='flow' and info and info['duration']>10:action='requires_10s_selection'
    result={'schema':'shotpatch.route.v2','task':task,'fidelity':fidelity,'available_backend_declared':access,
      'first_choice':first,'reason':why,'required_checks':risk,'warnings':warnings,'model_capabilities':CAPABILITIES,
      'suggested_action':action,
      'go_no_go':{'local_composite':'需准备真实透明素材和关键帧或跟踪结果；复杂遮挡要有前景mask',
                  'model_edit':'需账号权限/允许上传/付费同意；输出须人工视觉审查'},
      'note':'路由是离线计划不是端到端连接；Google Omni API已公开官方上传实拍编辑文档，但本包没有密钥或API调用。'}
    jwrite(out,result)
    if md:
        md.write_text(f'# 模型路由 / 实战方案\n\n任务：{task}；模式：{fidelity}。\n\n优先路线：**{first}**。{why}\n\n'
          +'## 物理与一致性约束\n'+''.join(f'- {x}\n' for x in risk)
          +'\n## 适配警告\n'+''.join(f'- {w}\n' for w in warnings or ['无输入级别阻断条件，仍需确认服务可用。'])
          +'\n**注意：**不上传源视频，不自动请求付费模型。任何真实视频编辑成功与否必须回片评估。\n',encoding='utf-8')
    print('已给出路由；接入状态与真实效果不等于理论能力：'+str(out))
    return result

def track(video,box,out,threshold=.62):
    cv2,np=cvmods(); info=engine.inspect_video(video)
    if len(box)!=4 or not all(isinstance(x,int) for x in box):fail('框必须是x,y,w,h整数')
    x,y,w,h=box;W,H=info['width'],info['height']
    if min(x,y)<0 or min(w,h)<12 or x+w>W or y+h>H:fail('首帧框越界或尺寸太小（至少12px）')
    if not .15<=threshold<=.95:fail('threshold必须在0.15～0.95')
    if info['vfr_warning'] or info['rotation_degrees']:fail('跟踪前先转换VFR/方向元数据为CFR正向视频')
    cap=cv2.VideoCapture(str(video));ok,frame=cap.read()
    if not ok:fail('无法读取第一帧')
    gray=cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY)
    template=gray[y:y+h,x:x+w].copy();old=template.copy()
    # Match original initial template inside a local motion window, no neural model.
    # Do not update on uncertain matches; a false match should stop the tracker.
    results=[{'frame':0,'t':0,'x':(x+w/2)/W,'y':(y+h/2)/H,'width':w/W,'confidence':1.,'status':'ok'}]
    prevx,prevy=x,y;idx=0;lost=False
    while True:
        ok,frame=cap.read()
        if not ok:break
        idx+=1
        if lost:break
        gray=cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY)
        margin=max(18,int(min(W,H)*.14))
        ax=max(0,prevx-margin);ay=max(0,prevy-margin)
        bx=min(W,prevx+w+margin);by=min(H,prevy+h+margin)
        window=gray[ay:by,ax:bx]
        if window.shape[0]<h or window.shape[1]<w:break
        metric=cv2.matchTemplate(window,template,cv2.TM_CCOEFF_NORMED)
        _,score,_,where=cv2.minMaxLoc(metric)
        # low-texture flat templates falsely match all regions as 1.0
        if float(np.std(template)) < 8:score=0
        if score<threshold:
            results.append({'frame':idx,'t':round(idx/info['fps'],6),'confidence':round(float(score),3),'status':'LOST_STOP','hint':'遮挡/模糊/形变或缺纹理：需手动补锚点，不能继续自动插值'})
            lost=True;continue
        px=where[0]+ax;py=where[1]+ay
        results.append({'frame':idx,'t':round(idx/info['fps'],6),'x':round((px+w/2)/W,6),
          'y':round((py+h/2)/H,6),'width':round(w/W,6),'degrees':0,'opacity':1,
          'confidence':round(float(score),3),'status':'ok'})
        prevx,prevy=px,py
        if idx>10000:break
    cap.release()
    payload={'schema':'shotpatch.track.v2','algorithm':'local_template_matching_nonrotating','source':str(video.resolve()),'box_initial':list(box),
      'samples':results,'quality':'incomplete' if lost else 'automatic_candidate_not_certified',
      'limits':['不能追踪3D旋转/快速缩放/弓箭释放/复杂遮挡','局部模板匹配不是多点物理跟踪','LOSS必须由人工纠偏后再续做']}
    jwrite(out,payload);print('跟踪完成：'+str(out)+'；'+payload['quality']);return payload

def ensure_sdr_8bit(info):
    if info.get('color_transfer') in ('smpte2084','arib-std-b67') or '10' in str(info.get('pixel_fmt','')) or '12' in str(info.get('pixel_fmt','')):
        fail('检测到HDR/10-bit或高位深格式：当前8-bit合成器不支持保真处理。请在有色彩管理的剪辑软件做明确的HDR→SDR转换后再使用，不自动丢弃色彩。')

def parse_overlay(job,base):
    # Support v1 layout + v2 multilayer assets, no third-party codecs beyond ffmpeg.
    if job.get('schema') not in ('shotpatch.overlay.v1','shotpatch.overlay.v2'):fail('overlay schema应为v1或v2')
    ls=[job] if job['schema']=='shotpatch.overlay.v1' else job.get('layers',[])
    if not isinstance(ls,list) or not ls:fail('至少提供一个效果层')
    def resolved(key):
        v=Path(key)
        return v if v.is_absolute() else (base/v).resolve()
    layers=[]
    for i,l in enumerate(ls):
        if not isinstance(l,dict):fail('图层必须为对象')
        keys,start,end=engine.validate_overlay({**l,"schema":"shotpatch.overlay.v1"})
        if 'png' not in l and 'sequence' not in l:fail('图层必须有png或sequence')
        if 'png' in l and 'sequence' in l:fail('图层不可同时指定png和sequence')
        pngs=[resolved(l['png'])] if 'png' in l else [resolved(x) for x in l['sequence']]
        if not pngs or len(pngs)>1000:fail('PNG序列为空或过多')
        for png in pngs:
            if not png.is_file() or png.suffix.lower()!='.png':fail('缺少PNG素材或后缀不正确：'+str(png))
        fps=float(l.get('sequence_fps',12))
        if not math.isfinite(fps) or not .1<=fps<=240:fail('sequence_fps越界')
        mask=resolved(l['occlusion_png']) if l.get('occlusion_png') else None
        masks=[resolved(x) for x in l['occlusion_sequence']] if l.get('occlusion_sequence') else None
        if mask and masks:fail('只能选择静态遮挡mask或序列遮挡mask')
        if mask and not mask.is_file():fail('遮挡mask不存在')
        if masks:
            if len(masks)!=len(pngs):fail('遮挡序列张数必须等于素材序列张数，以免错帧')
            if not all(m.is_file() for m in masks):fail('缺少遮挡序列文件')
        style=l.get('style_match',{})
        if style:
            if style.get('mode') not in ('ambient','off'):fail('style_match mode只能ambient/off')
            if not 0<=float(style.get('strength',.5))<=1:fail('style_match strength须0～1')
            if not 0<=float(style.get('blur_px',0))<=10:fail('style_match blur_px须0～10')
        gl=l.get('glow',{})
        if gl:
            strength=float(gl.get('strength',0))
            if not 0<=strength<=.8:fail('glow strength仅支持0到0.8')
            if strength and not l.get('light_mask'):fail('发光要求light_mask，避免把整幅原片染色')
        lm=resolved(l['light_mask']) if l.get('light_mask') else None
        if lm and not lm.is_file():fail('light_mask不存在')
        layers.append({'keys':keys,'start':start,'end':end,'pngs':pngs,'fps':fps,'mask':mask,'masks':masks,'glow':gl,'light_mask':lm,'style':style,'name':l.get('name',f'layer_{i}')})
    return layers

def composite(jobpath,output=None):
    cv2,np=cvmods();engine.verify_bin('ffmpeg');jobpath=jobpath.resolve();job=json.loads(jobpath.read_text(encoding='utf-8'))
    base=jobpath.parent;layers=parse_overlay(job,base)
    src=Path(job['video']);src=src if src.is_absolute() else (base/src).resolve()
    info=engine.inspect_video(src)
    ensure_sdr_8bit(info)
    if info['vfr_warning'] or info['rotation_degrees']:fail('合成前需统一方向并转换CFR')
    out=output or Path(job.get('output','composited.mp4'))
    out=out if out.is_absolute() else (base/out).resolve()
    if out==src.resolve():fail('不能覆盖原视频')
    if out.exists():fail('输出文件已存在：'+str(out))
    out.parent.mkdir(parents=True,exist_ok=True)
    H,W=info['height'],info['width']
    for layer in layers:
        layer['assets']=[]
        for p in layer['pngs']:
            im=unicode_imread(p,cv2.IMREAD_UNCHANGED)
            if im is None or im.ndim!=3 or im.shape[2]!=4:fail('素材必须为带Alpha透明PNG：'+str(p))
            layer['assets'].append(im)
        def read_mask(p):
            if p is None:return None
            im=unicode_imread(p,cv2.IMREAD_GRAYSCALE)
            if im is None or im.shape!=(H,W):fail('遮挡/照明mask必须与视频逐像素同尺寸')
            return im.astype(np.float32)/255.
        layer['matte']=read_mask(layer['mask'])
        layer['matte_seq']=[read_mask(m) for m in layer['masks']] if layer['masks'] else None
        layer['light_matte']=read_mask(layer['light_mask'])
    cap=cv2.VideoCapture(str(src))
    command=['ffmpeg','-hide_banner','-loglevel','error','-nostdin','-y',
       '-f','rawvideo','-pixel_format','bgr24','-video_size',f'{W}x{H}',
       '-framerate',f'{info["fps"]:.8f}','-i','pipe:0','-i',str(src),'-map','0:v:0','-map','1:a:0?',
       '-c:v','libx264','-preset','medium','-crf','18','-pix_fmt','yuv420p','-c:a','aac','-b:a','192k',
       '-shortest',str(out)]
    try:proc=subprocess.Popen(command,stdin=subprocess.PIPE,stderr=subprocess.PIPE,stdout=subprocess.DEVNULL)
    except Exception as ex:fail('ffmpeg启动失败：'+str(ex))
    i=0;write_error=None
    try:
        while True:
            ok,frame=cap.read()
            if not ok:break
            t=i/info['fps']
            for l in layers:
                if not l['start']<=t<l['end']:continue
                ix=min(len(l['assets'])-1,int(max(0,t-l['start'])*l['fps']))
                pos=engine.interpolate(l['keys'],t)
                # Masks indicate ORIGINAL FOREGROUND which must cover the newly inserted layer.
                occ=l['matte_seq'][ix] if l['matte_seq'] is not None else l['matte']
                frame=blend_asset(frame,l['assets'][ix],pos,cv2,np,occ,l['glow'],l['light_matte'],l['style'])
            try:proc.stdin.write(frame.tobytes())
            except BrokenPipeError as ex:write_error=ex;break
            i+=1
        if proc.stdin:
            proc.stdin.close();proc.stdin=None
        errors=proc.communicate()[1].decode('utf-8','replace')
        if proc.returncode!=0 or write_error:fail('合成失败：'+errors[-1200:])
        if not out.is_file() or out.stat().st_size<100:fail('输出为空')
        result=engine.inspect_video(out)
        if abs(result['duration']-info['duration'])>max(.3,3/info['fps']):fail('输出时长超出允许容差')
        print(f'实际完成图层合成：{out}；帧={i}；音轨={result["audio"]}')
        return result
    except Exception:
        if out.exists():out.unlink()
        raise
    finally:
        cap.release()
        if proc.poll() is None:proc.kill();proc.wait()

def blend_asset(frame,asset,k,cv2,np,occlusion=None,glow=None,light_mask=None,style=None):
    H,W=frame.shape[:2]
    ww=max(1,round(W*float(k['width'])));hh=max(1,round(ww*asset.shape[0]/asset.shape[1]))
    if ww>W*3 or hh>H*6 or ww*hh>25_000_000:fail('素材尺寸过大')
    obj=cv2.resize(asset,(ww,hh),interpolation=cv2.INTER_AREA if ww<asset.shape[1] else cv2.INTER_LINEAR)
    angle=float(k['degrees'])
    if abs(angle)>.001:
        diag=math.ceil(math.hypot(ww,hh))+2
        if diag>8000:fail('旋转图层尺寸过大')
        mat=cv2.getRotationMatrix2D((ww/2,hh/2),angle,1)
        mat[0,2]+=(diag-ww)/2;mat[1,2]+=(diag-hh)/2
        obj=cv2.warpAffine(obj,mat,(diag,diag),borderMode=cv2.BORDER_CONSTANT,borderValue=(0,0,0,0))
    oh,ow=obj.shape[:2]
    x0=round(float(k['x'])*W)-ow//2;y0=round(float(k['y'])*H)-oh//2
    x1=max(0,x0);y1=max(0,y0);x2=min(W,x0+ow);y2=min(H,y0+oh)
    if x1>=x2 or y1>=y2:return frame
    patch=obj[y1-y0:y2-y0,x1-x0:x2-x0].copy()
    if style and style.get('mode')=='ambient':
        # Approximate non-emissive prop grade based on immediate patch, not on global 'cinematic' stereotypes.
        strength=float(style.get('strength',.5))
        bg_gray=cv2.cvtColor(frame[y1:y2,x1:x2],cv2.COLOR_BGR2GRAY)
        fg_gray=cv2.cvtColor(patch[:,:,:3],cv2.COLOR_BGR2GRAY)
        opaque=patch[:,:,3]>80
        if opaque.any():
            source_luma=float(np.median(fg_gray[opaque]));target_luma=float(np.median(bg_gray))
            factor=max(.65,min(1.4,target_luma/max(1,source_luma)))
            factor=1+(factor-1)*strength
            patch[:,:,:3]=np.clip(patch[:,:,:3].astype(np.float32)*factor,0,255).astype(np.uint8)
        blur=float(style.get('blur_px',0))
        if blur>0:patch[:,:,:3]=cv2.GaussianBlur(patch[:,:,:3],(0,0),blur)
    alpha=patch[:,:,3].astype(np.float32)/255.*float(k['opacity'])
    if occlusion is not None:alpha*=1-occlusion[y1:y2,x1:x2]
    if glow and float(glow.get('strength',0))>0:
        # Artistic brightening only, NOT physical radiometric firelight simulation.
        radius=int(glow.get('radius_px',15))
        if radius<1 or radius>300:fail('glow radius_px 1～300')
        strength=float(glow['strength'])
        lum=cv2.GaussianBlur(alpha,(0,0),sigmaX=radius)
        lum*=light_mask[y1:y2,x1:x2]  # required, validated
        col=glow.get('bgr',[24,100,255]);col=np.array(col,dtype=np.float32)
        if col.shape!=(3,) or np.any(col<0) or np.any(col>255):fail('glow bgr无效')
        bg=frame[y1:y2,x1:x2].astype(np.float32)
        frame[y1:y2,x1:x2]=np.clip(bg+lum[:,:,None]*col[None,None,:]*strength,0,255).astype(np.uint8)
    bg=frame[y1:y2,x1:x2].astype(np.float32)
    fg=patch[:,:,:3].astype(np.float32)
    frame[y1:y2,x1:x2]=np.clip(bg*(1-alpha[:,:,None])+fg*alpha[:,:,None],0,255).astype(np.uint8)
    return frame

def audio_sync_probe(source, result, max_seconds=12):
    """Optional weak PCM cross-correlation; not a proof of dialogue sync."""
    cv2,np=cvmods()
    def pcm(path):
        c=['ffmpeg','-hide_banner','-loglevel','error','-nostdin','-t',str(max_seconds),
           '-i',str(path),'-map','0:a:0','-vn','-ac','1','-ar','8000','-f','f32le','pipe:1']
        p=subprocess.run(c,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        return np.frombuffer(p.stdout,dtype='<f4').astype(np.float64) if p.returncode==0 else None
    a=pcm(source);b=pcm(result)
    if a is None or b is None:return {'status':'NO_AUDIO_PAIR'}
    n=min(len(a),len(b),max_seconds*8000)
    if n<8000:return {'status':'AUDIO_TOO_SHORT'}
    a=a[:n];b=b[:n]
    ra=float(np.sqrt(np.mean(a*a)));rb=float(np.sqrt(np.mean(b*b)))
    if ra<.0001 or rb<.0001:return {'status':'SILENT_OR_MISSING','rms_source':round(ra,6),'rms_result':round(rb,6)}
    a=(a-np.mean(a))/max(ra,1e-8);b=(b-np.mean(b))/max(rb,1e-8)
    sz=1<<int(math.ceil(math.log2(2*n-1)))
    cross=np.fft.irfft(np.fft.rfft(a,sz)*np.conj(np.fft.rfft(b,sz)),sz)
    lagmax=min(8000,n//2);idx=np.r_[np.arange(lagmax),np.arange(sz-lagmax,sz)]
    peak=int(idx[np.argmax(cross[idx])]);lag=peak if peak<lagmax else peak-sz
    corr=float(cross[peak]/n)
    status='PROBABLE_SYNC' if abs(lag)<.08*8000 and corr>.2 else 'REVIEW_AUDIO_SYNC'
    return {'status':status,'offset_proxy_seconds':round(lag/8000,4),
            'correlation_proxy':round(corr,3),'source_rms':round(ra,5),'result_rms':round(rb,5),
            'note':'音频样本相关仅供警告：新配乐、声效、时间伸缩会影响计算，最终必须人工听对白和事件同步。'}

def make_audit_sheet(source,result,out,times,allowed_roi=None):
    cv2,np=cvmods();a=engine.inspect_video(source);capA=cv2.VideoCapture(str(source));capB=cv2.VideoCapture(str(result))
    tiles=[]
    for t in times[:4]:
        capA.set(cv2.CAP_PROP_POS_MSEC,t*1000);capB.set(cv2.CAP_PROP_POS_MSEC,t*1000)
        oka,A=capA.read();okb,B=capB.read()
        if not oka or not okb:continue
        if allowed_roi is not None:
            x,y,w,h=allowed_roi
            x1,y1=round(x*A.shape[1]),round(y*A.shape[0]);x2,y2=round((x+w)*A.shape[1]),round((y+h)*A.shape[0])
            cv2.rectangle(A,(x1,y1),(x2,y2),(50,190,90),2)
            cv2.rectangle(B,(x1,y1),(x2,y2),(50,190,90),2)
        dif=cv2.absdiff(A,B);delta=cv2.applyColorMap(cv2.cvtColor(dif,cv2.COLOR_BGR2GRAY),cv2.COLORMAP_INFERNO)
        target_w=min(500,A.shape[1]);target_h=round(A.shape[0]*target_w/A.shape[1])
        strip=[]
        for label,img in [('ORIGINAL',A),('RESULT',B),('DIFFERENCE',delta)]:
            im=cv2.resize(img,(target_w,target_h));cv2.rectangle(im,(0,0),(target_w,22),(20,20,20),-1)
            cv2.putText(im,label+' t='+str(round(t,2))+'s',(6,16),cv2.FONT_HERSHEY_SIMPLEX,.45,(255,255,255),1)
            strip.append(im)
        tiles.append(cv2.hconcat(strip))
    capA.release();capB.release()
    if tiles:
        ok,bytes_png=cv2.imencode('.png',cv2.vconcat(tiles))
        if ok:bytes_png.tofile(str(out))
    return bool(tiles)

def audit(source,result,out,allowed_roi=None):
    cv2,np=cvmods();a=engine.inspect_video(source);b=engine.inspect_video(result)
    checks=engine.review(source,result,None)
    if a['width']!=b['width'] or a['height']!=b['height']:fail('分辨率不一致，无法进行像素级ROI比较')
    if abs(a['fps']-b['fps'])>.1:fail('帧率不一致，无法同索引抽样')
    W,H=a['width'],a['height']
    if allowed_roi is not None:
        if len(allowed_roi)!=4 or any(not math.isfinite(v) for v in allowed_roi):fail('allowed-roi格式有误')
        x,y,w,h=allowed_roi
        if not(0<=x<1 and 0<=y<1 and 0<w<=1-x and 0<h<=1-y):fail('允许修改ROI必须处于归一化画面内')
    ca=cv2.VideoCapture(str(source));cb=cv2.VideoCapture(str(result))
    stride=max(1,round(a['fps']/4));data=[];f=0
    while True:
        oka,fa=ca.read();okb,fb=cb.read()
        if not oka or not okb:break
        if f%stride==0:
            dif=np.abs(fa.astype(np.float32)-fb.astype(np.float32))
            mask=np.ones((H,W),dtype=bool)
            if allowed_roi is not None:
                xa,ya,w0,h0=allowed_roi
                mask[round(ya*H):round((ya+h0)*H),round(xa*W):round((xa+w0)*W)]=False
            sub=dif[mask]
            if sub.size:
                data.append({'t':round(f/a['fps'],3),'mean_delta':round(float(sub.mean()),3),
                    'pixel_fraction_delta_gt_20':round(float(np.mean(np.max(dif[mask],axis=1)>20)),4)})
        f+=1
        if f>100000:break
    ca.release();cb.release()
    if not data:fail('源片与成品无可对照帧')
    maxchg=max(d['pixel_fraction_delta_gt_20'] for d in data)
    verdict='REVIEW_NEEDED' if maxchg>.04 or not checks['duration_near'] or not checks['fps_near'] else 'NUMERIC_PASS_REQUIRES_VISUAL'
    audio_check=audio_sync_probe(source,result) if a['audio'] and b['audio'] else {'status':'AUDIO_PRESENCE_MISMATCH' if a['audio']!=b['audio'] else 'NO_AUDIO'}
    critical=sorted(data,key=lambda d:d['pixel_fraction_delta_gt_20'],reverse=True)[:4]
    sheet=out.with_name(out.stem+'_审片对照.png')
    sheet_created=make_audit_sheet(source,result,sheet,[x['t'] for x in critical],allowed_roi)
    result={'schema':'shotpatch.audit.v2','source_sha256':sig(source),'result_sha256':sig(result),
      'audio_sync_proxy':audio_check,'comparison_sheet_path':str(sheet) if sheet_created else None,
      'allowed_roi':list(allowed_roi) if allowed_roi else None,'sampled':data,'max_fraction_outside_roi_delta_gt20':round(maxchg,4),
      'media_checks':checks,'verdict':verdict,'limitations':['有损转码也会产生像素差','物体不漂移/物理正确/身份一致不能仅由此判定',
      '不得把数值PASS理解为电影级验收通过']}
    jwrite(out,result);print('审计：'+verdict+'，'+str(out));return result

def validate_arrow(jobpath,out):
    j=json.loads(jobpath.read_text(encoding='utf-8'))
    ev=j.get('release_t');samples=j.get('samples',[])
    problems=[]
    if not isinstance(ev,(int,float)) or not math.isfinite(ev) or ev<=0:problems.append('release_t须为正数')
    if len(samples)<3:problems.append('至少3个采样，包含释放前与释放后')
    prev=-1;before=0;after=0
    for s in samples:
        t=s.get('t',-1)
        if not isinstance(t,(int,float)) or not math.isfinite(t) or t<=prev:problems.append('采样时间必须严格递增');break
        prev=t
        if ev and t<ev:
            before+=1
            if 'nock' in s and 'string' in s:
                dis=math.dist(s['nock'],s['string'])
                if dis>.04:problems.append(f'{t}s 箭尾脱离搭箭点：距离{dis:.3f}画面对角单位（仅归一化坐标）')
            else:problems.append(f'{t}s 无nock或string锚点，无法核验接触')
        elif ev and t>=ev:after+=1
    if before<1 or after<1:problems.append('缺少释放前或释放后样本')
    flights=[s for s in samples if ev and s.get('t',0)>ev and 'nock' in s]
    if len(flights)>=2:
        a,b=flights[0],flights[-1]
        dt=b['t']-a['t'];vx=(b['nock'][0]-a['nock'][0])/dt;vy=(b['nock'][1]-a['nock'][1])/dt
        if math.hypot(vx,vy)<.03:problems.append('释放后箭尾位移过小：疑似箭矢粘在手上')
        if 'aim_direction' in j:
            ax,ay=j['aim_direction'];norm=math.hypot(ax,ay)
            if norm<1e-6:problems.append('瞄准方向零向量')
            elif (vx*ax+vy*ay)/(norm*max(1e-6,math.hypot(vx,vy)))<.82:
                problems.append('释放后投影轨迹与瞄准方向相差超过约35度')
    else:problems.append('释放后至少需要2个含nock坐标的飞行样本')
    r={'schema':'shotpatch.arrow_check.v2','status':'FAIL' if problems else 'ANNOTATION_PASS_NOT_VISUAL',
      'problems':problems,'limits':'仅核对人工/外部算法标注的时间和2D接触与飞行方向，不构成真实射箭动力学或镜头物理验收。'}
    jwrite(out,r);print(r['status']);return r

def build_release_demo(folder):
    """Publicly safe graphics demo, illustrative not photoreal."""
    from PIL import Image,ImageDraw
    cv2,np=cvmods();folder.mkdir(parents=True,exist_ok=True)
    frames=[]
    for i in range(24):
        im=Image.new('RGBA',(160,160),(0,0,0,0));d=ImageDraw.Draw(im)
        dy=4*math.sin(i/3)
        sway=6*math.sin(i/5)
        # Original illustrative flame shape, not a realistic fire simulation.
        outer=[(35+sway,139),(34+sway,112),(48+sway,84),(47+sway,59),
               (68+sway,76),(83+sway,30+dy),(85+sway,70),
               (102+sway,66),(112+sway,103),(104+sway,139)]
        d.polygon(outer,fill=(246,121,31,210))
        core=[(54+sway,138),(51+sway,113),(64+sway,95),
              (79+sway,62+dy),(83+sway,99),(93+sway,116),(91+sway,138)]
        d.polygon(core,fill=(255,213,81,225))
        d.ellipse((63+sway,116,84+sway,140),fill=(235,245,180,230))
        p=folder/f'flame_{i:03}.png';im.save(p);frames.append(p.name)
    mask=Image.new('L',(640,360),0);d=ImageDraw.Draw(mask);d.rectangle((0,0,36,360),fill=255);mask.save(folder/'foreground_mask.png')
    light=Image.new('L',(640,360),0);d=ImageDraw.Draw(light);d.ellipse((140,40,550,350),fill=170);light.save(folder/'light_mask.png')
    print('已生成24帧示意动画素材与遮挡/照明mask（非真实火焰）')
    return frames

def normalize(video,out,fps=24):
    """Normalize phone/VFR/rotated source to a new CFR timeline. Re-check sync after encoding."""
    info=engine.inspect_video(video);engine.verify_bin('ffmpeg');ensure_sdr_8bit(info)
    if out.resolve()==video.resolve() or out.exists():fail('绝不覆盖原视频或已存在输出')
    if fps not in (12,15,24,25,30,48,50,60):fail('输出帧率只支持12/15/24/25/30/48/50/60')
    out.parent.mkdir(parents=True,exist_ok=True)
    vf=f'fps={fps},scale=trunc(iw/2)*2:trunc(ih/2)*2:flags=lanczos,setsar=1'
    args=['ffmpeg','-hide_banner','-loglevel','error','-nostdin','-i',str(video),
      '-map','0:v:0','-map','0:a:0?', '-vf',vf,'-fps_mode:v','cfr',
      '-c:v','libx264','-crf','17','-preset','medium','-pix_fmt','yuv420p',
      '-c:a','aac','-b:a','192k','-movflags','+faststart',str(out)]
    p=subprocess.run(args,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
    if p.returncode:
        if out.exists():out.unlink()
        fail('标准化失败：'+p.stderr.decode('utf-8','replace')[-700:])
    check=engine.inspect_video(out)
    if abs(check['duration']-info['duration'])>max(.25,2/fps):
        out.unlink(missing_ok=True);fail('标准化后时长明显异常，拒绝交付')
    if check['rotation_degrees']!=0:out.unlink(missing_ok=True);fail('方向元数据未清除，拒绝交付')
    if info['audio'] and not check['audio']:out.unlink(missing_ok=True);fail('音频意外丢失，拒绝交付')
    print('标准化成功：'+str(out)+'，请人工播放检查音画同步（时间轴和取景可能被旋转规范化）。')
    return check

def validate_fire(jobpath,out):
    """Check manually annotated roof/fire/smoke screen-space anchors, never claims CFD."""
    j=json.loads(jobpath.read_text(encoding='utf-8'));frames=j.get('samples',[])
    errors=[]
    if not isinstance(frames,list) or len(frames)<3:errors.append('最少需要三个依次排序的标注帧')
    last_t=-1;smokes=[]
    for s in frames if isinstance(frames,list) else []:
        if not isinstance(s,dict):errors.append('标注帧必须是对象');continue
        t=s.get('t')
        if not isinstance(t,(float,int)) or not math.isfinite(t) or t<=last_t:
            errors.append('时间必须单调递增且有效');continue
        last_t=t
        roof=s.get('roof_anchor');base=s.get('flame_base');smoke=s.get('smoke_center')
        try:
            if not all(isinstance(v,(list,tuple)) and len(v)==2 and all(math.isfinite(float(z)) and 0<=float(z)<=1 for z in v) for v in (roof,base,smoke)):
                errors.append(f'{t}s 坐标必须为归一化2D点');continue
            if math.dist(roof,base)>.035:errors.append(f'{t}s 火焰根部与屋顶接触点不符，可能漂浮')
            smokes.append((t,*smoke))
        except (ValueError,TypeError):errors.append(f'{t}s 坐标不合法')
    # Clouds may drift; test only impossible abrupt jumps in screen space, with human-provided anchors.
    for a,b in zip(smokes,smokes[1:]):
        dt=b[0]-a[0]
        if dt and math.hypot(b[1]-a[1],b[2]-a[2])/dt>2.5:
            errors.append(f'{b[0]}s 烟团屏幕速度异常，可能是跳帧或标注错误')
    status='ANNOTATION_PASS_NOT_CFD' if not errors else 'FAIL'
    data={'schema':'shotpatch.fire_check.v2','status':status,'problems':errors,
      'limits':'只测试人工标注的火焰根部/烟团2D连续性，不能模拟热流、风场、物理燃烧，不能证明烟颜色/环境光正确。'}
    jwrite(out,data);print(status);return data
