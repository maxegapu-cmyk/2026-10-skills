"""Offline stress suite: real encoded synthetic clips + deliberate negative cases."""
from __future__ import annotations
import json
import math
import pathlib
import subprocess
import sys
import tempfile
import unittest
ROOT=pathlib.Path(__file__).resolve().parents[1]
SCRIPTS=ROOT/'scripts'
sys.path.insert(0,str(SCRIPTS))
import vfx_modules as vfx
import engine
import cv2
import numpy as np
from PIL import Image,ImageDraw

class TestV2(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp=tempfile.TemporaryDirectory(prefix='shotpatch_中文_')
        cls.base=pathlib.Path(cls.temp.name)
        W,H=192,108;cls.W=W;cls.H=H
        # 3 seconds, 12fps; textured target walks to the right at 2px/frame.
        for name,night,with_cut in [('移动场景',False,False),('黑暗场景',True,False),('切镜场景',False,True)]:
            filename=cls.base/f'{name}_raw.mp4'
            wr=cv2.VideoWriter(str(filename),cv2.VideoWriter_fourcc(*'mp4v'),12,(W,H))
            for i in range(36):
                col=(28,42,54) if night else (80,100,120)
                frame=np.zeros((H,W,3),np.uint8);frame[:]=col
                if with_cut and i>=18: frame[:]=(185,180,160)
                x=20+i*2
                cv2.rectangle(frame,(x,34),(x+35,69),(50,80,220),-1)
                for k in range(6):
                    cv2.circle(frame,(x+5+k*4,37+k*3),2,(0,255,255),-1)
                wr.write(frame)
            wr.release()
            setattr(cls,{'移动场景':'source','黑暗场景':'night','切镜场景':'cut'}[name],filename)
        # add AAC audio to main source for muxing tests
        out=cls.base/'原片_有声音.mp4'
        p=subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-i',str(cls.source),'-f','lavfi','-i',
          'sine=frequency=340:sample_rate=44100:duration=3','-c:v','copy','-c:a','aac','-shortest',str(out)],capture_output=True)
        if p.returncode:raise RuntimeError(p.stderr)
        cls.audio=out
        cls.png=cls.base/'高亮道具.png';im=Image.new('RGBA',(38,38),(0,0,0,0));d=ImageDraw.Draw(im)
        d.ellipse((3,3,34,34),fill=(255,245,40,245));im.save(cls.png)
        cls.frames=[]
        for name,col in [('a',(255,0,0,255)),('b',(0,255,0,255))]:
            p=cls.base/(name+'.png');Image.new('RGBA',(38,38),col).save(p);cls.frames.append(p)
        oc=Image.new('L',(W,H),0);d=ImageDraw.Draw(oc);d.rectangle((0,0,W//2,H),fill=255)
        cls.oc=cls.base/'oc.png';oc.save(cls.oc)
        cls.light=cls.base/'light.png';Image.new('L',(W,H),255).save(cls.light)
    @classmethod
    def tearDownClass(cls):cls.temp.cleanup()
    def cli(self,*args,ok=True):
        p=subprocess.run([sys.executable,str(SCRIPTS/'shotpatch.py'),*map(str,args)],capture_output=True,text=True,timeout=40)
        if ok and p.returncode:
            self.fail(' '.join(map(str,args))+'\n'+p.stderr+'\n'+p.stdout)
        return p
    def job(self,name,layers,source=None):
        file=self.base/(name+'.json')
        j={'schema':'shotpatch.overlay.v2','video':str(source or self.audio),'output':name+'.mp4','layers':layers}
        file.write_text(json.dumps(j,ensure_ascii=False),encoding='utf-8')
        return file
    def layer(self,**change):
        val={'name':'arrow','png':str(self.png),'visible_from':0,'visible_until':3,
          'keyframes':[{'t':0,'x':.35,'y':.48,'width':.2,'degrees':0,'opacity':1},
                       {'t':3,'x':.65,'y':.48,'width':.2,'degrees':0,'opacity':1}]}
        val.update(change)
        return val

    def test_01_doctor(self):self.assertIn('2.0',self.cli('doctor').stdout)
    def test_02_analyze_light(self):
        a=vfx.analyze(self.audio,self.base/'light_scene.json')
        self.assertGreater(a['visual_estimates']['median_luma_0_255'],65)
        self.assertEqual(a['sampled_frames'],6)
    def test_03_analyze_night(self):
        a=vfx.analyze(self.night,self.base/'night.json')
        self.assertIn('暗场',a['visual_estimates']['ambience_hint'])
    def test_04_scene_cut_candidate(self):
        a=vfx.analyze(self.cut,self.base/'cut_scene.json')
        self.assertTrue(a['visual_estimates']['possible_cut_times_seconds'])
    def test_05_scene_hash_binding(self):
        a=vfx.analyze(self.audio,self.base/'sha.json')
        self.assertEqual(a['source_sha256'],vfx.sig(self.audio))
    def test_06_route_strict_arrow(self):
        r=vfx.route('arrow','strict','unknown',self.base/'r.json',video=self.audio)
        self.assertEqual(r['first_choice'],'local_composite')
        self.assertFalse(r['model_capabilities']['seedance25']['connected'])
    def test_07_route_flexible_google(self):
        r=vfx.route('fire','flexible','omni_api',self.base/'r2.json',video=self.audio)
        self.assertEqual(r['suggested_action'],'manual_platform')
    def test_08_seedance_length_block(self):
        r=vfx.route('fire','flexible','seedance25',self.base/'blocked.json',video=self.audio)
        self.assertEqual(r['suggested_action'],'blocked_until_trimmed')
    def test_09_track_moving_anchor(self):
        r=vfx.track(self.source,(20,34,35,35),self.base/'trace.json',threshold=.5)
        self.assertEqual(r['quality'],'automatic_candidate_not_certified')
        last=r['samples'][-1]
        self.assertGreater(last['x'],.55)
        self.assertLess(abs(last['x']-((20+35*2+17.5)/192)),.08)
    def test_10_track_reject_bad_box(self):
        with self.assertRaises(SystemExit):vfx.track(self.source,(190,20,60,15),self.base/'badtrack.json')
    def test_11_track_reject_bad_threshold(self):
        with self.assertRaises(SystemExit):vfx.track(self.source,(20,34,35,35),self.base/'badthres.json',2)
    def test_12_multilayer_render_and_audio(self):
        l1=self.layer();l2=self.layer(png=str(self.frames[1]),visible_from=1,visible_until=2, keyframes=[{'t':0,'x':.7,'y':.5,'width':.1,'degrees':15,'opacity':.4}])
        job=self.job('multi', [l1,l2]);r=vfx.composite(job)
        self.assertTrue(r['audio']);self.assertTrue((self.base/'multi.mp4').exists())
        self.assertLess(abs(r['duration']-3),.3)
    def test_13_sequence_render(self):
        layer=self.layer();layer.pop('png');layer['sequence']=[str(x) for x in self.frames];layer['sequence_fps']=1
        r=vfx.composite(self.job('sequence',[layer]));self.assertTrue((self.base/'sequence.mp4').exists())
        cap=cv2.VideoCapture(str(self.base/'sequence.mp4'));cap.set(cv2.CAP_PROP_POS_MSEC,250);_,a=cap.read()
        cap.set(cv2.CAP_PROP_POS_MSEC,1500);_,b=cap.read();cap.release()
        self.assertIsNotNone(a);self.assertIsNotNone(b)
        self.assertGreater(float(np.mean(np.abs(a.astype(float)-b.astype(float)))),.5)
    def test_14_foreground_occlusion(self):
        lay=self.layer(occlusion_png=str(self.oc),keyframes=[{'t':0,'x':.45,'y':.48,'width':.4,'degrees':0,'opacity':1}])
        vfx.composite(self.job('with_mask',[lay]))
        cap0=cv2.VideoCapture(str(self.audio));cap1=cv2.VideoCapture(str(self.base/'with_mask.mp4'))
        ok,a=cap0.read();ok2,b=cap1.read();cap0.release();cap1.release()
        self.assertTrue(ok and ok2)
        # Original foreground still visible (within lossy encode tolerance).
        self.assertLess(np.abs(a[:,30:65].astype(float)-b[:,30:65].astype(float)).mean(),7)
        self.assertGreater(np.abs(a[:,108:115].astype(float)-b[:,108:115].astype(float)).mean(),1)
    def test_15_firelight_mask(self):
        layer=self.layer(glow={'strength':.2,'radius_px':15,'bgr':[20,100,255]},light_mask=str(self.light))
        vfx.composite(self.job('glow',[layer]));self.assertTrue((self.base/'glow.mp4').exists())
    def test_16_glow_requires_lightmask(self):
        with self.assertRaises(SystemExit):vfx.composite(self.job('no_light',[self.layer(glow={'strength':.5})]))
    def test_17_occlusion_wrong_size_rejected(self):
        wrong=self.base/'smallmask.png';Image.new('L',(60,40),255).save(wrong)
        with self.assertRaises(SystemExit):vfx.composite(self.job('wrongmask',[self.layer(occlusion_png=str(wrong))]))
    def test_18_sequence_mismatch_rejected(self):
        l=self.layer(sequence=[str(x) for x in self.frames],occlusion_sequence=[str(self.oc)]);l.pop('png')
        with self.assertRaises(SystemExit):vfx.composite(self.job('wrongseq',[l]))
    def test_19_no_mutation_source(self):
        old=vfx.sig(self.audio)
        vfx.composite(self.job('immutability',[self.layer()]))
        self.assertEqual(old,vfx.sig(self.audio))
    def test_20_overwrite_source_rejected(self):
        with self.assertRaises(SystemExit):vfx.composite(self.job('overwrite',[self.layer()]),self.audio)
    def test_21_repeated_output_rejected(self):
        with self.assertRaises(SystemExit):vfx.composite(self.base/'immutability.json')
    def test_22_audit_background_unchanged_numeric(self):
        r=vfx.audit(self.audio,self.audio,self.base/'exact.json',(.2,.2,.4,.4))
        self.assertEqual(r['verdict'],'NUMERIC_PASS_REQUIRES_VISUAL')
    def test_23_audit_unrequested_wholeframe_change(self):
        r=vfx.audit(self.audio,self.base/'multi.mp4',self.base/'notpreserved.json',(.0,.0,.04,.04))
        self.assertEqual(r['verdict'],'REVIEW_NEEDED')
    def test_24_audit_bad_roi(self):
        with self.assertRaises(SystemExit):vfx.audit(self.audio,self.audio,self.base/'badroi.json',(0.8,.1,.5,.4))
    def test_25_missing_asset_rejected(self):
        with self.assertRaises(SystemExit):vfx.composite(self.job('missing',[self.layer(png='notexist.png')]))
    def test_26_invalid_rotation_scale_rejected(self):
        with self.assertRaises(SystemExit):vfx.composite(self.job('huge',[self.layer(keyframes=[{'t':0,'x':.5,'y':.5,'width':4,'degrees':89,'opacity':1}])]))
    def test_27_physics_valid_arrow_anchors(self):
        job={'release_t':1,'aim_direction':[1,0], 'samples':[
         {'t':0,'nock':[.2,.5],'string':[.2,.5]}, {'t':.8,'nock':[.25,.5],'string':[.25,.5]},
         {'t':1.1,'nock':[.35,.5]},{'t':1.3,'nock':[.6,.5]}]}
        p=self.base/'physics.json';p.write_text(json.dumps(job))
        self.assertEqual(vfx.validate_arrow(p,self.base/'physics_check.json')['status'],'ANNOTATION_PASS_NOT_VISUAL')
    def test_28_physics_wrong_direction(self):
        job={'release_t':1,'aim_direction':[1,0], 'samples':[
         {'t':0,'nock':[.2,.5],'string':[.2,.5]}, {'t':.9,'nock':[.2,.5],'string':[.2,.5]},
         {'t':1.1,'nock':[.35,.5]},{'t':1.2,'nock':[.25,.5]}]}
        p=self.base/'wrong_phys.json';p.write_text(json.dumps(job))
        self.assertEqual(vfx.validate_arrow(p,self.base/'wrong_physics_check.json')['status'],'FAIL')
    def test_29_physics_missing_release(self):
        p=self.base/'no_event.json';p.write_text(json.dumps({'samples':[]}))
        self.assertEqual(vfx.validate_arrow(p,self.base/'no_event_out.json')['status'],'FAIL')
    def test_30_demo_animation_24(self):
        files=vfx.build_release_demo(self.base/'public_demo')
        self.assertEqual(len(files),24)
        self.assertTrue((self.base/'public_demo'/'foreground_mask.png').exists())
    def test_31_unicode_paths_cli(self):
        o=self.base/'输出_房屋_中文.json';self.cli('analyze','--video',self.audio,'--out',o)
        self.assertTrue(o.exists())
    def test_32_corrupt_media(self):
        bad=self.base/'损坏.mp4';bad.write_bytes(b'\x00fake_video')
        p=self.cli('analyze','--video',bad,'--out',self.base/'corrupt.json',ok=False)
        self.assertNotEqual(p.returncode,0)
    def test_33_prepare_end_to_end(self):
        # prepare gives model fit + scene + image + immutable source reference.
        out=self.base/'analyze_prepare'
        self.cli('prepare','--video',self.audio,'--task','fire','--out',out)
        for name in ('编辑指令.md','场景体检.json','场景体检.md','模型路由.json','镜头抽帧.png','job.json'):
            self.assertTrue((out/name).exists(),name)
        self.assertEqual(json.loads((out/'job.json').read_text())['status'],'design_ready_not_rendered')
    def test_34_mask_no_copy_thirdparty(self):
        j=self.base/'analyze_prepare'/'job.json'
        if not j.exists():self.cli('prepare','--video',self.audio,'--task','fire','--out',self.base/'analyze_prepare')
        self.assertFalse(json.loads(j.read_text())['upload_approved'])

    def test_35_normalize_cfr_and_audio(self):
        dest=self.base/'normalized_24fps.mp4'
        self.cli('normalize','--video',self.audio,'--fps',24,'--out',dest)
        inf=engine.inspect_video(dest)
        self.assertLess(abs(inf['fps']-24),.01)
        self.assertTrue(inf['audio'])
        self.assertLess(abs(inf['duration']-3),.2)
    def test_36_normalize_never_overwrites(self):
        old=vfx.sig(self.audio)
        p=self.cli('normalize','--video',self.audio,'--fps',24,'--out',self.audio,ok=False)
        self.assertNotEqual(p.returncode,0)
        self.assertEqual(old,vfx.sig(self.audio))
    def test_37_vertical_video_analyze(self):
        path=self.base/'vertical.mp4'
        v=cv2.VideoWriter(str(path),cv2.VideoWriter_fourcc(*'mp4v'),12,(108,192))
        for i in range(12):v.write(np.full((192,108,3),(80,95,120),np.uint8))
        v.release();r=vfx.analyze(path,self.base/'vertical.json')
        self.assertEqual(r['source']['height'],192)
    def test_38_hdr_guard_10bit_input(self):
        v=dict(engine.inspect_video(self.audio));v['pixel_fmt']='yuv420p10le'
        with self.assertRaises(SystemExit):vfx.ensure_sdr_8bit(v)
    def test_39_fire_valid_roof_lock(self):
        p=self.base/'fire_good.json'
        p.write_text(json.dumps({'samples':[{'t':i,'roof_anchor':[.5,.4],'flame_base':[.501,.401],'smoke_center':[.5,.35-.1*i]} for i in [0,1,2]]}))
        self.assertEqual(vfx.validate_fire(p,self.base/'fire_ok.json')['status'],'ANNOTATION_PASS_NOT_CFD')
    def test_40_fire_root_float_rejected(self):
        p=self.base/'fire_bad.json'
        p.write_text(json.dumps({'samples':[{'t':i,'roof_anchor':[.5,.4],'flame_base':[.7,.7],'smoke_center':[.5,.3]} for i in [0,1,2]]}))
        self.assertEqual(vfx.validate_fire(p,self.base/'fire_fail.json')['status'],'FAIL')
    def test_41_ambient_style_match_render(self):
        j=self.job('ambient',[self.layer(style_match={'mode':'ambient','strength':.5,'blur_px':1})])
        self.assertTrue(vfx.composite(j)['duration']>2.9)
    def test_42_invalid_style_params(self):
        with self.assertRaises(SystemExit):vfx.composite(self.job('stylebad',[self.layer(style_match={'mode':'ambient','strength':4})]))
    def test_43_audio_sync_probe_same(self):
        q=vfx.audio_sync_probe(self.audio,self.audio)
        self.assertEqual(q['status'],'PROBABLE_SYNC')
        self.assertLess(abs(q['offset_proxy_seconds']),.01)
    def test_44_different_audio_streams_flag(self):
        q=vfx.audit(self.audio,self.source,self.base/'different_audio.json')
        self.assertEqual(q['audio_sync_proxy']['status'],'AUDIO_PRESENCE_MISMATCH')
    def test_45_modelcards_7_providers(self):
        from model_handoff import handoff
        scene=vfx.analyze(self.audio,self.base/'modelscene.json')
        handoff('arrow','弓弦2秒释放','保留背景和人脸',scene,self.base/'model_cards')
        names=[x.name for x in (self.base/'model_cards').glob('*.md')]
        self.assertEqual(len(names),7)
        self.assertIn('Interactions', (self.base/'model_cards'/'google_omni_api.md').read_text())
    def test_46_veo_not_wrongly_routed_as_editor(self):
        self.assertEqual(vfx.CAPABILITIES['veo31']['connected'],False)
        from model_handoff import PLATFORMS
        self.assertEqual(PLATFORMS['google_veo']['video_edit'],'not_generic_source_edit')
    def test_47_real_model_access_not_assumed(self):
        data=json.loads((self.base/'model_cards'/'平台能力清单.json').read_text()) if (self.base/'model_cards').exists() else None
        if data is None:
            from model_handoff import PLATFORMS;data=PLATFORMS
        self.assertIn('yes_with_access',data['seedance25']['video_edit'])
    def test_48_prepare_modelcard_source_binding(self):
        d=self.base/'analyze_prepare'
        if not d.exists():self.cli('prepare','--video',self.audio,'--task','fire','--out',d)
        self.assertTrue((d/'各平台操作卡'/'google_omni_api.md').is_file())
    def test_49_isolated_package_import(self):
        # Running with -I disallows PYTHONPATH, relies on only packaged sibling modules.
        p=subprocess.run([sys.executable,'-I',str(SCRIPTS/'shotpatch.py'),'doctor'],capture_output=True,text=True)
        self.assertEqual(p.returncode,0,p.stderr)
    def test_50_dynamic_demo_mask_size(self):
        dst=self.base/'demo3';vfx.build_release_demo(dst)
        self.assertEqual(Image.open(dst/'light_mask.png').size,(640,360))
    def test_51_audio_audit_comparison_sheet(self):
        r=vfx.audit(self.audio,self.base/'multi.mp4',self.base/'sheet_report.json',(.1,.1,.5,.6)) if (self.base/'multi.mp4').exists() else None
        if r is None:self.skipTest('需要multilayer测试先生成')
        self.assertTrue(pathlib.Path(r['comparison_sheet_path']).exists())
    def test_52_no_internet_code_deps(self):
        # Core code only relies on local Python and installed libraries; no remote fetch or SDK calls.
        v=(SCRIPTS/'vfx_modules.py').read_text()
        self.assertNotIn('requests.post(',v)
        self.assertNotIn('api_key=',v)

if __name__=='__main__':unittest.main()
