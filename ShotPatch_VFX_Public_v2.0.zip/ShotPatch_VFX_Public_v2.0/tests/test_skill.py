import json
import pathlib
import subprocess
import sys
import tempfile
import unittest

ROOT=pathlib.Path(__file__).resolve().parents[1]
CLI=ROOT/'scripts'/'shotpatch.py'

class TestShotPatch(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp=tempfile.TemporaryDirectory()
        cls.base=pathlib.Path(cls.tmp.name)
        cls.video=cls.base/'input.mp4'
        # Explicit original synthetic video with audio; no copyrighted footage.
        p=subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-f','lavfi','-i',
            'color=c=0x447744:s=320x180:r=12:d=3', '-f','lavfi','-i','sine=frequency=440:sample_rate=44100:duration=3',
            '-c:v','libx264','-pix_fmt','yuv420p','-c:a','aac','-shortest',str(cls.video)],capture_output=True)
        if p.returncode:raise RuntimeError(p.stderr.decode('utf-8','replace'))
        from PIL import Image,ImageDraw
        im=Image.new('RGBA',(200,40),(0,0,0,0))
        draw=ImageDraw.Draw(im)
        draw.line((5,20,170,20),fill=(190,140,100,255),width=6)
        draw.polygon([(170,9),(195,20),(170,31)],fill=(200,205,218,255))
        cls.asset=cls.base/'arrow.png';im.save(cls.asset)

    @classmethod
    def tearDownClass(cls): cls.tmp.cleanup()

    def cmd(self,*a,ok=True):
        p=subprocess.run([sys.executable,str(CLI),*map(str,a)],capture_output=True,text=True)
        if ok and p.returncode!=0:
            self.fail(p.stdout+'\n'+p.stderr)
        return p

    def test_doctor(self):
        r=self.cmd('doctor')
        self.assertIn('ffmpeg',r.stdout)

    def test_prepare_and_assets(self):
        out=self.base/'plan'
        self.cmd('prepare','--video',self.video,'--task','arrow','--change','给弓补箭','--out',out)
        self.assertTrue((out/'镜头抽帧.png').is_file())
        j=json.loads((out/'job.json').read_text(encoding='utf-8'))
        self.assertEqual(j['task'],'arrow')
        self.assertFalse(j['upload_approved'])
        self.assertIn('exactly ONE', (out/'编辑指令.md').read_text(encoding='utf-8'))
        self.assertEqual(j['source']['audio'],True)

    def test_render_and_review_with_audio(self):
        job={'schema':'shotpatch.overlay.v1','video':str(self.video),'png':str(self.asset),
            'output':'rendered.mp4','visible_from':0.0,'visible_until':3.0,
            'keyframes':[{'t':0,'x':0.30,'y':0.5,'width':0.3,'degrees':0,'opacity':1},
                         {'t':3,'x':0.8,'y':0.5,'width':0.3,'degrees':0,'opacity':1}]}
        p=self.base/'overlay.json';p.write_text(json.dumps(job),encoding='utf-8')
        self.cmd('render','--job',p)
        output=self.base/'rendered.mp4'
        self.assertTrue(output.is_file())
        report=self.base/'report.json'
        self.cmd('review','--source',self.video,'--result',output,'--out',report)
        data=json.loads(report.read_text(encoding='utf-8'))
        self.assertTrue(data['checks']['resolution_equal'])
        self.assertTrue(data['checks']['result_audio_present'])
        self.assertTrue(data['checks']['duration_near'])
        # Verify actual decoded pixel in overlay region changed meaningfully.
        import cv2,numpy as np
        ca=cv2.VideoCapture(str(self.video));cb=cv2.VideoCapture(str(output))
        ca.set(cv2.CAP_PROP_POS_FRAMES,15);cb.set(cv2.CAP_PROP_POS_FRAMES,15)
        a,fa=ca.read();b,fb=cb.read()
        ca.release();cb.release()
        self.assertTrue(a and b)
        self.assertGreater(float(np.mean(np.abs(fa.astype(np.float32)-fb.astype(np.float32)))),2)

    def test_render_validation_rejects_bad_and_no_overwrite(self):
        job={'schema':'shotpatch.overlay.v1','video':str(self.video),'png':str(self.asset),
            'output':str(self.video),'keyframes':[{'t':0,'x':0.5,'y':0.5,'width':.1,'degrees':0,'opacity':1}]}
        p=self.base/'bad.json';p.write_text(json.dumps(job),encoding='utf-8')
        r=self.cmd('render','--job',p,ok=False)
        self.assertNotEqual(r.returncode,0)
        self.assertIn('不能覆盖原视频',r.stderr)
        job['keyframes']=[{'t':2,'x':0.5,'y':0.5,'width':.1,'degrees':0,'opacity':1},{'t':1,'x':0.5,'y':0.5,'width':.1,'degrees':0,'opacity':1}]
        p.write_text(json.dumps(job),encoding='utf-8')
        r=self.cmd('render','--job',p,ok=False)
        self.assertIn('非法关键帧',r.stderr)

    def test_missing_video(self):
        p=self.cmd('prepare','--video',self.base/'missing.mp4','--out',self.base/'none',ok=False)
        self.assertNotEqual(p.returncode,0)
        self.assertIn('视频文件不存在',p.stderr)

if __name__=='__main__':unittest.main()
