@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
 echo 请先双击 INSTALL_安装依赖.bat
 pause
 exit /b 1
)
if exist "examples\demo_edited.mp4" (
  echo 已经生成过 examples\demo_edited.mp4。为了不覆盖已有结果，请先重命名原文件。
) else (
  .venv\Scripts\python.exe scripts\shotpatch.py render --job "examples\demo_overlay.json"
)
pause
