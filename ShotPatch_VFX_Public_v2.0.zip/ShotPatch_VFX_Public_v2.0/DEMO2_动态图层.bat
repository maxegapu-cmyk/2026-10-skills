@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
 echo 先双击 INSTALL_安装依赖.bat。
 pause
 exit /b 1
)
if exist "examples\demo_v2_result.mp4" (
 echo 已有examples\demo_v2_result.mp4，工具不会覆盖。请先重命名旧输出。
) else (
 .venv\Scripts\python.exe scripts\shotpatch.py render --job examples\demo_v2_overlay.json
)
if not exist "examples\arrow_event_test.json" (
 .venv\Scripts\python.exe scripts\shotpatch.py check-arrow --job examples\arrow_annotations.json --out examples\arrow_event_test.json
)
pause
