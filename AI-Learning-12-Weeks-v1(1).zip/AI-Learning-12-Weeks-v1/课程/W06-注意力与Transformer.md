# W06：注意力、Transformer 与多模态

[返回目录](../README.md) · [进度](../01-学习进度.md) · [下一周](W07-后训练与内容实验.md)

本周约 9 小时。目标：用小矩阵理解注意力，能跟踪 Transformer 的主要信息流；为图像生成建立一个初步概念。

## A｜谁应该参考谁，2.5 小时

一句话中的一个位置如何使用其他位置的信息？注意力计算一种依赖当前表示的加权汇总。

Q 是 query，K 是 key，V 是 value。直觉上，Q 用于提出匹配需求，K 用于被匹配，V 提供被汇总的信息。这是帮助理解计算的类比，不说明网络里每个向量都有固定、可读的人类含义。

计算分三步：Q 与 K 做点积得到分数；用 softmax 转成权重；根据权重汇总 V。标准缩放点积形式为 softmax(QK^T/sqrt(d_k))V。缩放帮助控制维度增加时分数尺度。

若 Q 的形状为 n×d_k，K 也是 n×d_k，则 QK^T 是 n×n，每个位置对每个位置一个分数。V 为 n×d_v，最后结果为 n×d_v。

自回归模型预测下一 token 时，训练中的位置不能看未来答案，因此通常需要因果遮罩。注意力以外，Transformer 还有位置相关信息、前馈层、残差连接和归一化。多头注意力允许多组表示进行汇总。

训练可并行计算许多位置的损失；自回归生成则通常逐步产生后续 token。这解释了训练与生成在计算流程上的一个区别。

## B｜手算再运行，3 小时

```python
import math

q = [1.0, 0.0]
keys = [[1.0, 0.0], [0.0, 1.0]]
values = [[10.0, 0.0], [0.0, 20.0]]

def softmax(scores):
    peak = max(scores)
    exps = [math.exp(s-peak) for s in scores]
    return [x/sum(exps) for x in exps]

scores = [sum(a*b for a,b in zip(q,k))/math.sqrt(len(q)) for k in keys]
weights = softmax(scores)
output = [sum(w*v[j] for w,v in zip(weights,values)) for j in range(2)]
print("分数", scores)
print("权重", weights, "和", sum(weights))
print("汇总", output)
```

先估计哪项权重更大，再运行。将 q 改为 [0,1]，只改变查询，观察输出。再把第二项分数设成负无穷，模拟遮罩；解释其权重为什么为零。

接着打开 [Zero to Hero](https://github.com/karpathy/nn-zero-to-hero) 的 Lecture 7 配套材料。限时 90 分钟，定位 embedding、attention、feed-forward、loss、generate 五处即可。先画形状，不要求从零训练完整 GPT。

## C｜多模态探索与复盘，3.5 小时

项目／探索 2 小时：前一小时把工作台输入中的文本、图片、数值表格列出来，说明哪些信息可能从图中观察到，哪些需要其他来源。图片中看不见的材质、认证和容量不能当作事实。

后一小时读 [Diffusion Course Unit 1](https://huggingface.co/learn/diffusion-course/unit1/1) 的入门部分。基本直觉：训练中构造不同噪声程度的样本，学习相应去噪任务；生成中从噪声出发逐步得到样本。文本或图像条件可以影响生成，但不保证真实产品细节自动保持。

用已有图像工具做一个小对照，或直接分析已有生成图片：固定产品参考与主要描述，只改变背景，检查形状、数量、文字和比例。记录实际模型与设置；如无法固定种子，注明。没有工具时做检查表即可，不新增订阅。

阅读 0.5 小时：[Attention Is All You Need](https://arxiv.org/abs/1706.03762) 的模型图和注意力公式。经典论文最初研究的任务范围，与今天所有模型的范围不同。

复盘 1 小时：给非技术同事解释注意力；列出你还不理解的两处；说明漂亮生成图与真实商品一致性是两个评测目标。

## 作业与验收

交：注意力手算和修改实验、Transformer 信息流草图、输入输出形状、图像一致性检查。

验收：知道注意力不是凭空“理解真相”；知道模型需要哪些其他组件；能解释遮罩为什么存在。扩展阅读 [CS336](https://cs336.stanford.edu/) 的相关讲座，仅按问题选段。
