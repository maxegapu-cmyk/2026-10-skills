# Skill Sentinel v1.0.0（安全哨兵）

面向 Codex / Claude Code 的**离线只读 Agent Skill 安全初筛 Skill**。Python 3.9+，纯标准库，不依赖 API Key、不联网、不下载、不运行被审技能。

**下载包结构**

```text
skill-sentinel/
├── SKILL.md
├── README.md
├── scripts/scan.py
└── references/REVIEW_GUIDE.md
```

## 安装

先将 ZIP 解压至临时目录，查看 `SKILL.md` 与 `scripts/scan.py`。确认接受后，把**整个 `skill-sentinel` 文件夹**复制到你使用的平台技能目录：

- Codex（用户级）：`~/.agents/skills/skill-sentinel/`
- Claude Code（用户级）：`~/.claude/skills/skill-sentinel/`
- Codex（项目级）：`<项目根>/.agents/skills/skill-sentinel/`
- Claude Code（项目级）：`<项目根>/.claude/skills/skill-sentinel/`

Windows 下 `~` 指 `%USERPROFILE%`（即 PowerShell 的 `$HOME`）。若你使用两个平台，就把同一文件夹复制到两个位置；不要创建软链接让扫描器盲信外部路径。自动检测不到时可重启 agent。

## 不经 Agent，直接扫描更安全

Windows PowerShell：

```powershell
py -3 "$HOME\.agents\skills\skill-sentinel\scripts\scan.py" --installed
py -3 "$HOME\.agents\skills\skill-sentinel\scripts\scan.py" "D:\Downloads\example-skill.zip"
```

macOS / Linux：

```bash
python3 "$HOME/.agents/skills/skill-sentinel/scripts/scan.py" --installed
python3 "$HOME/.agents/skills/skill-sentinel/scripts/scan.py" "$HOME/Downloads/example-skill.zip"
```

或在 Codex / Claude Code 中对助理说：**“使用 skill-sentinel 审计我已安装的所有本地 Skill，只做只读检测，不修改任何东西，按严重度列证据。”**

## 报告、追踪变更

在脚本所在目录外指定不冲突的报告路径：

```bash
python scripts/scan.py --installed --json "./audit-2026-10-25.json"
python scripts/scan.py --installed --snapshot "./snapshot-v1.json"
python scripts/scan.py --installed --compare "./snapshot-v1.json"
```

`--snapshot` 记录本轮已读取文件的 SHA256，用于**以后的文件变化提示**，不会自动判断变化是否正常。最好在**人为确认通过之后**保存第一次基线。输出包含本地文件路径及代码片段提示，请勿直接公开报告。脚本默认不写任何文件，并拒绝将报告写进被扫描的技能目录、拒绝覆盖同名报告。

## 结果怎么理解

- `BLOCK_REVIEW`：出现 HIGH/CRITICAL，优先手动审查或暂缓启用。
- `MANUAL_REVIEW`：出现 MEDIUM 或扫描不完整。
- `LOW_RISK_SIGNALS`：只有 LOW 信号。
- `NO_FINDINGS_DETECTED`：未匹配已知规则；**不是“已验证安全”。**

注意：本工具不是杀毒软件，不是完整沙箱，不自动做 CVE 漏洞数据库查询；它可以发现部分明显的危险执行、私货、Prompt Injection 及供应链线索，无法从静态文本证明恶意与否。对于需要商业部署或高权限的技能，建议在用户授权后再用独立的静态/语义引擎交叉审查。
