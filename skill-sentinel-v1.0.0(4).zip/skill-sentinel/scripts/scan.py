#!/usr/bin/env python3
"""Skill Sentinel: offline, read-only, bounded static scanner for Agent Skills.

Python >=3.9. No third-party dependencies, subprocess execution, downloads or dynamic imports.
This is a best-effort triage tool, not a security guarantee.
"""
from __future__ import annotations

import argparse
import base64
import ast
import hashlib
import io
import json
import os
import re
import stat
import sys
import zipfile
from collections import Counter
from pathlib import Path
from typing import Any

VERSION = "1.0.0"
MAX_FILE = 2 * 1024 * 1024
MAX_ARCHIVE_UNCOMPRESSED = 50 * 1024 * 1024
MAX_ARCHIVE_ENTRIES = 2000
MAX_NESTED_DEPTH = 1
TEXT_EXT = {".md", ".txt", ".yaml", ".yml", ".json", ".toml", ".ini", ".xml",
            ".py", ".sh", ".bash", ".zsh", ".fish", ".ps1", ".bat", ".cmd",
            ".js", ".ts", ".mjs", ".cjs", ".rb", ".pl", ".cfg", ".conf",
            ".env", ".sql", ".html", ".htm", ".csv", ".gitignore"}
INSTRUCTION_EXT = {".md", ".txt", ".yaml", ".yml", ".json", ".toml", ".xml"}
SCRIPT_EXT = {".sh", ".bash", ".zsh", ".fish", ".ps1", ".bat", ".cmd", ".js", ".ts", ".mjs", ".cjs"}
OPAQUE_EXT = {".exe", ".dll", ".so", ".dylib", ".node", ".pyc", ".pyd", ".jar", ".wasm", ".bin"}
UNINSPECTED_DOC = {".pdf", ".docx", ".pptx", ".xlsx"}
SEV_ORDER = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, "INFO": 4}
SENSITIVE = re.compile(r"(?i)(?:sk-[A-Za-z0-9_-]{18,}|gh[pousr]_[A-Za-z0-9_]{20,}|"
                       r"xox[baprs]-[A-Za-z0-9-]{18,}|AKIA[0-9A-Z]{16}|"
                       r"-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----)")
KV_SECRET = re.compile(r"(?i)\b(?:api[_-]?key|access[_-]?token|password|secret|authorization)\b\s*[:=]\s*['\"]?([^\s,'\"}]{8,})")
URL_CREDS = re.compile(r"(?i)(https?://)([^/@\s]+@)")

# These regexes are deliberately broad: a match is a REVIEW trigger, never proof of malice.
DOC_RULES = [
    ("PROMPT_PRIORITY_OVERRIDE", "HIGH", r"(?i)\b(?:ignore|disregard|override)\s+(?:all\s+)?(?:previous|prior|system|developer|safety)\s+(?:instructions?|rules?|polic(?:y|ies))\b|忽略.{0,20}(?:系统|开发者|上级|之前).{0,12}(?:指令|规则)|覆盖.{0,10}(?:系统|开发者).{0,10}(?:提示词|指令)", "Requests instruction-hierarchy override"),
    ("HIDE_FROM_USER", "HIGH", r"(?i)\b(?:do\s+not|don't|never)\s+(?:tell|inform|notify)\s+(?:the\s+)?user\b|(?:不要|禁止).{0,10}(?:告诉|通知|告知)用户|瞒着用户", "Requests concealment from user"),
    ("DISABLE_GUARDS", "HIGH", r"(?i)\bdisable\s+(?:audit(?:ing)?|security|logging|monitoring|safety)\b|(?:关闭|禁用|绕过).{0,12}(?:安全检查|审计日志|安全防护|防护机制)", "Requests security controls to be disabled"),
    ("SENSITIVE_DATA_TRANSFER", "HIGH", r"(?i)(?:\.ssh/id_rsa|\.aws/credentials|\.env|api[_-]?key|private[_-]?key|access[_-]?token|密钥|凭据|令牌).{0,90}(?:upload|send|post\b|exfiltrat|上传|发送|回传)|(?:upload|send|post\b|上传|发送).{0,90}(?:\.ssh/id_rsa|\.aws/credentials|\.env|private[_-]?key|密钥|凭据)", "Possible credential exfiltration instruction"),
    ("ROLE_SPOOFING", "MEDIUM", r"(?i)<\s*/?system\s*>|\[\s*im_start\s*\]\s*system|你现在是(?:系统|开发者)\b|\bSYSTEM MESSAGE\s*:", "Role or system-message impersonation"),
    ("SUPPLY_CHAIN_BOOTSTRAP", "MEDIUM", r"(?i)\b(?:pip|pip3|uv|npm|pnpm|yarn|npx)\b.{0,70}(?:git\+https?://|--extra-index-url|--pre\b|\-g\b|\-y\b)|(?:curl|wget)\b.{0,80}\.(?:whl|tar\.gz|deb|rpm)\b", "Installs dependencies from dynamic or elevated-trust sources"),
    ("AUTO_PRIVILEGE", "MEDIUM", r"(?i)(?:always|automatically)\s+(?:execute|run)\s+(?:as\s+root|sudo|on\s+startup|before\s+every)|(?:启动时|每次运行).{0,30}(?:自动执行|自动运行)|(?:无需|不必).{0,6}(?:用户确认|询问用户).{0,30}(?:执行|运行|上传|删除)", "Unexpected automatic privileged action"),
]
SHELL_RULES = [
    ("REMOTE_PIPE_EXEC", "CRITICAL", r"(?i)(?:curl|wget|iwr|invoke-webrequest)\b[^\r\n|]{0,250}\|\s*(?:(?:sudo\s+)?(?:sh|bash|zsh)\b|(?:iex|invoke-expression)\b)|\b(?:iex|invoke-expression)\b[^\r\n|]{0,80}\|\s*(?:iwr|invoke-webrequest)\b", "Direct remote code execution through a pipe"),
    ("ENCODED_EXEC", "HIGH", r"(?i)\b(?:powershell|pwsh)\b.{0,60}(?:-enc(?:odedcommand)?\b)|\bbase64\s+(?:-d|--decode)\b[^\r\n|]{0,80}\|\s*(?:bash|sh|python)\b", "Encoded/obfuscated command execution"),
    ("DANGEROUS_DELETE", "HIGH", r"(?i)\brm\s+-[a-zA-Z]*r[a-zA-Z]*f[a-zA-Z]*\s+(?:/\s*$|~/?\s*$|\$HOME\b|\.\./)|\b(?:del|remove-item)\b.{0,120}(?:-recurse\b.{0,30}-force|-force\b.{0,30}-recurse)", "Destructive recursive deletion"),
    ("SECURITY_DISABLER", "CRITICAL", r"(?i)Set-MpPreference\s+-DisableRealtimeMonitoring|(?:systemctl|service)\s+(?:stop|disable)\s+(?:auditd|falcon-sensor)|(?:ufw|iptables)\s+disable", "Explicit security-control disablement"),
    ("CREDENTIAL_UPLOAD", "HIGH", r"(?i)\b(?:curl|wget)\b.{0,150}(?:-d|--data|--data-binary|--upload-file|-F)\s+@?(?:[~./\\]*\.env\b|[~./\\]*\.ssh[/\\]id_rsa|[~./\\]*\.aws[/\\]credentials)", "Command appears to upload credential material"),
    ("REMOTE_COPY", "MEDIUM", r"(?i)\b(?:scp|rsync|sftp)\b.{0,120}(?:\.ssh|\.aws|\.env|credentials|id_rsa)", "Copies potentially sensitive credentials"),
    ("REMOTE_FETCH_EXEC", "MEDIUM", r"(?i)\b(?:curl|wget|invoke-webrequest)\b.{0,180}(?:install\.sh|setup\.sh|\.ps1|\.exe)\b", "Downloads executable or installer"),
]
SHELL_FILE = re.compile(r"(?i)(?:^|[\\/])(?:\.env(?:\..+)?|id_rsa|credentials|.*\.(?:pem|p12|pfx|key))$")
HIDDEN_CHARS = {"\u202a", "\u202b", "\u202d", "\u202e", "\u2066", "\u2067", "\u2068", "\u200b", "\u200c", "\u200d", "\ufeff"}


def safe_excerpt(value: str) -> str:
    value = value.replace("\r", " ").replace("\n", " ").replace("\t", " ")
    value = SENSITIVE.sub("[REDACTED_SECRET]", value)
    value = URL_CREDS.sub(r"\1[REDACTED_USERINFO]@", value)
    value = KV_SECRET.sub(lambda m: m.group(0).replace(m.group(1), "[REDACTED]"), value)
    return value[:180]


class Report:
    def __init__(self) -> None:
        self.findings: list[dict[str, Any]] = []
        self.files: dict[str, str] = {}
        self.skills: list[str] = []
        self.inspected = 0
        self.incomplete = False
        self._keys: set[tuple[str, str, str, int]] = set()

    def finding(self, rule: str, severity: str, target: str, detail: str,
                line: int = 0, evidence: str = "", confidence: str = "heuristic") -> None:
        key = (target, rule, severity, line)
        if key in self._keys:
            return
        self._keys.add(key)
        self.findings.append({"rule": rule, "severity": severity, "file": target,
                              "line": line, "detail": detail,
                              "evidence": safe_excerpt(evidence), "confidence": confidence})

    def gap(self, target: str, detail: str) -> None:
        self.incomplete = True
        self.finding("COVERAGE_GAP", "MEDIUM", target, detail)

    def result(self) -> dict[str, Any]:
        self.findings.sort(key=lambda f: (SEV_ORDER[f["severity"]], f["file"], f["line"], f["rule"]))
        counts = Counter(f["severity"] for f in self.findings)
        highest = min((SEV_ORDER[f["severity"]] for f in self.findings), default=5)
        verdict = ("BLOCK_REVIEW" if highest < 2 else
                   "MANUAL_REVIEW" if highest < 4 or self.incomplete else
                   "LOW_RISK_SIGNALS" if highest == 4 else "NO_FINDINGS_DETECTED")
        return {"scanner": "skill-sentinel", "version": VERSION, "mode": "static_offline_readonly",
                "verdict": verdict, "complete": not self.incomplete,
                "skills": sorted(set(self.skills)), "inspected_files": self.inspected,
                "counts": {s: counts.get(s, 0) for s in SEV_ORDER},
                "findings": self.findings, "hashes": dict(sorted(self.files.items()))}


def inspect_python(text: str, name: str, report: Report) -> tuple[bool, bool]:
    """Review Python AST without importing or executing the target."""
    try:
        tree = ast.parse(text, filename=name)
    except (SyntaxError, ValueError, RecursionError) as exc:
        report.gap(name, "Python AST could not be parsed: " + str(exc)[:100])
        return False, False
    aliases = {}
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                aliases[alias.asname or alias.name] = alias.name
        elif isinstance(node, ast.ImportFrom) and node.module:
            for alias in node.names:
                aliases[alias.asname or alias.name] = node.module + "." + alias.name

    network = False
    secrets = False
    secret_path = False
    parents = {id(child): parent for parent in ast.walk(tree) for child in ast.iter_child_nodes(parent)}
    for node in ast.walk(tree):
        if isinstance(node, ast.Constant) and isinstance(node.value, str):
            val = node.value
            is_sensitive_literal = bool(re.search(
                r"(?i)(?:\.ssh[/\\]|id_rsa|\.aws[/\\]credentials|/etc/shadow)", val))
            # A common literal '.env' in a list of extensions is not access to it.
            if val == ".env" and isinstance(parents.get(id(node)), (ast.Call, ast.Assign, ast.BinOp)):
                is_sensitive_literal = True
            if not val.startswith("(?i)") and is_sensitive_literal:
                secrets = True
                secret_path = True
                report.finding("SENSITIVE_FILE_LITERAL", "MEDIUM", name,
                               "Python references a sensitive local path", node.lineno,
                               evidence=val)
            # Regex rule definitions are evidence, not executable target commands.
            if not val.startswith("(?i)") and not val.startswith("(?m)"):
                for rid, sev, pattern, reason in SHELL_RULES:
                    matched = re.search(pattern, val)
                    if matched:
                        report.finding(rid, sev, name, reason, node.lineno, evidence=matched.group(0))
            if SENSITIVE.search(val):
                report.finding("EMBEDDED_SECRET", "CRITICAL", name,
                               "Recognizable credential/private-key marker embedded in Python", node.lineno,
                               evidence=val, confidence="strong")
        if isinstance(node, ast.Call):
            func = node.func
            parts = []
            while isinstance(func, ast.Attribute):
                parts.append(func.attr)
                func = func.value
            if isinstance(func, ast.Name):
                parts.append(func.id)
            fullname = ".".join(reversed(parts))
            first = fullname.split(".")[0]
            fullname = aliases.get(first, first) + fullname[len(first):]
            if fullname in {"exec", "eval", "builtins.exec", "builtins.eval"}:
                report.finding("DYNAMIC_PY_EXEC", "HIGH", name,
                               "Dynamic evaluation of Python code", node.lineno,
                               evidence=fullname, confidence="strong")
            if fullname.startswith("subprocess.") or fullname in {"os.system", "os.popen"}:
                shell_true = any(k.arg == "shell" and isinstance(k.value, ast.Constant) and k.value.value is True
                                 for k in node.keywords)
                sev = "HIGH" if shell_true or fullname in {"os.system", "os.popen"} else "MEDIUM"
                report.finding("COMMAND_EXEC", sev, name,
                               "Invokes an OS process (review exact command and parameters)",
                               node.lineno, evidence=fullname + (" shell=True" if shell_true else ""))
            if fullname in {"pickle.load", "pickle.loads", "marshal.loads"}:
                report.finding("UNSAFE_DESERIALIZATION", "MEDIUM", name,
                               "Deserializer may execute or load unsafe data", node.lineno, evidence=fullname)
            if fullname in {"requests.post", "requests.put", "requests.get", "requests.request",
                            "urllib.request.urlopen", "http.client.HTTPSConnection",
                            "socket.create_connection", "socket.socket", "httpx.post", "httpx.get",
                            "aiohttp.ClientSession"}:
                network = True
                report.finding("NETWORK_CAPABILITY", "LOW", name,
                               "Python code can connect to external endpoints", node.lineno, evidence=fullname)
            if fullname in {"os.getenv", "os.environ.get"}:
                secrets = secrets or any(isinstance(a, ast.Constant) and isinstance(a.value, str)
                                          and re.search(r"(?i)(api.?key|token|password|secret)", a.value)
                                          for a in node.args)
    if network and secret_path:
        report.finding("PRIVATE_FILE_WITH_NETWORK", "HIGH", name,
                       "Same script references private local files and makes network calls; inspect real dataflow")
    return network, secrets


def scan_text(raw: bytes, name: str, report: Report) -> tuple[bool, bool]:
    try:
        text = raw.decode("utf-8-sig")
    except UnicodeDecodeError:
        if raw.startswith((b"\xff\xfe", b"\xfe\xff")):
            try:
                text = raw.decode("utf-16")
            except UnicodeError:
                report.gap(name, "Unknown text encoding")
                return False, False
        else:
            report.gap(name, "Non-UTF-8 text could not be fully interpreted")
            return False, False
    suffix = Path(name).suffix.lower()
    basename = Path(name).name.lower()
    if any(c in text for c in HIDDEN_CHARS - {"\ufeff"}):
        report.finding("HIDDEN_UNICODE", "MEDIUM", name,
                       "Invisible or bidi-control characters can conceal instructions", evidence="unicode controls")
    if basename == "skill.md":
        validate_manifest(text, name, report)
    if SENSITIVE.search(text):
        for line_no, line in enumerate(text.splitlines(), 1):
            if SENSITIVE.search(line):
                report.finding("EMBEDDED_SECRET", "CRITICAL", name,
                               "A possible hard-coded credential/private key was detected; rotate if live",
                               line_no, evidence=line, confidence="strong")
                break
    net = False
    secrets = False
    if suffix == ".py":
        net, secrets = inspect_python(text, name, report)
    lines = text.splitlines()
    if suffix in INSTRUCTION_EXT or basename == "skill.md":
        for n, line in enumerate(lines, 1):
            if len(line) > 24000:
                report.gap(name, "A long text line exceeds heuristic analysis ceiling")
                continue
            for rid, sev, pattern, reason in DOC_RULES:
                m = re.search(pattern, line)
                if m:
                    # Explicit warnings/negations are common in security documentation.
                    context = line[:m.end()]
                    if rid == "SENSITIVE_DATA_TRANSFER" and re.search(
                            r"(?:不得|不要|禁止|不在|不应|避免|never|do not|don't|without)",
                            context, flags=re.I):
                        continue
                    report.finding(rid, sev, name, reason, n, evidence=m.group(0))
            if re.search(r"(?i)(?:读取|获取|读取文件|cat\s+|open\(|read_text\(|read\().{0,70}(?:\.ssh[/\\]|\.aws[/\\]credentials|\.env\b|密钥|token)", line):
                secrets = True
            if re.search(r"(?i)\b(?:curl\s+-|wget\s+-|requests\.(?:get|post)\(|fetch\()", line):
                net = True
    # Decode a small number of bounded base64 blobs, without evaluating the content.
    if (suffix in INSTRUCTION_EXT or suffix in SCRIPT_EXT) and len(text) <= MAX_FILE:
        encoded_seen = 0
        for blob in re.finditer(r"(?<![A-Za-z0-9+/])[A-Za-z0-9+/]{100,1600}={0,2}(?![A-Za-z0-9+/])", text):
            if encoded_seen >= 12:
                report.gap(name, "Too many encoded text candidates; full decode pass skipped")
                break
            encoded_seen += 1
            try:
                decoded = base64.b64decode(blob.group(0), validate=True).decode("utf-8")
            except (ValueError, UnicodeError):
                continue
            if re.search(r"(?i)(?:curl|wget).{0,160}\|\s*(?:bash|sh)|(?:\.ssh/id_rsa|\.aws/credentials)|ignore previous instructions|忽略.{0,10}系统.{0,10}指令", decoded):
                report.finding("OBFUSCATED_INSTRUCTIONS", "HIGH", name,
                               "Encoded text decodes to possible malicious instructions; verify manually",
                               text.count("\n", 0, blob.start()) + 1,
                               evidence="base64 encoded payload", confidence="heuristic")
    if suffix in SCRIPT_EXT or (basename == "skill.md"):
        for n, line in enumerate(lines, 1):
            if len(line) > 24000:
                continue
            for rid, sev, pattern, reason in SHELL_RULES:
                m = re.search(pattern, line)
                if m:
                    report.finding(rid, sev, name, reason, n, evidence=m.group(0))
    if basename in {"settings.json", "mcp.json"} or name.endswith(".mcp.json"):
        try:
            obj = json.loads(text)
            if isinstance(obj, dict) and obj.get("hooks"):
                report.finding("AUTOMATIC_HOOKS", "MEDIUM", name,
                               "Configuration defines hooks that can execute during agent lifecycle")
            if isinstance(obj, dict) and obj.get("mcpServers"):
                report.finding("MCP_EXECUTION", "MEDIUM", name,
                               "Configuration defines MCP servers; inspect command and permissions")
        except json.JSONDecodeError:
            report.gap(name, "JSON configuration could not be parsed")
    return net, secrets


def validate_manifest(text: str, name: str, report: Report) -> None:
    match = re.match(r"\A(?:\ufeff)?---\s*\n(.*?)\n---\s*(?:\n|$)", text, flags=re.S)
    if not match:
        report.finding("INVALID_MANIFEST", "MEDIUM", name,
                       "SKILL.md requires YAML frontmatter with name and description")
        return
    frontmatter = match.group(1)
    info = {}
    for line in frontmatter.splitlines():
        m = re.match(r"^([a-zA-Z][\w-]*):\s*(.*?)\s*$", line)
        if m:
            info[m.group(1)] = m.group(2).strip('"\'')
    skill_name = info.get("name", "")
    if not re.fullmatch(r"[a-z0-9]+(?:-[a-z0-9]+)*", skill_name) or len(skill_name) > 64:
        report.finding("INVALID_NAME", "MEDIUM", name,
                       "Skill name missing or not a valid agent-skills identifier")
    if not info.get("description"):
        report.finding("MISSING_DESCRIPTION", "MEDIUM", name,
                       "Manifest description is absent or unsupported multiline YAML")
    if len(info.get("description", "")) > 1024:
        report.finding("DESCRIPTION_TOO_LONG", "LOW", name,
                       "Description exceeds the 1024-character convention")
    # Parent name may differ for nested archive roots; only compare conventional directories.
    parent = Path(name).parent.name
    if parent and parent not in {".", "/"} and "::" not in name and skill_name and parent != skill_name:
        report.finding("NAME_DIRECTORY_MISMATCH", "LOW", name,
                       f"Declared name {skill_name!r} differs from directory {parent!r}")


def inspect_bytes(content: bytes, label: str, report: Report, depth: int = 0) -> tuple[bool, bool]:
    report.inspected += 1
    report.files[label] = hashlib.sha256(content).hexdigest()
    suffix = Path(label).suffix.lower()
    base = Path(label).name.lower()
    if len(content) > MAX_FILE:
        report.gap(label, f"File exceeds {MAX_FILE} byte inspection limit")
        return False, False
    if suffix in OPAQUE_EXT or content[:2] == b"MZ" or content[:4] == b"\x7fELF":
        report.finding("OPAQUE_EXECUTABLE", "HIGH", label,
                       "Executable/binary payload cannot be safely code-reviewed by this static scanner")
        report.incomplete = True
        return False, False
    if suffix in UNINSPECTED_DOC:
        report.gap(label, "Document may contain embedded content not statically inspected")
        return False, False
    if zipfile.is_zipfile(io.BytesIO(content)):
        if depth >= MAX_NESTED_DEPTH:
            report.gap(label, "Nested ZIP depth limit reached; inner files were not inspected")
        else:
            scan_zip(io.BytesIO(content), label, report, depth + 1)
        return False, False
    if suffix not in TEXT_EXT and base not in {"skill.md", "agents.md", "claude.md", "dockerfile", "makefile", "license", ".env", ".gitignore", ".npmrc", ".pypirc"} and not base.startswith(".env."):
        if b"\x00" in content[:1024] or suffix in {".png", ".jpg", ".jpeg", ".gif", ".webp", ".svg", ".woff2", ".ttf", ".ico"}:
            return False, False
        if not content:
            return False, False
        # No trust verdict is inferred from skipped unknown assets.
        report.gap(label, "Unknown file type not statically inspected")
        return False, False
    if b"\x00" in content[:1024] and suffix not in {".txt"}:
        report.gap(label, "File appears binary despite a text extension")
        return False, False
    if SHELL_FILE.search(label) and not base.endswith((".example", ".sample", ".template")):
        report.finding("SENSITIVE_NAMED_FILE", "HIGH", label,
                       "A credential-like file was bundled inside a skill")
    return scan_text(content, label, report)


def scan_zip(stream: io.BytesIO | Path, label: str, report: Report, depth: int = 0) -> None:
    try:
        if isinstance(stream, Path) and stream.stat().st_size > MAX_ARCHIVE_UNCOMPRESSED:
            report.gap(label, "ZIP compressed file exceeds 50 MiB bound")
            return
        with zipfile.ZipFile(stream, "r") as archive:
            members = archive.infolist()
            if depth == 0 and not any(Path(m.filename).name.lower() == "skill.md" for m in members):
                report.finding("MISSING_SKILL_MANIFEST", "MEDIUM", label,
                               "Archive does not contain a SKILL.md manifest")
            if len(members) > MAX_ARCHIVE_ENTRIES:
                report.gap(label, "ZIP contains more than 2000 entries")
                return
            total = 0
            for member in members:
                name = member.filename
                member_label = f"{label}::{name}"
                normalized = name.replace("\\", "/")
                if (normalized.startswith("/") or re.match(r"^[A-Za-z]:[/\\]", name)
                        or ".." in normalized.split("/") or "\x00" in name):
                    report.incomplete = True
                    report.finding("ZIP_PATH_TRAVERSAL", "HIGH", member_label,
                                   "Archive entry could escape its extraction directory", confidence="strong")
                    continue
                kind = member.external_attr >> 16
                if stat.S_ISLNK(kind):
                    report.incomplete = True
                    report.finding("ZIP_SYMLINK", "HIGH", member_label,
                                   "Archive contains symbolic link with unknown target")
                    continue
                if member.is_dir():
                    continue
                total += member.file_size
                if total > MAX_ARCHIVE_UNCOMPRESSED:
                    report.gap(label, "Total ZIP uncompressed bytes exceeds bound")
                    return
                if member.file_size > MAX_FILE:
                    report.gap(member_label, "ZIP entry exceeds per-file inspection limit")
                    continue
                if member.file_size > 1024 * 1024 and member.file_size / max(member.compress_size, 1) > 150:
                    report.gap(member_label, "Suspicious ZIP compression ratio; skipped")
                    continue
                try:
                    with archive.open(member) as item:
                        data = item.read(MAX_FILE + 1)
                    if len(data) > MAX_FILE:
                        report.gap(member_label, "ZIP entry exceeded per-file limit while reading")
                        continue
                    inspect_bytes(data, member_label, report, depth)
                except (RuntimeError, OSError, ValueError, EOFError, zipfile.BadZipFile) as exc:
                    report.gap(member_label, "ZIP entry unreadable: " + str(exc)[:100])
    except (OSError, RuntimeError, ValueError, zipfile.BadZipFile) as exc:
        report.gap(label, "ZIP archive unreadable: " + str(exc)[:100])


def scan_skill(path: Path, report: Report) -> None:
    if path.is_symlink():
        report.finding("SYMLINK_SKILL", "HIGH", str(path), "Skill root is a symlink: skipped to avoid outside reads")
        report.incomplete = True
        return
    if not path.is_dir():
        report.gap(str(path), "Skill root is not a directory")
        return
    root = str(path.absolute())
    report.skills.append(root)
    if not (path / "SKILL.md").is_file():
        report.finding("MISSING_SKILL_MANIFEST", "MEDIUM", root, "Root has no SKILL.md")
        report.incomplete = True
    net = False
    secret = False
    count = 0
    for base, dirs, files in os.walk(
            path, topdown=True, followlinks=False,
            onerror=lambda e: report.gap(str(getattr(e, "filename", path)),
                                         "Directory listing failed: " + str(e)[:100])):
        dirs.sort()
        files.sort()
        filtered = []
        for d in dirs:
            candidate = Path(base) / d
            if candidate.is_symlink():
                report.finding("SKILL_SYMLINK", "HIGH", str(candidate),
                               "Symlink directory skipped; could access files outside this skill")
                report.incomplete = True
            else:
                filtered.append(d)
        dirs[:] = filtered
        for fn in files:
            count += 1
            target = Path(base) / fn
            label = str(target.absolute())
            if count > MAX_ARCHIVE_ENTRIES:
                report.gap(root, "Skill file count exceeds 2000; remaining files not checked")
                return
            if target.is_symlink():
                report.finding("SKILL_SYMLINK", "HIGH", label,
                               "Symlink file skipped; could access files outside this skill")
                report.incomplete = True
                continue
            try:
                before = target.lstat()
                if not stat.S_ISREG(before.st_mode):
                    report.gap(label, "Special file skipped (not a regular file)")
                    continue
                if before.st_size > MAX_FILE:
                    report.gap(label, "File exceeds per-file inspection limit")
                    continue
                flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_BINARY", 0)
                fd = os.open(target, flags)
                with os.fdopen(fd, "rb") as fh:
                    data = fh.read(MAX_FILE + 1)
                if len(data) > MAX_FILE:
                    report.gap(label, "File changed/grown beyond limit while reading")
                    continue
                n, s = inspect_bytes(data, label, report)
                net = net or n
                secret = secret or s
            except (OSError, PermissionError, ValueError) as exc:
                report.gap(label, "Unreadable file: " + str(exc)[:100])
    if net and secret:
        report.finding("NETWORK_AND_SECRETS", "MEDIUM", root,
                       "Skill combines network capability with access to potentially sensitive data; review flows")


def select_skills(inputs: list[Path], report: Report) -> None:
    seen = set()
    for path in inputs:
        key = str(path.absolute())
        if key in seen:
            continue
        seen.add(key)
        if path.is_symlink():
            report.finding("SYMLINK_INPUT", "HIGH", key, "Top-level input is a symlink and was not followed")
            report.incomplete = True
        elif path.is_file() and path.suffix.lower() == ".zip":
            report.skills.append(key)
            scan_zip(path, key, report)
        elif path.is_file() and path.name.lower() == "skill.md":
            scan_skill(path.parent, report)
        elif path.is_dir():
            if (path / "SKILL.md").exists() or (path / "SKILL.md").is_symlink():
                scan_skill(path, report)
            else:
                children = sorted(path.iterdir(), key=lambda p: p.name)
                matched = False
                for child in children:
                    if child.is_dir() and ((child / "SKILL.md").exists() or (child / "SKILL.md").is_symlink()):
                        scan_skill(child, report)
                        matched = True
                    elif child.is_symlink():
                        report.finding("SYMLINK_CHILD", "MEDIUM", str(child),
                                       "Unknown linked child skipped; inspect manually")
                        report.incomplete = True
                if not matched:
                    report.gap(key, "No immediate SKILL.md or skill folders were found")
        else:
            report.gap(key, "Input does not exist or is not a supported ZIP/skill directory")


def installed_paths(cwd: Path, home: Path) -> list[Path]:
    roots: list[Path] = []
    for dir_name in (".agents/skills", ".claude/skills", ".copilot/skills"):
        p = home / dir_name
        if p.is_dir() or p.is_symlink():
            roots.append(p)
    ancestors = [cwd, *cwd.parents]
    for p in ancestors:
        for dir_name in (".agents/skills", ".claude/skills", ".github/skills"):
            candidate = p / dir_name
            if candidate.is_dir() or candidate.is_symlink():
                roots.append(candidate)
        if (p / ".git").exists():
            break
    return list(dict.fromkeys(roots))


def compare_snapshot(report: Report, snapshot_path: Path) -> None:
    try:
        old = json.loads(snapshot_path.read_text("utf-8"))
        if old.get("format") != "skill-sentinel-hashes-v1" or not isinstance(old.get("hashes"), dict):
            raise ValueError("snapshot schema mismatch")
        prev = old["hashes"]
        now = report.files
        for item in sorted(now.keys() - prev.keys()):
            report.finding("FILE_ADDED", "HIGH", item, "New file since saved snapshot")
        for item in sorted(prev.keys() - now.keys()):
            report.finding("FILE_REMOVED", "HIGH", item, "File removed or no longer readable since snapshot")
        for item in sorted(now.keys() & prev.keys()):
            if now[item] != prev[item]:
                report.finding("FILE_CHANGED", "HIGH", item, "SHA256 differs from saved snapshot")
    except (OSError, ValueError, TypeError, AttributeError) as exc:
        report.gap(str(snapshot_path), "Cannot use comparison snapshot: " + str(exc)[:120])


def render(report: dict[str, Any]) -> str:
    out = [f"Skill Sentinel v{VERSION} | {report['verdict']} | complete={report['complete']}",
           f"Targets: {len(report['skills'])} | files inspected: {report['inspected_files']}",
           "Findings: " + ", ".join(f"{k}={v}" for k, v in report["counts"].items())]
    if not report["findings"]:
        out.append("No indicators detected. This is NOT proof the skill is safe.")
    for f in report["findings"]:
        loc = f"{f['file']}:{f['line']}" if f["line"] else f["file"]
        out.append(f"[{f['severity']}] {f['rule']} | {loc}\n  {f['detail']}" +
                   (f"\n  Evidence: {f['evidence']}" if f["evidence"] else ""))
    out.append("Policy: never auto-run, repair, delete, or upload suspect skills. Review BLOCK/INCOMPLETE results manually.")
    return "\n".join(out)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Read-only offline static skill auditor (Python 3.9+)")
    parser.add_argument("paths", nargs="*", help="Skill folders, parent skills folders, or ZIP packages")
    parser.add_argument("--installed", action="store_true", help="Discover user and current-repository skill roots")
    parser.add_argument("--json", metavar="FILE", help="Write full JSON findings and SHA256 hashes")
    parser.add_argument("--snapshot", metavar="FILE", help="Explicitly save a SHA256 baseline after inspection")
    parser.add_argument("--compare", metavar="FILE", help="Compare hashes with a prior snapshot")
    parser.add_argument("--fail-on", choices=("critical", "high", "medium", "low"), default="high")
    parser.add_argument("--version", action="version", version=VERSION)
    args = parser.parse_args(argv)
    report = Report()
    targets = [Path(x).expanduser() for x in args.paths]
    if args.installed:
        targets += installed_paths(Path.cwd(), Path.home())
    if not targets:
        parser.error("Provide a skill path/ZIP or --installed")
    select_skills(targets, report)
    if args.compare:
        compare_snapshot(report, Path(args.compare).expanduser())
    result = report.result()
    print(render(result))
    outputs = []
    if args.json:
        outputs.append((Path(args.json).expanduser(), json.dumps(result, indent=2, ensure_ascii=False) + "\n"))
    if args.snapshot:
        snap = {"format": "skill-sentinel-hashes-v1", "scanner_version": VERSION,
                "hashes": result["hashes"]}
        outputs.append((Path(args.snapshot).expanduser(), json.dumps(snap, indent=2, ensure_ascii=False) + "\n"))
    if outputs:
        # Refuse overwrites and refuse any output inside a scanned input tree.
        source_dirs = [t.resolve() for t in targets if t.is_dir()]
        names = [o.resolve() for o, _ in outputs]
        if len(set(names)) != len(names):
            print("ERROR: output paths must be different", file=sys.stderr)
            return 3
        for out, content in outputs:
            resolved = out.resolve()
            if any(resolved == source or source in resolved.parents for source in source_dirs):
                print("ERROR: report/snapshot output cannot be inside scanned skills roots", file=sys.stderr)
                return 3
            if out.exists() or out.is_symlink():
                print("ERROR: output already exists (overwrite is never implicit): " + str(out), file=sys.stderr)
                return 3
            try:
                with out.open("x", encoding="utf-8") as fh:
                    fh.write(content)
            except OSError as exc:
                print("ERROR: cannot write output: " + str(exc), file=sys.stderr)
                return 3
    fail_limit = SEV_ORDER[args.fail_on.upper()]
    if any(SEV_ORDER[f["severity"]] <= fail_limit for f in result["findings"]):
        return 1
    if not result["complete"]:
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())
