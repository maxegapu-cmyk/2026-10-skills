# 人工二审操作手册

## 风险三连问

1. **目的：** 这段行为对技能声明的任务是否必需？配音 Skill 抓取用户 SSH 凭据就是明显目的不符；部署 Skill 调用 subprocess 可能是其正常职责。
2. **能力：** 这段行为实际能获得哪些文件、环境变量、网络地址、终端命令执行权限？不能仅看其 SKILL.md 的自我声明，必须看脚本和相关配置。
3. **触发：** 什么时候运行？是否通过 hooks/代理命令静默启动？是否需要用户知晓和批准？有无动态下载、版本不固定或二阶段代码？

## 复核结果怎么处理

- **CRITICAL/HIGH：** 保留风险证据，不执行可疑脚本。暂不启用新技能；已启用技能可由用户决定先禁用。逐条定位代码和访问路径，确认是否可在不改变功能的前提下移除行为。
- **MEDIUM：** 对照技能用途与来源、权限边界、依赖固定版本、网络目标及是否包含私有资料。若发现执行链涉及未知下载，继续人工审查。
- **LOW：** 标注潜在误报，但需留意多个低风险线索组合起来形成外传链。
- **COVERAGE_GAP：** 没扫描到的内容不得打绿灯。二进制需单独用专门分析工具，依赖漏洞需联网查询 CVE/OSV，图片/文档中的可执行或嵌入内容需要另行审计。

## 典型误报

- `COMMAND_EXEC` 命中音视频处理 Skill 的 ffmpeg：常属正常行为；应核对是否严格限制用户输入，是否开启 shell 解释和传入可控字符串。
- `NETWORK_CAPABILITY` 命中调用模型 API 的 Skill：正常与否取决于地址、所传输数据的范围、令牌授权范围、日志与用户授权。
- `SENSITIVE_FILE_LITERAL` 命中提醒用户保护秘密的文档或安全检测教程：可能是无害例子。检查是否真正读取、打包、上传。
- `EMBEDDED_SECRET`：扫描器只按常见令牌外形判断，测试字符串可能误报；真实凭据一旦泄露，先吊销/轮换，再清理与追查。

## 第三方第二引擎（可选，不自动执行）

权威项目：
- NVIDIA SkillSpector: https://github.com/NVIDIA/SkillSpector
- Cisco AI Defense Skill Scanner: https://github.com/cisco-ai-defense/skill-scanner

工具**已由用户自行安装**，且明确同意二审时，可按对应项目官方文档使用。例如 NVIDIA 的本地静态模式：

```bash
skillspector scan "/path/to/skill" --no-llm
```

Cisco 的基本静态检查：

```bash
skill-scanner scan "/path/to/skill"
```

命令上方的例子只是**说明合法审计接口**，不授权扫描器自己安装第三方软件。开启任何云端 / LLM / VirusTotal / 在线查询前，先向用户解释隐私风险和费用，并取得授权。交叉验证可提高覆盖，不能消除漏报与误报。

## 超出范围

- 不负责判断某个网络域名是否已经被劫持，不做联网威胁情报和 CVE 实时检索。
- 不支持把恶意目标动态执行在沙箱里观察；不提供无侵入执行隔离保证。
- 不做完整 Python/JS 数据流分析，也不保证识别拼接字符串、环境依赖、加密载荷、构建时脚本和图片文本中的隐蔽指令。
- 默认只检查 `~/.agents/skills`、`~/.claude/skills`、`~/.copilot/skills`，及工作目录向上至 Git 根的 `.agents/skills`、`.claude/skills`、`.github/skills`；不包含所有宿主应用中的 Skill 注册位置。
