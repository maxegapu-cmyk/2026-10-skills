#!/usr/bin/env python3
"""Offline content-case inspection. Observations are not causal proof.

This module never fetches URLs or claims to predict distribution.
"""
from __future__ import annotations

import datetime as dt
import json
import re
from pathlib import Path

METRICS = {
    "views": "播放/阅读量", "impressions": "曝光量", "ctr": "曝光点击率",
    "avg_view_seconds": "平均观看秒数", "completion_rate": "完成率",
    "shares": "分享数", "saves": "收藏数", "comments": "评论数", "likes": "点赞数",
}
RATES = {"ctr", "completion_rate"}
METRIC_POSITIVE = {"views", "impressions", "avg_view_seconds", "shares", "saves", "comments", "likes"}
CASING_RE = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9_-]{0,63}$")


def _number(value, label, rate=False):
    if value is None:
        return
    if isinstance(value, bool) or not isinstance(value, (float, int)):
        raise ValueError(f"{label} 必须是数值或 null")
    if value < 0 or (rate and value > 1):
        raise ValueError(f"{label} 超出有效范围（比率须为0~1）")


def _text(x, label, max_size=2500):
    if not isinstance(x, str) or len(x) > max_size:
        raise ValueError(f"{label} 应为不超过{max_size}字的文本")


def _object(data, label):
    if not isinstance(data, dict):
        raise ValueError(f"{label} 必须是 JSON 对象")


def _list(data, label, limit=200):
    if not isinstance(data, list) or len(data) > limit:
        raise ValueError(f"{label} 必须是数组，最多{limit}项")


def _get(doc, key):
    x = doc.get(key, {})
    _object(x, key)
    return x


def template(case_id: str) -> dict:
    if not CASING_RE.fullmatch(case_id):
        raise ValueError("案例代号只允许字母、数字、下划线与连字符，最长64位")
    return {
        "schema": 2, "case_id": case_id, "platform": "通用", "format": "long_video",
        "released_at": None, "observation_days": None, "duration_seconds": None,
        "content": {"topic": "", "audience_problem": "", "core_promise": "", "actual_payoff": "",
                    "hook_0_30s": "", "opening_sequence": "", "title": "", "cover_text": "",
                    "new_information": "", "emotional_shift": "", "share_motive": "",
                    "why_now": "", "structure_timeline": [], "cost_of_promise": ""},
        "metrics": {k: None for k in METRICS} | {"retention_points": []},
        "baseline": {"sample_count": None, "observation_days": None, "format": "long_video",
                     "same_topic_cluster": None, "similar_duration": None,
                     "similar_channel_stage": None, "traffic_source_mixture_comparable": None,
                     "metrics": {k: None for k in METRICS}},
        "external_context": {"trend_relevance": "", "paid_push": None, "platform_feature": "",
                             "distribution_shift": "", "collaboration": "", "other": ""},
        "observations": [], "hypotheses": [], "viewer_quotes": [], "experiment_results": []
    }


def validate(doc: dict):
    _object(doc, "案例")
    if doc.get("schema") != 2:
        raise ValueError("案例 schema 必须为2")
    cid = doc.get("case_id")
    if not isinstance(cid, str) or not CASING_RE.fullmatch(cid):
        raise ValueError("case_id 不合法")
    for k in ("platform", "format"):
        _text(doc.get(k, ""), k, 100)
    days = doc.get("observation_days")
    _number(days, "observation_days")
    if days is not None and (days == 0 or not float(days).is_integer()):
        raise ValueError("observation_days 必须为正整数")
    duration = doc.get("duration_seconds")
    _number(duration, "duration_seconds")
    if duration is not None and duration == 0:
        raise ValueError("duration_seconds 必须大于0")
    content = _get(doc, "content")
    for key, val in content.items():
        if key == "structure_timeline":
            _list(val, "structure_timeline", 100)
            for index, seg in enumerate(val):
                _object(seg, f"structure_timeline[{index}]")
                for t in ("start_sec", "end_sec"):
                    _number(seg.get(t), t)
                if seg.get("start_sec") is not None and seg.get("end_sec") is not None and seg["start_sec"] >= seg["end_sec"]:
                    raise ValueError("时间线片段结束时间必须晚于开始")
                for t in ("on_screen", "new_information", "reader_change", "evidence"):
                    if t in seg: _text(seg[t], t)
        else:
            _text(val, f"content.{key}")
    metrics = _get(doc, "metrics")
    baseline = _get(doc, "baseline")
    b_metrics = _get(baseline, "metrics")
    for pack, label in ((metrics, "metrics"), (b_metrics, "baseline.metrics")):
        for key in METRICS:
            _number(pack.get(key), f"{label}.{key}", key in RATES)
    p = metrics.get("retention_points", [])
    _list(p, "retention_points", 500)
    last_time = -1
    for pt in p:
        _object(pt, "retention_point")
        sec, pct = pt.get("sec"), pt.get("pct")
        _number(sec, "retention_point.sec")
        _number(pct, "retention_point.pct")  # repeat viewing may exceed 1
        if sec is None or pct is None or sec <= last_time or (duration is not None and sec > duration):
            raise ValueError("留存点时间必须递增、不为空且不超过视频长度")
        last_time = sec
    basecount = baseline.get("sample_count")
    _number(basecount, "baseline.sample_count")
    if basecount is not None and not float(basecount).is_integer():
        raise ValueError("baseline.sample_count 必须为整数")
    bdays = baseline.get("observation_days")
    _number(bdays, "baseline.observation_days")
    for k in ("same_topic_cluster", "similar_duration", "similar_channel_stage", "traffic_source_mixture_comparable"):
        if baseline.get(k) is not None and not isinstance(baseline[k], bool):
            raise ValueError(f"baseline.{k} 应为 true/false/null")
    _object(doc.get("external_context", {}), "external_context")
    observations = doc.get("observations", [])
    _list(observations, "observations")
    obs_ids = set()
    for o in observations:
        _object(o, "observation")
        ident = o.get("id", "")
        if not isinstance(ident, str) or not CASING_RE.fullmatch(ident) or ident in obs_ids:
            raise ValueError("观察记录 ID 缺失、重复或非法")
        obs_ids.add(ident)
        for k in ("claim", "evidence"):
            _text(o.get(k, ""), f"observation.{k}")
        if o.get("evidence_type") not in ("metric", "text", "comment", "context", "unknown"):
            raise ValueError("观察 evidence_type 需为 metric/text/comment/context/unknown")
    hyp_ids = set()
    hyps = doc.get("hypotheses", [])
    _list(hyps, "hypotheses", 50)
    for h in hyps:
        _object(h, "hypothesis")
        ident = h.get("id", "")
        if not isinstance(ident, str) or not CASING_RE.fullmatch(ident) or ident in hyp_ids:
            raise ValueError("假说 ID 缺失、重复或非法")
        hyp_ids.add(ident)
        for k in ("mechanism", "alternative", "transfer_rule", "test_change", "test_control", "rejection_condition"):
            _text(h.get(k, ""), f"hypothesis.{k}")
        if h.get("confidence") not in ("low", "moderate", "high"):
            raise ValueError("confidence 仅允许 low/moderate/high")
        linked = h.get("observations", [])
        _list(linked, "hypothesis.observations")
        if any(not isinstance(x, str) or x not in obs_ids for x in linked):
            raise ValueError("假说引用了不存在的观察 ID")
    _list(doc.get("viewer_quotes", []), "viewer_quotes")
    _list(doc.get("experiment_results", []), "experiment_results")
    for e in doc.get("experiment_results", []):
        _object(e, "experiment_result")
        if e.get("hypothesis_id") not in hyp_ids:
            raise ValueError("实验结果引用了不存在的假说 ID")
        if e.get("status") not in ("supported", "rejected", "inconclusive"):
            raise ValueError("实验结果 status 只能是 supported/rejected/inconclusive")
    return doc


def read_case(path: Path) -> dict:
    if not path.is_file():
        raise ValueError(f"案例文件不存在：{path}")
    if path.stat().st_size > 4_000_000:
        raise ValueError("案例文件超过4MB限制")
    doc = json.loads(path.read_text(encoding="utf-8-sig"))
    return validate(doc)


def analysis(doc: dict) -> dict:
    validate(doc)
    b = doc.get("baseline", {})
    m = doc.get("metrics", {})
    bm = b.get("metrics", {})
    comparability = {
        "observation_window": doc.get("observation_days") is not None and doc.get("observation_days") == b.get("observation_days"),
        "format": doc.get("format") == b.get("format"),
        "topic": b.get("same_topic_cluster") is True,
        "duration": b.get("similar_duration") is True,
        "account_stage": b.get("similar_channel_stage") is True,
        "traffic": b.get("traffic_source_mixture_comparable") is True,
    }
    comparable = all(comparability.values()) and isinstance(b.get("sample_count"), int) and b["sample_count"] >= 3
    lifts = {}
    for metric in METRICS:
        a, base = m.get(metric), bm.get(metric)
        if a is not None and base is not None and base > 0:
            lifts[metric] = round(a/base, 3)
    rp = m.get("retention_points", [])
    recalc = []
    for i in range(1, len(rp)-1):
        l, c, r = rp[i-1:i+2]
        if c["pct"] > l["pct"] and c["pct"] > r["pct"]:
            recalc.append({"sec": c["sec"], "type": "local_peak", "interpretation": "局部回看峰值；也可能是内容理解困难"})
        if c["pct"] < l["pct"] and c["pct"] < r["pct"]:
            recalc.append({"sec": c["sec"], "type": "local_dip", "interpretation": "局部下探；可能跳过、流失或观测噪声"})
    warnings = []
    if not comparable:
        warnings.append("缺少完全可比的同期基线：所有倍数只作为描述，不做增长归因。")
    if not m.get("impressions") or m.get("ctr") is None:
        warnings.append("入口数据不全：不能断言标题/封面是主要原因。")
    if not rp and m.get("avg_view_seconds") is None and m.get("completion_rate") is None:
        warnings.append("留存数据缺失：不能断言开场/节奏直接带来增长。")
    if not doc.get("hypotheses"):
        warnings.append("尚无有证据锚点的可反驳假说；不能输出确定的爆款原因。")
    if len(doc.get("observations", [])) < 2:
        warnings.append("可核对观察不足；需补至少两个独立证据锚点。")
    if not doc.get("external_context") or all(v in ("", None) for v in doc.get("external_context", {}).values()):
        warnings.append("未记录外部干扰因素：热度/分发/同期事件等未排除。")
    quality = "hypothesis_only"
    if comparable and len(doc.get("observations", [])) >= 2 and doc.get("hypotheses"):
        quality = "comparison_ready"
    if doc.get("experiment_results"):
        quality = "experiment_logged"
    return {"case_id": doc["case_id"], "case_status": quality, "baseline_comparable": comparable,
            "comparability_checks": comparability, "relative_to_baseline": lifts,
            "retention_shape_hints": recalc, "warnings": warnings,
            "causality_notice": "指标相关不等于因果；一次作品走红无法识别独立致因，需要同期可比对照和后续受控实验。"}


def _fmt(x):
    if x is None:
        return "未提供"
    return f"{x:.2f}" if isinstance(x, float) else str(x)


def markdown(doc: dict, report: dict) -> str:
    lines = ["# 内容传播逆向报告", "", f"案例代号：`{doc['case_id']}`；状态：`{report['case_status']}`。", "",
             "## 一、证据盘点", "", "| 指标 | 本期 | 同条件基线 | 倍数（仅描述） |", "|---|---:|---:|---:|"]
    for metric, label in METRICS.items():
        m = doc["metrics"].get(metric); bm=doc["baseline"]["metrics"].get(metric)
        lift=report["relative_to_baseline"].get(metric)
        lines.append(f"| {label} | {_fmt(m)} | {_fmt(bm)} | {str(lift)+'×' if lift is not None else '无法计算'} |")
    lines += ["", f"**基线是否足够可比：{'是' if report['baseline_comparable'] else '否'}**；比较至少需要相近时间窗、形式、题材、长度、账号阶段、流量来源与足够样本。", "",
              "## 二、观众行为六关", "", "1. 被看到：曝光来自哪里？与选题时点、分发来源、账号基本盘有多大关系？", 
              "2. 愿意点：标题和封面承诺了什么？是否存在点击率与曝光扩张的取舍？", 
              "3. 愿意留下：前30秒/第一屏是否兑现承诺？退出点在什么位置？", 
              "4. 愿意读完：每次推进是否提供新的信息、判断、悬念或情绪转折？", 
              "5. 愿意互动：收藏解决了什么需要？评论有没有争议或讨论的必要？", 
              "6. 愿意分享：转给别人能满足什么动机？表达身份、提供帮助、共同惊讶还是进入争论？", "",
              "## 三、观察事实（没有记录的不要补写成事实）", ""]
    if doc.get("observations"):
        for o in doc["observations"]:
            lines.append(f"- [{o['id']}] {o['claim']}；依据：{o['evidence']}（{o['evidence_type']}）")
    else:
        lines.append("- 暂无。先补数据、原文时间线、有效评论或可回查的内容节点。")
    lines += ["", "## 四、机制假说／竞争解释／反证出口", ""]
    if doc.get("hypotheses"):
        for h in doc["hypotheses"]:
            lines += [f"### {h['id']}（自评把握：{h['confidence']}，非验证结果）", "",
                      f"- 机制：{h['mechanism']}", f"- 证据锚点：{', '.join(h['observations']) or '不足'}",
                      f"- 竞争解释：{h['alternative'] or '待补'}",f"- 可迁移动作：{h['transfer_rule'] or '待补'}",
                      f"- 单变量测试：{h['test_change'] or '待补'}；固定：{h['test_control'] or '待补'}",
                      f"- 否证条件：{h['rejection_condition'] or '待补'}", ""]
    else:
        lines.append("尚无机制假说。请先描述观众的可观察行为，再列出至少两种互斥解释，禁止反推‘因为爆所以这一步有效’。")
    lines += ["", "## 五、留存形状提示", ""]
    if report["retention_shape_hints"]:
        lines += [f"- {x['sec']}秒：{x['type']}；{x['interpretation']}。" for x in report["retention_shape_hints"]]
    else:
        lines.append("没有足够的留存曲线点可计算局部形状；不代表没有流失。")
    lines += ["", "## 六、不能归因的部分", ""]
    lines += [f"- {x}" for x in report["warnings"]]
    lines += ["", "## 七、四个必须回答的逆向问题", "",
              "1. **如果拿走题材自带热度，这套内容仍有什么吸引力？** 要找内容贡献与外部推力的分界。",
              "2. **如果只保留标题，正文能兑现多少？** 要分清吸引力与信任损耗。",
              "3. **如果换一批不熟悉的读者，哪些信息仍成立？** 要检验机制能否迁移。",
              "4. **如果同样机制用在失败作品上，为什么没爆？** 至少找一篇反例，避免幸存者偏差。", "",
              "## 八、下一期原创迁移（人工填）", "",
              "- 保留：可解释观众行为的抽象机制，不照搬原句、原作结构、标题和细节。",
              "- 改变：题材、核心事实、论点推进、主要场景、实际交付价值。",
              "- 最小实验：只改一项包装或内容变量；确定主要指标、对照条件和停止条件。",
              "- 验证后：观察新作品表现，写入实验记录；没有可比样本时不升级为通用定律。", "",
              "**边界**：此工具组织证据和实验，不会自动识别真实观众心理、证明因果或预测爆款。", ""]
    return "\n".join(lines)


def experiment_brief(doc: dict, report: dict) -> str:
    lines = ["# 下一期创作实验卡", "", f"基于案例 `{doc['case_id']}`；分析级别 `{report['case_status']}`。", "",
             "原则：上一期的高数据是观察结果，不是可直接复制的配方。风格规律与传播规律分开建档。", ""]
    if not doc.get("hypotheses"):
        lines += ["未定义可测试假说：先补充本期观众行为证据，再生成新一期内容。", ""]
    for h in doc.get("hypotheses", []):
        lines += [f"## 候选机制 {h['id']}", "", f"传播机制（待验证）：{h['mechanism']}",
                  f"允许迁移的抽象行为：{h['transfer_rule'] or '未确定'}",
                  f"A/B 中唯一允许改动：{h['test_change'] or '尚未制定'}",
                  f"必须固定的条件：{h['test_control'] or '尚未制定'}",
                  f"否证条件（推翻假说的证据）：{h['rejection_condition'] or '尚未制定'}", ""]
    lines += ["## 下一期写作执行约束", "",
              "- 创作前确定新作品的受众问题和独立信息价值，不借用上期独有情节或原文表达。",
              "- 每一段都要有‘读者预期→新增信息→理解变化’，但节奏不得机械平均。",
              "- 包装A/B有两种不同阅读承诺；每个承诺必须在正文前段兑现并在全篇完成。",
              "- 先给可独立成立的完整作品，再做作者风格迁移，不让爆款假说抹平作者特征。",
              "- 实际发布后才填写效果：记录曝光、点击、留存、互动与来源；不只看总播放。", ""]
    return "\n".join(lines)


def add_result(doc: dict, experiment: dict) -> dict:
    validate(doc)
    _object(experiment, "experiment")
    needed = ("hypothesis_id", "status", "metric", "baseline_value", "variant_value", "window", "confounders", "notes")
    for key in needed:
        if key not in experiment:
            raise ValueError(f"实验记录缺少：{key}")
    if experiment["hypothesis_id"] not in {h["id"] for h in doc["hypotheses"]}:
        raise ValueError("实验关联的假说不存在")
    if experiment["status"] not in ("supported", "rejected", "inconclusive"):
        raise ValueError("status 非法")
    for k in ("baseline_value", "variant_value"):
        _number(experiment[k], k)
    for k in ("metric", "window", "confounders", "notes"):
        _text(experiment[k], k)
    if not experiment["window"]:
        raise ValueError("请填写观察时间窗")
    entry = {k: experiment[k] for k in needed}
    entry["logged_utc"] = dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()
    doc["experiment_results"].append(entry)
    validate(doc)
    return doc
