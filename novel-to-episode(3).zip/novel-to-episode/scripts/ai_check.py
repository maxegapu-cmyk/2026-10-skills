#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
小说改单集 v3 · 剧本去 AI 味检查脚本

用法：
    python ai_check.py 剧本.txt               # 中文报告
    python ai_check.py 剧本.md --json         # JSON 输出
    python ai_check.py 剧本.txt --min 90      # 及格线，默认 90
    python ai_check.py 剧本.txt --words 1000-2000   # 字数范围

只检查正文：标题、人物表之后到【完】之前。.md 文件若含 ``` 代码块，只查代码块内。
脚本只能查可数的问题，红队三轮人工审查不能省。
"""
import argparse
import json
import re
import sys
from collections import defaultdict

STOP = r'[^。！？!?\n]'
CONTRAST = [
    (rf'不是{STOP}{{0,40}}?而是', '不是……而是……'),
    (rf'并不是{STOP}{{0,40}}?[，,；;]\s*(?:是|只是)', '并不是……是……'),
    (rf'是{STOP}{{0,30}}?而不是', '是……而不是……'),
    (rf'不像{STOP}{{0,30}}?倒像', '不像……倒像……'),
    (rf'没有{STOP}{{0,30}}?但也', '没有……但也……'),
    (rf'与其说{STOP}{{0,30}}?不如说', '与其说……不如说……'),
    (rf'不仅{STOP}{{0,40}}?更是', '不仅……更是……'),
    (rf'不是{STOP}{{1,20}}?[，,]\s*是', '不是……，是……'),
]
AI_WORDS = [
    '仿佛', '似乎', '一丝', '一抹', '不禁', '缓缓', '微微', '淡淡的', '嘴角勾起', '嘴角上扬',
    '眼中闪过', '眸子', '眸光', '空气凝固', '空气仿佛', '五味杂陈', '深吸一口气', '命运',
    '这一刻', '宛如', '无声地', '莫名', '心头一颤', '心中一暖', '百感交集', '意味深长',
    '若有所思', '不由得', '此时此刻', '仿若', '恍若', '眼眶泛红', '红了眼眶', '眉头紧锁',
    '指节泛白', '喉结滚动', '邪魅', '阴鸷', '冷笑一声',
]
STOCK_ACTIONS = ['握紧拳头', '攥紧衣角', '沉默片刻', '愣在原地', '身体一僵', '夺眶而出', '转身离去', '僵在原地']
BAD_LINES = [
    '你听我解释', '我不是故意的', '你给我滚', '够了！', '够了!', '凭什么', '你会后悔的',
    '从今天起', '到此为止', '你根本不懂', '求你了', '你知道我是谁', '三年之期',
]
AI_SURNAMES = '顾陆沈江萧慕容'
AI_GIVEN = '晚晴辰墨寒夜瑶烬渊珩宸璃'
AI_NAME_RE = re.compile(rf'(?:林晚|苏晴|苏念|顾沉|陆沉|沈夜|江辰|[{AI_SURNAMES}][{AI_GIVEN}])')
EMOTION_RE = re.compile(
    r'我(?:真的|真|好|很|太|非常|特别){1,2}(?:难过|生气|伤心|痛苦|害怕|开心|失望|委屈|绝望|愤怒|后悔|恨你|爱你)'
)
EMOTION_WORDS = ['我恨你', '我爱你']
ADVERB_PAREN = re.compile(r'[（(][^）)]{0,6}地[）)]')
THOUGHT = ['终于明白', '明白了', '心想', '心里想', '心中', '内心', '感到', '感觉到', '意识到', '暗想', '暗自']
SIMILE_RE = re.compile(r'像[^。！？\n]{1,15}一样|如同|宛若|好似')
SUMMARY_END = ['终于', '明白', '原来', '一切', '从此', '新的开始', '再也', '永远', '真正的']

HEADING_RE = re.compile(r'^\s*(第\s*\S+?\s*[集场]|\d+\s*[-－]?\s*\d*\s*[日夜晨昏]|\d+\s*[-－]\s*\d+|《)')
DIALOGUE_RE = re.compile(r'^\s*([^\s：:△【#|\-*>]{1,10}?)\s*((?:（[^）]*）|\([^)]*\))*)\s*[：:]\s*(.+)$')
PAREN_RE = re.compile(r'（[^）]*）|\([^)]*\)')
PUNCT_RE = re.compile(r'[，,。！？!?、；;：:“”"‘’\'…—\-\s「」『』《》]')
SENT_SPLIT = re.compile(r'[。！？!?…—]+')
CJK_RE = re.compile(r'[一-鿿A-Za-z0-9]')

COST = {
    'contrast_action': 6, 'contrast_dialogue': 2, 'ai_word': 3, 'stock_action': 2,
    'bad_line': 3, 'ai_name': 4, 'adverb_paren': 2, 'emotion': 3, 'thought': 3,
    'long_line': 1, 'parallel': 3, 'pingpong': 4, 'ellipsis': 3, 'simile': 2,
    'summary_end': 6, 'words': 10, 'os': 2, 'opening': 8,
}
LABEL = {
    'contrast_action': '对比否定句（描写）', 'contrast_dialogue': '对比否定句（台词，酌情）',
    'ai_word': 'AI 高频词', 'stock_action': '万能动作', 'bad_line': '短剧烂台词',
    'ai_name': 'AI 爱用的名字', 'adverb_paren': '情绪副词提示', 'emotion': '情绪直说',
    'thought': '内心叙述', 'long_line': '台词过长', 'parallel': '排比',
    'pingpong': '乒乓对白', 'ellipsis': '省略号过密', 'simile': '比喻过多',
    'summary_end': '结尾总结句', 'words': '字数不达标', 'os': 'OS 过多', 'opening': '开场无冲突迹象',
}
OPENING_BAN = ['闹钟', '阳光', '清晨', '天际线', '空镜', '我叫', '那一年', '睁开眼', '醒来', '回忆', '夕阳']


def body_lines(text, path):
    lines = list(enumerate(text.splitlines(), 1))
    if path.lower().endswith('.md') and '```' in text:
        out, inside = [], False
        for i, line in lines:
            if line.strip().startswith('```'):
                inside = not inside
                continue
            if inside:
                out.append((i, line))
        lines = out
    result = []
    for i, line in lines:
        s = line.strip()
        if s.startswith('【完】') or s.startswith('改编说明'):
            break
        result.append((i, line))
    return result


def classify(s):
    if not s:
        return 'blank', None, None
    if HEADING_RE.match(s) or s.startswith('人物：') or s.startswith('人物:'):
        return 'heading', None, None
    if s.startswith('△') or s.startswith('【'):
        return 'action', None, s
    m = DIALOGUE_RE.match(s)
    if m and m.group(1) not in ('人物', '注', '备注', '地点', '时间'):
        return 'dialogue', m.group(1), m.group(3)
    return 'narration', None, s


def is_parallel(sentence):
    clauses = [c.strip() for c in re.split(r'[，,；;、]', sentence) if c.strip()]
    run = 1
    for a, b in zip(clauses, clauses[1:]):
        same = a[:2] == b[:2] or (run == 1 and b[:2] in a[:8])
        if len(a) >= 2 and len(b) >= 2 and same and len(a) <= 12 and len(b) <= 12:
            run += 1
            if run >= 3:
                return True
        else:
            run = 1
    return False


def check(text, path, wmin, wmax):
    issues = []
    add = lambda ln, k, d: issues.append({'line': ln, 'type': k, 'detail': d})
    speaker_sents = defaultdict(list)
    os_count = 0
    content = []
    in_cast = False
    seq = []  # (line, speaker or None) for ping-pong
    total_chars = 0
    ellipsis = 0
    seen_names = set()

    for ln, raw in body_lines(text, path):
        s = raw.strip()
        kind, speaker, body = classify(s)
        if s.startswith('人物：') or s.startswith('人物:'):
            in_cast = True
            continue
        if kind == 'blank':
            in_cast = False
            continue
        if in_cast and kind != 'action':
            continue
        if kind == 'heading':
            continue
        content.append((ln, s, kind))
        total_chars += len(CJK_RE.findall(s))
        ellipsis += s.count('……') + s.count('...')

        for pat, name in CONTRAST:
            if re.search(pat, s):
                add(ln, 'contrast_dialogue' if kind == 'dialogue' else 'contrast_action', name)
                break
        for w in AI_WORDS:
            if w in s:
                add(ln, 'ai_word', w)
        for w in STOCK_ACTIONS:
            if w in s:
                add(ln, 'stock_action', w)
        for w in BAD_LINES:
            if w in s:
                add(ln, 'bad_line', w)
        for m in set(AI_NAME_RE.findall(s)):
            if m not in seen_names:
                seen_names.add(m)
                add(ln, 'ai_name', m)
        for m in ADVERB_PAREN.findall(s):
            add(ln, 'adverb_paren', m)

        if kind == 'dialogue':
            seq.append((ln, speaker))
            if re.search(r'[（(]\s*(?:OS|os)\s*[）)]', s.split('：')[0]):
                os_count += 1
            clean = PAREN_RE.sub('', body)
            hits = set(EMOTION_RE.findall(clean)) | {w for w in EMOTION_WORDS if w in clean}
            for w in sorted(hits):
                add(ln, 'emotion', w)
            for sent in SENT_SPLIT.split(clean):
                n = len(PUNCT_RE.sub('', sent))
                if n == 0:
                    continue
                speaker_sents[speaker].append(n)
                if n > 25:
                    add(ln, 'long_line', f'{speaker} 一句 {n} 字')
                if is_parallel(sent):
                    add(ln, 'parallel', sent[:20])
        else:
            seq.append((ln, None))
            for w in THOUGHT:
                if w in s:
                    add(ln, 'thought', w)
                    break
            for sent in SENT_SPLIT.split(s):
                if is_parallel(sent):
                    add(ln, 'parallel', sent[:20])

    # 乒乓对白：连续 8 行以上只有两个人轮流说话、中间没有动作
    run, start, pair, prev = 0, None, set(), None
    for ln, sp in seq + [(0, None)]:
        if sp and sp != prev and len(pair | {sp}) <= 2:
            if run == 0:
                start = ln
            run += 1
            pair.add(sp)
            prev = sp
        else:
            if run >= 8:
                add(start, 'pingpong', f'第 {start} 行起连续 {run} 句两人轮流对白，中间没有动作')
            if sp:
                run, start, pair, prev = 1, ln, {sp}, sp
            else:
                run, start, pair, prev = 0, None, set(), None

    # 比喻
    similes = [(ln, s) for ln, s, k in content if k != 'dialogue' and SIMILE_RE.search(s)]
    for ln, s in similes[1:]:
        add(ln, 'simile', '动作描写里比喻超过一处')

    # 开场：前 3 行
    if content:
        first3 = content[:3]
        for ln, s, k in first3:
            hit = next((w for w in OPENING_BAN if w in s), None)
            if hit:
                add(ln, 'opening', f'开场出现「{hit}」')
                break
        if all(k != 'dialogue' for _, _, k in first3) and not any(
            re.search(r'[！!？?]|拍|摔|砸|撕|推|拽|跪|抢|扔|按|锁|堵|砍|烧|血|死', s) for _, s, _ in first3
        ):
            add(first3[0][0], 'opening', '前 3 行没有台词，也没有明显的冲突动作')

    # 结尾
    if content:
        ln, s, k = content[-1]
        hit = next((w for w in SUMMARY_END if w in s), None)
        if hit:
            add(ln, 'summary_end', f'最后一行含「{hit}」，疑似总结或升华')

    if os_count > 1:
        add(0, 'os', f'全集 {os_count} 处 OS，最多 1 处')
    if total_chars and ellipsis / total_chars * 1000 > 8:
        add(0, 'ellipsis', f'省略号 {ellipsis} 处，每千字 {ellipsis / total_chars * 1000:.1f} 处')
    if not (wmin <= total_chars <= wmax):
        add(0, 'words', f'正文 {total_chars} 字，要求 {wmin}–{wmax} 字')

    cost = defaultdict(int)
    for it in issues:
        cost[it['type']] += COST[it['type']]
    cost['long_line'] = min(cost.get('long_line', 0), 8)
    cost['opening'] = min(cost.get('opening', 0), 8)
    score = max(0, 100 - sum(cost.values()))
    avgs = {k: round(sum(v) / len(v), 1) for k, v in speaker_sents.items() if len(v) >= 3}
    return issues, score, total_chars, avgs


def main():
    ap = argparse.ArgumentParser(description='剧本去 AI 味检查（v3）')
    ap.add_argument('file')
    ap.add_argument('--json', action='store_true')
    ap.add_argument('--min', type=int, default=90)
    ap.add_argument('--words', default='1000-2000')
    a = ap.parse_args()
    wmin, wmax = (int(x) for x in a.words.split('-'))
    with open(a.file, encoding='utf-8') as f:
        text = f.read()
    issues, score, chars, avgs = check(text, a.file, wmin, wmax)
    passed = score >= a.min
    if a.json:
        print(json.dumps({'score': score, 'passed': passed, 'chars': chars,
                          'avg_sentence_len': avgs, 'issues': issues}, ensure_ascii=False, indent=2))
        return 0 if passed else 1
    counts = defaultdict(int)
    for it in issues:
        counts[it['type']] += 1
    print(f'去 AI 味分数：{score} / 100（及格线 {a.min}）→ {"通过" if passed else "需要返修"}')
    print(f'正文字数：{chars}（要求 {wmin}–{wmax}）')
    if avgs:
        print('角色平均句长：' + '，'.join(f'{k} {v} 字' for k, v in avgs.items()))
    if counts:
        print('问题统计：' + '，'.join(f'{LABEL[k]} {v}' for k, v in counts.items()))
        print('\n逐条明细：')
        for it in sorted(issues, key=lambda x: x['line']):
            where = f'第 {it["line"]} 行' if it['line'] else '全局'
            print(f'  [{where}] {LABEL[it["type"]]}：{it["detail"]}')
    else:
        print('没有发现可数的问题。红队人工审查仍需照做。')
    return 0 if passed else 1


if __name__ == '__main__':
    sys.exit(main())
