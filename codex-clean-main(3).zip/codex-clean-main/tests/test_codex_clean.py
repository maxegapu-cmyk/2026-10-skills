#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Self-contained regression suite for codex_clean.py (stdlib only).

Run:  python tests/test_codex_clean.py
Exit: 0 = all passed, 1 = at least one failure.

The suite never touches a real agent home: every case points CODEX_HOME /
CLAUDE_HOME / PI_AGENT_HOME at a throwaway temp directory.
"""
from __future__ import annotations

import io
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

SCRIPT = Path(__file__).resolve().parent.parent / "scripts" / "codex_clean.py"
PY = sys.executable
results: list[tuple[str, bool]] = []
_tmpdirs: list[str] = []


_FALLBACK_HOME = None


def _fallback_home():
    """Throwaway dir used for any agent home a test forgot to set.

    Without this, a forgotten `--target` falls back to the default agent and a
    forgotten env var falls back to the *real* ~/.codex -- which is exactly how
    one of these tests once began cleaning the developer's own machine. The
    sandbox's delete guard stopped it, but the suite should not depend on that.
    """
    global _FALLBACK_HOME
    if _FALLBACK_HOME is None:
        _FALLBACK_HOME = tempfile.mkdtemp(prefix="cc_fallback_")
        _tmpdirs.append(_FALLBACK_HOME)
    return _FALLBACK_HOME


def run(args, home=None):
    env = dict(os.environ)
    env["PYTHONIOENCODING"] = "utf-8"
    if home:
        env.update(home)
    # Safety net: every agent home points at a throwaway dir unless the test
    # named one, so no invocation can ever touch a real agent home.
    _fb = _fallback_home()
    for _var in ("CODEX_HOME", "CLAUDE_HOME", "PI_AGENT_HOME",
                 "XDG_DATA_HOME", "GEMINI_CLI_HOME"):
        if not env.get(_var):
            env[_var] = _fb
    return subprocess.run([PY, str(SCRIPT), *args], capture_output=True,
                          text=True, encoding="utf-8", env=env)


def check(name, cond, detail=""):
    results.append((name, bool(cond)))
    print(("  PASS  " if cond else "  FAIL  ") + name + ("   " + detail if detail and not cond else ""))


def mk(root, rel, size):
    p = Path(root) / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    with open(p, "wb") as f:
        f.write(b"x" * size)
    return p


def mkhome(prefix, files):
    d = tempfile.mkdtemp(prefix=prefix)
    _tmpdirs.append(d)
    for rel, size in files:
        if rel.endswith("/"):
            os.makedirs(Path(d) / rel, exist_ok=True)
        else:
            mk(d, rel, size)
    return d


def _script_version():
    """Read VERSION from the script (single source of truth for releases)."""
    for line in SCRIPT.read_text(encoding="utf-8").splitlines():
        if line.startswith("VERSION"):
            return line.split("=", 1)[1].strip().strip('"')
    return None


def mkclaude():
    """Fresh fake ~/.claude with both cleanable and protected content."""
    return mkhome("cc_home_", [
        ("cache/x.bin", 50000), ("debug/y.log", 40000),
        ("projects/p.jsonl", 9000), ("memory/m.md", 1000),
        ("skills/s/SKILL.md", 2000), ("settings.json", 100), ("plugins/", 0)])


def mkpi():
    """Fresh fake ~/.pi/agent with cleanable + protected content.

    Mirrors the real layout from pi's source: tmp/extensions/<hash> holds
    temporary package checkouts, npm/ holds user-installed packages, and the
    debug log lives at the agent root.
    """
    return mkhome("pi_home_", [
        ("cache/c.bin", 30000), ("tmp/t.bin", 20000),
        ("tmp/extensions/ab12cd34/node_modules/x/index.js", 5000),
        ("pi-debug.log", 3000),
        ("npm/pkg/index.js", 8000), ("sessions/s.jsonl", 5000),
        ("skills/s/SKILL.md", 1000), ("extensions/ext.ts", 900),
        ("settings.json", 100), ("trust.json", 100),
        ("auth.json", 100), ("models.json", 100)])


def main() -> int:
    # ---------------- Codex: backwards compatibility ----------------
    cx = mkhome("cx_home_", [(".tmp/a.bin", 100000), ("tmp/b.bin", 30000),
                             ("plugins/cache/c.bin", 20000),
                             ("sessions/keep.jsonl", 5000), ("config.toml", 100)])
    items = json.loads(run(["--scan", "--json", "--lang", "en"], {"CODEX_HOME": cx}).stdout)
    names = [i["name"] for i in items]
    check("T1  codex is still the default target", all(i["agent"] == "codex" for i in items))
    check("T2  codex item names unchanged",
          set(names) >= {"tmp", "tmp2", "plugin-cache", "logs-db", "state-db"}, str(sorted(names)))
    check("T3  codex keeps SQLite vacuum items", any(i["kind"] == "vacuum" for i in items))
    check("T4  codex protected entries are not cleanable", "sessions" not in names)
    check("T5  codex reclaimable total is accurate",
          sum(i["reclaimable_bytes"] for i in items if i["exists"]) == 150000)
    check("T6  codex --age still works",
          run(["--scan", "--json", "--age", "7"], {"CODEX_HOME": cx}).returncode == 0)

    # ---------------- Claude Code ----------------
    cc = mkclaude()
    citems = json.loads(run(["--scan", "--json", "--target", "claude-code", "--lang", "en"],
                            {"CLAUDE_HOME": cc}).stdout)
    cnames = [i["name"] for i in citems]
    check("T7  claude target scans its own home", all(i["agent"] == "claude-code" for i in citems))
    check("T8  claude emits only whitelisted deletes",
          set(cnames) == {"claude-cache", "claude-debug", "claude-shell-snapshots", "claude-statsig"},
          str(sorted(cnames)))
    check("T9  claude has no vacuum item while it has no SQLite",
          not any(i["kind"] == "vacuum" for i in citems))
    check("T10 claude never lists protected dirs",
          not any(n in cnames for n in ("projects", "memory", "skills", "settings.json")))
    check("T11 missing dirs tolerated (exists=false)",
          all(i["exists"] is False for i in citems
              if "snapshots" in i["name"] or "statsig" in i["name"]))
    check("T12 claude reclaimable = cache + debug only",
          sum(i["reclaimable_bytes"] for i in citems if i["exists"]) == 90000)

    r = run(["--scan", "--vacuum", "--target", "claude-code", "--lang", "en"], {"CLAUDE_HOME": cc})
    check("T13 --vacuum on claude reports 'does not apply'", "does not apply" in r.stdout)
    check("T14 --vacuum on claude still exits 0", r.returncode == 0)
    r = run(["--scan", "--rebuild-logs", "--target", "claude-code", "--lang", "en"],
            {"CLAUDE_HOME": cc})
    check("T15 --rebuild-logs on claude reports 'does not apply'", "does not apply" in r.stdout)

    r = run(["--clean", "--yes", "--target", "claude-code", "--lang", "en"], {"CLAUDE_HOME": cc})
    check("T16 claude clean succeeded", r.returncode == 0, r.stderr[:200])
    check("T17 claude cache deleted", not (Path(cc) / "cache").exists())
    check("T18 claude debug deleted", not (Path(cc) / "debug").exists())
    check("T19 claude PROTECTED entries survived",
          all((Path(cc) / p).exists() for p in ("projects/p.jsonl", "memory/m.md",
                                                "skills/s/SKILL.md", "settings.json")))

    cc2 = mkclaude()
    r = run(["--clean", "--yes", "--target", "claude-code", "--json"], {"CLAUDE_HOME": cc2})
    ok = r.stdout.strip().startswith("{")
    check("T20 claude clean emits JSON", ok, r.stdout[:120])
    if ok:
        rep = json.loads(r.stdout)
        check("T21 clean JSON carries agent", rep.get("agent") == "claude-code")
        check("T22 clean JSON protected list is the claude one",
              "projects" in rep.get("protected_untouched", [])
              and "config.toml" not in rep.get("protected_untouched", []))
    else:
        check("T21 clean JSON carries agent", False)
        check("T22 clean JSON protected list is the claude one", False)

    # ---------------- Pi ----------------
    pi = mkpi()
    pitems = json.loads(run(["--scan", "--json", "--target", "pi", "--lang", "en"],
                            {"PI_AGENT_HOME": pi}).stdout)
    pnames = [i["name"] for i in pitems]
    check("T23 pi target scans its own home", all(i["agent"] == "pi" for i in pitems))
    check("T24 pi emits only whitelisted deletes",
          set(pnames) == {"pi-cache", "pi-tmp", "pi-logs", "pi-debug-log"},
          str(sorted(pnames)))
    check("T25 pi protects npm/ (user-installed packages)",
          "npm" not in pnames and "sessions" not in pnames and "skills" not in pnames)
    check("T26 pi missing logs dir tolerated",
          all(i["exists"] is False for i in pitems if i["name"] == "pi-logs"))
    check("T27 pi reclaimable = cache + tmp (+tmp/extensions) + debug log",
          sum(i["reclaimable_bytes"] for i in pitems if i["exists"]) == 58000)
    r = run(["--clean", "--yes", "--target", "pi", "--lang", "en"], {"PI_AGENT_HOME": pi})
    check("T28 pi clean succeeded", r.returncode == 0, r.stderr[:200])
    check("T29 pi cache + tmp deleted",
          not (Path(pi) / "cache").exists() and not (Path(pi) / "tmp").exists())
    check("T30 pi PROTECTED survived (npm/sessions/skills/extensions/settings/trust/auth/models)",
          all((Path(pi) / p).exists() for p in ("npm/pkg/index.js", "sessions/s.jsonl",
                                                "skills/s/SKILL.md", "extensions/ext.ts",
                                                "settings.json", "trust.json",
                                                "auth.json", "models.json")))

    # ---------------- Pi plugin / package ecosystem ----------------
    pifx = mkhome("pi_plug_", [
        ("tmp/extensions/deadbeef/npm/node_modules/pkg/i.js", 12000),
        ("tmp/t.log", 4000), ("pi-debug.log", 2000),
        ("npm/node_modules/userpkg/index.js", 7000),
        ("git/github.com/u/r/file.ts", 6000),
        ("extensions/my-ext.ts", 5000), ("skills/s/SKILL.md", 3000),
        ("sessions/s.jsonl", 1000), ("settings.json", 100),
        ("trust.json", 100), ("auth.json", 100), ("models.json", 100)])
    plug = json.loads(run(["--scan", "--json", "--target", "pi", "--lang", "en"],
                          {"PI_AGENT_HOME": pifx}).stdout)
    pn = {i["name"]: i for i in plug}
    check("T57 pi cleans its debug log",
          "pi-debug-log" in pn and pn["pi-debug-log"]["exists"])
    check("T58 pi tmp covers nested extension checkouts",
          "pi-tmp" in pn
          and pn["pi-tmp"]["path"].replace("\\", "/").endswith("/tmp")
          and pn["pi-tmp"]["reclaimable_bytes"] == 16000,
          str({k: v["reclaimable_bytes"] for k, v in pn.items()}))
    check("T59 pi reclaimable excludes user packages and clones",
          sum(i["reclaimable_bytes"] for i in plug if i["exists"]) == 18000,
          str(sum(i["reclaimable_bytes"] for i in plug if i["exists"])))
    r = run(["--clean", "--yes", "--target", "pi", "--lang", "en"], {"PI_AGENT_HOME": pifx})
    check("T60 pi plugin cleanup succeeds", r.returncode == 0, r.stderr[:200])
    check("T61 pi tmp/ and debug log removed",
          not (Path(pifx) / "tmp").exists() and not (Path(pifx) / "pi-debug.log").exists())
    check("T62 pi user packages + git clones + extensions + skills survived",
          all((Path(pifx) / p).exists() for p in (
              "npm/node_modules/userpkg/index.js", "git/github.com/u/r/file.ts",
              "extensions/my-ext.ts", "skills/s/SKILL.md", "sessions/s.jsonl",
              "settings.json", "trust.json", "auth.json", "models.json")))

    # ---------------- Pi package manifest (pi install) ----------------
    pkgjson = Path(__file__).resolve().parent.parent / "package.json"
    if pkgjson.exists():
        pk = json.loads(pkgjson.read_text(encoding="utf-8"))
        check("T63 package.json declares a pi manifest", "pi" in pk)
        check("T64 pi manifest points at the extension",
              any("pi-extension" in e for e in pk.get("pi", {}).get("extensions", [])),
              str(pk.get("pi", {}).get("extensions")))
        check("T65 pi manifest exposes the skill directory",
              any("skills" in e for e in pk.get("pi", {}).get("skills", [])),
              str(pk.get("pi", {}).get("skills")))
        check("T66 package version matches script VERSION",
              pk.get("version") == _script_version(),
              f"{pk.get('version')} vs {_script_version()}")
        check("T67 extension entry file exists",
              (Path(__file__).resolve().parent.parent / "pi-extension" / "index.ts").exists())
        check("T68 packaged skill is present",
              (Path(__file__).resolve().parent.parent / "skills" / "codex-clean" / "SKILL.md").exists())

    # ---------------- VACUUM is data-driven, not hardcoded ----------------
    ccdb = mkclaude()
    mk(ccdb, "history.sqlite", 4096)          # simulate a future SQLite file
    ditems = json.loads(run(["--scan", "--json", "--target", "claude-code", "--lang", "en"],
                            {"CLAUDE_HOME": ccdb}).stdout)
    check("T31 discovered SQLite becomes a vacuum item (not hardcoded off)",
          any(i["kind"] == "vacuum" and i["name"] == "history" for i in ditems),
          str([i["name"] for i in ditems]))
    r = run(["--scan", "--vacuum", "--target", "claude-code", "--lang", "en"], {"CLAUDE_HOME": ccdb})
    check("T32 with a DB present, 'does not apply' is gone",
          "does not apply" not in r.stdout, r.stdout[:160])

    # ---------------- --age works for non-Codex agents ----------------
    ccage = mkclaude()
    aged = run(["--scan", "--json", "--age", "7", "--target", "claude-code"],
               {"CLAUDE_HOME": ccage}).stdout
    check("T33 --age applies to claude deletes too", "age_filter_days" in aged)

    # ---------------- CLI / i18n ----------------
    check("T34 invalid --target rejected with exit 2",
          run(["--scan", "--target", "nope"]).returncode == 2)
    r = run(["--help", "--lang", "zh"])
    check("T35 zh --help is localized and lists --target",
          "--target" in r.stdout and "agent" in r.stdout)
    check("T36 --target help lists all three agents",
          all(a in run(["--help", "--lang", "en"]).stdout for a in ("codex", "claude-code", "pi")))

    # ---------------- WAL watchdog hint ----------------
    wx = tempfile.mkdtemp(prefix="wal_home_")
    _tmpdirs.append(wx)
    with open(Path(wx) / "logs_2.sqlite-wal", "wb") as f:
        f.truncate(40 * 1024 * 1024)
    check("T37 WAL hint shown when WAL > 32MB",
          "WAL totals" in run(["--scan", "--lang", "en"], {"CODEX_HOME": wx}).stdout)
    check("T38 no WAL hint for a small WAL",
          "WAL totals" not in run(["--scan", "--lang", "en"], {"CODEX_HOME": cx}).stdout)

    # ---------------- F4: --list-targets ----------------
    tgt = json.loads(run(["--list-targets", "--json"]).stdout)
    check("T39 --list-targets JSON lists every agent",
          {t["name"] for t in tgt} == {"codex", "claude-code", "pi", "opencode", "gemini"},
          str(sorted(t["name"] for t in tgt)))
    r = run(["--list-targets", "--lang", "en"])
    check("T40 --list-targets text mode prints agents + capabilities",
          "claude-code" in r.stdout and "pi" in r.stdout and "vacuum=" in r.stdout)

    # ---------------- F1: --target all ----------------
    cx2 = mkhome("all_cx_", [(".tmp/a.bin", 10000)])
    cc3 = mkhome("all_cc_", [("cache/c.bin", 20000)])
    pi3 = mkhome("all_pi_", [("cache/p.bin", 30000)])
    oc3 = mkhome("all_oc_", [("opencode/log/l.bin", 40000)])
    gm3 = mkhome("all_gm_", [(".gemini/tmp/g.bin", 50000)])
    allenv = {"CODEX_HOME": cx2, "CLAUDE_HOME": cc3, "PI_AGENT_HOME": pi3,
              "XDG_DATA_HOME": oc3, "GEMINI_CLI_HOME": gm3}
    ritems = json.loads(run(["--scan", "--json", "--target", "all"], allenv).stdout)
    ags = {i["agent"] for i in ritems}
    check("T41 --target all covers every agent",
          ags == {"codex", "claude-code", "pi", "opencode", "gemini"}, str(sorted(ags)))
    r = run(["--scan", "--target", "all", "--lang", "en"], allenv)
    check("T42 --target all prints one section per agent",
          r.stdout.count("directory:") >= 5, r.stdout[:120])
    r = run(["--clean", "--yes", "--target", "all", "--json"], allenv)
    check("T43 --target all clean runs without crashing", r.returncode == 0,
          r.stderr[:150])
    if r.stdout.strip().startswith("{"):
        rep_all = json.loads(r.stdout)
        check("T44 --target all report unions protected lists",
              "sessions" in rep_all.get("protected_untouched", [])
              and "npm" in rep_all.get("protected_untouched", [])
              and "repos" in rep_all.get("protected_untouched", []))
    else:
        check("T44 --target all report unions protected lists", False)

    # ---------------- F2: --exclude / --only ----------------
    fi = json.loads(run(["--scan", "--json", "--target", "all",
                         "--exclude", "pi-cache"], allenv).stdout)
    check("T45 --exclude drops the named item",
          not any(i["agent"] == "pi" and i["name"] == "pi-cache" for i in fi))
    fi = json.loads(run(["--scan", "--json", "--target", "all",
                         "--exclude", "codex"], allenv).stdout)
    check("T46 --exclude can drop a whole agent",
          not any(i["agent"] == "codex" for i in fi))
    fi = json.loads(run(["--scan", "--json", "--target", "all",
                         "--only", "pi-cache"], allenv).stdout)
    check("T47 --only keeps just the matching item",
          [i["name"] for i in fi] == ["pi-cache"], str([i["name"] for i in fi]))
    fi = json.loads(run(["--scan", "--json", "--target", "all",
                         "--exclude", "projects,sessions"], allenv).stdout)
    check("T48 --exclude accepts a comma-separated list",
          not any(i["name"] in ("projects", "sessions") for i in fi))

    # ---------------- F3: --dry-run ----------------
    dr = mkclaude()
    r = run(["--clean", "--yes", "--dry-run", "--target", "claude-code"],
            {"CLAUDE_HOME": dr})
    check("T49 --dry-run exits 0", r.returncode == 0, r.stderr[:150])
    check("T50 --dry-run deletes nothing", (Path(dr) / "cache").exists())
    rep = json.loads(run(["--clean", "--yes", "--dry-run", "--target",
                          "claude-code", "--json"], {"CLAUDE_HOME": dr}).stdout)
    check("T51 --dry-run JSON sets dry_run", rep.get("dry_run") is True)
    check("T52 --dry-run JSON items are 'planned'",
          bool(rep.get("items")) and all(i["status"] == "planned" for i in rep["items"]))
    check("T53 --dry-run protected list still reported",
          "projects" in rep.get("protected_untouched", []))

    # ---------------- F5: --check N ----------------
    chk = mkhome("chk_home_", [(".tmp/a.bin", 2 * 1024 * 1024)])
    r = run(["--scan", "--check", "1"], {"CODEX_HOME": chk})
    check("T54 --check exits 3 when reclaimable >= threshold",
          r.returncode == 3, "rc=%d" % r.returncode)
    r = run(["--scan", "--check", "500"], {"CODEX_HOME": chk})
    check("T55 --check exits 0 when under threshold",
          r.returncode == 0, "rc=%d" % r.returncode)
    r = run(["--scan", "--check", "1", "--json"], {"CODEX_HOME": chk})
    check("T56 --check still emits JSON and exits 3",
          r.returncode == 3 and r.stdout.strip().startswith("["))

    # ---------------- F5: opencode (multi-root agent) ----------------
    oc_data = mkhome("oc_data_", [("opencode/log/l.bin", 40000),
                                  ("opencode/repos/r.txt", 90000)])
    oc_cache = mkhome("oc_cache_", [("opencode/bin/b.bin", 70000)])
    oc_tmp = mkhome("oc_tmp_", [("opencode/t.bin", 30000)])
    ocenv = {"XDG_DATA_HOME": oc_data, "XDG_CACHE_HOME": oc_cache,
             "OPENCODE_TMPDIR": oc_tmp}
    oitems = json.loads(run(["--scan", "--json", "--target", "opencode"], ocenv).stdout)
    _n = lambda p: p.replace("\\", "/")
    opaths = {i["name"]: _n(i["path"]) for i in oitems}
    check("T69 opencode data home = XDG_DATA_HOME + home_sub",
          opaths.get("opencode-log") == _n(oc_data) + "/opencode/log",
          str(opaths.get("opencode-log")))
    check("T70 opencode cache lives under the separate XDG_CACHE_HOME root",
          opaths.get("opencode-cache") == _n(oc_cache) + "/opencode",
          str(opaths.get("opencode-cache")))
    check("T71 opencode tmp lives under the OS temp root, outside the data home",
          opaths.get("opencode-tmp") == _n(oc_tmp) + "/opencode",
          str(opaths.get("opencode-tmp")))
    check("T72 opencode whitelist covers log/cache/tmp",
          {"opencode-log", "opencode-cache", "opencode-tmp"} <= set(opaths),
          str(sorted(opaths)))
    check("T73 opencode never offers user repos for deletion",
          not any("repos" in p for p in opaths.values()), str(sorted(opaths.values())))
    check("T74 opencode is a first-class target for --target all",
          "opencode" in {t["name"] for t in
                         json.loads(run(["--list-targets", "--json"]).stdout)})

    # ---------------- F6: running-process detection ----------------
    sys.path.insert(0, str(SCRIPT.parent))
    try:
        import codex_clean as _cc
    except Exception:
        _cc = None
    if _cc is not None:
        _cc._running_process_names = lambda: {"codex.exe", "pycharm", "opencode"}
        hits = dict(_cc.running_agents(["codex", "claude-code", "pi", "opencode"]))
        check("T75 detects running agents by exact process stem",
              "Codex" in hits and "opencode" in hits, str(hits))
        check("T76 a short name like 'pi' does not match 'pycharm'",
              "Pi" not in hits, str(hits))
        check("T77 absent agents are not reported",
              "Claude Code" not in hits, str(hits))
        _cc._running_process_names = lambda: set()
        check("T78 an unavailable probe reports nothing (never blocks a clean)",
              _cc.running_agents(["codex", "opencode"]) == [], "non-empty")

        # The warning must never pollute JSON stdout -- it breaks json.loads in
        # automation. Drive main() in-process with a faked process list.
        _cc._running_process_names = lambda: {"codex.exe"}
        cxj = mkhome("json_pure_", [(".tmp/a.bin", 12000)])
        _old_home, _old_argv, _old_out, _old_err = (
            os.environ.get("CODEX_HOME"), sys.argv, sys.stdout, sys.stderr)
        _bo, _be = io.StringIO(), io.StringIO()
        try:
            os.environ["CODEX_HOME"] = cxj
            sys.argv = ["codex_clean.py", "--clean", "--yes", "--json", "--lang", "en"]
            sys.stdout, sys.stderr = _bo, _be
            try:
                _cc.main()
            except SystemExit:
                pass
        finally:
            sys.stdout, sys.stderr, sys.argv = _old_out, _old_err, _old_argv
            if _old_home is None:
                os.environ.pop("CODEX_HOME", None)
            else:
                os.environ["CODEX_HOME"] = _old_home
        try:
            json.loads(_bo.getvalue())
            _pure = True
        except Exception:
            _pure = False
        check("T79 JSON stdout stays parseable while the agent is running",
              _pure, _bo.getvalue()[:120])
        check("T80 the running warning is routed to stderr, not stdout",
              "running" in _be.getvalue().lower(), _be.getvalue()[:120])
    else:
        check("T75 import codex_clean for process-detection tests", False)

    # ---------------- F7: fast walk, symlink policy, honest failures ----------------
    v = run(["--version"])
    check("T81 --version prints the script version",
          v.stdout.strip() == "codex-clean " + _script_version(), v.stdout.strip())

    if _cc is not None:
        _real_unlink = os.unlink
        _boom = lambda *a, **k: (_ for _ in ()).throw(OSError("locked"))

        # A failing unlink must be reported, never swallowed. Regression: the old
        # shutil.rmtree(ignore_errors=True) returned success and the full estimate
        # even when nothing at all was deleted.
        d1 = Path(tempfile.mkdtemp(prefix="v18_fail_"))
        _tmpdirs.append(str(d1))
        (d1 / "a.bin").write_bytes(b"x" * 2048)
        os.unlink = _boom
        try:
            ok1, msg1, got1 = _cc.delete_item(d1)
        finally:
            os.unlink = _real_unlink
        check("T82 a failed delete reports failure", ok1 is False, msg1)
        check("T83 a failed delete reports 0 bytes freed", got1 == 0, str(got1))
        check("T84 the offending path is named", "a.bin" in msg1, msg1)
        check("T85 nothing was actually lost", d1.exists(), str(d1))

        # A successful delete reports what really went away (measured, not assumed).
        d2 = Path(tempfile.mkdtemp(prefix="v18_ok_"))
        _tmpdirs.append(str(d2))
        (d2 / "b.bin").write_bytes(b"y" * 4096)
        ok2, _msg2, got2 = _cc.delete_item(d2)
        check("T86 a successful delete measures freed bytes",
              ok2 is True and got2 == 4096, "ok=%s freed=%s" % (ok2, got2))

        # main() must surface a partial clean as exit code 4 for automation.
        d3 = Path(tempfile.mkdtemp(prefix="v18_exit_"))
        _tmpdirs.append(str(d3))
        (d3 / ".tmp").mkdir()
        (d3 / ".tmp" / "held.bin").write_bytes(b"z" * 1024)
        _oh, _oa, _oo, _oe = (os.environ.get("CODEX_HOME"), sys.argv,
                              sys.stdout, sys.stderr)
        # Separate buffers: the running-process warning goes to stderr, and
        # sharing one buffer would mix it into the JSON we want to parse.
        _bo, _be3 = io.StringIO(), io.StringIO()
        os.unlink = _boom
        try:
            os.environ["CODEX_HOME"] = str(d3)
            sys.argv = ["codex_clean.py", "--clean", "--yes", "--json", "--lang", "en"]
            sys.stdout, sys.stderr = _bo, _be3
            try:
                code3 = _cc.main()
            except SystemExit as e:
                code3 = e.code
        finally:
            os.unlink = _real_unlink
            sys.stdout, sys.stderr, sys.argv = _oo, _oe, _oa
            if _oh is None:
                os.environ.pop("CODEX_HOME", None)
            else:
                os.environ["CODEX_HOME"] = _oh
        check("T87 a partial clean exits 4", code3 == 4, str(code3))
        try:
            _rep3 = json.loads(_bo.getvalue())
        except Exception:
            _rep3 = {}
        check("T88 the JSON report marks the clean as not ok",
              _rep3.get("ok") is False and _rep3.get("failed_items") == 1, str(_rep3.get("ok")))

        # Symlinks: never counted at target size, never followed on delete.
        outd = Path(tempfile.mkdtemp(prefix="v18_out_"))
        _tmpdirs.append(str(outd))
        (outd / "big.bin").write_bytes(b"B" * 40000)
        lh = Path(tempfile.mkdtemp(prefix="v18_link_"))
        _tmpdirs.append(str(lh))
        (lh / "real.bin").write_bytes(b"r" * 1000)
        try:
            os.symlink(str(outd), str(lh / "dirlink"))
            os.symlink(str(outd / "big.bin"), str(lh / "filelink"))
            _links = True
        except (OSError, NotImplementedError, AttributeError):
            _links = False
        if _links:
            check("T89 a symlink target's size is not counted",
                  _cc._size_of(lh) == 1000, str(_cc._size_of(lh)))
            _fails = []
            _cc._remove_path(lh, _fails)
            check("T90 deleting a tree never follows symlinks",
                  (outd / "big.bin").exists() and not lh.exists(), str(_fails))
        else:
            print("  SKIP  T89/T90  symlinks unavailable (needs developer mode on Windows)")

    # ---------------- F8: Gemini CLI (third home-resolution mode) ----------------
    # GEMINI_CLI_HOME replaces the *home* directory; ".gemini" is still appended.
    # Getting this wrong yields $GEMINI_CLI_HOME instead of $GEMINI_CLI_HOME/.gemini,
    # which would scan the wrong place entirely -- hence the explicit assertion.
    g_root = mkhome("gem_home_", [(".gemini/tmp/cache.bin", 9000),
                                  (".gemini/settings.json", 100),
                                  (".gemini/oauth_creds.json", 50)])
    genv = {"GEMINI_CLI_HOME": g_root}
    gitems = json.loads(run(["--scan", "--json", "--target", "gemini"], genv).stdout)
    gpaths = {i["name"]: _n(i["path"]) for i in gitems}
    check("T91 GEMINI_CLI_HOME replaces the home dir, not the agent dir",
          gpaths.get("gemini-tmp") == _n(g_root) + "/.gemini/tmp",
          str(gpaths.get("gemini-tmp")))
    check("T92 gemini exposes its temp dir as the cleanable item",
          set(gpaths) == {"gemini-tmp"}, str(sorted(gpaths)))
    check("T93 gemini never offers config or credentials for deletion",
          not any(k in " ".join(gpaths.values())
                  for k in ("settings.json", "oauth_creds.json")),
          str(sorted(gpaths.values())))
    check("T94 gemini is a first-class target",
          "gemini" in {t["name"] for t in
                       json.loads(run(["--list-targets", "--json"]).stdout)})

    gr = json.loads(run(["--clean", "--yes", "--target", "gemini",
                         "--json", "--lang", "en"], genv).stdout)
    check("T95 gemini clean removes tmp and reports measured bytes",
          gr.get("ok") is True and gr.get("actual_freed_bytes") == 9000
          and not (Path(g_root) / ".gemini" / "tmp").exists(),
          "ok=%s freed=%s" % (gr.get("ok"), gr.get("actual_freed_bytes")))
    check("T96 gemini config and credentials survived the clean",
          (Path(g_root) / ".gemini" / "settings.json").exists()
          and (Path(g_root) / ".gemini" / "oauth_creds.json").exists())

    # The "base" mode must not leak into the other agents: gemini's rel path is
    # appended to the env var, whereas CODEX_HOME names the directory itself.
    cx_self = mkhome("self_cx_", [(".tmp/x.bin", 1000)])
    r_self = json.loads(run(["--scan", "--json"], {"CODEX_HOME": cx_self}).stdout)
    check("T97 CODEX_HOME still names the directory itself",
          any(_n(i["path"]).startswith(_n(cx_self) + "/.tmp") for i in r_self),
          str([_n(i["path"]) for i in r_self]))

    # ---------------- F9: cross-file consistency ----------------
    # The Pi extension test under node carries a literal list of expected agents
    # (node cannot reliably spawn an interpreter across sandboxes, so it is not
    # derived at runtime). Nothing used to tie that literal back to the registry,
    # which is why it went stale twice -- once for opencode, once for gemini, the
    # second time only turning red on CI. This check closes that gap: adding an
    # agent now fails here, locally and immediately.
    try:
        import codex_clean as _ccx
        _want = ",".join(sorted(_ccx.AGENTS))
    except Exception:
        _want = None
    _mjs = Path(__file__).resolve().parent / "test_pi_extension.mjs"
    _src = _mjs.read_text(encoding="utf-8") if _mjs.exists() else ""
    _m = re.search(r'join\(","\) === "([^"]+)"', _src)
    check("T98 the Pi extension test lists exactly the registered agents",
          _want is not None and _m is not None and _m.group(1) == _want,
          "extension has %r, registry has %r" % (_m.group(1) if _m else None, _want))

    # ---------------- F10: config file ----------------
    cf_home = mkhome("cfg_home_", [(".tmp/a.bin", 1000),
                                   ("plugins/cache/b.bin", 2000)])
    cfg_dir = Path(tempfile.mkdtemp(prefix="cfg_file_"))
    _tmpdirs.append(str(cfg_dir))
    no_cfg = str(cfg_dir / "absent.json")      # default path that does not exist

    def wcfg(obj, name="c.json"):
        fp = cfg_dir / name
        fp.write_text(json.dumps(obj), encoding="utf-8")
        return str(fp)

    def cenv(cfg_path=None, **extra):
        """Env for config tests: never let the real default config leak in."""
        e = {"CODEX_HOME": cf_home, "CODEX_CLEAN_CONFIG": cfg_path or no_cfg}
        e.update(extra)
        return e

    def cscan(cfg_path=None, args=(), **extra):
        r = run(["--scan", "--json", *args], cenv(cfg_path, **extra))
        try:
            return {i["name"] for i in json.loads(r.stdout)}, r
        except Exception:
            return set(), r

    base, _ = cscan()
    check("T99 baseline scan finds the fixture items",
          {"tmp", "plugin-cache"} <= base, str(sorted(base)))

    p = wcfg({"exclude": ["codex:tmp"]})
    got, _ = cscan(p)
    check("T100 a config file can narrow the set",
          "tmp" not in got and "plugin-cache" in got, str(sorted(got)))

    # Precedence: CLI > env > config > default. Each case excludes a different item.
    got, _ = cscan(p, args=["--exclude", "codex:plugin-cache"],
                   CODEX_CLEAN_EXCLUDE="codex:tmp")
    check("T101 CLI beats both env and config",
          "plugin-cache" not in got and "tmp" in got, str(sorted(got)))
    got, _ = cscan(p, CODEX_CLEAN_EXCLUDE="codex:plugin-cache")
    check("T102 env beats config", "plugin-cache" not in got and "tmp" in got,
          str(sorted(got)))
    got, _ = cscan(p)
    check("T103 config applies when neither CLI nor env sets it",
          "tmp" not in got and "plugin-cache" in got, str(sorted(got)))

    # SECURITY: the whitelist lives in the registry, so a config file cannot add to it.
    p = wcfg({"deletable": ["evil"], "targets": ["/etc"], "cleanable": ["x"],
              "whitelist": ["y"], "add_cleanable": ["z"]})
    got, r = cscan(p)
    check("T104 a config file cannot add a delete target", got == base,
          str(sorted(got)))
    check("T105 unknown config keys are reported on stderr",
          "deletable" in r.stderr and "targets" in r.stderr, r.stderr[:120])

    # `protected` from the config is additive, never a replacement.
    p = wcfg({"protected": ["my-notes"]})
    rows = json.loads(run(["--list-targets", "--json"],
                          cenv(p)).stdout)
    row = [x for x in rows if x["name"] == "codex"][0]
    check("T106 config protections are added to the registry's",
          "my-notes" in row["protected"] and "sessions" in row["protected"],
          str(row["protected"]))

    # An explicit path must exist; the default one is optional.
    r = run(["--scan", "--json", "--config", str(cfg_dir / "nope.json")],
            {"CODEX_HOME": cf_home})
    check("T107 an explicitly requested missing config fails", r.returncode == 2,
          str(r.returncode))
    r = run(["--scan", "--json"], cenv())
    check("T108 a missing default config is not an error", r.returncode == 0,
          "exit=%s err=%s" % (r.returncode, r.stderr[:60]))

    # Config filtering narrows only; it can never surface a new item.
    p = wcfg({"only": ["codex:tmp"]})
    got, _ = cscan(p)
    check("T109 config `only` narrows the set", got == {"tmp"}, str(sorted(got)))
    p = wcfg({"only": ["codex:sessions"]})       # a protected entry, not an item
    got, _ = cscan(p)
    check("T110 config cannot surface a protected path", got == set(), str(sorted(got)))

    for d in _tmpdirs:
        shutil.rmtree(d, ignore_errors=True)

    bad = [n for n, ok_ in results if not ok_]
    print("\n%d/%d passed" % (len(results) - len(bad), len(results)))
    if bad:
        print("FAILED:", bad)
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
