#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Clean regenerable cache/log/WAL files of AI coding agents (whitelist, confirm before clean).

Agents live in the AGENTS registry: codex (default), claude-code, pi,
opencode and gemini. Per-agent differences (home path, data format, optional capabilities
such as VACUUM) are data, not branches. Protected data (conversations, config,
projects) is never touched.

Usage: codex_clean.py [--scan | --clean] [--config PATH] [--age N] [--vacuum]
                      [--rebuild-logs]
                      [--target codex|claude-code|pi|opencode|gemini|all]
                      [--exclude LIST]
                      [--only LIST] [--dry-run] [--list-targets] [--check N]
                      [--ignore-running]
                      [--json] [--lang en|zh|auto] [--yes]
Settings order: CLI flag > environment variable > config file > built-in
default. The cleanable set itself always comes from the AGENTS registry: a
config file may only narrow it (only/exclude) or add protections.

Lang order: --lang > CODEX_CLEAN_LANG > LANG/LC_ALL > OS UI lang > en.
Exit codes: 0 ok, 2 bad args, 3 reclaimable reached --check threshold,
             4 the cleanup did not fully succeed (some paths survived).
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import sqlite3
import stat
import subprocess
import sys
import tempfile
import time
from pathlib import Path

# Single source of truth: keep in sync with the GitHub Release tag (v1.7.0).
VERSION = "1.9.0"

# Per-agent registry. Adding an agent = one entry here; nothing else branches on
# the agent. Paths are relative to the agent home and resolved at scan time.
#   deletable   -> (item name, relative path, i18n description key)
#   dbs         -> (item name, relative path, i18n key); empty = no SQLite at all
#   capabilities-> optional features that do not apply to every agent
# ---------------------------------------------------------------------------
# Known per-agent LIMITATIONS (verified, not oversights -- see README):
#
#   --rebuild-logs  (claude-code, pi)
#       Neither agent has an "oversized diagnostic log DB". Their logs are plain
#       files (claude: debug/, pi: logs/) already covered by the delete whitelist,
#       so there is no database to rebuild. The flag reports "does not apply".
#
#   --vacuum  (claude-code, pi)
#       Not hardcoded as unsupported: these agents declare no fixed DB list and set
#       discover_dbs=True, so scan() picks up any *.sqlite / *.sqlite3 / *.db found
#       in their home. Verified today: 0 such files under ~/.claude, so --vacuum
#       reports "does not apply" because there is nothing to shrink. If a future
#       release ships a database, VACUUM starts working with no code change.
# ---------------------------------------------------------------------------
AGENTS = {
    "codex": {
        "label": "Codex",
        "home_env": "CODEX_HOME",
        "home_rel": ".codex",
        "deletable": [
            ("tmp", ".tmp", "desc.tmp"),
            ("tmp2", "tmp", "desc.tmp2"),
            ("plugin-cache", "plugins/cache", "desc.plugin-cache"),
        ],
        "dbs": [
            ("logs-db", "logs_2.sqlite", "desc.logs-db"),
            ("state-db", "state_5.sqlite", "desc.state-db"),
            ("threads-db", "thread_history_1.sqlite", "desc.threads-db"),
            ("queue-db", "queue_1.sqlite", "desc.queue-db"),
            ("goals-db", "goals_1.sqlite", "desc.goals-db"),
            ("memories-db", "memories_1.sqlite", "desc.memories-db"),
        ],
        "protected": [
            "sessions", "config.toml", "auth.json", "backups", "backups_state",
            "cc-switch-model-catalog.json", "rules", "skills",
        ],
        "rebuild_db": "logs-db",
        "discover_dbs": False,
        "capabilities": {"vacuum": True, "rebuild_logs": True},
        # Desktop ships as an Appx package, hence the dotted name.
        "procs": ["codex", "openai.codex", "chatgpt"],
    },
    "claude-code": {
        "label": "Claude Code",
        "home_env": "CLAUDE_HOME",
        "home_rel": ".claude",
        # Conversations are JSONL; no fixed DB list -> databases are discovered
        # at runtime (see the LIMITATIONS block above).
        "deletable": [
            ("claude-cache", "cache", "desc.claude-cache"),
            ("claude-debug", "debug", "desc.claude-debug"),
            ("claude-shell-snapshots", "shell-snapshots", "desc.claude-snapshots"),
            ("claude-statsig", "statsig", "desc.claude-statsig"),
        ],
        "dbs": [],
        "protected": [
            "projects", "memory", "plugins", "skills", "settings.json", "config.json",
            "backups", "sessions", "ide", "history.jsonl",
        ],
        "rebuild_db": None,
        "discover_dbs": True,
        "capabilities": {"vacuum": True, "rebuild_logs": False},
        "procs": ["claude"],
    },
    "pi": {
        "label": "Pi",
        "home_env": "PI_AGENT_HOME",
        "home_rel": ".pi/agent",
        # Verified against pi source (packages/coding-agent/src/config.ts and
        # core/package-manager.ts). ~/.pi/agent holds sessions/, skills/,
        # extensions/, npm/ (node_modules of user-installed packages), git/
        # (cloned packages), bin/, tools/, prompts/, themes/, settings.json,
        # trust.json, auth.json, models.json, models-store.json, AGENTS.md,
        # SYSTEM.md -- all user data, all protected.
        # Regenerable: tmp/ (incl. tmp/extensions/<hash> package checkouts) and
        # the debug log. cache/ and logs/ are not documented by pi; they are
        # kept as best-effort entries and only touched if they actually exist.
        "deletable": [
            ("pi-cache", "cache", "desc.pi-cache"),
            ("pi-tmp", "tmp", "desc.pi-tmp"),
            ("pi-logs", "logs", "desc.pi-logs"),
            ("pi-debug-log", "pi-debug.log", "desc.pi-debug-log"),
        ],
        "dbs": [],
        "protected": [
            "sessions", "skills", "extensions", "npm", "git", "bin", "tools",
            "prompts", "themes", "settings.json", "trust.json", "auth.json",
            "AGENTS.md", "SYSTEM.md", "models.json", "models-store.json",
        ],
        "rebuild_db": None,
        "discover_dbs": True,
        "capabilities": {"vacuum": True, "rebuild_logs": False},
        "procs": ["pi"],
    },
    "opencode": {
        "label": "opencode",
        # opencode spreads its data across SEVERAL XDG roots, so it needs the
        # extra-roots mechanism (see `roots`) instead of a single home dir.
        "home_env": "XDG_DATA_HOME",
        "home_rel": ".local/share",
        "home_sub": "opencode",
        # Verified against opencode source (packages/core/src/global.ts) and
        # xdg-basedir@5.1.0, the version it declares. xdg-basedir 5.x has NO
        # macOS/Windows fallback, so the XDG roots are used verbatim on every
        # platform: on Windows the data dir is ~/.local/share/opencode, NOT
        # %LOCALAPPDATA%. Counter-intuitive, hence spelled out here.
        #   data  = $XDG_DATA_HOME/opencode  | ~/.local/share/opencode
        #   cache = $XDG_CACHE_HOME/opencode | ~/.cache/opencode
        #   tmp   = os.tmpdir()/opencode
        #   log   = data/log    bin = cache/bin    repos = data/repos
        #   db    = data/opencode.db (journal_mode=WAL, per database.ts)
        # OPENCODE_TEST_HOME is test-only and OPENCODE_CONFIG_DIR redirects
        # only the config dir, so neither is used to resolve the data home.
        "deletable": [
            ("opencode-log", "log", "desc.opencode-log"),
            ("opencode-cache", "@cache", "desc.opencode-cache"),
            ("opencode-tmp", "@tmp", "desc.opencode-tmp"),
        ],
        "dbs": [
            ("opencode-db", "opencode.db", "desc.opencode-db"),
        ],
        # repos/ holds cloned user repos; state/ holds Flock lock files.
        "protected": ["repos", "config", "state", "auth.json"],
        "rebuild_db": None,
        "discover_dbs": True,
        "capabilities": {"vacuum": True, "rebuild_logs": False},
        "procs": ["opencode"],
        "roots": {
            # name -> env override, subdir joined onto that env value, and the
            # default used when the env var is unset.
            "cache": {"env": "XDG_CACHE_HOME", "dir": "opencode",
                      "base": "home", "default": ".cache/opencode"},
            "tmp": {"env": "OPENCODE_TMPDIR", "dir": "opencode",
                    "base": "tmp", "default": "opencode"},
        },
    },
    "gemini": {
        "label": "Gemini CLI",
        # home_env_mode="base": GEMINI_CLI_HOME replaces the *home* directory
        # and GEMINI_DIR ('.gemini') is still appended -- unlike CODEX_HOME,
        # which names the directory itself.
        "home_env": "GEMINI_CLI_HOME",
        "home_rel": ".gemini",
        "home_env_mode": "base",
        # Verified against gemini-cli source, not its docs:
        #   packages/core/src/utils/paths.ts  -> GEMINI_DIR='.gemini';
        #       homedir() returns $GEMINI_CLI_HOME or os.homedir()
        #   packages/core/src/config/storage.ts -> the layout below
        #   dir = $GEMINI_CLI_HOME/.gemini  |  ~/.gemini
        #
        # Only tmp/ is regenerable: it holds scratch files plus the binaries
        # downloaded into tmp/bin (TMP_DIR_NAME / BIN_DIR_NAME).
        #
        # Everything else must be treated as user data, because by default
        # getGlobalRuntimeDir() returns the SAME directory as the config dir:
        # ~/.gemini mixes config AND runtime state -- settings.json,
        # oauth_creds.json, google_accounts.json, trustedFolders.json,
        # installation_id, policy_integrity.json, mcp-oauth-tokens.json,
        # a2a-oauth-tokens.json, chat history, and the user's own commands/,
        # skills/, agents/, policies/, keybindings.json.
        # (~/.cache/.gemini is used only under the macOS seatbelt sandbox,
        # SANDBOX=sandbox-exec, so it is deliberately not scanned.)
        # User skills also live in ~/.agents, outside this home entirely, so
        # they are never in scan scope.
        "deletable": [
            ("gemini-tmp", "tmp", "desc.gemini-tmp"),
        ],
        "dbs": [],
        "protected": [
            "settings.json", "oauth_creds.json", "google_accounts.json",
            "trustedFolders.json", "installation_id", "policy_integrity.json",
            "mcp-oauth-tokens.json", "a2a-oauth-tokens.json", "auto-saved.toml",
            "commands", "skills", "agents", "policies", "keybindings.json",
            "history",
        ],
        "rebuild_db": None,
        "discover_dbs": True,
        "capabilities": {"vacuum": True, "rebuild_logs": False},
        "procs": ["gemini"],
    },
}



def agent_home(target: str) -> Path:
    """Resolve an agent's data directory.

    `home_env_mode` selects how the env var is interpreted:
      "dir"  (default) -- the env var names the agent's directory itself
                          (CODEX_HOME / CLAUDE_HOME / PI_AGENT_HOME);
      "base"           -- the env var replaces the user's *home*, and the
                          relative path is still appended. Gemini CLI works
                          this way: GEMINI_CLI_HOME=/x means the directory is
                          /x/.gemini, not /x.

    With no env var set both modes fall back to home / home_rel. `home_sub` is
    appended in every branch, which is what keeps opencode working: its env var
    points at a shared XDG root rather than at opencode's own directory.
    """
    spec = AGENTS[target]
    env = os.environ.get(spec["home_env"])
    if not env:
        base = Path.home() / spec["home_rel"]
    elif spec.get("home_env_mode") == "base":
        base = Path(env) / spec["home_rel"]
    else:
        base = Path(env)
    sub = spec.get("home_sub")
    return base / sub if sub else base


def agent_root(target: str, name: str) -> Path:
    """Resolve a secondary directory from an agent's `roots` map.

    Needed by agents that spread data over several roots -- opencode keeps its
    cache under XDG_CACHE_HOME and its temp files under the OS temp dir, and
    neither lives under its data home.
    """
    r = AGENTS[target]["roots"][name]
    if os.environ.get(r["env"]):
        return Path(os.environ[r["env"]]) / r["dir"]
    base = Path.home() if r.get("base", "home") == "home" else Path(tempfile.gettempdir())
    return base / r["default"]


def resolve_item_path(target: str, home: Path, rel: str) -> Path:
    """Resolve a registry item path, honouring `@root[/sub]` secondary roots."""
    if not rel.startswith("@"):
        return home / rel
    root_name, _, sub = rel[1:].partition("/")
    base = agent_root(target, root_name)
    return base / sub if sub else base

# i18n
_MSGS = {
    "en": {
        "prog.desc": "Codex cache/log cleaner v{v}",
        "scan.title": "=== {label} cleanable items (read-only scan) ===",
        "scan.codedir": "{label} directory: {path}",
        "scan.agefilter": "Age filter: only files older than {days} days are counted",
        "scan.reclaim": "Estimated reclaimable: {size}",
        "scan.of_total": "  (DB total {size})",
        "scan.hint": "\nRun --clean to confirm item-by-item; --clean --yes to clean all safe items;",
        "scan.hint2": "add --vacuum to allow DB VACUUM; add --rebuild-logs to rebuild oversized log DB.",
        "desc.tmp": "Temp download/extract cache (plugins/marketplaces)",
        "desc.tmp2": "Codex temp directory",
        "desc.plugin-cache": "Plugin cache (re-downloadable)",
        "desc.logs-db": "Runtime log DB",
        "desc.state-db": "Session state DB (VACUUM/WAL only, data kept)",
        "desc.threads-db": "Thread history DB (VACUUM/WAL only)",
        "desc.queue-db": "Queue DB (VACUUM/WAL only)",
        "desc.goals-db": "Goals DB (VACUUM/WAL only)",
        "desc.memories-db": "Memories DB (VACUUM/WAL only)",
        "desc.logs-rebuild": "Log DB exceeds {mb}MB; rebuild recommended (backup then recreate; VACUUM keeps diagnostics)",
        "action.delete": "Delete {size}",
        "action.delete_aged": "Delete files older than {days}d ({size})",
        "action.vacuum": "VACUUM shrink + WAL cleanup (est. reclaim)",
        "action.rebuild": "Back up and rebuild log DB (reclaim {size})",
        "clean.none": "No cleanable safe items found (pure deletes gone? or add --vacuum/--rebuild-logs).",
        "confirm.autoyes": "Auto-confirmed via --yes for:",
        "confirm.title": "=== Items to confirm ===",
        "confirm.prompt": "\nEnter numbers to clean (comma separated), all=everything, or empty=cancel:",
        "confirm.invalid": "Invalid input, cancelled.",
        "confirm.cancelled": "Cancelled.",
        "confirm.none": "No items selected.",
        "clean.title": "\n=== Running cleanup ===",
        "clean.estimated": "Estimated: {size}",
        "clean.actual": "Actually freed: {size}",
        "clean.delta": "Delta vs estimate: {delta}",
        "clean.freed": "Estimated space freed: {size}",
        "clean.tip": "Tip: deleted .tmp/plugins-cache and rebuilt log DB will be auto-recreated by Codex on next start.",
        "clean.failed_summary": "{n} item(s) did not fully clean -- see the lines marked failed above.",
        "db.notexists": "not found",
        "db.vacuum_ok": "VACUUM + WAL cleanup done",
        "db.vacuum_fail": "failed: {err}",
        "db.wal_ok": "WAL checkpointed",
        "delete_ok": "deleted",
        "delete_aged_ok": "removed {n} files older than {days}d ({size})",
        "delete_fail": "failed: {err}",
        "delete_partial": "{n} path(s) could not be removed (first: {err})",
        "delete_none_aged": "nothing older than {days}d",
        "rebuild_ok": "backed up to {name} and rebuilt (Codex recreates empty DB on next start)",
        "rebuild_fail": "failed: {err}",
        "arg.age": "only clean temp files older than N days (0 = no filter)",
        "arg.scan": "read-only scan (default)",
        "arg.clean": "run cleanup (confirm each item)",
        "arg.yes": "auto-confirm, skip interaction (required with --clean --json)",
        "arg.vacuum": "allow DB VACUUM (with --clean)",
        "arg.rebuild": "allow rebuilding oversized log DB (with --clean)",
        "arg.lang": "output language (default: auto-detect)",
        "arg.json": "machine-readable output",
        "arg.target": "which agent's data to clean (default: codex)",
        "scan.wal_hint": "Hint: WAL totals {size} - consider a periodic --clean --vacuum.",
        "scan.no_vacuum": "Note: --vacuum does not apply - no SQLite databases found under this target.",
        "scan.no_rebuild": "Note: this target has no oversized log DB, so --rebuild-logs does not apply.",
        "desc.claude-cache": "Claude Code cache (regenerable)",
        "desc.claude-debug": "Claude Code debug logs (regenerable)",
        "desc.claude-snapshots": "Shell snapshots (regenerable)",
        "desc.claude-statsig": "Statsig/telemetry cache (regenerable)",
        "desc.pi-cache": "Pi cache (regenerable; best-effort, cleaned only if present)",
        "desc.pi-tmp": "Pi temp files (regenerable; best-effort)",
        "desc.pi-logs": "Pi logs (regenerable; best-effort)",
        "desc.pi-debug-log": "Pi debug log (regenerable)",
        "desc.gemini-tmp": "Gemini CLI temp files + downloaded binaries (regenerable)",
        "desc.opencode-log": "opencode log directory (regenerable)",
        "desc.opencode-cache": "opencode cache incl. downloaded binaries (re-downloadable)",
        "desc.opencode-tmp": "opencode temp files (regenerable)",
        "desc.opencode-db": "opencode state DB (VACUUM/WAL only, data kept)",
        "proc.running": "{label} appears to be running ({procs})",
        "proc.hint": "A live process may hold open handles on deleted files, so the space is not reclaimed until it exits.",
        "proc.hint2": "Best practice: quit the agent first, or pass --ignore-running to skip this check.",
        "proc.prompt": "Continue anyway? (y/N):",
        "arg.ignorerunning": "skip the running-process check before cleaning",
        "arg.config": "path to a JSON config file (default: per-OS location)",
        "cfg.missing": "config file not found: {path}",
        "cfg.bad": "cannot read config {path}: {err}",
        "cfg.notobj": "config {path} must be a JSON object",
        "cfg.unknown": "ignoring unknown config key: {name}",
        "cfg.badtype": "ignoring config key {name}: wrong type",
        "cfg.bad_target": "invalid target in config: {name}",
        "desc.discovered-db": "Auto-discovered SQLite DB (VACUUM/WAL only, data kept)",
        "arg.exclude": "comma-separated item or agent:item names to skip",
        "arg.only": "comma-separated item or agent:item names to keep (inverse of --exclude)",
        "arg.dryrun": "show what --clean would do, without changing anything",
        "arg.listtargets": "list supported agents and their capabilities, then exit",
        "arg.check": "exit 3 when reclaimable space reaches N MB (0 = off; for automation)",
        "list.title": "=== Available cleanup targets ===",
        "dry.title": "=== Dry run - no changes will be made ===",
        "check.over": "Reclaimable {size} reached the {thr} threshold",
        "json.est_vs_act": "estimated={est} actual={act} delta={delta}",
    },
    "zh": {
        "prog.desc": "Codex 缓存/日志完整清理器 v{v}",
        "scan.title": "=== {label} 可清理项(只读扫描) ===",
        "scan.codedir": "{label} 目录: {path}",
        "scan.agefilter": "年龄过滤: 仅统计超过 {days} 天的文件",
        "scan.reclaim": "预计可回收: {size}",
        "scan.of_total": "  (库总 {size})",
        "scan.hint": "\n运行 --clean 逐项确认; --clean --yes 全清安全项;",
        "scan.hint2": "加 --vacuum 允许 VACUUM; 加 --rebuild-logs 允许重建超大日志库。",
        "desc.tmp": "临时下载/解压缓存(插件/市场)",
        "desc.tmp2": "Codex 临时目录",
        "desc.plugin-cache": "插件缓存(可重新下载)",
        "desc.logs-db": "运行日志库",
        "desc.state-db": "会话状态库(仅VACUUM/WAL,不清数据)",
        "desc.threads-db": "线程历史库(仅VACUUM/WAL)",
        "desc.queue-db": "队列库(仅VACUUM/WAL)",
        "desc.goals-db": "目标库(仅VACUUM/WAL)",
        "desc.memories-db": "记忆库(仅VACUUM/WAL)",
        "desc.logs-rebuild": "日志库超过 {mb}MB, 建议重建(备份后重建; VACUUM保留诊断数据)",
        "action.delete": "删除 {size}",
        "action.delete_aged": "删除超过 {days} 天的文件 ({size})",
        "action.vacuum": "VACUUM收缩+WAL清理(可回收估算)",
        "action.rebuild": "备份并重建日志库(可回收 {size})",
        "clean.none": "没有可清理的安全项(纯删除项已无? 或需加 --vacuum/--rebuild-logs)",
        "confirm.autoyes": "已通过 --yes 自动确认以下项:",
        "confirm.title": "=== 待确认清理项 ===",
        "confirm.prompt": "\n输入要清理的编号(逗号分隔), 或 all=全部, 或空=取消:",
        "confirm.invalid": "输入无效, 取消",
        "confirm.cancelled": "取消",
        "confirm.none": "未选择任何项",
        "clean.title": "\n=== 执行清理 ===",
        "clean.estimated": "预估: {size}",
        "clean.actual": "实际释放: {size}",
        "clean.delta": "与预估差值: {delta}",
        "clean.freed": "预计释放: {size}",
        "clean.tip": "提示: 删除的 .tmp/plugins-cache 和重建的日志库, Codex 下次启动会自动重建所需部分。",
        "clean.failed_summary": "有 {n} 项未能完全清理——请查看上方标记为失败的条目。",
        "db.notexists": "不存在",
        "db.vacuum_ok": "VACUUM+WAL清理完成",
        "db.vacuum_fail": "失败: {err}",
        "db.wal_ok": "WAL 已 checkpoint",
        "delete_ok": "已删除",
        "delete_aged_ok": "已删除 {n} 个超过 {days} 天的文件 ({size})",
        "delete_fail": "失败: {err}",
        "delete_partial": "有 {n} 个路径无法删除(首个: {err})",
        "delete_none_aged": "没有超过 {days} 天的文件",
        "rebuild_ok": "已备份到 {name} 并重建(Codex下次启动自动生成空库)",
        "rebuild_fail": "失败: {err}",
        "arg.age": "仅清理超过 N 天的临时文件 (0=不过滤)",
        "arg.scan": "只读扫描(默认)",
        "arg.clean": "执行清理(逐项确认)",
        "arg.yes": "自动确认, 跳过交互(--clean --json 时必需)",
        "arg.vacuum": "允许数据库 VACUUM (配合 --clean)",
        "arg.rebuild": "允许重建超大日志库 (配合 --clean)",
        "arg.lang": "输出语言(默认自动检测)",
        "arg.json": "机器可读输出",
        "arg.target": "要清理哪个 agent 的数据(默认: codex)",
        "scan.wal_hint": "提示: WAL 合计 {size}, 建议定期执行 --clean --vacuum。",
        "scan.no_vacuum": "说明: --vacuum 不适用——该目标下未发现 SQLite 数据库。",
        "scan.no_rebuild": "说明: 该目标没有超大日志库, --rebuild-logs 不适用。",
        "desc.claude-cache": "Claude Code 缓存(可再生)",
        "desc.claude-debug": "Claude Code 调试日志(可再生)",
        "desc.claude-snapshots": "Shell 快照(可再生)",
        "desc.claude-statsig": "Statsig/遥测缓存(可再生)",
        "desc.pi-cache": "Pi 缓存(可再生; 尽力而为, 仅当存在时清理)",
        "desc.pi-tmp": "Pi 临时文件(可再生; 尽力而为)",
        "desc.pi-logs": "Pi 日志(可再生; 尽力而为)",
        "desc.pi-debug-log": "Pi 调试日志(可再生)",
        "desc.gemini-tmp": "Gemini CLI 临时文件与已下载的可执行文件(可再生)",
        "desc.opencode-log": "opencode 日志目录(可再生)",
        "desc.opencode-cache": "opencode 缓存, 含已下载的可执行文件(可重新下载)",
        "desc.opencode-tmp": "opencode 临时文件(可再生)",
        "desc.opencode-db": "opencode 状态库(仅 VACUUM/WAL, 保留数据)",
        "proc.running": "{label} 似乎正在运行({procs})",
        "proc.hint": "运行中的进程可能仍持有被删除文件的句柄, 磁盘空间要等它退出后才真正释放。",
        "proc.hint2": "最佳实践: 先退出该 agent, 或用 --ignore-running 跳过此检查。",
        "proc.prompt": "仍要继续吗? (y/N):",
        "arg.ignorerunning": "跳过清理前的进程占用检查",
        "arg.config": "JSON 配置文件路径（默认取系统对应位置）",
        "cfg.missing": "找不到配置文件: {path}",
        "cfg.bad": "无法读取配置 {path}: {err}",
        "cfg.notobj": "配置 {path} 必须是一个 JSON 对象",
        "cfg.unknown": "忽略未知的配置项: {name}",
        "cfg.badtype": "忽略配置项 {name}: 类型不对",
        "cfg.bad_target": "配置中的目标无效: {name}",
        "desc.discovered-db": "自动发现的 SQLite 库(仅VACUUM/WAL, 保留数据)",
        "arg.exclude": "逗号分隔的项名或 agent:项名, 跳过这些项",
        "arg.only": "逗号分隔的项名或 agent:项名, 只保留这些项(--exclude 的反义)",
        "arg.dryrun": "只显示 --clean 将要做什么, 不做任何改动",
        "arg.listtargets": "列出支持的 agent 及其能力后退出",
        "arg.check": "可回收空间达到 N MB 时以退出码 3 返回(0=关闭; 用于自动化)",
        "list.title": "=== 可用清理目标 ===",
        "dry.title": "=== 预演 - 不会做任何改动 ===",
        "check.over": "可回收 {size} 已达到阈值 {thr}",
        "json.est_vs_act": "预估={est} 实际={act} 差值={delta}",
    },
}

_LANG = "en"
_AGE_DAYS = 0


def _t(key: str, **kw) -> str:
    table = _MSGS.get(_LANG) or _MSGS["en"]
    tmpl = table.get(key) or _MSGS["en"].get(key, key)
    return tmpl.format(**kw) if kw else tmpl


def _detect_sys_lang() -> str:
    """Return OS UI language hint: 'zh' for Chinese, 'en' otherwise."""
    if os.name == "nt":
        try:
            import ctypes
            lang_id = ctypes.windll.kernel32.GetUserDefaultUILanguage()
            if (lang_id & 0x3FF) == 0x04:  # Chinese primary language
                return "zh"
        except Exception:
            pass
    return "en"


def _pre_scan_lang(argv: list[str]) -> str:
    """Read the requested language before argparse builds its localized help text."""
    for i, a in enumerate(argv):
        if a == "--lang" and i + 1 < len(argv):
            return argv[i + 1]
        if a.startswith("--lang="):
            return a.split("=", 1)[1]
    return os.environ.get("CODEX_CLEAN_LANG") or "auto"


def _resolve_lang(lang_arg: str) -> str:
    if lang_arg in ("en", "zh"):
        return lang_arg
    for env in ("CODEX_CLEAN_LANG", "LANG", "LC_ALL"):
        v = os.environ.get(env, "")
        if v.lower().startswith("zh"):
            return "zh"
        if v.lower().startswith("en"):
            return "en"
    return _detect_sys_lang()


# Backwards-compatible aliases (Codex stays the default target).
CODEX_HOME = agent_home("codex")
PROTECTED = AGENTS["codex"]["protected"]

LOGS_REBUILD_MB = 100
WAL_WARN_MB = 32


# Helpers
def _walk_files(root: Path, dirs: list = None):
    """Yield (path, size, mtime) for every regular file under `root`.

    Uses os.scandir rather than os.walk: a DirEntry caches the stat data the OS
    already returned while reading the directory, which removes a per-file
    syscall. Measured ~30x faster than os.walk + Path.stat on a 12k-file tree
    on Windows, where path resolution dominates the old approach.

    Symlinks are never followed and never counted. A link is skipped entirely
    so it cannot inflate the reclaimable figure with the size of a target that
    lives outside the agent's home, and we never descend through one. When
    `dirs` is given, directories are appended to it (used to prune empty
    directories after an age-filtered delete).
    """
    stack = [str(root)]
    while stack:
        cur = stack.pop()
        try:
            it = os.scandir(cur)
        except OSError:
            continue
        with it:
            for e in it:
                try:
                    if e.is_dir(follow_symlinks=False):
                        if dirs is not None:
                            dirs.append(e.path)
                        stack.append(e.path)
                        continue
                    if not e.is_file(follow_symlinks=False):
                        continue          # symlink, socket, fifo, device
                    st = e.stat(follow_symlinks=False)
                except OSError:
                    continue
                yield e.path, st.st_size, st.st_mtime


def _size_of(p: Path) -> int:
    if not p.exists():
        return 0
    try:
        # A symlink is measured as the link itself, never as its target.
        if p.is_file() or p.is_symlink():
            return p.lstat().st_size
    except OSError:
        return 0
    total = 0
    for _path, size, _mtime in _walk_files(p):
        total += size
    return total
def human(n: int) -> str:
    n = max(0, n)
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024 or unit == "GB":
            return f"{n:.1f} {unit}" if unit != "B" else f"{n} B"
        n /= 1024
    return f"{n:.1f} GB"


def _db_sizes(db_path: Path) -> tuple[int, int, int]:
    main = _size_of(db_path)
    wal = _size_of(Path(str(db_path) + "-wal"))
    shm = _size_of(Path(str(db_path) + "-shm"))
    return main, wal, shm


def _age_stats(root: Path, days: float) -> tuple[int, int, int, int]:
    """Return (eligible_bytes, eligible_count, total_bytes, total_count); days<=0 = no filter.

    Symlinks are skipped by _walk_files, so a link can never make the estimate
    reflect data that actually lives outside the agent's home.
    """
    if not root.exists():
        return 0, 0, 0, 0
    cutoff = time.time() - days * 86400 if days > 0 else None
    try:
        if root.is_file() or root.is_symlink():
            st = root.lstat()
            old = cutoff is None or st.st_mtime < cutoff
            return (st.st_size, 1, st.st_size, 1) if old else (0, 0, st.st_size, 1)
    except OSError:
        return 0, 0, 0, 0
    eb = ec = tb = tc = 0
    for _path, size, mtime in _walk_files(root):
        tb += size
        tc += 1
        if cutoff is None or mtime < cutoff:
            eb += size
            ec += 1
    return eb, ec, tb, tc
def _planned_action(kind: str, path: str, reclaim_bytes: int, days: int) -> dict:
    """Structured dry-run preview of what cleaning this item would do."""
    return {
        "type": kind,
        "target": path,
        "reclaimable_bytes": reclaim_bytes,
        "reclaimable": human(reclaim_bytes),
        "reversible": kind == "vacuum",  # vacuum keeps data; deletes do not
        "confirm_required": True,
        "age_filter_days": days if (days > 0 and kind == "delete") else None,
    }


def scan(age_days: int = 0, target: str = "codex"):
    spec = AGENTS.get(target) or AGENTS["codex"]
    home = agent_home(target)
    caps = spec["capabilities"]
    items = []
    for name, rel, dkey in spec["deletable"]:
        path = resolve_item_path(target, home, rel)
        eb, ec, tb, tc = _age_stats(path, age_days)
        # With an age filter only the eligible bytes are actually reclaimable.
        sz = eb if age_days > 0 else tb
        action = (_t("action.delete_aged", days=age_days, size=human(sz))
                  if age_days > 0 else _t("action.delete", size=human(sz)))
        items.append({
            "kind": "delete", "name": name, "path": str(path), "agent": target,
            "desc": _t(dkey), "size_bytes": sz, "size": human(sz),
            "exists": path.exists(), "action": action,
            "age_filter_days": age_days if age_days > 0 else None,
            "eligible_bytes": eb, "eligible_size": human(eb),
            "eligible_files": ec, "total_files": tc,
            "total_bytes": tb, "total_size": human(tb),
            "reclaimable_bytes": sz,
            "planned_action": _planned_action("delete", str(path), sz, age_days),
            "safe": True,
        })
    if caps["vacuum"]:
        db_specs = list(spec["dbs"])
        # No fixed DB list -> discover SQLite files at runtime. Finding none is
        # normal for agents that store JSONL; --vacuum then reports "does not apply".
        if spec.get("discover_dbs"):
            for pat in ("*.sqlite", "*.sqlite3", "*.db"):
                for p in sorted(home.glob(pat)):
                    if p.is_file() and all(p.name != r for _n, r, _k in db_specs):
                        db_specs.append((p.stem, p.name, "desc.discovered-db"))
        for name, rel, dkey in db_specs:
            db_path = resolve_item_path(target, home, rel)
            main, wal, shm = _db_sizes(db_path)
            total = main + wal + shm
            has_db = db_path.exists()
            items.append({
                "kind": "vacuum", "name": name, "path": str(db_path), "agent": target,
                "desc": _t(dkey), "size_bytes": total, "size": human(total),
                "exists": has_db, "db_main": main, "db_wal": wal, "db_shm": shm,
                "action": _t("action.vacuum"),
                "age_filter_days": None,
                "reclaimable_bytes": wal,
                "planned_action": _planned_action("vacuum", str(db_path), wal, 0),
                "safe": True,
            })
            if spec["rebuild_db"] == name and main > LOGS_REBUILD_MB * 1024 * 1024:
                items.append({
                    "kind": "rebuild", "name": "logs-rebuild", "path": str(db_path),
                    "agent": target,
                    "desc": _t("desc.logs-rebuild", mb=LOGS_REBUILD_MB),
                    "size_bytes": main, "size": human(main), "exists": True,
                    "action": _t("action.rebuild", size=human(main)),
                    "age_filter_days": None,
                    "reclaimable_bytes": main,
                    "planned_action": _planned_action("rebuild", str(db_path), main, 0),
                    "safe": False,  # destructive: requires explicit --rebuild-logs
                })
    # Surface the biggest reclaimable wins first for easier triage.
    items.sort(key=lambda i: i.get("reclaimable_bytes", 0), reverse=True)
    return items


def vacuum_db(db_path: Path) -> tuple[bool, str, int]:
    """VACUUM + WAL checkpoint. Returns (ok, message, reclaimed_bytes).

    reclaimed_bytes is the measured before/after size delta (main + wal + shm).
    """
    if not db_path.exists():
        return False, _t("db.notexists"), 0
    before = sum(_db_sizes(db_path))
    try:
        con = sqlite3.connect(str(db_path), timeout=5)
        con.execute("PRAGMA wal_checkpoint(TRUNCATE);")
        con.execute("VACUUM;")
        con.commit()
        con.close()
        after = sum(_db_sizes(db_path))
        return True, _t("db.vacuum_ok"), max(0, before - after)
    except Exception as e:
        after = sum(_db_sizes(db_path))
        return False, _t("db.vacuum_fail", err=e), max(0, before - after)


def _remove_path(path: Path, failures: list) -> None:
    """Remove `path` (file or tree), recording anything that survived.

    Hand-rolled rather than shutil.rmtree, for three reasons:
      * rmtree(ignore_errors=True) hides failures -- which is exactly how this
        tool used to report success after deleting nothing;
      * we already walk bottom-up with scandir, so this reuses the fast path;
      * symlinks are unlinked as links and never traversed;
      * a read-only file is made writable and retried once, because Windows
        agents do leave them behind and one such file used to abort the tree.
    """
    if path.is_symlink() or not path.is_dir():
        try:
            os.unlink(path)
        except OSError:
            try:
                if not path.is_symlink():
                    os.chmod(path, stat.S_IWRITE)
                os.unlink(path)
            except OSError:
                failures.append(str(path))
        return

    # Post-order traversal: children must be gone before a parent can be rmdir'd.
    stack = [(str(path), False)]
    while stack:
        cur, expanded = stack.pop()
        if not expanded:
            stack.append((cur, True))
            try:
                with os.scandir(cur) as it:
                    for e in it:
                        try:
                            if e.is_dir(follow_symlinks=False):
                                stack.append((e.path, False))
                        except OSError:
                            pass
            except OSError:
                pass
            continue
        try:
            with os.scandir(cur) as it:
                entries = [(e.path,
                            e.is_dir(follow_symlinks=False),
                            e.is_symlink()) for e in it]
        except OSError:
            entries = []
        for p, isdir, islink in entries:
            if isdir:
                continue              # its own stack entry handles it
            try:
                os.unlink(p)
            except OSError:
                try:
                    if not islink:
                        os.chmod(p, stat.S_IWRITE)
                    os.unlink(p)
                except OSError:
                    failures.append(p)
        try:
            os.rmdir(cur)
        except OSError:
            failures.append(cur)


def delete_item(path: Path) -> tuple[bool, str, int]:
    """Delete a whitelisted path. Returns (ok, message, actually_freed_bytes).

    `freed` is measured (size before minus size after), not assumed, so the
    number in the report is what really went away. Anything that survived is
    reported as a failure rather than silently swallowed.
    """
    before = _size_of(path)
    # Never follow a link: unlinking the link itself is safe and cheap, while
    # recursing into it could reach data outside the agent's home.
    failures = []
    _remove_path(path, failures)
    after = _size_of(path)
    freed = max(0, before - after)
    if failures:
        return False, _t("delete_partial", n=len(failures),
                         err=os.path.basename(failures[0])), freed
    return True, _t("delete_ok"), freed
def delete_item_aged(path: Path, days: int) -> tuple[bool, str, int]:
    """Delete only files older than `days`; keep newer ones. Returns (ok, msg, freed).

    Symlinks are skipped: a link's own mtime says nothing about its target's, so
    following one could delete data that was written seconds ago. Directories
    left empty by the removals are pruned afterwards.
    """
    cutoff = time.time() - days * 86400
    freed = 0
    removed = 0
    failed = 0

    if path.is_symlink() or path.is_file():
        try:
            st = path.lstat()
        except OSError:
            return False, _t("delete_fail", err=os.path.basename(str(path))), 0
        if st.st_mtime >= cutoff:
            return True, _t("delete_none_aged", days=days), 0
        try:
            os.unlink(path)
        except OSError:
            try:
                if not path.is_symlink():
                    os.chmod(path, stat.S_IWRITE)
                os.unlink(path)
            except OSError:
                return False, _t("delete_fail", err=os.path.basename(str(path))), 0
        return True, _t("delete_aged_ok", n=1, days=days,
                        size=human(st.st_size)), st.st_size

    dirs = []
    for f, size, mtime in _walk_files(path, dirs):
        if mtime >= cutoff:
            continue
        try:
            os.unlink(f)
        except OSError:
            try:
                os.chmod(f, stat.S_IWRITE)
                os.unlink(f)
            except OSError:
                failed += 1
                continue
        freed += size
        removed += 1

    # Prune directories emptied by the removals; deepest first so parents can
    # become empty in turn. Failure here is normal and not reported.
    for d in sorted(dirs, key=len, reverse=True):
        try:
            os.rmdir(d)
        except OSError:
            pass

    if failed:
        return False, _t("delete_partial", n=failed, err=""), freed
    if removed == 0:
        return True, _t("delete_none_aged", days=days), 0
    return True, _t("delete_aged_ok", n=removed, days=days,
                    size=human(freed)), freed
def rebuild_logs(db_path: Path) -> tuple[bool, str]:
    if not db_path.exists():
        return False, _t("db.notexists")
    stamp = time.strftime("%Y%m%d-%H%M%S")
    bak = Path(str(db_path) + f".bak-{stamp}")
    try:
        shutil.copy2(db_path, bak)
        for suffix in ("", "-wal", "-shm"):
            p = Path(str(db_path) + suffix)
            if p.exists():
                p.unlink()
        return True, _t("rebuild_ok", name=bak.name)
    except Exception as e:
        return False, _t("rebuild_fail", err=e)


def _item_key(it) -> tuple:
    """Identity of a cleanable item.

    (agent, name) rather than bare name: with `--target all` two agents can own
    items with the same name, and the confirm/execute flow must not confuse them.
    """
    return (it.get("agent", "codex"), it["name"])


def resolve_targets(target: str) -> list:
    """`--target all` expands to every registered agent (alphabetical)."""
    return sorted(AGENTS) if target == "all" else [target]


def filter_items(items, exclude_csv: str, only_csv: str) -> list:
    """Apply `--exclude` / `--only`.

    Patterns match a bare item name, an `agent:name` pair, or a whole agent.
    Filtering can only narrow the whitelist: protected entries are never part of
    the scanned items, so no pattern can surface one.
    """
    ex = [s.strip() for s in (exclude_csv or "").split(",") if s.strip()]
    on = [s.strip() for s in (only_csv or "").split(",") if s.strip()]
    if not ex and not on:
        return items
    out = []
    for it in items:
        labels = {it["name"], f"{it.get('agent', 'codex')}:{it['name']}",
                  it.get("agent", "codex")}
        if ex and (labels & set(ex)):
            continue
        if on and not (labels & set(on)):
            continue
        out.append(it)
    return out


# --------------------------------------------------------------------- config
CONFIG_ENV = "CODEX_CLEAN_CONFIG"

# The only keys a config file may set. Note what is deliberately absent: there
# is no key that adds a cleanable path. The whitelist is derived from AGENTS
# alone, so a config file is structurally unable to widen it -- it can only
# narrow the set (only/exclude) or add protections. `protected` is additive by
# construction (see _protected_union).
CONFIG_KEYS = ("lang", "target", "exclude", "only", "age", "check", "vacuum",
               "rebuild_logs", "dry_run", "ignore_running", "protected")

# Protections contributed by the config file, appended to each agent's own list.
EXTRA_PROTECTED = []


def default_config_path() -> Path:
    """Per-OS default config location. The file is optional there."""
    if os.name == "nt":
        base = os.environ.get("APPDATA") or str(Path.home() / "AppData" / "Roaming")
        return Path(base) / "codex-clean" / "config.json"
    base = os.environ.get("XDG_CONFIG_HOME") or str(Path.home() / ".config")
    return Path(base) / "codex-clean" / "config.json"


def load_config(path_arg: str):
    """Load the config file. Returns (config, warnings, error).

    Warnings and the error are (i18n_key, kwargs) pairs so they can be rendered
    after the language is known -- the file itself may set that language.

    An explicitly requested file must exist and parse. The default location is
    optional: absent means "no config", not an error. Unknown keys are dropped
    with a warning rather than honoured, which is the security property and not
    merely tidiness -- a typo or a stale key must never be able to smuggle in a
    delete target.
    """
    warnings, error = [], None
    explicit = bool(path_arg)
    if not path_arg:
        path_arg = os.environ.get(CONFIG_ENV) or str(default_config_path())
    p = Path(path_arg)
    if not p.exists():
        if explicit:
            return {}, warnings, ("cfg.missing", {"path": str(p)})
        return {}, warnings, None
    try:
        raw = json.loads(p.read_text(encoding="utf-8"))
    except Exception as e:
        return {}, warnings, ("cfg.bad", {"path": str(p), "err": e})
    if not isinstance(raw, dict):
        return {}, warnings, ("cfg.notobj", {"path": str(p)})
    cfg = {}
    for k, v in raw.items():
        if k in CONFIG_KEYS:
            cfg[k] = v
        else:
            warnings.append(("cfg.unknown", {"name": str(k)}))
    if "protected" in cfg and not isinstance(cfg["protected"], list):
        warnings.append(("cfg.badtype", {"name": "protected"}))
        del cfg["protected"]
    return cfg, warnings, None


def _pick(cli_val, env_val, cfg_val, default):
    """Precedence: CLI flag > environment variable > config file > default."""
    if cli_val is not None:
        return cli_val
    if env_val is not None:
        return env_val
    if cfg_val is not None:
        return cfg_val
    return default


def _as_csv(v) -> str:
    """Accept either a comma string or a JSON list for the list-valued options."""
    if isinstance(v, (list, tuple)):
        return ",".join(str(x) for x in v)
    return "" if v is None else str(v)


def _protected_union(targets) -> list:
    """Protected entries of every selected agent (order preserved, deduped).

    Entries contributed by the config file are appended: a config file may ADD
    protections but can never remove a registry one.
    """
    out = []
    for t in targets:
        for p in AGENTS[t]["protected"]:
            if p not in out:
                out.append(p)
    for p in EXTRA_PROTECTED:
        if p not in out:
            out.append(p)
    return out


def cmd_list_targets(json_mode: bool) -> int:
    """Print the agent registry: names, homes, capabilities, whitelists."""
    rows = []
    for t in sorted(AGENTS):
        sp = AGENTS[t]
        rows.append({
            "name": t, "label": sp["label"], "home": str(agent_home(t)),
            "home_env": sp["home_env"],
            "deletable": [n for n, _r, _k in sp["deletable"]],
            "dbs": [n for n, _r, _k in sp["dbs"]],
            "discover_dbs": sp.get("discover_dbs", False),
            "protected": _protected_union([t]),
            "capabilities": sp["capabilities"],
        })
    if json_mode:
        print(json.dumps(rows, ensure_ascii=False, default=str))
        return 0
    print(_t("list.title"))
    for r in rows:
        caps = r["capabilities"]
        print(f"  {r['name']:<12} {r['label']:<12} {r['home']}")
        print(f"      vacuum={caps['vacuum']}  rebuild_logs={caps['rebuild_logs']}"
              f"  discover_dbs={r['discover_dbs']}")
        print(f"      deletable={', '.join(r['deletable']) or '-'}"
              f"  dbs={', '.join(r['dbs']) or '-'}")
    return 0


def _check_exit(items, args) -> int:
    """`--check N` -> exit 3 once reclaimable space reaches N MB (automation)."""
    if not getattr(args, "check", 0):
        return 0
    tot = sum(i.get("reclaimable_bytes", 0) for i in items if i["exists"])
    thr = args.check * 1024 * 1024
    if tot >= thr:
        if not args.json:
            print(_t("check.over", size=human(tot), thr=human(thr)))
        return 3
    return 0


# CLI
def _running_process_names() -> set:
    """Best-effort set of lowercased running process names (stdlib only).

    Returns an empty set when detection is unavailable. A failed probe must
    never block a clean -- only a positive match may warn.
    """
    names = set()
    try:
        if os.name == "nt":
            out = subprocess.run(["tasklist", "/FO", "CSV", "/NH"],
                                 capture_output=True, text=True, timeout=15)
            for line in out.stdout.splitlines():
                first = line.split(",")[0].strip().strip('"')
                if first:
                    names.add(first.lower())
        elif os.path.isdir("/proc"):
            for entry in os.listdir("/proc"):
                if not entry.isdigit():
                    continue
                try:
                    with open("/proc/%s/comm" % entry, encoding="utf-8",
                              errors="ignore") as fh:
                        names.add(fh.read().strip().lower())
                except OSError:
                    continue
        else:
            out = subprocess.run(["ps", "-eo", "comm="],
                                 capture_output=True, text=True, timeout=15)
            for line in out.stdout.splitlines():
                if line.strip():
                    names.add(line.strip().lower())
    except Exception:
        return set()
    return names


def running_agents(targets) -> list:
    """Return [(label, [matched process names])] for agents that look busy.

    Matching is exact on the process stem (".exe" stripped) so a short name
    such as "pi" cannot match an unrelated process like "pycharm".
    """
    names = _running_process_names()
    if not names:
        return []
    stems = set(n[:-4] if n.endswith(".exe") else n for n in names)
    hits = []
    for t in targets:
        want = set(w.lower() for w in AGENTS.get(t, {}).get("procs") or [])
        matched = sorted(stems & want)
        if matched:
            hits.append((AGENTS[t]["label"], matched))
    return hits


def main():
    global _LANG, _AGE_DAYS
    # Resolve language before building the parser so --help is localized too.
    _LANG = _resolve_lang(_pre_scan_lang(sys.argv))
    ap = argparse.ArgumentParser(description=_t("prog.desc", v=VERSION))
    ap.add_argument("--version", action="version",
                    version="codex-clean %s" % VERSION)
    ap.add_argument("--config", metavar="PATH", default=None, help=_t("arg.config"))
    ap.add_argument("--scan", action="store_true", help=_t("arg.scan"))
    ap.add_argument("--clean", action="store_true", help=_t("arg.clean"))
    ap.add_argument("--yes", action="store_true", help=_t("arg.yes"))
    ap.add_argument("--vacuum", action="store_true", help=_t("arg.vacuum"))
    ap.add_argument("--rebuild-logs", action="store_true", help=_t("arg.rebuild"))
    ap.add_argument("--age", type=int, default=None, metavar="N", help=_t("arg.age"))
    ap.add_argument("--target", choices=sorted(AGENTS) + ["all"], default=None,
                    help=_t("arg.target"))
    ap.add_argument("--lang", choices=["en", "zh", "auto"], default=None,
                    help=_t("arg.lang"))
    ap.add_argument("--json", action="store_true", help=_t("arg.json"))
    ap.add_argument("--exclude", metavar="LIST", default=None, help=_t("arg.exclude"))
    ap.add_argument("--only", metavar="LIST", default=None, help=_t("arg.only"))
    ap.add_argument("--dry-run", action="store_true", help=_t("arg.dryrun"))
    ap.add_argument("--list-targets", action="store_true", help=_t("arg.listtargets"))
    ap.add_argument("--check", type=int, default=None, metavar="N", help=_t("arg.check"))
    ap.add_argument("--ignore-running", action="store_true",
                    help=_t("arg.ignorerunning"))
    args = ap.parse_args()

    # Config first, so every other setting can fall back to it. Its diagnostics
    # are deferred: the file itself may choose the language they print in.
    cfg, cfg_warn, cfg_err = load_config(args.config)
    if isinstance(cfg.get("protected"), list):
        EXTRA_PROTECTED.extend(str(x) for x in cfg["protected"])

    _env = lambda n: (os.environ.get(n) or None)  # noqa: E731
    args.lang = _pick(args.lang, _env("CODEX_CLEAN_LANG"), cfg.get("lang"), "auto")
    _LANG = _resolve_lang(args.lang)

    for key, kw in cfg_warn:
        print(_t(key, **kw), file=sys.stderr)
    if cfg_err:
        print(_t(cfg_err[0], **cfg_err[1]), file=sys.stderr)
        return 2

    args.target = _pick(args.target, _env("CODEX_CLEAN_TARGET"), cfg.get("target"), "codex")
    args.exclude = _as_csv(_pick(args.exclude, _env("CODEX_CLEAN_EXCLUDE"),
                                 cfg.get("exclude"), ""))
    args.only = _as_csv(_pick(args.only, _env("CODEX_CLEAN_ONLY"), cfg.get("only"), ""))
    args.age = int(_pick(args.age, _env("CODEX_CLEAN_AGE"), cfg.get("age"), 0))
    args.check = int(_pick(args.check, _env("CODEX_CLEAN_CHECK"), cfg.get("check"), 0))
    args.vacuum = bool(_pick(args.vacuum, None, cfg.get("vacuum"), False))
    args.rebuild_logs = bool(_pick(args.rebuild_logs, None, cfg.get("rebuild_logs"), False))
    args.dry_run = bool(_pick(args.dry_run, None, cfg.get("dry_run"), False))
    args.ignore_running = bool(_pick(args.ignore_running, None,
                                     cfg.get("ignore_running"), False))

    # `choices` only guards the CLI, so a config-supplied target needs its own check.
    if args.target not in list(AGENTS) + ["all"]:
        print(_t("cfg.bad_target", name=args.target), file=sys.stderr)
        return 2
    if args.check < 0:
        ap.error("--check must be >= 0")
    if args.age < 0:
        ap.error("--age must be >= 0")

    if args.list_targets:
        return cmd_list_targets(args.json)
    _AGE_DAYS = args.age
    targets = resolve_targets(args.target)
    items = []
    for _tn in targets:
        items.extend(scan(args.age, _tn))
    items = filter_items(items, args.exclude, args.only)

    if not args.clean:
        if args.json:
            print(json.dumps(items, ensure_ascii=False, default=str))
            return _check_exit(items, args)
        for _tn in targets:
            _sp = AGENTS[_tn]
            _sub = [i for i in items if i.get("agent") == _tn]
            print(_t("scan.title", label=_sp["label"]))
            print(_t("scan.codedir", label=_sp["label"], path=agent_home(_tn)))
            if args.vacuum and not any(i["kind"] == "vacuum" for i in _sub):
                print(_t("scan.no_vacuum"))
            if args.rebuild_logs and not _sp["capabilities"]["rebuild_logs"]:
                print(_t("scan.no_rebuild"))
            if args.age > 0:
                print(_t("scan.agefilter", days=args.age))
            print()
            for it in _sub:
                # Column shows the reclaimable amount so it sums to the footer; the DB
                # total is annotated when the two differ (VACUUM reclaims the WAL only).
                disp = it.get("reclaimable_bytes", it["size_bytes"])
                note = _t("scan.of_total", size=it["size"]) if disp != it["size_bytes"] else ""
                print(f"  [{it['kind']:<6}] {human(disp):>10}  {it['name']:<24} {it['desc']}{note}")
                if it["exists"]:
                    print(f"              {it['path']}")
        wal_total = sum(i.get("db_wal", 0) for i in items if i["kind"] == "vacuum")
        if wal_total > WAL_WARN_MB * 1024 * 1024:
            print(_t("scan.wal_hint", size=human(wal_total)))
        tot = sum(i.get("reclaimable_bytes", 0) for i in items if i["exists"])
        print(f"\n{_t('scan.reclaim', size=human(tot))}")
        print(_t("scan.hint"))
        print(_t("scan.hint2"))
        return _check_exit(items, args)

    # --- cleanup ---
    candidates = []
    for it in items:
        if not it["exists"]:
            continue
        _sp = AGENTS.get(it.get("agent", "codex"), AGENTS["codex"])
        if it["kind"] == "delete":
            candidates.append(it)
        elif it["kind"] == "vacuum" and args.vacuum and _sp["capabilities"]["vacuum"]:
            candidates.append(it)
        elif it["kind"] == "rebuild" and args.rebuild_logs and _sp["capabilities"]["rebuild_logs"]:
            candidates.append(it)

    if not candidates:
        print(_t("clean.none"))
        return 0

    # Warn when the target agent is still running: a live process may hold open
    # handles on files we are about to delete, so the space only comes back once
    # it exits. Detection is best-effort; a failed probe never blocks a clean.
    busy = [] if args.ignore_running else running_agents(targets)
    if busy:
        # JSON mode must keep stdout parseable, so warnings go to stderr there.
        _out = sys.stderr if args.json else sys.stdout
        for label, procs in busy:
            print(_t("proc.running", label=label, procs=", ".join(procs)), file=_out)
        print(_t("proc.hint"), file=_out)
        if not args.yes:
            print(_t("proc.hint2"), file=_out)
            print(_t("proc.prompt"), file=_out)
            try:
                _r = input("> ").strip().lower()
            except EOFError:
                _r = ""
            if _r not in ("y", "yes"):
                print(_t("confirm.cancelled"))
                return 0

    confirmed = []
    if args.yes:
        confirmed = [_item_key(c) for c in candidates]
        if not args.json:
            print(_t("confirm.autoyes"))
    else:
        if args.json:
            # Non-interactive JSON mode requires --yes.
            print(_t("confirm.none"))
            return 0
        print(_t("confirm.title"))
        for i, c in enumerate(candidates):
            _pfx = (c.get("agent", "codex") + ":") if len(targets) > 1 else ""
            print(f"  [{i + 1}] {_pfx + c['name']:<24} ({c['size']:>8})  {c['desc']}")
        print(_t("confirm.prompt"))
        try:
            resp = input("> ").strip().lower()
        except EOFError:
            resp = ""
        if resp in ("all", "a"):
            confirmed = [_item_key(c) for c in candidates]
        elif resp:
            try:
                idxs = [int(x) for x in resp.split(",") if x.strip()]
                confirmed = [_item_key(candidates[i - 1]) for i in idxs
                             if 1 <= i <= len(candidates)]
            except ValueError:
                print(_t("confirm.invalid"))
                return 0
        else:
            print(_t("confirm.cancelled"))
            return 0

    if not confirmed:
        print(_t("confirm.none"))
        return 0

    estimated = sum(c.get("reclaimable_bytes", c["size_bytes"])
                    for c in candidates if _item_key(c) in confirmed)

    if args.dry_run:
        planned = [c for c in candidates if _item_key(c) in confirmed]
        if args.json:
            print(json.dumps({
                "ok": True, "dry_run": True, "version": VERSION,
                "agent": args.target, "targets": targets,
                "age_filter_days": args.age if args.age > 0 else None,
                "estimated_bytes": estimated, "estimated": human(estimated),
                "items": [{"agent": c.get("agent", "codex"), "name": c["name"],
                           "kind": c["kind"], "path": c["path"],
                           "estimated_bytes": c.get("reclaimable_bytes", c["size_bytes"]),
                           "planned_action": c.get("planned_action"),
                           "status": "planned"} for c in planned],
                "protected_untouched": _protected_union(targets),
            }, ensure_ascii=False, default=str))
            return 0
        print(_t("dry.title"))
        for c in planned:
            _pfx = (c.get("agent", "codex") + ":") if len(targets) > 1 else ""
            print(f"  [{c['kind']:<6}] {human(c.get('reclaimable_bytes', 0)):>10}  "
                  f"{_pfx + c['name']}")
        print(f"\n{_t('clean.estimated', size=human(estimated))}")
        return 0

    results = []
    freed = 0
    failed_items = 0

    if not args.json:
        print(_t("clean.title"))

    for it in items:
        if _item_key(it) not in confirmed:
            continue
        est = it["size_bytes"]
        if it["kind"] == "delete":
            if args.age > 0:
                ok, msg, got = delete_item_aged(Path(it["path"]), args.age)
            else:
                ok, msg, got = delete_item(Path(it["path"]))
            # Count what actually went away, even when the item partly failed.
            freed += got
            if not ok:
                failed_items += 1
            results.append({"agent": it.get("agent", "codex"), "name": it["name"],
                            "kind": "delete",
                            "status": "ok" if ok else "failed",
                            "estimated_bytes": est, "actual_bytes": got,
                            "message": msg})
            if not args.json:
                print(f"  {('✓' if ok else '✗')} {it['name']}: {msg}")
        elif it["kind"] == "vacuum":
            if args.vacuum and AGENTS.get(it.get("agent", "codex"),
                                          AGENTS["codex"])["capabilities"]["vacuum"]:
                # `got` is the measured shrink (before - after), not just the WAL size.
                ok, msg, got = vacuum_db(Path(it["path"]))
                freed += got
                results.append({"agent": it.get("agent", "codex"), "name": it["name"],
                                "kind": "vacuum",
                                "status": "ok" if ok else "failed",
                                "estimated_bytes": est, "actual_bytes": got,
                                "message": msg})
                if not args.json:
                    print(f"  {('✓' if ok else '✗')} {it['name']} (VACUUM): {msg}")
        elif it["kind"] == "rebuild":
            if args.rebuild_logs and AGENTS.get(it.get("agent", "codex"),
                                                AGENTS["codex"])["capabilities"]["rebuild_logs"]:
                ok, msg = rebuild_logs(Path(it["path"]))
                got = est if ok else 0
                if ok:
                    freed += got
                results.append({"agent": it.get("agent", "codex"), "name": it["name"],
                                "kind": "rebuild",
                                "status": "ok" if ok else "failed",
                                "estimated_bytes": est, "actual_bytes": got,
                                "message": msg})
                if not args.json:
                    print(f"  {('✓' if ok else '✗')} {it['name']} (rebuild): {msg}")

    if args.json:
        print(json.dumps({
            "ok": failed_items == 0,
            "dry_run": False,
            "version": VERSION,
            "agent": args.target,
            "targets": targets,
            "agent_home": str(agent_home(targets[0])) if len(targets) == 1 else None,
            "agent_homes": {t: str(agent_home(t)) for t in targets},
            "codex_home": str(CODEX_HOME),
            "age_filter_days": args.age if args.age > 0 else None,
            "estimated_bytes": estimated,
            "estimated": human(estimated),
            "actual_freed_bytes": freed,
            "actual_freed": human(freed),
            "delta_bytes": freed - estimated,
            "summary": _t("json.est_vs_act", est=human(estimated),
                          act=human(freed), delta=human(freed - estimated)),
            "failed_items": failed_items,
            "items": results,
            "protected_untouched": _protected_union(targets),
        }, ensure_ascii=False, default=str))
        # Exit 4 so automation can tell a partial clean from a clean one.
        return 4 if failed_items else 0

    print(f"\n{_t('clean.estimated', size=human(estimated))}")
    print(_t("clean.actual", size=human(freed)))
    print(_t("clean.delta", delta=human(freed - estimated)))
    print(_t("clean.tip"))
    if failed_items:
        print(_t("clean.failed_summary", n=failed_items))
    return 4 if failed_items else 0


if __name__ == "__main__":
    sys.exit(main())
