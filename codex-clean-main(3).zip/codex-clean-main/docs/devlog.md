# codex-clean 开发日志 / Development Log

> 本文件按迭代记录设计决策、实现要点与审查结论。版本号遵循 semver：变化幅度决定第二位（MINOR，向后兼容的新功能）还是第三位（PATCH，文档/小修）；MAJOR 仅用于不兼容的 API 变更。
> 脚本内 `VERSION` 常量必须与 GitHub Release 版本号完全一致（单一来源）。

---

## v1.2.0 — Iteration 1（2026-09-03 发布）

**范围**：Milestone #1，对应 Issue #1 / #2 / #3，3/3 完成。

### 目标
- **#1 `--json` 增强**：扫描即给出每项"将要做什么"的预览；清理时给出「预估回收 vs 实际回收」对照，便于脚本/CI 消费与审计。
- **#2 `--age N`**：只清理超过 N 天的临时文件，新文件保留，避免误删 Codex 正在使用的缓存。
- **#3 中文文档**：新增 `README.zh-CN.md`，并说明本 skill 与通用"清理电脑"工具的本质区别。

### 实现要点
1. **版本号单一来源**：`VERSION = "1.2.0"`，`prog.desc` 用 `v{v}` 模板引用，发布前只改这一处。
2. **年龄过滤 `_age_stats`**：`days<=0` 视为不过滤；`days>0` 用 `time.time() - days*86400` 作为 cutoff，只统计 `mtime < cutoff` 的文件，并同时报告 `eligible`（符合条件）与 `total`（全部）的字节/文件数。
3. **VACUUM 实测回收量**：`vacuum_db` 测量 VACUUM 前后 `(main+wal+shm)` 的真实差值，而非沿用 WAL 大小——之前的实现让"预估 vs 实际"失去意义。
4. **`--lang` 提前解析**：新增 `_pre_scan_lang`，在 `argparse` 构建 help 文本之前预扫描 `argv` 与 `CODEX_CLEAN_LANG`，修复了 `--help` 永远英文的既有 bug；各参数 help 也做了 i18n。
5. **保护清单显式审计**：`PROTECTED`（sessions/config/auth/backups/skills…）在 `--json` 清理报告中以 `protected_untouched` 字段输出，证明未被触碰。
6. **语言解析顺序**：`--lang` > `CODEX_CLEAN_LANG` > `LANG`/`LC_ALL` > OS UI 语言（Windows 用 `GetUserDefaultUILanguage`，中文主语言 `0x04`）> `en`。

### 代码审查结论
- **安全模型**：严格白名单（仅 `DELETABLE` + `SQLITE_DBS`）+ 逐项确认 + `protected_untouched` 审计，无越权删除路径。✅
- **边界行为**：`--age 0` 不过滤；`--age -1` 经 `ap.error` 以退出码 2 拒绝；`--clean --json` 缺 `--yes` 时安全退出且零删除。✅
- **测试覆盖**：150KB 假目录（100KB 老 + 50KB 新）→ `--age 7` 仅报 100KB 并只删老文件、新文件保留；真实 `~/.codex` 扫描（.tmp 67.7MB + plugin-cache 11.8MB + logs-db 24.5MB）正常；VACUUM 实测 1.5MB 库回收 1.47MB。✅
- **非阻塞改进建议**：扫描页 "Total reclaimable" 当前把 DB 主文件大小也计入总和，会高估可回收量（VACUUM 只回收 WAL + 内部碎片，不回收主数据）。建议只累加 delete 项大小 + WAL 可回收量；JSON 的 `planned_action.reclaimable_bytes` 已较准确（vacuum 取 wal），两者可统一。不影响安全性，留待后续迭代优化。

### 发布状态
- commit `54f260d` → `main`；tag **v1.2.0** 已发布。
- Issues #1 / #2 / #3 由 commit 的 `Closes` 自动关闭；Milestone #1（v1.2.0）已关闭。
- 后续：Milestone #2 **v1.3.0**（增强清理，含 #10 pi agent 支持）、#3 **v1.4.0**（自动任务/进程检测/CI）。


---

## v1.2.1 — Iteration 1 补丁（2026-09-04 发布）

**范围**：v1.2.x 补丁线（非 v1.3 迭代），纯修复与工程优化，无新功能，版本号升 PATCH。

### 优化内容
- **"可回收"总量数值修正（准确性修复）**：原扫描页汇总是把 SQLite 库的主文件大小(主+WAL+SHM)也计入"可回收"，虚高——VACUUM 只回收 WAL 与库内碎片，不回收有效数据。现每项新增 `reclaimable_bytes`（delete=可删量、vacuum=WAL 量、rebuild=主库量），总量只累加它，数字才真实。
- **`--clean` 预估一致化**：清理模式的 estimated 也改用 `reclaimable_bytes`，与扫描口径统一，"预估 vs 实际"才可比。
- **扫描结果按可回收量从大到小排序**，最大头一眼可见，便于取舍。
- **消除一次冗余目录遍历**：deletable 目录的大小与年龄统计合并到单次 walk，大缓存树下扫描略快。

### 验证
- 自测（CODEX_HOME 指向临时目录，不碰真实数据）：`--age 7` 可回收=150KB（仅老文件）、无年龄过滤=200KB（含新文件）、排序降序、`--clean --yes --age 7` 精确释放 150KB 且新文件保留、`--age -1` 退出码 2。全部通过。

### 发布状态
- 版本号升 v1.2.1（PATCH）；脚本 `VERSION` 与 Release 一致。


---

## 2026-09-05 — 文档双语化 + 注释精简 + opencode 列入迭代（无版本迭代）

**范围**：不加新功能、不升版本、不发 Release。仅文档 / 注释 / issue 规划。

### 1. opencode 兼容提上日程（Issue #11 / #12，Milestone v1.3.0）

路径全部从 `anomalyco/opencode` 源码核实，未凭印象编写：

- `packages/core/src/global.ts`：经 `xdg-basedir` 解析 —— `data = $XDG_DATA_HOME/opencode`、
  `log = <data>/log`、`repos = <data>/repos`、`cache = $XDG_CACHE_HOME/opencode`、
  `bin = <cache>/bin`、`tmp = os.tmpdir()/opencode`。
- `packages/core/src/database/database.ts` 与 `drizzle.config.ts`：数据库为 `<data>/opencode.db`，
  且显式执行 `PRAGMA journal_mode = WAL` —— 因此存在 `-wal` / `-shm` 文件，
  正好命中本工具已有的 VACUUM + WAL checkpoint 能力。

- **#12** 负责 opencode 的清理目标与保护清单（`repos/` 是用户克隆的仓库、`config/` 含配置与凭证，必须保护）。
- **#11** 负责把清理目标重构为「按 agent 组织的注册表」，避免为第二个、第三个 agent 复制扫描/清理逻辑。

### 2. 代码注释精简并统一英文

注释原本就已是英文，本次核心是**精简**：

- 模块 docstring 25 行 → 11 行；`_pre_scan_lang` / `_age_stats` / `vacuum_db` 的多行 docstring 压成一行（或两行）。
- 分隔横幅（`# ---- i18n ----`）改为短标记（`# i18n`）。
- 文件 627 → 606 行；校验通过：注释中无 CJK 残留、无超长注释行、关键逻辑 token 未丢失。
- 自测 **10/10 通过**：年龄过滤（100KB 老文件计入、50KB 新文件不计入）、可回收量降序、
  `--clean` 精确释放 100KB 且新文件保留、保护清单存在、VACUUM 实测回收 2.0MB、
  `--age -1` 退出码 2、`--help --lang zh` 本地化。确认纯注释改动无行为影响。

### 3. 文档双语化

约定：**无后缀 `.md` = 英文主版，`.zh-CN.md` = 中文版**，两份互相链接。

- 新增 `SKILL.zh-CN.md`（原 SKILL.md 中文内容迁出），`SKILL.md` 改写为英文版
  （frontmatter `description` 保留中英双语触发词，不影响 Codex 触发）。
- 新增 `CONTRIBUTING.zh-CN.md`；英文 `CONTRIBUTING.md` 增加语言切换行。
- 两份 README 的路线图同步补入 opencode / 多 agent 注册表，并互链双语文档。
- 仓库 About 描述改为中英双语，补充 10 个 topics。
- **Project #3 看板 README 首次写入**（此前为空），中英双段：版本规则、里程碑表、安全契约。

### 4. 踩坑记录

- Windows 版 Python 不认 Git Bash 的 `/tmp` 路径，用 `CODEX_HOME=/tmp/xxx` 做冒烟测试会
  静默扫到空目录（全部 0 B，看起来"通过"实则没测到）。测试必须用 Windows 路径
  （如 `C:/Users/.../Temp/...`）或在 Python 内用 `tempfile.mkdtemp()` 建目录。
- 正则替换里若写 `r'...\n...'`（raw string 中的双反斜杠），匹配的是字面 `
` 文本而非换行，
  会静默失配；匹配跨行文本应直接用 `
` 或 `.*?` + `re.S`，并配 `assert` 计数。

### 5. 发布状态

本次为纯文档/注释/规划改动，**未升版本号、未发 Release**；main 上脚本 `VERSION` 仍为 `1.2.1`。

### 6. 追加修复：扫描列表数字与合计不一致（真机验证时发现）

在真实 `~/.codex` 上做端到端验证时发现：列表**各行列出的大小合计 129.5 MB，底部"预计可回收"却是 107.3 MB**，
差额 22.2 MB。定位结果：

| 类别 | 显示值(size_bytes) | 计入合计的值(reclaimable_bytes) |
|---|---|---|
| delete | 可删量 | 可删量 → 一致 |
| **vacuum** | **main + WAL + SHM（库总大小）** | **仅 WAL** → 不一致 |

例：logs-db 显示 34.0 MB（主库 20.60 + WAL 13.37 + SHM 0.03），但实际只贡献 13.37 MB。
这会让用户以为能回收 129.5 MB，与 v1.2.1「让数字真实」的目标相悖。

**修复**：列表列改为显示 `reclaimable_bytes`，当它与 `size_bytes` 不等时在后面标注库总大小，
如 `logs-db  13.4 MB  (库总 34.0 MB)`。列与页脚现可精确对齐。
**JSON 契约不变**：`size_bytes` 仍是总大小，`reclaimable_bytes` 仍是可回收量（两者语义不同，均保留），
稳定字段（`name`/`kind`/`path`/`planned_action`）未变。

**回归测试 14/14 通过**：列与页脚精确相等（153600 B = 153600 B）、中英文均正确标注、
JSON 契约未变、年龄过滤、精确释放 100KB、VACUUM 实测回收 2.0MB、`--age -1` 退出码 2。

### 7. 本地技能语言回归修复

上一步把仓库 `SKILL.md` 改为英文主版时，一并覆盖了你本机 `~/.codex/skills/codex-clean/SKILL.md`，
而你的 Codex 客户端是中文环境、原本那份一直是中文——属于我改动引入的回归。
已恢复：**仓库保持英文主版（对外一致），本地安装使用中文版**，两份都保留在本地目录。

### 8. 另一个工具坑

写 Python 脚本时，路径字符串里的 `WorkBuddy` 被改写成了 `.workbuddy`
（`C:\\Users\\27385\\.workbuddy\\2026-09-02-14-21-35\\...`），导致 `FileNotFoundError`。
**规避：脚本内路径一律用正斜杠**（Windows 完全接受），可彻底避免反斜杠被改写。


## 2026-09-06 规划：新增 Claude Code 支持（仅规划，不改代码）

按用户要求**本轮只做规划**（建 issue + 挂里程碑 + 更新文档），代码留到下一次迭代；
Claude Code 支持包含**两项**：清理目标 + Claude Code 技能。

### 先核实再动手（避免基于错误前提开发）
核对发现需求描述中几项与项目现状不符，已向用户确认方向：
- 项目**零 Claude 引用**；**无配置生成/加载逻辑**（脚本只读两个环境变量，不生成任何配置文件）；
  **无 tests/ 目录**。故"配置生成与加载""测试用例"在当时无可改对象。
- 目标目前是**硬编码单 Agent**（`CODEX_HOME` 全局常量），多 Agent 注册表仍是未实现的 #11。

### 核实到的 Claude Code 事实
- 真实 `~/.claude` 布局（只读列出，共 20.4 MB）：`plugins/` 10.0MB、`skills/` 9.9MB（均须保护）、
  `cache/` 0.4MB（可清）、`projects/`（JSONL 会话，须保护）、`memory/`、`settings.json`、
  `config.json`、`~/.claude.json`、`backups/`、`sessions/`、`ide/`、`history.jsonl`。
- **无 SQLite** → VACUUM / WAL checkpoint / 日志库重建**均不适用**，这是与 Codex 的关键能力差异。
- Claude Code 技能遵循 **Agent Skills 开放标准**，与 Codex 的 SKILL.md 同格式
  → 可共用同一份 SKILL.md 主体，仅 frontmatter 与安装路径不同
  （`~/.claude/skills/codex-clean/SKILL.md`，目录名即 `/codex-clean` 命令；
  需 `allowed-tools: Bash, Read`）。

### 产出
- Issue **#13**（`~/.claude` 清理目标，含保护/可清清单与能力开关设计）、
  Issue **#14**（作为 Claude Code 技能/斜杠命令发布），均挂 Milestone **v1.3.0**。
- 两份 README 的 Supported agents 表与路线图补入 Claude Code；CHANGELOG 记录规划。
- **未改代码、未升版本**（`VERSION` 仍 1.2.1）。


## v1.3.0（2026-09-07）：多 Agent 目标注册表 + Claude Code 支持

### 迭代范围（从 Milestone #2 的 8 个 issue 中选定）
- **#11** per-agent 注册表重构（前置依赖）
- **#13** Claude Code 清理目标
- **#14** Claude Code 技能安装文档
- **#4**  WAL 增长看护提示
- 延后到 v1.4.0：#5（桌面版运行时缓存）、#6（`--exclude`）、#10（pi）、#12（opencode）。
  理由：注册表就位后它们都是"加一条 spec"的工作量，但 pi 的目录布局无法在本机核实、
  opencode 涉及 XDG 跨平台细节，不宜在本轮硬塞。

### 实现要点
- `AGENTS` 注册表取代了 `DELETABLE` / `SQLITE_DBS` / `PROTECTED` 三个模块级常量；
  路径改为相对 agent home 的字符串，扫描时解析。
- `agent_home(target)` 统一解析目录（env 覆盖优先，沿用 `CODEX_HOME` 的模式，Claude 用 `CLAUDE_HOME`）。
- 能力差异声明式：Claude Code 的 `dbs: []`、`capabilities.vacuum=False`；
  `--vacuum` / `--rebuild-logs` 对它自动降级为提示而非报错。
- `scan(age_days, target="codex")`，默认仍是 codex → **旧行为零变化**。
- 新增 `--target`；JSON 新增 `agent` / `agent_home`（**纯新增字段**，`codex_home` 与所有旧键保留）。

### 验证
- 自测 **28/28 通过**：含 Codex 向后兼容（目标/项目名/可回收总量/--age）、
  Claude Code 白名单与保护项存活、无 SQLite 时不产生 vacuum 项、能力降级提示、
  缺失目录容错、非法 `--target` 退出码 2、中英 `--help`、WAL 提示阈值。
- 真机只读扫描：真实 `~/.codex`（79.0 MB tmp 等）与真实 `~/.claude`（418.7 KB cache）均正常。
- 修掉两处自引入的显示问题：扫描标题写死 "Codex"（改为按 agent 标签）、
  名称列 14 宽导致 `claude-shell-snapshots` 排版错位（改为 24 宽）。


## v1.4.0（2026-09-07）：新增 Pi 支持 + 补齐/澄清 Claude 的能力限制

### 1. 新增 Pi（Issue #10）
- 路径**从官方源码核实**（`earendil-works/pi` → `packages/coding-agent/docs/settings.md`）：
  家目录 `~/.pi/agent`，含 `sessions/`、`skills/`、`npm/`、`settings.json`、`trust.json`、
  `auth.json`、`AGENTS.md`、`SYSTEM.md`。
- **关键判断**：文档原文 "User installs go under `~/.pi/agent/npm/`" → `npm/` 是
  **用户已安装的包**，删掉等于卸载扩展，因此列入**保护**而非清理。
- 可清理项 `cache/`/`tmp/`/`logs/`：官方未记载缓存，属"尽力而为"，仅当存在时处理
  （缺失目录报 exists=false，不创建、不假设）。Pi 未装在核实环境，故刻意保守。

### 2. 逐项梳理 Claude 被标记为"不支持"的能力
| 能力 | 原状态 | 处理 |
|---|---|---|
| `--vacuum` | 硬编码 `capabilities.vacuum=False` | **改为数据驱动**：`discover_dbs=True`，扫描时自动发现 sqlite；当前 `~/.claude` 实测 0 个 → 提示"不适用"，未来有库自动生效 |
| `--rebuild-logs` | 标记不适用 | **确属不适用**：无"超大诊断日志库"概念，日志是 `debug/` 普通文件且已在删除白名单 → 代码注释 + README 明确标注原因 |
| `--age N` | 未文档化但实际可用 | 补测试 T33 确认对非 Codex agent 同样生效 |

### 3. 限制说明落点
- 代码：`AGENTS` 注册表上方新增 **LIMITATIONS 注释块**，写明两项限制及原因。
- 文档：两份 README 新增 **Known limitations / 已知限制** 小节。

### 4. 验证
- 测试从 28 项扩到 **38/38 通过**，新增 Pi 目标、Pi 保护项（`npm/` 等）存活、
  **sqlite 自动发现后生成 vacuum 项且"不适用"提示消失**（证明非硬编码）、
  `--age` 对 Claude 生效、`--target` 列出三个 agent。


## v1.5.0（2026-09-09）：新增 5 项实际功能（非插件机制）

用户澄清"扩展"= **给工具加实际功能**，不是做插件体系。按 09-09 架构审查的优先级落地：

### 功能清单与实现思路
| # | 功能 | 涉及模块 | 数据结构/接口 | 对现有代码影响 |
|---|---|---|---|---|
| F1 | `--target all` | `resolve_targets()` + `main()` | items 标识由 `name` 改为 `(agent, name)`（`_item_key`） | confirm/执行/统计全改用 `_item_key`；JSON 增 `targets`/`agent_homes` |
| F2 | `--exclude` / `--only`（#6） | `filter_items()` | 匹配 `name` / `agent:name` / agent | scan 后插入一层过滤；**只能收窄白名单** |
| F3 | `--dry-run` | main 执行前分支 | 复用 `planned_action` | 新增分支，不动执行路径 |
| F4 | `--list-targets` | `cmd_list_targets()` | 导出 AGENTS 注册表 | 纯新增，scan 前 return |
| F5 | `--check N` | `_check_exit()` | 退出码 3 | 仅在新 flag 下生效，不动既有 0/2 |

### 关键设计决策
- **item 标识改为 (agent, name)**：这是 `--target all` 的**必要前提**——
  不同 agent 可能有同名项，原 `if it["name"] not in confirmed` 会误匹配。
- **过滤只能收窄**：受保护项本就不在 items 里，故任何 `--only` 都无法把保护项"放回来"，
  安全契约天然成立。
- **能力判定下沉到 item**：原先 `allow_vacuum` 是全局标量，多 agent 下失效；
  改为按 item 的 agent 查 `capabilities`。
- 显示层抽出 per-agent 循环（原来写死单个 spec/home），顺带让 `main()` 瘦身一点。

### 未做（有意为之）
- **配置文件接口**（审查里的 P1）：需设计 CLI/env/文件三者优先级，且"配置不得削弱保护清单"
  要单独论证，留到下一轮，避免本轮一次塞太多。

### 验证
- 测试 38 → **56 项全通过**（新增 T39–T56 覆盖 5 个功能）。
- 真实环境：`--list-targets` 列出三 agent 及能力；`--target all` 正确分段输出
  （Claude 418.7KB + Codex 79MB 等）；`--check 1` 退 3、`--check 99999` 退 0。
