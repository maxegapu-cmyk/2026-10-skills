#!/usr/bin/env python3
"""Deterministic attack-record contract checker. Never claims strategic correctness."""
from __future__ import annotations
import argparse
import json
import sys
from pathlib import Path

EVIDENCE = {"source_checked", "user_report", "inference", "unknown"}
VERDICTS = {"GO", "PILOT", "REVISE", "STOP", "INSUFFICIENT"}
SEVERITY = {"critical", "high", "medium", "low"}

def filled(s):
    return isinstance(s, str) and bool(s.strip())

def _ids(rows):
    return [r.get('id') for r in rows if isinstance(r, dict) and filled(r.get('id'))]

def audit(data):
    errors, warnings = [], []
    if not isinstance(data, dict):
        return ['root must be a JSON object'], []
    target = data.get('target')
    if not isinstance(target, dict):
        errors.append('target object required')
    else:
        for f in ('plan', 'goal', 'success_signal', 'baseline', 'scope_limit'):
            if not filled(target.get(f)):
                errors.append('target.%s required' % f)
    claims = data.get('claims')
    if not isinstance(claims, list) or not claims:
        errors.append('claims must be nonempty list')
        claims = []
    claim_ids = _ids(claims)
    if len(set(claim_ids)) != len(claim_ids):
        errors.append('duplicate claim id')
    for i, c in enumerate(claims):
        if not isinstance(c, dict):
            errors.append('claims[%d] must be object' % i)
            continue
        for f in ('id', 'assertion', 'steelman', 'failure_consequence'):
            if not filled(c.get(f)):
                errors.append('claims[%d].%s required' % (i, f))
        if not isinstance(c.get('status'), str) or c.get('status') not in EVIDENCE:
            errors.append('claims[%d].status invalid' % i)
        if c.get('status') == 'source_checked' and not filled(c.get('source')):
            errors.append('claims[%d] source_checked requires source' % i)
    attacks = data.get('attacks')
    if not isinstance(attacks, list) or not attacks:
        errors.append('attacks must be nonempty list')
        attacks = []
    attack_ids = _ids(attacks)
    if len(set(attack_ids)) != len(attack_ids):
        errors.append('duplicate attack id')
    for i, a in enumerate(attacks):
        if not isinstance(a, dict):
            errors.append('attacks[%d] must be object' % i)
            continue
        for f in ('id', 'steelman', 'attack_mechanism', 'failure_signal', 'cheapest_test',
                  'retraction_condition', 'minimum_repair', 'fallback', 'consequence', 'severity_reason'):
            if not filled(a.get(f)):
                errors.append('attacks[%d].%s required' % (i, f))
        if a.get('target_claim') not in claim_ids:
            errors.append('attacks[%d].target_claim unknown' % i)
        if not isinstance(a.get('severity'), str) or a.get('severity') not in SEVERITY:
            errors.append('attacks[%d].severity invalid' % i)
        if not isinstance(a.get('evidence_status'), str) or a.get('evidence_status') not in EVIDENCE:
            errors.append('attacks[%d].evidence_status invalid' % i)
        if a.get('evidence_status') == 'source_checked' and not filled(a.get('source')):
            errors.append('attacks[%d] source_checked requires source' % i)
        if a.get('evidence_status') in ('unknown','inference'):
            warnings.append('attacks[%d] attack evidence unverified' % i)
    verdict = data.get('verdict')
    if not isinstance(verdict, dict):
        errors.append('verdict object required')
    else:
        if not isinstance(verdict.get('state'), str) or verdict.get('state') not in VERDICTS:
            errors.append('verdict.state invalid')
        for f in ('reason', 'next_observation', 'stop_rule', 'review_point'):
            if not filled(verdict.get(f)):
                errors.append('verdict.%s required' % f)
        refs = verdict.get('blocking_attacks')
        if not isinstance(refs, list) or any(x not in attack_ids for x in refs):
            errors.append('verdict.blocking_attacks must reference valid attacks')
        elif verdict.get('state') in ('REVISE', 'STOP') and not refs:
            errors.append('blocking verdict must identify attack')
    return errors, warnings

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('record', type=Path)
    ap.add_argument('--json', action='store_true')
    args=ap.parse_args()
    try:
        data=json.loads(args.record.read_text(encoding='utf-8-sig'))
        errors,warnings=audit(data)
    except (OSError,UnicodeError,json.JSONDecodeError) as exc:
        print('FAIL: %s' % exc,file=sys.stderr)
        return 1
    if args.json:
        print(json.dumps({'ok':not errors,'errors':errors,'warnings':warnings,'note':'structural only; no facts verified'},ensure_ascii=False,indent=2))
    else:
        for w in warnings: print('WARNING: '+w)
        for e in errors: print('ERROR: '+e)
        print('PASS: structurally valid; not evidence-verified' if not errors else 'FAIL: invalid attack record')
    return int(bool(errors))

if __name__=='__main__':
    sys.exit(main())
