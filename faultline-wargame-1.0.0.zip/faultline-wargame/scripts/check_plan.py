#!/usr/bin/env python3
"""Inspect plan dependencies, task gates, and cycles; never execute plan steps."""
from __future__ import annotations
import argparse
import json
import sys
from pathlib import Path

STATUSES = {'pending', 'in_progress', 'done', 'blocked'}

def filled(s):
    return isinstance(s,str) and bool(s.strip())

def inspect(data):
    errors, warnings=[], []
    if not isinstance(data,dict):
        return ['root must be JSON object'], []
    for f in ('objective','budget_boundary','approval_owner'):
        if not filled(data.get(f)): errors.append('missing '+f)
    tasks=data.get('tasks')
    if not isinstance(tasks,list) or not tasks:
        return errors+['tasks must be nonempty list'], warnings
    ids=[]
    mapping={}
    for i,t in enumerate(tasks):
        if not isinstance(t,dict):
            errors.append('tasks[%d] must be object' % i)
            continue
        for f in ('id','action','acceptance','stop_signal'):
            if not filled(t.get(f)):errors.append('tasks[%d].%s missing' % (i,f))
        k=t.get('id')
        if filled(k):
            ids.append(k)
            if k not in mapping: mapping[k]=t
        if not isinstance(t.get('status'), str) or t.get('status') not in STATUSES:
            errors.append('tasks[%d].status invalid' % i)
        dep=t.get('depends_on')
        if not isinstance(dep,list) or not all(filled(x) for x in dep):
            errors.append('tasks[%d].depends_on must be string list' % i)
        if t.get('status')=='done' and not filled(t.get('evidence')):
            errors.append('tasks[%d] done requires evidence locator' % i)
    if len(ids)!=len(set(ids)):
        errors.append('duplicate task id')
    edges={}
    for i,t in enumerate(tasks):
        if not isinstance(t,dict) or not filled(t.get('id')): continue
        deps=t.get('depends_on')
        if not isinstance(deps,list):continue
        if not all(filled(x) for x in deps):
            continue  # already reported invalid dependency field above
        if len(set(deps))!=len(deps):errors.append('tasks[%d] duplicate dependency' % i)
        for d in deps:
            if d not in mapping: errors.append('tasks[%d] unknown dependency: %s' % (i,d))
            if d==t['id']: errors.append('tasks[%d] self dependency' % i)
            dep=mapping.get(d)
            if t.get('status')=='done' and dep and dep.get('status')!='done':
                errors.append('tasks[%d] done while dependency %s incomplete' % (i,d))
        edges[t['id']]=[d for d in deps if d in mapping]
    state={}
    def visit(n):
        if state.get(n)==1:return True
        if state.get(n)==2:return False
        state[n]=1
        for d in edges.get(n,[]):
            if visit(d):return True
        state[n]=2
        return False
    if any(visit(x) for x in edges if x not in state):
        errors.append('dependency cycle detected')
    if not any(isinstance(x,dict) and not x.get('depends_on') for x in tasks):
        warnings.append('no dependency-free start task')
    return errors,warnings

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('plan',type=Path)
    args=p.parse_args()
    try:
        errors,warnings=inspect(json.loads(args.plan.read_text(encoding='utf-8-sig')))
    except (OSError,UnicodeError,json.JSONDecodeError) as e:
        print('FAIL: %s' % e,file=sys.stderr);return 1
    for w in warnings:print('WARNING: '+w)
    for e in errors:print('ERROR: '+e)
    print('PASS: dependencies structurally consistent (execution NOT verified)' if not errors else 'FAIL: plan invalid')
    return int(bool(errors))

if __name__=='__main__':
    sys.exit(main())
