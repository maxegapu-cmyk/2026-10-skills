#!/usr/bin/env python3
"""Validate a portable SKILL.md entry and its local references (not skill quality)."""
from __future__ import annotations
import argparse
import json
import re
import sys
from pathlib import Path

NAME=re.compile(r'^[a-z0-9]+(?:-[a-z0-9]+)*$')
LINK=re.compile(r'(?<!!)\[[^]]*\]\(([^)]+)\)')

def check(path):
    errors=[]
    root=Path(path).resolve()
    if not root.is_dir():return ['not a skill directory']
    entry=root/'SKILL.md'
    if not entry.is_file():return ['missing SKILL.md']
    try:content=entry.read_text(encoding='utf-8-sig')
    except (OSError,UnicodeError) as exc:return ['SKILL.md unreadable: %s' % exc]
    mt=re.match(r'\A---\s*\n(.*?)\n---\s*\n',content,re.S)
    if not mt:return ['missing frontmatter delimiters']
    fields={}
    for line in mt.group(1).splitlines():
        if not line.strip() or line.lstrip().startswith('#'):continue
        m=re.fullmatch(r'([A-Za-z][A-Za-z0-9_-]*):\s*(.*?)\s*',line)
        if not m:
            errors.append('frontmatter line malformed')
            continue
        key,val=m.groups()
        if key in fields: errors.append('duplicate field '+key)
        try:
            if val.startswith('"'):val=json.loads(val)
        except json.JSONDecodeError:
            errors.append('invalid quoted field '+key)
        fields[key]=val
    name=fields.get('name','')
    desc=fields.get('description','')
    if not isinstance(name,str) or not NAME.fullmatch(name) or len(name)>64:
        errors.append('invalid name')
    elif name!=root.name:errors.append('name must match directory')
    if not isinstance(desc,str) or not 1<=len(desc)<=1024:
        errors.append('invalid description')
    if not content[mt.end():].strip():errors.append('empty body')
    if re.search(r'\bTODO\b|\bTBD\b|\[PLACEHOLDER\]',content,re.I):
        errors.append('unfinished placeholder')
    for target in LINK.findall(content):
        target=target.split('#',1)[0].strip()
        if not target or re.match(r'^[a-z]+://',target) or target.startswith('mailto:'):continue
        dest=(root/target).resolve()
        if not dest.is_relative_to(root):errors.append('link escapes directory: '+target)
        elif not dest.is_file():errors.append('missing link target: '+target)
    return errors

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('path',type=Path)
    a=ap.parse_args()
    errors=check(a.path)
    print('PASS: basic SKILL.md contract' if not errors else 'FAIL:\n'+ '\n'.join(errors))
    return int(bool(errors))

if __name__=='__main__':sys.exit(main())
