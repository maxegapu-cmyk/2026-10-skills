"""Deterministic regression tests for attack and plan contracts."""
import copy
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from audit_wargame import audit
from check_plan import inspect
from validate_skill import check

class TestAttackContract(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.record=json.loads((ROOT/'assets/attack-record-example.json').read_text(encoding='utf-8'))

    def test_example_valid(self):
        errs, warn=audit(self.record)
        self.assertEqual([],errs)
        self.assertTrue(warn)

    def test_root_rejects_list(self):
        self.assertTrue(audit([])[0])

    def test_target_required(self):
        d=copy.deepcopy(self.record);d['target']['goal']=''
        self.assertTrue(any('target.goal' in e for e in audit(d)[0]))

    def test_verified_source_is_not_optional(self):
        d=copy.deepcopy(self.record);d['claims'][0]['status']='source_checked'
        self.assertTrue(any('source_checked requires source' in e for e in audit(d)[0]))

    def test_attack_verified_requires_source(self):
        d=copy.deepcopy(self.record);d['attacks'][0]['evidence_status']='source_checked'
        self.assertTrue(any('source_checked requires source' in e for e in audit(d)[0]))

    def test_steelman_required(self):
        d=copy.deepcopy(self.record);d['attacks'][0]['steelman']=''
        self.assertTrue(any('.steelman' in e for e in audit(d)[0]))

    def test_critics_retraction_required(self):
        d=copy.deepcopy(self.record);d['attacks'][0].pop('retraction_condition')
        self.assertTrue(any('retraction_condition' in e for e in audit(d)[0]))

    def test_no_unanchored_attacks(self):
        d=copy.deepcopy(self.record);d['attacks'][0]['target_claim']='imagined'
        self.assertTrue(any('target_claim unknown' in e for e in audit(d)[0]))

    def test_duplicate_attack_ids(self):
        d=copy.deepcopy(self.record);d['attacks'].append(copy.deepcopy(d['attacks'][0]))
        self.assertTrue(any('duplicate attack id' in e for e in audit(d)[0]))

    def test_duplicate_claim_ids(self):
        d=copy.deepcopy(self.record);d['claims'].append(copy.deepcopy(d['claims'][0]))
        self.assertTrue(any('duplicate claim id' in e for e in audit(d)[0]))

    def test_invalid_risk_severity(self):
        d=copy.deepcopy(self.record);d['attacks'][0]['severity']='100%'
        self.assertTrue(any('severity invalid' in e for e in audit(d)[0]))

    def test_blocking_verdict_requires_id(self):
        d=copy.deepcopy(self.record);d['verdict']['state']='STOP';d['verdict']['blocking_attacks']=[]
        self.assertTrue(any('blocking verdict' in e for e in audit(d)[0]))

    def test_blocking_ref_must_exist(self):
        d=copy.deepcopy(self.record);d['verdict']['blocking_attacks']=['not-real']
        self.assertTrue(any('blocking_attacks' in e for e in audit(d)[0]))

    def test_bad_json_types_are_errors_not_traceback(self):
        d=copy.deepcopy(self.record)
        d["attacks"][0]["evidence_status"]=["unknown"]
        self.assertTrue(any("evidence_status invalid" in e for e in audit(d)[0]))

    def test_source_checked_after_evidence(self):
        d=copy.deepcopy(self.record);d['attacks'][0]['evidence_status']='source_checked';d['attacks'][0]['source']='user-provided-document-1'
        self.assertEqual([],audit(d)[0])

class TestPlan(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.sample=json.loads((ROOT/'assets/plan-example.json').read_text(encoding='utf-8'))

    def test_good(self):
        self.assertEqual([],inspect(self.sample)[0])

    def test_missing_task(self):
        d=copy.deepcopy(self.sample);d['tasks']=[]
        self.assertTrue(any('tasks' in e for e in inspect(d)[0]))

    def test_duplicate_ids(self):
        d=copy.deepcopy(self.sample);d['tasks'][1]['id']='t1'
        self.assertTrue(any('duplicate task id' in e for e in inspect(d)[0]))

    def test_unknown_dep(self):
        d=copy.deepcopy(self.sample);d['tasks'][1]['depends_on']=['phantom']
        self.assertTrue(any('unknown dependency' in e for e in inspect(d)[0]))

    def test_self_dependency(self):
        d=copy.deepcopy(self.sample);d['tasks'][0]['depends_on']=['t1']
        self.assertTrue(any('self dependency' in e for e in inspect(d)[0]))

    def test_dependency_cycle(self):
        d=copy.deepcopy(self.sample);d['tasks'][0]['depends_on']=['t3']
        self.assertTrue(any('cycle' in e for e in inspect(d)[0]))

    def test_premature_completion(self):
        d=copy.deepcopy(self.sample);d['tasks'][1]['status']='done';d['tasks'][1]['evidence']='not-run-locator'
        self.assertTrue(any('incomplete' in e for e in inspect(d)[0]))

    def test_done_without_evidence(self):
        d=copy.deepcopy(self.sample);d['tasks'][0]['status']='done'
        self.assertTrue(any('done requires evidence' in e for e in inspect(d)[0]))

    def test_done_with_evidence(self):
        d=copy.deepcopy(self.sample);d['tasks'][0]['status']='done';d['tasks'][0]['evidence']='record-001'
        self.assertEqual([],inspect(d)[0])

    def test_invalid_status(self):
        d=copy.deepcopy(self.sample);d['tasks'][0]['status']='approved magically'
        self.assertTrue(any('status invalid' in e for e in inspect(d)[0]))

    def test_bad_root(self):
        self.assertTrue(inspect('not-object')[0])

    def test_malformed_dependency_list_does_not_crash(self):
        d=copy.deepcopy(self.sample);d["tasks"][0]["depends_on"]=[["nested"]]
        self.assertTrue(any("depends_on" in e for e in inspect(d)[0]))

    def test_invalid_dep_type(self):
        d=copy.deepcopy(self.sample);d['tasks'][0]['depends_on']='t2'
        self.assertTrue(any('depends_on' in e for e in inspect(d)[0]))

class TestCLI(unittest.TestCase):
    def test_cli_from_clean_cwd_and_bad_file(self):
        with tempfile.TemporaryDirectory() as td:
            for name,sample in (('audit_wargame.py','attack-record-example.json'),('check_plan.py','plan-example.json')):
                script=ROOT/'scripts'/name
                p=ROOT/'assets'/sample
                proc=subprocess.run([sys.executable,'-B',str(script),str(p)],cwd=td,capture_output=True,text=True)
                self.assertEqual(proc.returncode,0,proc.stderr)
                broken=Path(td)/'broken.json';broken.write_text('{','utf-8')
                proc=subprocess.run([sys.executable,'-B',str(script),str(broken)],cwd=td,capture_output=True,text=True)
                self.assertNotEqual(proc.returncode,0)
                proc=subprocess.run([sys.executable,'-B',str(script),'--help'],cwd=td,capture_output=True,text=True)
                self.assertEqual(proc.returncode,0)

    def test_validate_release_skill_entry(self):
        self.assertEqual([],check(ROOT))

    def test_refuses_bad_external_local_reference(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td)/"bad";root.mkdir()
            (root/"SKILL.md").write_text("---\nname: bad\ndescription: \"x\"\n---\n\n[bad](../escape.md)\n",encoding="utf-8")
            self.assertTrue(any("escapes directory" in e for e in check(root)))

    def test_semantic_cases_not_fake_results(self):
        obj=json.loads((ROOT/'evals/cases.json').read_text(encoding='utf-8'))
        self.assertIn('NOT RUN',obj['status'])
        self.assertGreaterEqual(len(obj['cases']),10)
        self.assertEqual(len(obj['cases']),len(set(x['id'] for x in obj['cases'])))

    def test_referenced_docs_exist(self):
        md=(ROOT/'SKILL.md').read_text(encoding='utf-8')
        import re
        for ref in re.findall(r'\]\(([^)#]+)\)',md):
            self.assertTrue((ROOT/ref).is_file(),ref)
        self.assertTrue(md.startswith('---\nname: faultline-wargame\n'))

if __name__=='__main__':
    unittest.main()
