# Faultline Wargame 1.0.0 — 本地执行报告

日期：2026-10-23。全新独立公开版，用于策略、计划和论证的**对抗式压力测试**；与 Bedrock Agora 的第一性原理决策/Skill 生成任务分工明确，未复制外部 GitHub Skill 内容。

## 实际文件及能力

- 入口 `SKILL.md`；模式 `STRIKE / WAR-GAME / REPAIR / GATE`。
- `references/attack-playbook.md`：钢人化、承重假设、因果破坏、自我反证、条件撤销。
- `references/scenario-playbook.md`：资源受限的合理对手/环境响应、二阶后果、停止规则。
- `assets/attack-record-example.json`、`assets/plan-example.json`、`examples/worked-examples.md`：虚构可读示例。
- `scripts/audit_wargame.py`：攻击记录字段、交叉引用、证据声明、阻断理由检查。
- `scripts/check_plan.py`：依赖图、未知项、循环、提前完成的检查；不执行计划。
- `scripts/validate_skill.py`：检查入口 frontmatter 与本地链接。
- `evals/cases.json`：12 个**尚未执行**的行为测试场景。

## 已在开发目录实际运行

- 环境：Linux，Python 3.13.5，标准库，无第三方依赖。
- `python -I -B -m unittest discover -s tests -q`：**33 项通过**。
- `python -I -B scripts/validate_skill.py .`：通过。
- `python -I -B scripts/audit_wargame.py assets/attack-record-example.json`：结构通过，明确提示攻击证据未独立核实。
- `python -I -B scripts/check_plan.py assets/plan-example.json`：依赖结构通过，未运行真实计划。
- 正/负例覆盖重复 ID、无来源的“已验证”、伪造状态、缺失撤回标准、悬空依赖、依赖环、缺证据就标记完成、畸形 JSON 输入和从陌生目录执行 CLI。

## 重要限制

- 未运行独立模型/真人盲评、真实商业攻防、效果提升实证；测试通过只说明代码/结构路径。
- 未在真实 Python 3.9 环境运行；3.9 语法解析不是实际兼容证明。
- 结构校验器不能验证对手的实际意图、攻击结论的真实性或商业判断质量。

最终 ZIP 哈希、独立全新解压后复验记录见发布包外 `DUAL_SKILLS_发布复验.md`。
