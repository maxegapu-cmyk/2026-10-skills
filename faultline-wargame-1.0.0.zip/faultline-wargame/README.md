# Faultline Wargame 1.0.0｜断层攻防室

独立的公开版对抗式**推理与规划审查 Skill**；与 Bedrock Agora 互补而非重复。前者更偏第一性原理决策与造 Skill；本产品聚焦：**钢人化 → 攻击承重假设 → 对攻击反击 → 合理竞争场景 → 最低成本试验和止损**。

安装：将整个 `faultline-wargame/` 目录放在 `.claude/skills/` 或 `.agents/skills/`，让代理使用其中的 `SKILL.md`。无需第三方 Python 依赖（Python 3.9+ 为目标，当前运行环境见验证报告）。

调用示例：
- `STRIKE：用最强反方攻击这个商业计划，但先准确复述它`。
- `WAR-GAME：假设竞争对手对我们的促销做出合理反应，推演两轮，列停止条件`。
- `REPAIR：只修复被证据支持的最致命问题，保留原来有效部分`。
- `GATE：产品上线前做对抗评审，不允许编造实际结果`。

真实工具：

```bash
python scripts/validate_skill.py .
python scripts/audit_wargame.py assets/attack-record-example.json
python scripts/check_plan.py assets/plan-example.json
python -B -m unittest discover -s tests -v
```

这些只做结构验证，不联网、不执行攻击、不进行模型推理，也不调用其他 Skill。MIT License。GitHub公开参考与限制见 `references/source-notes.md`。
