# Public references, adaptation and limitations

These materials were reviewed as **public pattern inspirations**; Faultline's prose, examples, JSON contracts, code and tests were independently authored. Do not copy/paste these third-party Skills as this product. Their current repositories may change independently.

- [phuryn/pm-skills — strategy-red-team](https://github.com/phuryn/pm-skills/blob/main/pm-execution/skills/strategy-red-team/SKILL.md) — idea: isolate load-bearing assumptions and cheapest tests; our addition: critic's own retraction standard, adaptive countermoves and deterministic contract audit.
- [kdoble/red-team-skeptic](https://github.com/kdoble/red-team-skeptic) — idea: attack valid premises rather than generating generic criticism; our addition: plan DAG checking and explicit exit planning.
- [b1rdmania/claude-premortem-skill](https://github.com/b1rdmania/claude-premortem-skill/blob/main/SKILL.md) — idea: prospective hindsight; our design does **not** require invented future events.
- [obra/superpowers](https://github.com/obra/superpowers) — composable skills, verification before completion, explicit planning; we do not inherit its mandatory interview and subagent requirements.
- [anthropics/skills skill-creator](https://github.com/anthropics/skills/blob/main/skills/skill-creator/SKILL.md) — progressive disclosure and genuinely evaluated test cases.

**Limitations:** deterministic CLI tests do not assess reasoning quality, simulate markets, validate source authenticity, measure independent reviewer agreement or prove improved real-world decisions. Semantic cases require real model/human tests and remain unexecuted unless release report says otherwise.
