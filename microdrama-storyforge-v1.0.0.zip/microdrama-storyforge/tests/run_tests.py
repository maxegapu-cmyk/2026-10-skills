#!/usr/bin/env python3
"""Dependency-free regression suite. Execute from any working directory."""
from pathlib import Path
import json
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / 'scripts'))
from project_cli import (init_project, checkpoint, approve, check_project, check_outline,
                         check_episode, visible_chars)
from validate_skill import validate


def ep_text(n, footer=True, dialogue=True):
    part = f'''第{n}集 谁拿了秤
{n}-1 菜市场 早/内景
人物：陈青、老罗
△ 老罗把秤放到台面上。陈青伸手挡住秤盘，发现封条被换过。
'''
    if dialogue:
        part += '陈青（盯着封条）：昨天不是这张。\n老罗（把手缩回去）：我只负责收东西。\n'
    part += '△ 陈青拿出手机，记下封条编码。\n'
    if footer:
        part += f'（第{n}集 完）\n'
    return part


class StoryforgeTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.project = Path(self.temp.name) / 'project'
        init_project(self.project)
    def tearDown(self):
        self.temp.cleanup()

    def test_skill_manifest_valid(self):
        self.assertEqual(validate(), [])

    def test_init_safe_no_overwrite(self):
        path = self.project / 'story_bible.md'
        path.write_text('人工锁定内容', encoding='utf-8')
        with self.assertRaisesRegex(ValueError, '拒绝覆盖'):
            init_project(self.project)
        self.assertEqual(path.read_text(encoding='utf-8'), '人工锁定内容')

    def test_outline_placeholder_rejected(self):
        problems = check_outline(self.project)
        self.assertTrue(any(x['code'] == 'outline_unfilled' for x in problems))
        self.assertFalse(check_project(self.project, 'outline')['ok'])

    def test_outline_complete_15_valid(self):
        lines = ['# 大纲', '| 集 | 标题 | 压力 | 目标 | 行动 | 阻碍 | 反转 | 代价 | 尾钩 | 场景 | 预算 |',
                 '|---|---|---|---|---|---|---|---|---|---|---|']
        for n in range(1, 16):
            lines.append(f'| {n} | 剧集{n} | 被追责 | 查账 | 寻证 | 对手封路 | 查出仓库 | 失去支持 | 次日会议 | 仓库 | 2333 |')
        (self.project / 'outline.md').write_text('\n'.join(lines), encoding='utf-8')
        self.assertTrue(check_project(self.project, 'outline')['ok'])
        self.assertIn('已写入', checkpoint(self.project, 'outline', None, '15集大纲草案'))
        s = json.loads((self.project / 'project_state.json').read_text(encoding='utf-8'))
        self.assertFalse(s['approved']['outline'])
        self.assertEqual(s['stage'], 'outline')

    def test_episode_valid_and_checkpoint(self):
        (self.project / 'episodes' / 'EP01.md').write_text(ep_text(1), encoding='utf-8')
        result = check_project(self.project, 'episode', 1, 0)
        self.assertTrue(result['ok'], result['issues'])
        self.assertGreater(result['visible_character_total'], 0)
        checkpoint(self.project, 'episode', 1, '初稿完成')
        state = json.loads((self.project / 'project_state.json').read_text(encoding='utf-8'))
        self.assertEqual(state['completed_episodes'], [1])
        self.assertFalse(state['history'][0]['approved_by_user'])

    def test_episode_missing_action_rejected(self):
        text = ep_text(1).replace('△', '※')
        (self.project / 'episodes' / 'EP01.md').write_text(text, encoding='utf-8')
        problems, _ = check_episode(self.project, 1, min_chars=0)
        self.assertTrue(any(x['code'] == 'scene_action' for x in problems))

    def test_episode_wrong_scene_id_rejected(self):
        text = ep_text(1).replace('1-1 菜市场', '2-1 菜市场')
        (self.project / 'episodes' / 'EP01.md').write_text(text, encoding='utf-8')
        problems, _ = check_episode(self.project, 1, min_chars=0)
        self.assertTrue(any(x['code'] == 'scene_episode_mismatch' for x in problems))

    def test_episode_missing_dialogue_rejected(self):
        (self.project / 'episodes' / 'EP01.md').write_text(ep_text(1, dialogue=False), encoding='utf-8')
        problems, _ = check_episode(self.project, 1, min_chars=0)
        self.assertTrue(any(x['code'] == 'scene_dialogue' for x in problems))

    def test_episode_missing_footer_rejected(self):
        (self.project / 'episodes' / 'EP01.md').write_text(ep_text(1, footer=False), encoding='utf-8')
        problems, _ = check_episode(self.project, 1, min_chars=0)
        self.assertTrue(any(x['code'] == 'episode_footer' for x in problems))

    def test_final_missing_episodes_fails(self):
        result = check_project(self.project, 'final', min_chars=0)
        self.assertFalse(result['ok'])
        self.assertIn('episode_missing', [p['code'] for p in result['issues']])

    def test_checkpoint_requires_complete(self):
        with self.assertRaisesRegex(ValueError, '未通过'):
            checkpoint(self.project, 'outline', None, '空模板')
        with self.assertRaisesRegex(ValueError, '缺少'):
            checkpoint(self.project, 'episode', 3, '还未写')

    def test_checkpoint_appends_handoff_not_overwrite(self):
        (self.project / 'episodes' / 'EP01.md').write_text(ep_text(1), encoding='utf-8')
        before = (self.project / 'HANDOFF.md').read_text(encoding='utf-8')
        checkpoint(self.project, 'episode', 1, '初稿')
        after = (self.project / 'HANDOFF.md').read_text(encoding='utf-8')
        self.assertTrue(after.startswith(before))
        self.assertIn('下一动作：审查第1集', after)

    def test_approve_requires_user_confirmation(self):
        (self.project / 'episodes' / 'EP01.md').write_text(ep_text(1), encoding='utf-8')
        checkpoint(self.project, 'episode', 1, '初稿')
        with self.assertRaisesRegex(ValueError, '明确批准'):
            approve(self.project, 'episode', 1, '', False)
        approve(self.project, 'episode', 1, '用户确认', True)
        state = json.loads((self.project / 'project_state.json').read_text(encoding='utf-8'))
        self.assertEqual(state['approved_episodes'], [1])
        self.assertEqual([h['approved_by_user'] for h in state['history']], [False, True])

    def test_checkpoint_rejects_out_of_range(self):
        with self.assertRaisesRegex(ValueError, '1到15'):
            checkpoint(self.project, 'episode', 99, '')

    def test_char_count(self):
        self.assertEqual(visible_chars('主角：来\n 去。'), 6)


if __name__ == '__main__':
    unittest.main(verbosity=2)
