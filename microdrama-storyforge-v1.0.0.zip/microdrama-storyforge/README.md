# Microdrama Storyforge 1.0.0｜十三职能竖屏微短剧剧本Skill

把用户提供的原始13位职能编剧矩阵，升级为真实可用的**Agent Skills 标准目录**（`SKILL.md` + 参考资料 + 模板 + 无第三方依赖的项目状态/结构验收脚本）。

## 主要功能

- 保留13位编剧职能，但不会假装真的并行调用13个AI。
- 题材重构（3个差异显著的原创选项）→ 故事圣经→15集大纲→第一集钩子→逐集正文→7项检查→保存/续写。
- 默认15集、约35,000可见字符；按产出滚动分配；**不保证同时满足超短时长目标**。
- 用户原来的中文格式 `第X集` / `X-1 地点 时间/内外景` / `人物：` / `△` / `角色（表情/小动作）：` / `（第X集 完）` 被保留。
- 权利核查、低成本拍摄建议、反转因果、角色连续性、明确的审批状态和落盘交接。
- 原始用户材料保存在 `source/original-user-material.txt`，**不要随意把这个文件发给第三方或公开仓库**；需要公开版请移除源文本后再复核授权。

## 安装

解压后把 **`microdrama-storyforge` 整个目录**放入你使用的AI宿主识别的Skill目录，确保它内含 `SKILL.md`。不同宿主的安装位置/启用方式可能不同，按其官方说明选择。也可直接在对话中将 `SKILL.md` 提供给支持文件读取的模型。

## 初始化作品工作区

在本Skill目录执行：

```bash
python scripts/project_cli.py init --project ./my-drama
python scripts/project_cli.py validate --project ./my-drama --mode outline
```

初始 `outline.md` 全是“待定”，因此验证提示不完整是**预期行为**。

当完成第一集，把完整剧本保存到 `my-drama/episodes/EP01.md`，再执行：

```bash
python scripts/project_cli.py validate --project ./my-drama --mode episode --episode 1
python scripts/project_cli.py checkpoint --project ./my-drama --stage episode --episode 1 --note "第1集初稿保存"
```

**`checkpoint`只确认文件确已生成且结构有效，不代表用户已批准。** 如果用户明确说“第1集确认通过”，再执行：

```bash
python scripts/project_cli.py approve --project ./my-drama --stage episode --episode 1 --user-confirmed --note "用户审核通过第1集"
```

全季大纲确认则用 `--stage outline --user-confirmed`。两种操作都会追加 `HANDOFF.md`，不覆盖已经存在的剧本或手写交接记录。改动核心事实需记变更历史。

完稿验收：

```bash
python scripts/project_cli.py validate --project ./my-drama --mode final
python tests/run_tests.py
```

静态验证只能发现文件缺失、结构格式、集数/计数异常。因果、版权、实际审查请按七门验收人工复核。`--json` 可以输出结构化校验结果供其他自动化消费。

## 源文件与外部参考

原始需求不等于已经创作的剧本，因此这个压缩包是**可执行的写作工作流与模板**，不是虚构完成15集成片。结构遵循Agent Skills官方格式：https://agentskills.io/specification 。微短剧合规参考：https://www.nrta.gov.cn/art/2026/7/31/art_113_73785.html （2026-09-01生效；上线仍应复核现行规定）。

## 长期进度

`project_state.json`为进度指针；每集 `EPxx.md` 是真实正文；`continuity.json` 是剧情事实账；`HANDOFF.md` 是移交入口。当前Skill源码本身不保存用户未来创作结果，必须在工作区真正写盘才能持续。
