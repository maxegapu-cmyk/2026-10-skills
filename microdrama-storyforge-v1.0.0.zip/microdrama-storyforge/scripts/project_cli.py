#!/usr/bin/env python3
"""Microdrama Storyforge: project init, static format checks and safe checkpoints.

Python 3.9+, standard library only. Neither semantic review nor copyright clearance.
"""

from __future__ import annotations
import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import re
import shutil
import sys
import tempfile
from typing import Any

ROOT = Path(__file__).resolve().parent.parent
ASSETS = ROOT / 'assets'
EP_HEAD = re.compile(r'^第\s*0*(\d+)\s*集\s+\S+', re.M)
SCENE = re.compile(r'^(\d+)-(\d+)\s+(.+)$')
END = re.compile(r'^（第\s*0*(\d+)\s*集\s*完）\s*$')
DIALOGUE = re.compile(r'^[^\s△#（）|]{1,24}(?:（[^（）\n]{1,28}）)?：\S+')
SOURCE_PATHS = {
    'project_state.template.json': 'project_state.json',
    'story_bible.template.md': 'story_bible.md',
    'concepts.template.md': 'concepts.md',
    'outline.template.md': 'outline.md',
    'opening.template.md': 'opening.md',
    'continuity.template.json': 'continuity.json',
    'HANDOFF.template.md': 'HANDOFF.md',
}
INVALID_CELL = {'', '-', '—', '待定', '待填写', '【待定】', '[待定]', '待写'}


def visible_chars(text: str) -> int:
    """Unicode non-whitespace code points; includes Chinese punctuation."""
    return sum(not c.isspace() for c in text)


def atomically_write_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile('w', encoding='utf-8', dir=path.parent,
                                     prefix='.tmp-storyforge-', suffix='.json', delete=False) as f:
        temp = Path(f.name)
        json.dump(obj, f, indent=2, ensure_ascii=False)
        f.write('\n')
        f.flush()
        os.fsync(f.fileno())
    try:
        os.replace(temp, path)
    finally:
        if temp.exists():
            temp.unlink()


def issue(level: str, code: str, detail: str) -> dict[str, str]:
    return {'level': level, 'code': code, 'detail': detail}


def load_state(project: Path):
    p = project / 'project_state.json'
    if not p.is_file():
        raise ValueError(f'找不到 {p}，请先运行 init')
    try:
        obj = json.loads(p.read_text(encoding='utf-8'))
    except (OSError, json.JSONDecodeError) as e:
        raise ValueError(f'状态JSON无效：{e}') from e
    if not isinstance(obj, dict) or not isinstance(obj.get('format'), dict):
        raise ValueError('project_state.json 缺少必填格式对象')
    return obj


def check_outline(project: Path, episode_count: int = 15) -> list[dict]:
    path = project / 'outline.md'
    if not path.is_file():
        return [issue('error', 'outline_missing', f'缺少{path}')]
    content = path.read_text(encoding='utf-8')
    rows = []
    for lno, line in enumerate(content.splitlines(), start=1):
        if not line.lstrip().startswith('|'):
            continue
        cells = [p.strip() for p in line.strip().strip('|').split('|')]
        if cells and re.fullmatch(r'\d+', cells[0]):
            rows.append((int(cells[0]), cells, lno))
    errors = []
    indices = [r[0] for r in rows]
    target = list(range(1, episode_count + 1))
    if sorted(indices) != target:
        errors.append(issue('error', 'outline_indices', f'必须各有一行第1—{episode_count}集，实际为 {indices}'))
    for n, cells, lineno in rows:
        if len(cells) < 10:
            errors.append(issue('error', 'outline_columns', f'第{lineno}行第{n}集结构列不足（至少10列）'))
            continue
        if any(x in INVALID_CELL or '[待' in x or '【待' in x for x in cells[1:10]):
            errors.append(issue('error', 'outline_unfilled', f'第{n}集第{lineno}行仍有空白/待定字段'))
    if rows and all(len(c[1]) >= 11 for c in rows):
        for n, cells, _ in rows:
            if not re.fullmatch(r'\d+', cells[10]) or int(cells[10]) <= 0:
                errors.append(issue('warning', 'outline_budget', f'第{n}集字符预算应为正整数'))
    return errors


def check_episode(project: Path, episode: int, target_total: int = 35000,
                  episode_count: int = 15, min_chars: int = 900) -> tuple[list[dict], int]:
    path = project / 'episodes' / f'EP{episode:02d}.md'
    if not path.is_file():
        return [issue('error', 'episode_missing', f'缺少{path}')], 0
    txt = path.read_text(encoding='utf-8-sig')
    count = visible_chars(txt)
    lines = txt.splitlines()
    errors = []
    heads = list(EP_HEAD.finditer(txt))
    if len(heads) != 1 or int(heads[0].group(1)) != episode:
        errors.append(issue('error', 'episode_heading', f'EP{episode:02d}开头应恰好出现“第{episode}集 标题”'))
    # Find all numbered scene lines; flag mismatched prefix/duplicates/nonsequential order.
    scene_lines = []
    for idx, line in enumerate(lines):
        match = SCENE.fullmatch(line.strip())
        if match:
            scene_lines.append((idx, int(match.group(1)), int(match.group(2)), match.group(3)))
    if not scene_lines:
        errors.append(issue('error', 'scene_missing', '缺少“X-1 地点 时间/内外景”等场次'))
    else:
        seen = []
        for idx, pref, n, header in scene_lines:
            if pref != episode:
                errors.append(issue('error', 'scene_episode_mismatch', f'第{idx+1}行场号{pref}-{n}应以{episode}-开头'))
            seen.append(n)
            if not re.search(r'(内景|外景|/内|/外)', header):
                errors.append(issue('error', 'scene_int_ext', f'第{idx+1}行未指定内/外景'))
            if not re.search(r'(早|晨|午|下午|傍晚|黄昏|晚|夜|凌晨|日|两小时后|次日)', header):
                errors.append(issue('warning', 'scene_time', f'第{idx+1}行未出现明确时间标记'))
        if seen != list(range(1, len(seen) + 1)):
            errors.append(issue('error', 'scene_sequence', f'场次编号应从1连续递增，实际为 {seen}'))
        for i, (idx, pref, n, _) in enumerate(scene_lines):
            endline = scene_lines[i+1][0] if i+1 < len(scene_lines) else len(lines)
            body = lines[idx+1:endline]
            if not any(re.match(r'^人物：\s*\S+', l.strip()) for l in body):
                errors.append(issue('error', 'scene_cast', f'场{n}缺少“人物：出场角色”'))
            if not any(l.lstrip().startswith('△') for l in body):
                errors.append(issue('error', 'scene_action', f'场{n}缺少可拍动作标记△'))
            if not any(DIALOGUE.match(l.strip()) and not l.strip().startswith(('人物：', '道具：', '字幕：')) for l in body):
                errors.append(issue('error', 'scene_dialogue', f'场{n}缺少角色台词“角色（动作）：台词”'))
    if not any((m := END.fullmatch(l.strip())) and int(m.group(1)) == episode for l in lines):
        errors.append(issue('error', 'episode_footer', f'缺少（第{episode}集 完）'))
    if count < min_chars:
        errors.append(issue('warning', 'episode_short', f'仅{count}个非空白字符，低于提醒阈值{min_chars}；此项不构成结构失败'))
    estimated = round(target_total / episode_count) if episode_count > 0 else 0
    if estimated and count > estimated * 2:
        errors.append(issue('warning', 'episode_long', f'本集{count}字符，显著高于默认每集{estimated}字符预算'))
    return errors, count


def check_project(project: Path, mode: str, episode: int | None = None,
                  min_chars: int = 900) -> dict:
    state = load_state(project)
    fmt = state['format']
    n = fmt.get('episode_count', 15)
    target = fmt.get('target_total_visible_characters', 35000)
    if not isinstance(n, int) or not 1 <= n <= 100:
        raise ValueError('format.episode_count 应为1—100的整数')
    if not isinstance(target, int) or target < 0:
        raise ValueError('format.target_total_visible_characters 必须为非负整数')
    issues, counts = [], {}
    if mode in {'outline', 'final'}:
        issues.extend(check_outline(project, n))
    if mode == 'episode':
        if episode is None or not 1 <= episode <= n:
            raise ValueError(f'episode模式必须用 --episode 1到{n}')
        found, c = check_episode(project, episode, target, n, min_chars)
        issues.extend(found)
        counts[f'EP{episode:02d}'] = c
    if mode == 'final':
        for k in range(1, n + 1):
            found, c = check_episode(project, k, target, n, min_chars)
            issues.extend(found)
            counts[f'EP{k:02d}'] = c
        if len(counts) == n and all(c > 0 for c in counts.values()) and target:
            total = sum(counts.values())
            if abs(total - target) / target > 0.15:
                issues.append(issue('warning', 'season_character_budget',
                                    f'实际{total}非空白字符，距目标{target}超过15%；请人工评估时长和质量'))
    errors = [i for i in issues if i['level'] == 'error']
    return {'ok': not errors, 'mode': mode, 'issues': issues, 'counts': counts,
            'visible_character_total': sum(counts.values()),
            'note': '静态检查不代表因果、版权或播出合规审核通过'}


def init_project(project: Path) -> str:
    if project.exists() and any(project.iterdir()):
        raise ValueError(f'拒绝覆盖非空目录：{project}。请选择空目录，确保保留已有工作。')
    project.mkdir(parents=True, exist_ok=True)
    (project / 'episodes').mkdir(exist_ok=True)
    for source, dest in SOURCE_PATHS.items():
        shutil.copyfile(ASSETS / source, project / dest)
    return f'已初始化 {project}，模板未获用户批准；请从concepts.md开始。'


def append_handoff(project: Path, line: str, next_action: str) -> None:
    """Append checkpoint evidence, never overwrite a manually edited handoff."""
    path = project / 'HANDOFF.md'
    with path.open('a', encoding='utf-8') as f:
        f.write(f"\n\n## 自动检查点\n- {line}\n- 下一动作：{next_action}\n")


def approve(project: Path, stage: str, episode: int | None, note: str, confirmed: bool) -> str:
    if not confirmed:
        raise ValueError('明确批准需要 --user-confirmed；不得代替用户自行确认')
    state = load_state(project)
    if stage == 'episode':
        if episode is None:
            raise ValueError('批准剧本需要 --episode N')
        if episode not in state.get('completed_episodes', []):
            raise ValueError('仅能批准已完成并存档的集数')
        issues, _ = check_episode(project, episode, min_chars=0)
        if any(x['level'] == 'error' for x in issues):
            raise ValueError('该集结构验证未通过，拒绝批准')
        dest = state.setdefault('approved_episodes', [])
        if episode not in dest:
            dest.append(episode)
            dest.sort()
    else:
        if stage not in {'concept', 'bible', 'outline', 'opening'}:
            raise ValueError('只能批准 concept/bible/outline/opening/episode')
        if stage == 'outline':
            if any(i['level'] == 'error' for i in check_outline(project, state['format']['episode_count'])):
                raise ValueError('大纲结构验证未通过，拒绝批准')
        else:
            target = {'concept': 'concepts.md', 'bible': 'story_bible.md', 'opening': 'opening.md'}[stage]
            if not (project / target).is_file():
                raise ValueError('成果文件不存在')
            content = (project / target).read_text(encoding='utf-8')
            if '待定' in content or '【待写】' in content:
                raise ValueError('成果文件仍包含待写占位，拒绝批准')
        state['approved'][stage] = True
    now = datetime.now(timezone.utc).isoformat(timespec='seconds')
    state['history'].append({'at': now, 'stage': stage, 'episode': episode, 'note': note or '用户确认批准',
                             'approved_by_user': True})
    state['last_checkpoint'] = now
    atomically_write_json(project / 'project_state.json', state)
    append_handoff(project, f'{now} 用户批准 stage={stage} 集数={episode}；{note}', state['next_action'])
    return f'已记录明确批准 stage={stage} episode={episode}，并追加HANDOFF；未修改既有剧本。'


def checkpoint(project: Path, stage: str, episode: int | None, note: str) -> str:
    state = load_state(project)
    fmt = state['format']
    allowed = {'concept', 'bible', 'outline', 'opening', 'episode', 'review'}
    if stage not in allowed:
        raise ValueError(f'stage只能取 {sorted(allowed)}')
    files = {'concept': 'concepts.md', 'bible': 'story_bible.md',
             'outline': 'outline.md', 'opening': 'opening.md'}
    if stage in files:
        fp = project / files[stage]
        if not fp.is_file():
            raise ValueError(f'缺少成果文件：{fp}')
        if stage == 'outline':
            issues = check_outline(project, fmt['episode_count'])
            if any(i['level'] == 'error' for i in issues):
                raise ValueError('大纲未通过结构检查：' + '; '.join(i['detail'] for i in issues[:3]))
        elif '待定' in fp.read_text(encoding='utf-8') or '【待写】' in fp.read_text(encoding='utf-8'):
            raise ValueError(f'{fp.name}仍包含待定/待写占位，拒绝标记完成')
    else:
        if episode is None or not 1 <= episode <= fmt['episode_count']:
            raise ValueError(f'{stage}里程碑需带 --episode 1到{fmt["episode_count"]}')
        issues, _ = check_episode(project, episode, fmt['target_total_visible_characters'],
                                  fmt['episode_count'], 0)
        if any(i['level'] == 'error' for i in issues):
            raise ValueError('剧本结构未通过：' + '; '.join(i['detail'] for i in issues[:3]))
        if episode not in state['completed_episodes']:
            state['completed_episodes'].append(episode)
            state['completed_episodes'].sort()
    now = datetime.now(timezone.utc).isoformat(timespec='seconds')
    state['stage'] = stage
    state['last_checkpoint'] = now
    state['history'].append({'at': now, 'stage': stage, 'episode': episode, 'note': note or '存档',
                             'approved_by_user': False})
    if stage == 'episode':
        state['next_action'] = f'审查第{episode}集，确认后续写第{episode + 1}集' if episode < fmt['episode_count'] else '进行全季审查'
    elif stage == 'outline':
        state['next_action'] = '设计第一集黄金开场（或直接写EP01）'
    elif stage in {'concept', 'bible'}:
        state['next_action'] = '确认故事圣经及15集因果大纲'
    elif stage == 'opening':
        state['next_action'] = '写第一集完整剧本'
    else:
        state['next_action'] = f'按反馈改写EP{episode:02d}或继续下一集'
    atomically_write_json(project / 'project_state.json', state)
    append_handoff(project, f'{now} 已生成 stage={stage} 集数={episode}；{note or '存档'}（未代表用户批准）', state['next_action'])
    return f'已写入检查点 stage={stage}, episode={episode}, 时间={now}；尚未自动认定用户批准。'


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='cmd', required=True)
    ini = sub.add_parser('init', help='创建新作品的文件结构，拒绝覆盖非空目录')
    ini.add_argument('--project', required=True, type=Path)
    val = sub.add_parser('validate', help='对已写文件做静态结构检查')
    val.add_argument('--project', required=True, type=Path)
    val.add_argument('--mode', required=True, choices=['outline', 'episode', 'final'])
    val.add_argument('--episode', type=int)
    val.add_argument('--min-chars', type=int, default=900, help='单集过短警告阈值，默认900')
    val.add_argument('--json', action='store_true', help='输出结构化JSON结果')
    cp = sub.add_parser('checkpoint', help='文件存在且结构合法后写入进度指针，不冒充批准')
    cp.add_argument('--project', required=True, type=Path)
    cp.add_argument('--stage', required=True, choices=['concept', 'bible', 'outline', 'opening', 'episode', 'review'])
    cp.add_argument('--episode', type=int)
    cp.add_argument('--note', default='')
    ap = sub.add_parser('approve', help='仅在用户已明确确认后，把成果批准记录进state')
    ap.add_argument('--project', required=True, type=Path)
    ap.add_argument('--stage', required=True, choices=['concept', 'bible', 'outline', 'opening', 'episode'])
    ap.add_argument('--episode', type=int)
    ap.add_argument('--user-confirmed', action='store_true', help='必须由用户明确确认后才能填写')
    ap.add_argument('--note', default='')
    args = parser.parse_args(argv)
    try:
        if args.cmd == 'init':
            print(init_project(args.project))
            return 0
        if args.cmd == 'checkpoint':
            print(checkpoint(args.project, args.stage, args.episode, args.note))
            return 0
        if args.cmd == 'approve':
            print(approve(args.project, args.stage, args.episode, args.note, args.user_confirmed))
            return 0
        if args.min_chars < 0:
            raise ValueError('--min-chars不得为负数')
        result = check_project(args.project, args.mode, args.episode, args.min_chars)
        if args.json:
            print(json.dumps(result, indent=2, ensure_ascii=False))
        else:
            print(f"{'PASS' if result['ok'] else 'FAIL'} {args.mode}；累计{result['visible_character_total']}非空白字符")
            for it in result['issues']:
                print(f"[{it['level']}] {it['code']}: {it['detail']}")
            print(result['note'])
        return 0 if result['ok'] else 1
    except (ValueError, OSError, KeyError) as e:
        print(f'ERROR: {e}', file=sys.stderr)
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
