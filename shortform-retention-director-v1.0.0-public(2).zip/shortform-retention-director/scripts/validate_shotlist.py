#!/usr/bin/env python3
"""Validate a director shot list using only Python's standard library.

This is a structural/semantic preflight, not an audience-retention predictor.
"""
from __future__ import annotations

import argparse
import json
import math
import re
import sys
from pathlib import Path

ROLES = {"hook", "context", "proof", "development", "turn", "payoff", "close"}
GOALS = {"reach", "trust", "engagement", "conversion"}
STATUSES = {"verified", "unverified_user_claim", "creative_hypothesis", "fiction"}
REQUIRED_BEAT = (
    "id", "start_s", "end_s", "role", "information_gain", "speech",
    "visual", "on_screen_text", "sound", "cut", "asset", "retention_intent",
)
DUMMY = re.compile(r"(?i)\b(?:TODO|TBD|FIXME|PLACEHOLDER)\b|待补充|这里填写|待定")
EPS = 0.051  # 50ms authoring tolerance, not frame-exact QC


def is_number(value: object) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def validate(data: object) -> dict:
    errors, warnings = [], []

    def err(code: str, message: str) -> None:
        errors.append({"code": code, "message": message})

    def warn(code: str, message: str) -> None:
        warnings.append({"code": code, "message": message})

    if not isinstance(data, dict):
        err("ROOT", "JSON root must be an object")
        return {"ok": False, "errors": errors, "warnings": warnings}

    if data.get("schema_version") != "1.0":
        err("VERSION", "schema_version must be '1.0'")

    project = data.get("project")
    if not isinstance(project, dict):
        err("PROJECT", "project must be an object")
        project = {}
    for key in ("title", "platform", "audience"):
        if not isinstance(project.get(key), str) or not project[key].strip():
            err("PROJECT_FIELD", f"project.{key} must be a non-empty string")
    if not isinstance(project.get("goal"), str) or project.get("goal") not in GOALS:
        err("PROJECT_GOAL", f"project.goal must be one of {sorted(GOALS)}")
    if not isinstance(project.get("claim_status"), str) or project.get("claim_status") not in STATUSES:
        err("FACT_STATUS", f"project.claim_status must be one of {sorted(STATUSES)}")
    if not isinstance(project.get("aspect_ratio"), str) or project.get("aspect_ratio") not in {"9:16", "16:9", "1:1", "4:5", "other"}:
        err("ASPECT", "project.aspect_ratio has an unsupported value")
    duration = project.get("duration_s")
    if not is_number(duration) or duration <= 0:
        err("DURATION", "project.duration_s must be a positive finite number")
        duration = None

    beats = data.get("beats")
    if not isinstance(beats, list) or len(beats) < 2:
        err("BEATS", "beats must contain at least two items")
        beats = []

    ids = set()
    prev_end = None
    has_payoff = False
    for i, beat in enumerate(beats):
        prefix = f"beats[{i}]"
        if not isinstance(beat, dict):
            err("BEAT_TYPE", f"{prefix} must be an object")
            continue
        for key in REQUIRED_BEAT:
            if key not in beat:
                err("MISSING_FIELD", f"{prefix}.{key} is missing")
        bid = beat.get("id")
        if not isinstance(bid, str) or not bid.strip():
            err("BEAT_ID", f"{prefix}.id must be a non-empty string")
        elif bid in ids:
            err("DUPLICATE_ID", f"{prefix}.id = {bid!r} is duplicated")
        else:
            ids.add(bid)
        role = beat.get("role")
        if not isinstance(role, str) or role not in ROLES:
            err("ROLE", f"{prefix}.role must be one of {sorted(ROLES)}")
        if role == "payoff":
            has_payoff = True
        if i == 0 and role != "hook":
            err("HOOK", "first beat must have role 'hook'")
        start, end = beat.get("start_s"), beat.get("end_s")
        valid_times = is_number(start) and is_number(end)
        if not valid_times or start < 0 or end <= start:
            err("BEAT_TIME", f"{prefix} must have 0 <= start_s < end_s (finite)")
        else:
            if i == 0 and abs(start) > EPS:
                err("START", "first beat should start at 0 seconds")
            if prev_end is not None:
                delta = start - prev_end
                if delta < -EPS:
                    err("OVERLAP", f"{prefix} overlaps previous beat by {-delta:.2f}s")
                elif delta > EPS:
                    err("GAP", f"{prefix} leaves an unexplained {delta:.2f}s gap")
            prev_end = end
            if end - start > 12:
                warn("LONG_BEAT", f"{prefix} lasts {end - start:.1f}s: verify real change inside the shot")
            speech = beat.get("speech", "")
            if isinstance(speech, str) and speech:
                cn_count = len(re.findall(r"[\u4e00-\u9fff]", speech))
                if cn_count and cn_count / (end - start) > 6.3:
                    warn("SPEECH_DENSITY", f"{prefix} has ~{cn_count / (end - start):.1f} Hanzi/s: read aloud and retime")
            if role == "hook" and i == 0 and end - start > 5:
                warn("LATE_HOOK", f"hook beat lasts {end-start:.1f}s: confirm value lands near the opening")
        for field in ("information_gain", "visual", "cut", "asset", "retention_intent"):
            v = beat.get(field)
            if not isinstance(v, str) or not v.strip():
                err("EMPTY_BEAT_FIELD", f"{prefix}.{field} must be a non-empty string")
        for field in ("speech", "on_screen_text", "sound"):
            if field in beat and not isinstance(beat[field], str):
                err("INVALID_TEXT", f"{prefix}.{field} must be a string")
        for key, value in beat.items():
            if isinstance(value, str) and DUMMY.search(value):
                err("PLACEHOLDER", f"{prefix}.{key} still contains a placeholder")

    if not has_payoff:
        err("NO_PAYOFF", "at least one beat must have role 'payoff'")
    if duration is not None and prev_end is not None and abs(prev_end - duration) > EPS:
        err("TOTAL", f"timeline ends at {prev_end:.2f}s, but project.duration_s is {duration:.2f}s")

    promises = data.get("promises")
    if not isinstance(promises, list) or not promises:
        err("PROMISES", "promises must be a non-empty array")
        promises = []
    seen_promises = set()
    for i, p in enumerate(promises):
        pre = f"promises[{i}]"
        if not isinstance(p, dict):
            err("PROMISE_TYPE", f"{pre} must be an object")
            continue
        pid = p.get("id")
        if not isinstance(pid, str) or not pid.strip():
            err("PROMISE_ID", f"{pre}.id must be a non-empty string")
        elif pid in seen_promises:
            err("PROMISE_DUP", f"{pre}.id is repeated")
        else:
            seen_promises.add(pid)
        for field in ("promise", "answer"):
            val = p.get(field)
            if not isinstance(val, str) or not val.strip() or DUMMY.search(val):
                err("PROMISE_CONTENT", f"{pre}.{field} must be a real non-placeholder string")
        opened, resolved = p.get("opened_s"), p.get("resolved_s")
        if (not is_number(opened) or not is_number(resolved) or opened < 0 or resolved < opened
                or (duration is not None and resolved > duration + EPS)):
            err("PROMISE_TIME", f"{pre} needs 0 <= opened_s <= resolved_s <= duration_s")
        elif beats and is_number(resolved):
            # Resolution must fall in a beat that actually delivers information.
            matching = [b for b in beats if isinstance(b, dict)
                        and is_number(b.get("start_s")) and is_number(b.get("end_s"))
                        and b["start_s"] - EPS <= resolved <= b["end_s"] + EPS]
            if not matching:
                warn("PROMISE_PLACEMENT", f"{pre} resolves outside a timed beat")

    qa = data.get("qa")
    if not isinstance(qa, dict):
        err("QA", "qa must be an object")
    else:
        for field in ("primary_metric", "observation_hypothesis"):
            if not isinstance(qa.get(field), str) or not qa[field].strip():
                err("QA_FIELD", f"qa.{field} must be a non-empty string")
        if any(k in qa for k in ("predicted_completion_pct", "guaranteed_views")):
            err("FALSE_FORECAST", "do not include fake retention predictions or guaranteed view counts")

    return {"ok": len(errors) == 0, "errors": errors, "warnings": warnings,
            "summary": {"beat_count": len(beats), "planned_duration_s": duration}}


def reject_dupes(pairs: list[tuple]) -> dict:
    result = {}
    for k, v in pairs:
        if k in result:
            raise ValueError(f"Duplicate JSON key: {k}")
        result[k] = v
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("shotlist", type=Path, help="JSON shot list")
    parser.add_argument("--json", action="store_true", help="machine readable report")
    args = parser.parse_args()
    try:
        data = json.loads(args.shotlist.read_text(encoding="utf-8-sig"), object_pairs_hook=reject_dupes)
    except (OSError, ValueError, UnicodeError) as exc:
        print(f"INPUT_ERROR: {exc}", file=sys.stderr)
        return 2
    report = validate(data)
    if args.json:
        print(json.dumps(report, ensure_ascii=False, indent=2))
    else:
        print(f"{'PASS' if report['ok'] else 'FAIL'} | beats={report['summary']['beat_count']} | "
              f"errors={len(report['errors'])} | warnings={len(report['warnings'])}")
        for item in report["errors"]:
            print(f"ERROR {item['code']}: {item['message']}")
        for item in report["warnings"]:
            print(f"WARN {item['code']}: {item['message']}")
        print("Note: structural preflight only; not a real audience-retention prediction.")
    return 0 if report["ok"] else 1


if __name__ == "__main__":
    sys.exit(main())
