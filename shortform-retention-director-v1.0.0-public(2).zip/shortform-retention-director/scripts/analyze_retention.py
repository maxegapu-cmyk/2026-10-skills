#!/usr/bin/env python3
"""Describe retention curve patterns without inventing attribution or certainty.

CSV format: second,retention_pct. The percentages must use a known,
consistent denominator and come from the same reporting context.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import sys
from pathlib import Path


def load_curve(path: Path) -> list[tuple[float, float]]:
    with path.open("r", encoding="utf-8-sig", newline="") as stream:
        reader = csv.DictReader(stream)
        if not reader.fieldnames or not {"second", "retention_pct"} <= set(reader.fieldnames):
            raise ValueError("CSV needs headers: second,retention_pct")
        rows = []
        for line, record in enumerate(reader, start=2):
            try:
                t = float(record["second"])
                y = float(record["retention_pct"])
            except (ValueError, TypeError) as exc:
                raise ValueError(f"line {line}: expected numeric second/retention_pct") from exc
            if not math.isfinite(t) or not math.isfinite(y) or t < 0 or y < 0:
                raise ValueError(f"line {line}: negative or non-finite values are not permitted")
            if rows and t <= rows[-1][0]:
                raise ValueError(f"line {line}: seconds must be strictly increasing")
            rows.append((t, y))
    if len(rows) < 3:
        raise ValueError("at least 3 timed retention points are required")
    if rows[0][0] > 0.05:
        raise ValueError("curve must begin at second 0")
    return rows


def sample(curve: list[tuple[float, float]], t: float) -> float:
    if t < curve[0][0] - 1e-9 or t > curve[-1][0] + 1e-9:
        raise ValueError("sample time is out of range")
    for i in range(1, len(curve)):
        x0, y0 = curve[i - 1]
        x1, y1 = curve[i]
        if t <= x1:
            fraction = (t - x0) / (x1 - x0)
            return y0 + (y1 - y0) * fraction
    return curve[-1][1]


def analyze(curve: list[tuple[float, float]]) -> dict:
    length = curve[-1][0]
    intervals = []
    for (t0, y0), (t1, y1) in zip(curve, curve[1:]):
        intervals.append({"start_s": t0, "end_s": t1,
                          "delta_points": round(y1 - y0, 3),
                          "rate_points_per_s": round((y1 - y0) / (t1 - t0), 3)})
    dips = sorted((i for i in intervals if i["delta_points"] < 0),
                  key=lambda i: (i["rate_points_per_s"], i["start_s"]))[:3]
    rises = sorted((i for i in intervals if i["delta_points"] > 0),
                   key=lambda i: (-i["rate_points_per_s"], i["start_s"]))[:2]
    anchors = {f"{int(frac * 100)}pct_time": round(sample(curve, length * frac), 3)
               for frac in (0.25, 0.5, 0.75, 1.0)}
    return {
        "end_s": length, "points": len(curve), "curve_anchors_pct": anchors,
        "steepest_decline_intervals": dips, "steepest_rise_intervals": rises,
        "interpretation": "Descriptive pattern only. A drop is not proof of a specific editing cause. "
                          "A rise may indicate replay, skipping, sampling, or measurement effects. "
                          "Never treat these percentages as unique-viewer survival without platform definition."
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("csv", type=Path)
    parser.add_argument("--baseline", type=Path, help="matched definition and duration baseline CSV")
    parser.add_argument("--confirm-same-definition", action="store_true", help="affirm identical denominator, reporting basis and conditions")
    parser.add_argument("--json", action="store_true", help="output JSON instead of text")
    args = parser.parse_args()
    if args.baseline and not args.confirm_same_definition:
        print("INPUT_ERROR: baseline comparison requires --confirm-same-definition", file=sys.stderr)
        return 2
    try:
        curve = load_curve(args.csv)
        report = {"file": args.csv.name, "analysis": analyze(curve)}
        if args.baseline:
            base = load_curve(args.baseline)
            if abs(base[-1][0] - curve[-1][0]) > 0.051:
                raise ValueError("baseline and candidate must have the same video duration")
            baseline_data = analyze(base)
            report["baseline"] = {"file": args.baseline.name, "analysis": baseline_data}
            report["anchor_point_difference_candidate_minus_baseline"] = {
                k: round(v - baseline_data["curve_anchors_pct"][k], 3)
                for k, v in report["analysis"]["curve_anchors_pct"].items()
            }
            report["comparison_warning"] = ("Comparability is user-confirmed, not machine-verified. "
                                            "These are descriptive differences, not causal impact estimates.")
    except (ValueError, OSError, UnicodeError) as exc:
        print(f"INPUT_ERROR: {exc}", file=sys.stderr)
        return 2
    if args.json:
        print(json.dumps(report, ensure_ascii=False, indent=2))
    else:
        data = report["analysis"]
        print(f"Curve: {report['file']} | duration={data['end_s']:.1f}s | samples={data['points']}")
        print("Points at 25%/50%/75%/100% of time:", data["curve_anchors_pct"])
        print("Steepest declines (descriptive, not causal):")
        for d in data["steepest_decline_intervals"]:
            print(f"  {d['start_s']:.1f}-{d['end_s']:.1f}s: {d['delta_points']:+.2f} pct points "
                  f"({d['rate_points_per_s']:+.2f}/s)")
        if "baseline" in report:
            print("Candidate minus baseline at matched anchors:",
                  report["anchor_point_difference_candidate_minus_baseline"])
            print(report["comparison_warning"])
        print(data["interpretation"])
    return 0


if __name__ == "__main__":
    sys.exit(main())
