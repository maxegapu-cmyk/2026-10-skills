# 公开参考与原创边界（查阅于 2026-10-13）

本包是独立编写的通用编导工具。公开资料用于验证 Agent Skills 结构、创意工作的常用考虑项以及平台能提供哪些指标；**没有复制任何第三方 Skill 的源码、提示词或范文**。下面的 URL 是参考，不是本包的依赖；未将参考仓库打包、修改或再分发。

## 格式权威资料

- Agent Skills specification：https://agentskills.io/specification （必备 SKILL.md YAML frontmatter、相对路径与按需加载资源）
- Agent Skills GitHub：https://github.com/agentskills/agentskills/blob/main/docs/specification.mdx

## 官方平台资料

- YouTube Help — key moments for audience retention：https://support.google.com/youtube/answer/9314415 （平稳、下降、峰值与重看；具体数据可见性有限制）
- YouTube Help — Understand your YouTube content performance：https://support.google.com/youtube/answer/12220281 （Views、Engaged views、Stayed to watch、平均观看时间的差异；需按最新说明使用）
- TikTok for Business — Creative Guidance：https://ads.tiktok.com/business/creativecenter/quicktok/online/tiktok_creative_accelerator/pc/en （广告创意中的 hook、body、close 与受众语境；不是自然分发算法规定）
- TikTok for Business — 5 Creative tips：https://ads.tiktok.com/business/creativecenter/quicktok/online/5_creative_tips/pc/en （广告语境建议，官方也强调不是绝对处方）

## 检索到的公开同类 Skill（仅用于能力覆盖对照）

- https://github.com/astDeniss/business-skills/blob/main/short-form-video/SKILL.md （脚本、平台、拍摄与脚本模板范畴）
- https://github.com/Glad-Labs/poindexter/blob/main/src/cofounder_agent/skills/content/video-director/SKILL.md （短片逐镜导演与自审范畴）
- https://github.com/social-media-skills/skills/blob/main/skills/short-form-video-script/SKILL.md （短视频脚本与观看回报范畴）

不同开源项目的许可可能不同。本包只借鉴一般的问题领域，不复制文本；不能仅因内容在 GitHub 上就当作没有版权。

## 可靠性备注

官方 TikTok 建议多来自广告创意而非自然内容的受控因果实验；本包不会把广告建议误写为平台自然推荐硬规则。YouTube 数据术语会更新，复盘时优先核对用户所在产品的实时字段说明。AI 能做计划与程序化校验，无法在发布前保证用户留存。
