# 短视频编导与留存工作台 / Shortform Retention Director

**v1.0.0 · 可公开分发 · MIT · 无付费依赖**

一个遵循 Agent Skills 通用格式的中文短视频编导 Skill，服务抖音、快手、小红书、视频号、B 站、YouTube Shorts、TikTok、Reels，以及需要短视频导演方案的其他场景。

它不是「告诉你哪个关键词必火」的玄学提示词。它提供六件真实可交付的东西：明确观看回报、设计两种开头、按时间轴写可拍镜头、控制声音/镜头/信息节奏、做拍摄剪辑执行单、用真实数据定位潜在留存断点。

## 安装

解压后的顶层目录必须保留名字 `shortform-retention-director/`，其中要直接有 `SKILL.md`。把这个文件夹放到你的 Agent Skills 目录，例如：

- **Codex 项目级**：`项目根目录/.agents/skills/shortform-retention-director/`。
- **Claude Code 项目级**：`项目根目录/.claude/skills/shortform-retention-director/`。
- **其他兼容产品**：放到对应产品支持的 Skills 目录，或按其导入流程导入包含单一顶层文件夹的 ZIP。

目录与路径须按你实际使用的客户端版本核对。不需要额外安装 Python 包；如果只使用编导提示词和模板，甚至不需要 Python。

## 怎么叫它干活

在支持 Skills 的智能体中直接说：

> 用 shortform-retention-director，把「一个人用手机拍 30 秒解释为什么硬盘复制不等于备份」做成一条竖屏短视频。我只有手机、桌面和电脑。给逐秒台词、镜头、音乐、字幕、物料表，先做最能执行的版本。

> 用 shortform-retention-director 重写我的 45 秒口播草稿，保留事实，找出中段最拖节奏的三处，并给两个有实质差别的开头。不要编造留存数据。

> 用 shortform-retention-director 分析这条视频的数据。我会给出平台定义、同口径历史基线、视频逐镜时间轴。请分开描述事实、可能原因和要验证的实验。

## 可独立运行的脚本

```bash
# 从解压后的 skill 根目录执行
python scripts/validate_shotlist.py examples/sample-shotlist.json

# 给出真实 CSV 时可做描述性诊断；此处 CSV 是虚构演示数据，不代表实测结果
python scripts/analyze_retention.py examples/sample-retention.csv

# 同定义、同分母、同长度的两条曲线才允许作描述性比较
python scripts/analyze_retention.py examples/sample-retention.csv \
  --baseline examples/sample-retention-baseline.csv --confirm-same-definition

# 质量回归测试
python -m unittest discover -s tests -v
```

### 数据分析的输入

`CSV` 需两列：`second,retention_pct`。留存率来自平台导出与官方分母定义，本脚本不推算未知观看人群、不模拟真实平台分发，不输出「预测完播率」。允许曲线值超过 100% 以容纳重复观看等情形，结果始终是曲线描述，不是观看人数生存概率。

`JSON` 格式在 `assets/shotlist.schema.json`；脚本另检查时间轴、承诺兑现、字段占位和口播过密提醒。程序化 PASS 只表示结构上基本可用，**不是故事好、画面好或者真的能留住观众**。

## 文件结构

```text
shortform-retention-director/
  SKILL.md                         # 唯一技能入口
  README.md                        # 安装和使用
  LICENSE
  references/
    directing.md                   # 情绪、镜头、声音节奏
    formats.md                     # 不同叙事类型
    platforms.md                   # 平台差异
    quality.md                     # 质检红线与审核量表
    measurement.md                 # 留存口径/诊断/对照试验
    sources.md                     # 公开依据与原创边界
  assets/
    brief.template.md              # 快速创作简报
    delivery.template.md           # 完整导演交付模板
    shotlist.schema.json           # 结构化分镜数据格式
  examples/
    sample-shotlist.json
    sample-director-output.md       # 完整实操示例
    sample-retention.csv           # 纯演示，不是平台实测
    sample-retention-baseline.csv  # 纯演示，不是平台实测
  scripts/
    validate_shotlist.py           # 无第三方依赖
    analyze_retention.py           # 无第三方依赖
  tests/
    test_skill.py                  # 正常/异常/边界回归
```

## 来源与版权边界

本包为原创实现；参考的是公开的通用 Agent Skills 规范、YouTube 和 TikTok 官方创意/分析资料、GitHub 上若干独立 Skill 的**能力范围**，没有搬运它们的文本、代码或结构。公开参考完整列在 `references/sources.md`。可以按 MIT 条款分享或修改；对未授权的图片、音频和视频素材并不自动获得使用权。

## 声明

- 设计层能控制节奏变量与镜头方案，不能保证观众留存或流量。
- 本包没有使用者或频道的真实 A/B 测试结果，因此不声称达到某个留存数字。
- 包内 CSV 属于自造的数学测试样本，不能引用为运营案例。
- 官方的平台限制、报表术语、音乐许可会变化，发布前核实适用版本。
