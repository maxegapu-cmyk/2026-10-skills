"""Run: python -m unittest discover -s tests -v"""
from __future__ import annotations

import copy
import importlib.util
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def load_module(name: str, file: str):
    spec = importlib.util.spec_from_file_location(name, ROOT / "scripts" / file)
    module = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    spec.loader.exec_module(module)
    return module


validator = load_module("shot_validator", "validate_shotlist.py")
curve = load_module("curve_analyzer", "analyze_retention.py")
SAMPLE = json.loads((ROOT / "examples" / "sample-shotlist.json").read_text(encoding="utf-8"))


class ShotListTests(unittest.TestCase):
    def test_known_good_sample(self):
        result = validator.validate(SAMPLE)
        self.assertTrue(result["ok"], result["errors"])
        self.assertEqual(result["summary"]["beat_count"], 6)

    def check_error(self, doc, code):
        result = validator.validate(doc)
        self.assertFalse(result["ok"])
        self.assertIn(code, [item["code"] for item in result["errors"]])

    def test_wrong_duration(self):
        doc = copy.deepcopy(SAMPLE)
        doc["project"]["duration_s"] = 40
        self.check_error(doc, "TOTAL")

    def test_overlap(self):
        doc = copy.deepcopy(SAMPLE)
        doc["beats"][1]["start_s"] = 2
        self.check_error(doc, "OVERLAP")

    def test_gap(self):
        doc = copy.deepcopy(SAMPLE)
        doc["beats"][1]["start_s"] = 4
        self.check_error(doc, "GAP")

    def test_missing_payoff(self):
        doc = copy.deepcopy(SAMPLE)
        doc["beats"][4]["role"] = "development"
        self.check_error(doc, "NO_PAYOFF")

    def test_unresolved_promise(self):
        doc = copy.deepcopy(SAMPLE)
        doc["promises"][0]["resolved_s"] = 31
        self.check_error(doc, "PROMISE_TIME")

    def test_placeholder(self):
        doc = copy.deepcopy(SAMPLE)
        doc["beats"][0]["visual"] = "TODO"
        self.check_error(doc, "PLACEHOLDER")

    def test_fabricated_forecast(self):
        doc = copy.deepcopy(SAMPLE)
        doc["qa"]["predicted_completion_pct"] = 99
        self.check_error(doc, "FALSE_FORECAST")

    def test_duplicate_id(self):
        doc = copy.deepcopy(SAMPLE)
        doc["beats"][1]["id"] = doc["beats"][0]["id"]
        self.check_error(doc, "DUPLICATE_ID")

    def test_invalid_numeric(self):
        doc = copy.deepcopy(SAMPLE)
        doc["beats"][1]["start_s"] = float("nan")
        self.check_error(doc, "BEAT_TIME")

    def test_still_allows_long_shot_if_explained(self):
        doc = copy.deepcopy(SAMPLE)
        # Merge B03 into 14s visual hold and keep timeline consistent.
        doc["beats"][1]["end_s"] = 16
        doc["beats"].pop(2)
        doc["beats"][2]["start_s"] = 16
        result = validator.validate(doc)
        self.assertTrue(result["ok"], result["errors"])
        self.assertIn("LONG_BEAT", [w["code"] for w in result["warnings"]])


class CurveTests(unittest.TestCase):
    def test_known_good_curve(self):
        data = curve.load_curve(ROOT / "examples" / "sample-retention.csv")
        result = curve.analyze(data)
        self.assertEqual(result["curve_anchors_pct"]["100pct_time"], 61)
        self.assertGreater(len(result["steepest_decline_intervals"]), 0)

    def test_may_exceed_100_percent(self):
        result = curve.analyze([(0, 100), (3, 108), (6, 95)])
        self.assertEqual(result["curve_anchors_pct"]["50pct_time"], 108)
        self.assertEqual(len(result["steepest_rise_intervals"]), 1)

    def test_reject_unsorted_curve(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "bad.csv"
            p.write_text("second,retention_pct\n0,100\n3,88\n2,80\n", encoding="utf-8")
            with self.assertRaises(ValueError):
                curve.load_curve(p)

    def test_reject_wrong_columns(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "bad.csv"
            p.write_text("time,value\n0,100\n1,90\n2,80\n", encoding="utf-8")
            with self.assertRaises(ValueError):
                curve.load_curve(p)

    def test_reject_empty_csv(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "empty.csv"
            p.write_text("second,retention_pct\n", encoding="utf-8")
            with self.assertRaises(ValueError):
                curve.load_curve(p)

    def test_cli_comparison_requires_confirmation(self):
        cmd = [sys.executable, str(ROOT / "scripts" / "analyze_retention.py"),
               str(ROOT / "examples" / "sample-retention.csv"),
               "--baseline", str(ROOT / "examples" / "sample-retention-baseline.csv")]
        res = subprocess.run(cmd, text=True, capture_output=True, check=False)
        self.assertEqual(res.returncode, 2)
        self.assertIn("--confirm-same-definition", res.stderr)

    def test_cli_comparison_works_with_confirmation(self):
        cmd = [sys.executable, str(ROOT / "scripts" / "analyze_retention.py"),
               str(ROOT / "examples" / "sample-retention.csv"),
               "--baseline", str(ROOT / "examples" / "sample-retention-baseline.csv"),
               "--confirm-same-definition", "--json"]
        res = subprocess.run(cmd, text=True, capture_output=True, check=False)
        self.assertEqual(res.returncode, 0, res.stderr)
        self.assertIn("anchor_point_difference_candidate_minus_baseline", json.loads(res.stdout))

    def test_cli_invalid_json(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "bad.json"
            p.write_text('{"a":2, "a":3}', encoding="utf-8")
            cmd = [sys.executable, str(ROOT / "scripts" / "validate_shotlist.py"), str(p)]
            res = subprocess.run(cmd, text=True, capture_output=True, check=False)
            self.assertEqual(res.returncode, 2)
            self.assertIn("Duplicate JSON key", res.stderr)


if __name__ == "__main__":
    unittest.main()
