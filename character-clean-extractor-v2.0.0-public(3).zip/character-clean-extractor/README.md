# Character Clean Extractor 2.0.0 (Public Clean Edition)

**人物身份、服装与跨视图一致性 Skill**。用户用一句“把图中左边那位人物提取出来，后续保持一致”，即可启动证据记录 → 主体锁定 → 人物档案 → 分步生图提示词 → 审图和局部修复。核心依赖是 Agent 的视觉理解及可选的图像编辑工具，本包本身不包含生图模型、私有角色素材或 API 密钥。

## 安装

解压后保留 `character-clean-extractor/` 完整文件夹，将该文件夹放入 Agent Skills 客户端支持的 skills 目录，如支持 `.agents/skills/` 的项目可放到 `.agents/skills/character-clean-extractor/`。使客户端重新扫描 Skills；在会话中上传参考图片并说“使用 character-clean-extractor 提取这张图的主要人物，出身份板”。不同客户端扫描目录不同，以本机客户端文档为准。

Python 可选，离线工具运行无需联网：

```bash
python scripts/charlock.py validate assets/example-profile.json
python scripts/charlock.py prompt assets/example-profile.json --mode sheet
python scripts/charlock.py compare assets/example-profile.json tests/fixtures/candidate-pass.json
python -m unittest discover -s tests -v
```

`compare` 的 0=PASS、3=REVIEW、4=FAIL；`validate` 不合规则退出 2；这检查的是录入的观察记录，不是直接比图像像素。

## 使用例句

- “图里有三个人，只提取右边穿红外套那一位，其他人全部不要。”
- “保留这个游戏人物的脸型、盔甲和美术风格，分别制作正/左侧/背面；看不到的地方明确标注。”
- “只把图 2 的大衣换给图 1 的人物，图 1 的脸、头发、身材、姿势都不动。”
- “对比昨天的 5 张角色图，找出明显变脸、袖章跑边、衣服错层，并给局部修复指令。”
- “只做文字角色档案和可复制提示词，不实际生图。”

## 从公开 1.0 基线到 2.0 的增强

保留基线用途：指定人物→提取其身份和服饰特征→整理可复用角色资产，避免多人串脸、遮挡处乱补。新增：有来源的逐属性证据状态、来源权责冲突排查、镜像左右校准、服装拓扑及层次、结构化人物档案、可执行无依赖档案校验器/提示词编译器/文本比对、手工视觉测试矩阵、只修失败点策略、显式能力边界。

**来源说明**：本压缩包以已知的公开版 1.0 功能定义为升级目标进行独立实现。因未取得 1.0 原 ZIP 字节，无法声称基于旧文件做逐行补丁，也不假装进行了 1.0/2.0 图像 A/B 对照。它不引用任何个人内部制作包或私有提示词。未包含演示用真实人物照片。

## 公开资料（用于技术方向参照，并非拷贝第三方代码/模板）

- Agent Skills 规范： https://agentskills.io/specification （目录、`SKILL.md` YAML metadata、渐进式加载）
- GenielabsOpenSource character-consistency： https://github.com/GenielabsOpenSource/style-consistency-ai/tree/main/skills/character-consistency （从最低成本局部修复升级到更多参考/模型的策略）
- TencentARC PhotoMaker V2： https://github.com/TencentARC/PhotoMaker （多图身份条件与结合其他控制方法）
- ToTheBeginning PuLID： https://github.com/ToTheBeginning/PuLID （ID定制与参考约束）
- cubiq IP-Adapter ComfyUI： https://github.com/cubiq/ComfyUI_IPAdapter_plus （图片条件；该仓库 2025 年宣布维护模式）

以上外部项目各有自己的许可证、适配范围与限制。本包不打包它们的源代码、模型权重、图像、文本模板或受保护内容。

## 安全与局限

确保有权处理和分享人物图像；不要未经授权上传敏感肖像或私密照片到第三方模型。这里的“人物身份”仅指用于画面连续性的可见外貌特征，不是现实世界身份鉴定，不识别真实姓名。若参考仅含低分辨率单张照片，强制背面和多角度一致性无法得到事实保证。无图工具时只有提示词与文本档案，没有生成图。完整验证见 `TEST_REPORT.md` 和 `references/test-matrix.md`。
