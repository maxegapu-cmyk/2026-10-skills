#!/usr/bin/env python3
"""Character Clean Extractor v2 public-clean: record validation, text-field
comparisons and prompt compilation only. NO pixel recognition or generation.
Standard library only, Python >=3.9.
"""
import argparse
import copy
import json
import re
import sys
from pathlib import Path

VERSION = '2.0.0'
STATUSES = {'OBSERVED', 'INFERRED', 'UNKNOWN'}
VIEWS = {'front', 'three_quarter', 'subject_left', 'subject_right', 'back', 'mixed', 'unknown'}
SIDES = {'subject_left', 'subject_right', 'image_left', 'image_right', 'unknown', 'not_applicable'}
SCOPES = {'identity', 'outfit', 'style', 'temporary'}
CONF = {'high', 'medium', 'low', 'unknown'}
MODES = {'extract', 'sheet', 'wardrobe', 'transfer', 'audit', 'repair'}
FEATURE_RE = re.compile(r'^[a-z][a-z0-9_.-]*$')


def read_json(path):
    with open(path, 'r', encoding='utf-8') as file:
        return json.load(file)


def write_json(path, content):
    with open(path, 'w', encoding='utf-8') as file:
        json.dump(content, file, ensure_ascii=False, indent=2)
        file.write('\n')


def validate(data):
    errors = []
    warnings = []
    if not isinstance(data, dict):
        return ['profile must be a JSON object'], warnings
    if data.get('format_version') != VERSION:
        errors.append('format_version must be 2.0.0')
    subject = data.get('subject')
    if not isinstance(subject, dict) or not isinstance(subject.get('id'), str) or not subject['id'].strip():
        errors.append('subject.id must be a nonempty string')
    if not isinstance(subject, dict) or not isinstance(subject.get('selector'), str) or not subject['selector'].strip():
        errors.append('subject.selector must identify the target person')
    refs = data.get('references')
    if not isinstance(refs, list):
        errors.append('references must be a list')
        refs = []
    reference_ids = set()
    for i, ref in enumerate(refs):
        if not isinstance(ref, dict) or not isinstance(ref.get('id'), str) or not ref['id']:
            errors.append('references[%s] missing id' % i)
            continue
        if ref['id'] in reference_ids:
            errors.append('duplicate reference id: ' + ref['id'])
        reference_ids.add(ref['id'])
        roles = ref.get('roles')
        if not isinstance(roles, list) or not roles or any(not isinstance(role, str) or role not in {'identity','outfit','pose','style','context'} for role in roles):
            errors.append('references[%s].roles invalid' % i)
        if not isinstance(ref.get('locator'), str) or not ref['locator'].strip():
            errors.append('references[%s].locator missing' % i)
    rows = data.get('observations')
    if not isinstance(rows, list):
        errors.append('observations must be a list')
        rows = []
    features = {}
    for i, row in enumerate(rows):
        at = 'observations[%s]' % i
        if not isinstance(row, dict):
            errors.append(at + ' must be an object')
            continue
        feature = row.get('feature')
        if not isinstance(feature, str) or not FEATURE_RE.fullmatch(feature):
            errors.append(at + '.feature must be dotted lowercase identifier')
            continue
        if feature in features:
            errors.append('duplicate observation feature: ' + feature)
        features[feature] = row
        status = row.get('status')
        if not isinstance(status, str) or status not in STATUSES:
            errors.append(at + '.status invalid')
        value = row.get('value')
        if not isinstance(value, str):
            errors.append(at + '.value must be a string')
        elif status == 'OBSERVED' and not value.strip():
            errors.append(at + '.value required when observed')
        elif status == 'UNKNOWN' and value.strip():
            errors.append(at + '.value must be empty when unknown')
        ids = row.get('source_ids')
        if not isinstance(ids, list) or any(not isinstance(ref_id, str) for ref_id in ids):
            errors.append(at + '.source_ids must be a list of ids')
            ids = []
        for ref_id in ids:
            if not isinstance(ref_id, str):
                continue
            if ref_id not in reference_ids:
                errors.append(at + '.source_ids refers to undeclared id: ' + ref_id)
        if status == 'OBSERVED' and not ids:
            errors.append(at + '.OBSERVED requires at least one source')
        if not isinstance(row.get('view'), str) or row.get('view') not in VIEWS:
            errors.append(at + '.view invalid')
        if not isinstance(row.get('side'), str) or row.get('side') not in SIDES:
            errors.append(at + '.side invalid')
        if not isinstance(row.get('scope'), str) or row.get('scope') not in SCOPES:
            errors.append(at + '.scope invalid')
        if not isinstance(row.get('confidence'), str) or row.get('confidence') not in CONF:
            errors.append(at + '.confidence invalid')
        if not isinstance(row.get('region'), str):
            errors.append(at + '.region missing')
        if status == 'OBSERVED' and row.get('confidence') == 'low':
            warnings.append(feature + ': low confidence; verify before making a hard lock')
        if row.get('side') in {'image_left', 'image_right'} and row.get('view') == 'unknown':
            warnings.append(feature + ': image-side coordinate lacks a view; cannot assert person-side')
    locks = data.get('locks')
    if not isinstance(locks, dict):
        errors.append('locks must be an object')
        locks = {}
    seen_lock = {}
    for tier in ('hard', 'soft', 'mutable'):
        keys = locks.get(tier)
        if not isinstance(keys, list):
            errors.append('locks.' + tier + ' must be a list')
            continue
        for feature in keys:
            if not isinstance(feature, str):
                errors.append('locks.' + tier + ' contains non-string feature')
                continue
            if feature in seen_lock:
                errors.append(feature + ' appears in multiple lock groups')
            seen_lock[feature] = tier
            if feature not in features:
                errors.append('locks.' + tier + ' missing observation: ' + feature)
            elif tier == 'hard' and features[feature].get('status') != 'OBSERVED':
                errors.append('hard lock must have OBSERVED evidence: ' + feature)
            elif tier == 'hard' and features[feature].get('confidence') in ('low','unknown'):
                warnings.append('hard lock has weak confidence: ' + feature)
    if not refs:
        warnings.append('No original reference yet; profile is only a draft')
    if not rows:
        warnings.append('No observations yet; add image-grounded facts')
    return errors, warnings


def feature_rows(data):
    return {row['feature']: row for row in data['observations']}


def compare(base, candidate):
    base_errors, _ = validate(base)
    cand_errors, _ = validate(candidate)
    if base_errors or cand_errors:
        raise ValueError('Invalid profile(s): base=' + repr(base_errors) + ', candidate=' + repr(cand_errors))
    base_rows, candidate_rows = feature_rows(base), feature_rows(candidate)
    results = []
    priority = {'FAIL': 0, 'REVIEW': 1, 'PASS': 2}
    if base['subject']['id'] != candidate['subject']['id']:
        results.append({'feature': 'subject.id', 'tier': 'hard', 'status': 'FAIL',
                        'baseline': base['subject']['id'], 'candidate': candidate['subject']['id'],
                        'reason': 'Subject id differs; cannot compare as the same person'})
    for tier in ('hard', 'soft'):
        for key in base['locks'][tier]:
            original, newer = base_rows[key], candidate_rows.get(key)
            if newer is None or newer['status'] != 'OBSERVED' or newer['confidence'] == 'unknown':
                state, reason = 'REVIEW', 'Not independently observed in candidate'
            elif original['status'] != 'OBSERVED':
                state, reason = 'REVIEW', 'Baseline is not observed'
            elif original['side'] in ('subject_left', 'subject_right') and newer['side'] not in ('subject_left', 'subject_right'):
                state, reason = 'REVIEW', 'Candidate does not establish person-side location'
            elif original['value'] != newer['value'] or (original['side'] != newer['side']
                    and original['side'] in ('subject_left', 'subject_right')
                    and newer['side'] in ('subject_left', 'subject_right')):
                state = 'FAIL' if tier == 'hard' else 'REVIEW'
                reason = 'Recorded value or subject-side changed; visually confirm framing vs true drift'
            else:
                state, reason = 'PASS', 'Recorded textual feature agrees'
            results.append({'feature': key, 'tier': tier, 'status': state,
                            'baseline': original.get('value',''),
                            'candidate': newer.get('value','') if newer else None,
                            'reason': reason})
    if any(row['status'] == 'FAIL' for row in results):
        final = 'FAIL'
    elif not results or any(row['status'] == 'REVIEW' for row in results):
        final = 'REVIEW'
    else:
        final = 'PASS'
    results.sort(key=lambda row: (priority[row['status']], row['feature']))
    return {'result': final, 'scope': 'recorded textual observations only; NOT image similarity',
            'checks': results, 'baseline_subject': base['subject']['id'],
            'candidate_subject': candidate['subject']['id']}


def compile_prompt(data, mode):
    errors, _ = validate(data)
    if errors:
        raise ValueError('Invalid profile: ' + repr(errors))
    rows = feature_rows(data)
    hard = [rows[key] for key in data['locks']['hard']]
    soft = [rows[key] for key in data['locks']['soft'] if rows[key]['status'] == 'OBSERVED']
    unknown = [row['feature'] for row in data['observations'] if row['status'] == 'UNKNOWN']
    byrole = {role:[] for role in ('identity','outfit','pose','style','context')}
    for item in data['references']:
        for role in item['roles']:
            byrole[role].append(item['id'] + '=' + item['locator'])
    lines = [f'任务：{mode.upper()}；主体：{data["subject"]["selector"]}（项目ID：{data["subject"]["id"]}）。',
             '参考图身份与其他职责：' + '；'.join(role + ':' + ', '.join(values) for role,values in byrole.items() if values) + '。',
             '确认不可变的事实：' + ('；'.join(r['feature'] + '=' + r['value'] for r in hard) if hard else '尚无确认强锁，不得宣称身份验证通过') + '。']
    if soft:
        lines.append('次优先外观参考：' + '；'.join(r['feature'] + '=' + r['value'] for r in soft) + '。')
    if unknown:
        lines.append('原图未知（禁止伪称提取到）：' + '、'.join(unknown) + '。')
    actions = {
      'extract':'按原始身份图仅提取指定人物，隔离周围人和背景，默认中性光与自然表情；保持媒介质感。先记录可见证据，若需生成图则先出单张母图并验收。',
      'sheet':'先生成单张可审查母图，再分别处理正面、人物左侧与背面；侧背未看到的部位只作保守设计性补全并标注。不要一口气生成密集且人脸过小的九宫格。',
      'wardrobe':'只提取已见服装的单品、颜色、版型、纹理、接缝及层次；鞋、背面不在图内则保持未知。',
      'transfer':'目标身份图只供脸/人体/镜头，服装图只供服装；仅替换授权衣物，其他部位不可重新设计。',
      'audit':'与原始图对照：目标是否正确、五官与比例、服装层次、人物左右、风格是否漂移；没看到的给 REVIEW。',
      'repair':'仅修一个已确认的最高优先级错误；能遮罩则局部编辑，不把失败图升级为身份主参考。',
    }
    lines += [actions[mode], '左右以人物自身为准，镜像未证实则不绑定人物左右。',
              '交付：来源证据、观察/推断/未知、输出说明与逐项 PASS/REVIEW/FAIL。\n如没有可调用图像工具，只交付文本指令，不能声称已生图。']
    return '\n'.join(lines)


def main(argv=None):
    parser = argparse.ArgumentParser(description='Public character profile helper; no image recognition')
    parser.add_argument('--version', action='version', version=VERSION)
    commands = parser.add_subparsers(dest='command', required=True)
    p_init = commands.add_parser('init', help='create an editable draft profile')
    p_init.add_argument('destination')
    p_val = commands.add_parser('validate', help='validate structure and evidence links')
    p_val.add_argument('profile')
    p_cmp = commands.add_parser('compare', help='compare manually recorded observations (not pixels)')
    p_cmp.add_argument('baseline'); p_cmp.add_argument('candidate')
    p_comp = commands.add_parser('prompt', help='compile grounded text prompt')
    p_comp.add_argument('profile'); p_comp.add_argument('--mode', choices=sorted(MODES), default='extract')
    args = parser.parse_args(argv)
    try:
        if args.command == 'init':
            base = Path(__file__).resolve().parent.parent / 'assets' / 'profile-template.json'
            target = Path(args.destination)
            if target.exists():
                print('ERROR: destination exists; will not overwrite', file=sys.stderr)
                return 2
            target.parent.mkdir(parents=True, exist_ok=True)
            write_json(target, read_json(base))
            print('Draft created:', target)
            return 0
        if args.command == 'validate':
            errors, warnings = validate(read_json(args.profile))
            for msg in warnings: print('WARN:', msg)
            for msg in errors: print('ERROR:', msg)
            print('VALID' if not errors else 'INVALID')
            return 2 if errors else 0
        if args.command == 'compare':
            result = compare(read_json(args.baseline), read_json(args.candidate))
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return {'PASS':0,'REVIEW':3,'FAIL':4}[result['result']]
        if args.command == 'prompt':
            print(compile_prompt(read_json(args.profile), args.mode))
            return 0
    except (OSError, ValueError, json.JSONDecodeError, TypeError, KeyError) as error:
        print('ERROR:', error, file=sys.stderr)
        return 2
    return 2


if __name__ == '__main__':
    sys.exit(main())
