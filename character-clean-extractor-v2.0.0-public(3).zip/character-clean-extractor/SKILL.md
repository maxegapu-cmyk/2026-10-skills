---
name: character-clean-extractor
description: Extract a specified character from one or more reference images, preserve identity and outfit details, produce auditable character profiles or reference-sheet prompts, compare visual observations across outputs, and repair face, anatomy, clothing, or left-right drift. Use for 人物提取、人物一致性、服装提取、角色三视图、character extraction, identity sheets, continuity checks, and costume fidelity for photo, animation, comics or game images.
license: MIT
compatibility: Works in any Agent Skills-capable agent; Python 3.9+ only for optional offline profile checking and prompt compilation. Rendering needs an available image-editing/generation tool; no model or GPU bundled.
metadata:
  version: "2.0.0"
  release: "public-clean"
---

# Character Clean Extractor 2.0.0 | 人物提取与一致性

**目标**：从用户指定的参考人物中建立可核查的视觉档案，并最大限度减少后续脸、发型、体型、服装、左右不对称、画风和遮挡细节的漂移。可用于摄影、漫画、动画、游戏截图与已有角色设定。**本 Skill 不承诺像素级一致，也不会把从没看见的背面伪装成原始事实。**

## 触发和默认输出

收到“提取图里这个人物/让他一直是同一个人/提取衣服/做身份板/为什么人物每张都不像”时运行。若未指定模式，默认 `EXTRACT`；若用户明确要三视图，用 `SHEET`；只要衣服用 `WARDROBE`；不同画面比对用 `AUDIT`；需要改坏图用 `REPAIR`；指定换装用 `TRANSFER`。使用用户提供的参考图，不得从网上找相似人物替代。

| 模式 | 输入 | 交付 |
|---|---|---|
| `EXTRACT` | 原图+指定对象 | 主体指认、证据记录、可观察人物身份/服装描述、未知项、紧凑生成指令、结构化 `profile.json`（环境支持写文件时） |
| `SHEET` | 原图/档案 | 正面母图→可证据支持的侧面和背面→面部细节板的分步生成方案；若可用图像工具，实际生成并审图 |
| `WARDROBE` | 原图/指定服装 | 服装层次、结构、穿着状态、颜色/材料/配饰、不确定区与复现指令；不改变人物身份 |
| `TRANSFER` | 目标人物图+服装参考图 | 只转移服装，保留目标人物的身份/身体/姿态；先建立两张图的职责分配 |
| `AUDIT` | 已有档案+候选输出 | 视觉逐项对照，给 `PASS/REVIEW/FAIL`、差异定位和修复优先级 |
| `REPAIR` | 原始参考+失败输出 | 只改真正失败的区域/属性，不以失败图覆盖主参考 |

如果用户仅发一个多人图片且没有说是谁：用**相对定位**（左起第几位、衣服特征、画面位置）列候选，无法唯一指认才问一次；不猜真实姓名。单人图默认唯一主体。没有图像工具时仍完整交付可执行生成提示词和审查结果，但**不可声称生成了图片**。

## 先读资源

- 涉及多人/多图冲突/遮挡：`references/evidence-selection.md`
- 涉及人体特征/左右方向/多视角：`references/identity-and-geometry.md`
- 涉及服装、饰品、换装：`references/outfit-extraction.md`
- 涉及模型选择/生图执行：`references/rendering-and-prompts.md`
- 涉及坏图诊断：`references/continuity-review.md`
- 格式字段：`assets/profile-template.json`；中文示范：`assets/example-profile.json`

## 作业链（严格次序）

### 1. 定义主体与来源权属

写明目标是谁（不能把外形相似的人当同一人）。逐张分配用途：**身份参考 ID**、**服装参考 OUTFIT**、**姿势 POSE**、**风格 STYLE**、**环境 CONTEXT**。同图可拥有多个用途，但用户明确指定的职责优先；有冲突时以身份参考锁脸，服装参考不许提供新脸，风格参考不许提供新服装。多人需选定确切人框/位置，注明会干扰的相邻人物；不拼脸。

### 2. 采集证据，禁止神补

每个特征赋状态：`OBSERVED` 明确可见；`INFERRED` 基于图像合理但未直接看到，不能作为强锁；`UNKNOWN` 不可见或无法确认。颜色尽量写“深灰蓝、低饱和”等相对色；舞台灯光、滤镜、阴影下的准确 RGB 属未知。绝不凭一张近景编造身高、鞋履、背面图案或发际线。记录哪张图、哪个视角和可见区域支持结论。

先按身份、服装、风格、瞬时状态分别描述；不可把表情、光线或镜头畸变当成年龄/脸型固定特征。不能从照片可靠得知的真实姓名、族裔、体重、性格不写。

### 3. 固定最小辨识组合

使用少量但有区分度的正向锚点（通常 6–12 条），优先：整体头脸轮廓、眼距/眉眼关系、鼻和嘴关系、下颌、发际线/发束、面部不对称特征、颈肩和四肢轮廓、最有辨识度的衣服剪裁与标志。每一条应具可观察描述，避免“很漂亮/高级感”这种低信息词。仅锁定确实观察到的特征；看不到就写未知。

每次有条件变化（表情、角度、衣着、背景），保留原始身份依据，不让生成结果自发变成新身份权威。面部特写、全身、左右侧和背面分别需要不同证据覆盖；不能只凭微小头像重建衣物纹样。

### 4. 选择输出，默认小步执行

- `EXTRACT`：先输出人物可见事实卡、服装卡、未知项和可运行生成指令。若可调用图像编辑工具且用户需要视觉资产，生成**单个隔离人物母图**，再检查。
- `SHEET`：推荐先做一张中性正面全身/半身母图，然后逐视角复用**原始参考 + 已确认母图**。跨视角生成前建立“人物自身的左右”映射；背面未可见细节标记设计性补全，并先征求用户对重大设计决策的接受，或使用保守无标识补全且明确标注。
- `WARDROBE`：逐件提取内外层、连接、材质、纹理、穿法、配件；记录谁穿着，不把旁人的衣物算到目标身上。
- `TRANSFER`：只换指定服装区域，禁止用服装源照片覆盖目标脸/体型/姿势/背景；转移前写清保留项与替换项。
- `AUDIT`：从已有参考做人工视觉验收；可用 `scripts/charlock.py compare baseline.json candidate.json` 辅助**文本档案逐字段**检查，不能把它当成自动视觉相似度识别。
- `REPAIR`：先看高优先级错误（不是同一个人/错误对象 → 左右错位 → 衣服拓扑 → 比例 → 局部纹理），每轮只修一类最严重缺陷；先局部掩膜编辑、必要时重生成该视角，不盲目整张重绘。

### 5. 生成指令编排（精简有冲突检测）

输入 `源图职责 → 不可变的具体锚点 → 本轮唯一变动 → 几何/遮挡要求 → 明确未知及允许补全边界 → 交付视图`。同时包含“要什么”和“不能混进什么”，禁令限于已出现的失败类型；避免堆砌五十条否定词。长图版式角色板仍要先考虑每格像素是否足以看清脸、鞋、纹理：空间不够就分张输出，不追求花哨排版。

使用 `python scripts/charlock.py prompt assets/example-profile.json --mode sheet` 查看编译效果。细节模板在 `references/rendering-and-prompts.md`。

### 6. 验收、修复和交付

按照 `references/continuity-review.md` 做逐格检查：人是否正确，脸的相对几何有没有变化，发/身材/服装的层次与数量是否一致，衣物标志、饰物及左右是否对应，哪些未知被随意写死了。三态结果：

- **PASS**：所有本次可见、可核查的关键锁定项均匹配；其余未观察项明确标记，不能等同于无限制通过。
- **REVIEW**：关键部位遮挡/模糊，无法核验，或用户尚未确认的设计性补全。
- **FAIL**：一个确认的强锁冲突（如换脸、镜像纹身、衣领类别、服装层次不对或将旁人混入）。

交付顺序：①指定人物定位；②已观察的身份+服装精要；③未知/补全；④本轮结果或明确无法出图；⑤核验结论+单点修复建议。不要用没有做过的视觉测试声称“95%一致”。

## 可选离线脚本（Python 3.9+，无第三方依赖）

```bash
python scripts/charlock.py init /tmp/new-profile.json
python scripts/charlock.py validate assets/example-profile.json
python scripts/charlock.py prompt assets/example-profile.json --mode extract
python scripts/charlock.py compare assets/example-profile.json tests/fixtures/candidate-pass.json
python scripts/charlock.py compare assets/example-profile.json tests/fixtures/candidate-drift.json
python -m unittest discover -s tests -v
```

注意：`validate` 是结构与证据完整性检查；`compare` 是**人工观察记录的静态比对**，没有视觉模型，不能直接从图片识别五官，也不代替人工审图。工具报通过只是表示脚本预期逻辑通过。

## 不可违反

- 不从未知的背面“提取”徽记或材质；设计性补全要明确标识。
- 不将衣服参考中的另一个人当作目标本人，也不混用两人五官。
- 不把镜像自拍/相机视角中的观察左右未经校验就当做人物左右。
- 不因换衣、表情、年龄设定、光线变化而偷换身份与风格。
- 不自动发送、上传参考照片到第三方服务；尊重图片授权与人物隐私。
- 不伪称运行了图像模型、做过像素级识别、验收了未提供的图片。
