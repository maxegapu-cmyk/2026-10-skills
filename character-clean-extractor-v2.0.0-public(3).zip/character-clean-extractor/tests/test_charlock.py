import copy
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
import charlock


def fixture(filename):
    return json.loads((ROOT / filename).read_text(encoding='utf-8'))


class ValidationTests(unittest.TestCase):
    def setUp(self):
        self.base = fixture('assets/example-profile.json')

    def test_normal_profile_valid(self):
        errors, warns = charlock.validate(self.base)
        self.assertEqual(errors, [])
        self.assertEqual(warns, [])

    def test_template_is_valid_draft_with_warnings(self):
        profile = fixture('assets/profile-template.json')
        self.assertEqual(charlock.validate(profile)[0], [])
        self.assertTrue(charlock.validate(profile)[1])

    def test_unknown_value_must_be_empty(self):
        self.base['observations'][6]['value'] = 'invented backside logo'
        self.assertIn('value must be empty when unknown', ' '.join(charlock.validate(self.base)[0]))

    def test_observed_requires_real_reference_id(self):
        self.base['observations'][0]['source_ids'] = ['not-declared']
        errors = ' '.join(charlock.validate(self.base)[0])
        self.assertIn('undeclared id', errors)

    def test_hard_lock_cannot_be_unknown(self):
        self.base['observations'][0]['status'] = 'UNKNOWN'
        self.base['observations'][0]['value'] = ''
        self.base['observations'][0]['source_ids'] = []
        self.assertIn('hard lock must have OBSERVED', ' '.join(charlock.validate(self.base)[0]))

    def test_lock_conflicts_rejected(self):
        self.base['locks']['mutable'].append('face.jaw')
        self.assertIn('multiple lock', ' '.join(charlock.validate(self.base)[0]))

    def test_duplicate_feature_rejected(self):
        self.base['observations'].append(copy.deepcopy(self.base['observations'][0]))
        self.assertIn('duplicate observation', ' '.join(charlock.validate(self.base)[0]))

    def test_nonstring_enums_rejected_without_crash(self):
        self.base['observations'][0]['status'] = []
        self.base['observations'][0]['scope'] = {'bad':'value'}
        self.base['observations'][0]['source_ids'] = [{}]
        errors, warnings = charlock.validate(self.base)
        self.assertTrue(errors)

    def test_bad_role_rejected_without_crash(self):
        self.base['references'][0]['roles'] = [{}]
        self.assertTrue(charlock.validate(self.base)[0])

    def test_invalid_shape_rejected_cleanly(self):
        self.assertTrue(charlock.validate([])[0])
        self.base['observations'] = ['broken']
        self.assertTrue(charlock.validate(self.base)[0])


class ComparisonTests(unittest.TestCase):
    def setUp(self):
        self.base = fixture('assets/example-profile.json')

    def test_pass(self):
        result = charlock.compare(self.base, fixture('tests/fixtures/candidate-pass.json'))
        self.assertEqual(result['result'], 'PASS')

    def test_drifts_are_fail(self):
        result = charlock.compare(self.base, fixture('tests/fixtures/candidate-drift.json'))
        self.assertEqual(result['result'], 'FAIL')
        self.assertEqual(result['checks'][0]['feature'], 'outfit.left_patch')

    def test_missing_observation_is_review(self):
        result = charlock.compare(self.base, fixture('tests/fixtures/candidate-unverifiable.json'))
        self.assertEqual(result['result'], 'REVIEW')

    def test_left_right_flip_fails_even_with_same_value(self):
        candidate = copy.deepcopy(self.base)
        candidate['observations'][5]['side'] = 'subject_right'
        self.assertEqual(charlock.compare(self.base, candidate)['result'], 'FAIL')

    def test_person_side_unknown_is_review(self):
        candidate = copy.deepcopy(self.base)
        candidate['observations'][5]['side'] = 'unknown'
        self.assertEqual(charlock.compare(self.base, candidate)['result'], 'REVIEW')

    def test_image_side_is_not_person_side(self):
        candidate = copy.deepcopy(self.base)
        candidate['observations'][5]['side'] = 'image_right'
        self.assertEqual(charlock.compare(self.base, candidate)['result'], 'REVIEW')

    def test_changed_subject_fails(self):
        candidate = copy.deepcopy(self.base)
        candidate['subject']['id'] = 'someone-else'
        self.assertEqual(charlock.compare(self.base, candidate)['result'], 'FAIL')

    def test_mutable_expression_does_not_fail(self):
        candidate = copy.deepcopy(self.base)
        candidate['observations'][8]['value'] = '生气'
        self.assertEqual(charlock.compare(self.base, candidate)['result'], 'PASS')

    def test_soft_lock_mismatch_is_review(self):
        base = copy.deepcopy(self.base)
        base['locks']['hard'].remove('hair.cut')
        base['locks']['soft'].append('hair.cut')
        candidate = copy.deepcopy(base)
        candidate['observations'][2]['value'] = 'brown long hair'
        self.assertEqual(charlock.compare(base, candidate)['result'], 'REVIEW')

    def test_empty_comparison_is_review(self):
        base = fixture('assets/profile-template.json')
        self.assertEqual(charlock.compare(base, copy.deepcopy(base))['result'], 'REVIEW')


class PromptAndCliTests(unittest.TestCase):
    def test_prompt_preserves_unknown_and_source_roles(self):
        text = charlock.compile_prompt(fixture('assets/example-profile.json'), 'sheet')
        self.assertIn('outfit.back_mark', text)
        self.assertIn('outfit.left_patch', text)
        self.assertIn('身份', text)

    def test_cli_validate_exit_code(self):
        result = subprocess.run([sys.executable, str(ROOT / 'scripts/charlock.py'), 'validate',
                                str(ROOT / 'assets/example-profile.json')],capture_output=True,text=True)
        self.assertEqual(result.returncode, 0)
        self.assertIn('VALID', result.stdout)

    def test_cli_fail_exit_code(self):
        result = subprocess.run([sys.executable, str(ROOT / 'scripts/charlock.py'), 'compare',
                                str(ROOT / 'assets/example-profile.json'),
                                str(ROOT / 'tests/fixtures/candidate-drift.json')],capture_output=True,text=True)
        self.assertEqual(result.returncode, 4)

    def test_cli_pass_exit_code(self):
        result = subprocess.run([sys.executable, str(ROOT / 'scripts/charlock.py'), 'compare',
                                str(ROOT / 'assets/example-profile.json'),
                                str(ROOT / 'tests/fixtures/candidate-pass.json')], capture_output=True, text=True)
        self.assertEqual(result.returncode, 0)

    def test_cli_review_exit_code(self):
        result = subprocess.run([sys.executable, str(ROOT / 'scripts/charlock.py'), 'compare',
                                str(ROOT / 'assets/example-profile.json'),
                                str(ROOT / 'tests/fixtures/candidate-unverifiable.json')],capture_output=True,text=True)
        self.assertEqual(result.returncode, 3)

    def test_init_no_overwrite(self):
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp) / 'new.json'
            args = [sys.executable, str(ROOT / 'scripts/charlock.py'), 'init', str(target)]
            self.assertEqual(subprocess.run(args,capture_output=True).returncode, 0)
            self.assertEqual(subprocess.run(args,capture_output=True).returncode, 2)
            self.assertEqual(charlock.validate(json.loads(target.read_text(encoding='utf-8')))[0], [])


if __name__ == '__main__':
    unittest.main()
