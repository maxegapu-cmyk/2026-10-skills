---
name: library-steward
description: 接入並管理本地知識庫/資料庫/風格庫/素材庫：接入後先摸清全貌、和使用者討論用法，然後負責檢索、精確定位（行號/頁碼）、呼叫（整組取出）、入庫、來源登記、快照、撤回恢復與校驗。使用者提到"知識庫/資料庫/風格庫/素材庫/公共庫/相簿"，或說"幫我找…""在哪一頁/哪一行""把…拿出來用""入庫""某個庫更新了""庫的全貌""校驗/回滾"時使用，即使沒有點名本技能。
---

# Library Steward — 知識庫管家

一個指令碼 `scripts/steward.py` 包辦全部動作，只依賴 Python 3.8+ 標準庫（SQLite FTS5 trigram，中文直接可搜）。
可選增強：`pip install pypdf opencc-python-reimplemented`（PDF 正文 + 繁簡互通檢索）。
所有命令都可加 `--json`。庫根用 `--root` 指定，或設 `STEWARD_ROOT`，或在庫內任意子目錄執行。
下文 `S` = `python <本技能目錄>/scripts/steward.py`。

## 工作主線：接入 → 討論 → 檢索 / 定位 / 呼叫 / 管理

### 1. 接入（首次，約 3 分鐘，一口氣做完再彙報）

```
S doctor                                   # 環境；缺可選依賴就提示安裝
S survey --root <庫根> --out <庫根>/LIBRARY_MAP.md   # 只讀摸底
S init --root <庫根> [--collection-depth 2 | --collections '{"名":"路徑"}'] [--exclude "_tmp,*.bak"]
S index --root <庫根>
S vocab -n 60                              # 庫裡高頻主題片段
S snapshot --label baseline
```
- 集合層級：LIBRARY_MAP.md 末尾有建議值；頂層只有一個目錄時用 `--collection-depth 2`。
- 讀「疑似登記/說明檔案」（README、registry、來源、清單……），提煉約定。已有正式登記時，以它為權威。
- 已有 `<庫根>/ADAPTATION.md` 說明以前接入過：先讀它，跳過討論裡已回答的問題，直接 `S status`。

### 2. 討論（把庫和使用者的需求對上）

帶著摸底結果開口，先給一段全貌：多少集合、檔案、圖文配對組，主題高頻詞是什麼，有哪些登記檔案。
然後用 AskUserQuestion 一次問清（最多 4 題，按需挑）：
1. **主要用途**：查資料找答案 / 找素材拿去用 / 維護更新庫 / 都有
2. **常找什麼**：讓使用者舉 2–3 個真例項子，當場用 `S find` 演示，確認命中合乎預期
3. **說法差異**：使用者的叫法和庫裡寫法不同（品牌簡稱、英文、繁簡）→ 寫進 config.json 的 `synonyms`
4. **管理規矩**：哪些目錄不能動、新資料從哪來、多久更新一次

結果寫入 `<庫根>/ADAPTATION.md`（模板：`references/adaptation-template.md`），含常用檢索與同義詞。以後每次接手先讀它。

### 3. 檢索與精確定位

```
S find "深海藍 主色"                 # 空格=且
S find "海報|poster" -e png,jpg      # |=或；-e 限型別
S find "復古海報 -手寫體"            # -詞=排除
S find '"安全 邊距"'                 # 引號=短語
S find "預算" -c 規範 --since 30d    # 集合 + 時間
S find "logo" --name                 # 只搜檔名/路徑
S find "定價策略" --ctx 3            # 命中行帶上下 3 行
```
結果按「同名組」聚合（`a.png + a.txt` 一組），每組列出 **`路徑:行號 第N頁  原文`**，最多 3 處（`--loc` 調整）。
- docx/pptx/xlsx/pdf 都會讀正文；pptx/pdf 給頁碼，xlsx 按「## 工作表」分段。
- 繁簡自動互通（裝了 opencc）；同義詞來自 config.json。
- 詞長 ≥3 走全文索引，1–2 字自動改走模糊匹配（較慢但可用）。
- 沒結果：換同義詞 → 減條件 → `S status` 看索引是否最新 → `S index`。

**回答問題的標準動作**：`find` 定位 → `cat` 讀出那一段 → 依據原文回答，並標註出處 `路徑:行號` 或 `第N頁`。不要整份檔案讀進來。

```
S cat 規範/品牌手冊.md --around 42 --ctx 10   # 第 42 行上下各 10 行
S cat 規範/品牌手冊.md --lines 120-160
S cat 提案/年度提案.pptx --page 7
```

### 4. 呼叫（把結果拿去用）

```
S pick "復古海報" --to ./work/refs -n 8         # 整組（圖+原詞）複製出來，附 _picked.json 清單
S pick "復古海報" --to ./work/refs -e png --flat # 只要圖，鋪平
S pick --paths 海報/復古/p001 規範/品牌手冊.md --to ./work
S show 海報/復古/p001                            # 看一組的雜湊、來源、批次、絕對路徑
```
庫內原件只讀；需要改動的素材一律先 pick 出來再處理。

### 5. 管理

| 場景 | 命令 |
|---|---|
| 現狀 | `S status`（集合、來源、最近批次、未索引改動） |
| 新資料入庫 | `S ingest <庫外目錄> --collection C --source 名 --url 網址` 看演練 → `--apply` |
| 來源登記 | `S source add --name … --url … --collection …` / `S source list` |
| 撤回 / 反悔 | `S undo <批次>` → `--apply`；`S restore <批次>` |
| 改了什麼 | `S diff`（最近快照 vs 當前）/ `S diff 快照A 快照B` |
| 有無損壞 | `S verify [-c 集合]` |
| 定期巡檢 | 用會話的定時任務工具建 scheduled task：index → verify → status，異常才通知 |

詳細流程（來源更新、大批次入庫、恢復演練、遷移、與現有登記對賬）：`references/playbooks.md`。

## 鐵律

1. **先演練再執行**：ingest、undo 預設只演練；批次執行前給使用者看演練摘要（使用者說過"直接做"就免）。
2. **不刪不覆蓋**：同名自動存成 `__v2`；內容重複（sha256 相同）跳過；撤回只移入 `.steward/trash/`。
3. **入庫必帶來源**，名稱與正式登記一致。
4. **手工改過庫就先 `S index`** 再檢索。
5. **答案帶出處**（`路徑:行號` / 第N頁）；**彙報帶數字**（新增、跳過、批次號、耗時）。批次號是撤回的鑰匙，必須告訴使用者。
6. **與原有體系共存**：庫裡已有正式登記時，steward 只做索引與操作層，發現不一致就報告，不擅自改原登記。

## 資料位置

`<庫根>/.steward/`：`config.json`（適配與同義詞）、`index.db`（索引、來源、批次）、`snapshots/`、`batches/`、`trash/`。
刪除後可 `init --force` + `index` 重建，庫檔案不受影響；來源與批次記錄在 index.db 裡，刪前先備份。

## 自檢

`S selftest`：在臨時目錄跑 24 項（定位、docx/pptx、繁簡、同義詞、cat、pick、入庫、撤回、恢復、篡改檢出……），升級或換機器後跑一次。
