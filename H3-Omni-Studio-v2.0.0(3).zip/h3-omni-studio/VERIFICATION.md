# H3 Omni Studio v2.0.0 · release validation evidence

Release date: 2026-10-22. Target: stand-alone, cleanly extracted Skill package, Python standard-library-only validator.

## Verified locally

- Original v1 T2VA tattoo/dialogue/action examples remain structurally compatible.
- All 5 H3 modes have passing prompt examples; Ref2VA also includes video-continuation, video-edit and tattoo-reference variants.
- Unit tests cover valid paths and negative paths: wrong mode, wrong field order, malformed alignment, mismatched final timestamp, missing reference definitions, skipped shot numbers, late cuts, broken dialogue markup, audio-only references, excessive media counts and duration, mismatched asset manifest.
- Static validator never calls MiniMax API, opens private media or changes other directories.
- Package includes only its own independently authored Markdown/Python/JSON/YAML, plus reused author-owned v1 examples; no third-party Git clones, repository histories, cached credentials or external asset files.
- The SHA-256 package manifest and cold-extracted validation commands provide repeatability. Actual counts and checksum appear in the companion release verification JSON beside the ZIP.

## Acceptance commands (run after extracting the ZIP)

```bash
python -B -m unittest discover -s tests -v
python -B tools/validate_prompt.py examples/i2va-first-frame.txt --mode I2VA --duration 8 --assets examples/i2va-assets.example.json
python -B tools/validate_prompt.py examples/ref2va-identity-motion-voice.txt --mode Ref2VA --duration 8 --assets examples/ref-assets.example.json
python -B tools/verify_manifest.py
```

These commands are expected to exit 0. See `tests/AB-PROTOCOL.md` for an actual H3 video comparison design; **no real H3 generation was run for this release**. Success here means package/format compatibility checks, not audiovisual quality proof. If the official H3 protocol or backend limits change, update this Skill, its tests, and the manifest.
