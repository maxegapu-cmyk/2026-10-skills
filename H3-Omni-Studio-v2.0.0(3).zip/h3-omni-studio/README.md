# H3 Omni Studio 2.0.0（MiniMax H3 全模式视频提示词 Skill）

这是一套**独立编写、只产出提示词与静态校验**的开源便携 Skill。由早期 `h3-t2v-studio v1.0.0` 扩展：完整保留文生视频能力，将支持范围扩大至 **T2VA、I2VA、FL2VA、L2VA、Ref2VA** 五种官方模式。

本项目**非 MiniMax 官方产品、非官方模型权重或云 API 客户端**。原生视频的成片表现必须使用 H3 自己测试；仓库里的测试均是离线协议/配置/回归测试。

## 新版对旧版的真实变化

| 项目 | v1.0 T2V | v2.0 Omni |
| --- | --- | --- |
| 文生视频 T2VA | 支持 | 保留并优化 |
| 首帧 / 末帧 / 首尾帧 | 不支持 | 支持，含精确锚定首行 |
| 多模态参考 Ref2VA | 不支持 | 六字段、素材 ID、保留关系、声音引用 |
| 视频续写/参考剪辑 | 不支持 | 作为 Ref2VA 的任务类型处理；不单列虚假 H3 模式 |
| 音频/对白 | 基础声效 | 加入声音参考、配乐/画内声分层、中文对白 |
| 情境范式 | 9个文生案例 | 5模式范例、专项配方与兼容旧版案例 |
| 静态检验 | T2VA | 5模式、时长、标签、素材清单、负例 |

## 使用

1. 将压缩包里的 `h3-omni-studio/` 文件夹放在 Claude Code 项目的 `.claude/skills/`，或 Codex 项目的 `.agents/skills/`（按你的 Agent Skills 运行时规则安装）。
2. 对 Agent 说“用 h3-omni-studio 帮我把这段剧本写成 H3 文生视频”，或“这张图做首帧，这段视频只参考运镜，帮我选模式并写提示词”。
3. 没有 Agent Skills 环境，直接复制 `MASTER-PROMPT.md` 作为跨平台通用母提示词。
4. 想检查提示词：`python tools/validate_prompt.py examples/i2va-first-frame.txt --mode I2VA --duration 8`。
5. 参考资产数量检查：`python tools/validate_prompt.py examples/ref2va-identity-motion-voice.txt --mode Ref2VA --duration 8 --assets examples/ref-assets.example.json`。

## 不同需求对应哪种文件

- 一句话上手：`QUICKSTART.md`
- 一键全模式母提示词：`MASTER-PROMPT.md`
- 官方兼容的字段写法与关键帧句式：`references/h3-format.md`
- 多图 / 多视频 / 多音频 / 续写参考：`references/ref2va-workflow.md`
- 十余个场景的专业策略：`recipes/INDEX.md`
- 错误诊断：`references/diagnose-and-repair.md`
- 测试与许可：`VERIFICATION.md`、`SOURCES.md`、`LICENSE`

## 技术边界

- H3 官方当前支持的基本输出时长 4–15 秒，Ref2VA 参考图最多9张、参考视频最多3段、参考音频最多3段，混合素材总数至多12个；参考音频必须搭配图/视频。不同使用端、平台产品封装可能增加额外限制，实际提交前以官方接口为准。
- **不要把文字中的“16:9、2K、8秒”当成 API 参数已设置**。在使用网站/客户端时另行设定真实参数；关键帧模式通常按输入图片比例确定构图。
- 引导模型生成完整视觉不是“强制模型精确遵守”；涉及具体文字/字体/品牌资产、脸部身份、运动接触、连续长片时要保留人工检查环节。
- 不包含任何用户私有电影导演包、个人知识库、仓库历史或外部付费内容；也没有上传到 GitHub。使用者自行选择公开发布。
