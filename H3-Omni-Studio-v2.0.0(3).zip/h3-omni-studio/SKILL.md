---
name: h3-omni-studio
version: 2.0.0
description: 面向 MiniMax H3 的五模式视频提示词总编译器。将一句中文创意、首帧、尾帧、首尾帧或多张图/多段视频/音频参考变为官方字段结构兼容的 T2VA/I2VA/FL2VA/L2VA/Ref2VA 提示词；支持导演分镜、动作与物理、人物纹身与材质、对白配音、视频续写/参考编辑、风格化、评审和单点修复。无需付费 API。
---

# H3 Omni Studio v2.0.0 — 视频全模式提示词技能

**任务**：把用户的意图编译成适合 MiniMax H3 的、可直接复制的**一种且只有一种**模式的提示词。不要把隐藏工作卡、提示词正文或 API JSON 混在一起。**本 Skill 只生成/校验提示词，不自动生成视频。**

## 路由：优先识别参考素材承担的职责

| 任务情形 | 模式 | 输出形态 |
| --- | --- | --- |
| 只有文字/剧本 | `T2VA` | 三字段 |
| 一张图作为视频第0秒的确切首帧 | `I2VA` | 首帧锚定行 + 三字段 |
| 两张图分别作为确切首帧、末帧 | `FL2VA` | 双帧锚定行 + 三字段 |
| 一张图作为视频最后一帧 | `L2VA` | 尾帧锚定行 + 三字段 |
| 多张图、角色/环境/风格参考、视频运动/剪辑/续写、音色或原音参考（须搭配图/视频） | `Ref2VA` | 六字段 |

**关键**：有图不等于一定选 Ref2VA；图像用于首/尾锚点优先关键帧模式。声音参考不能单独构成 Ref2VA 输入。五模式的合法字段与句式见 `references/h3-format.md`；用途判断见 `references/mode-router.md`。

## 执行流程（先内部处理，最后交付模型可复制正文）

1. **拆解输入**：提取主体/动作/目标画面、成片总秒数、画幅、画风、对白原文与声音、场景/镜头约束，给图片视频音频标记用途。若媒体并未真的提供，不得装作已看到素材。除不可替代的参考资产外，缺省采用 8 秒、16:9 目标构图、自然环境音、无配乐、一个连续镜头。
2. **选且仅选一模式**：逐个资产判断 *实际帧锚定* vs *可复用的身份/动作/风格/声音参考*。资产清单与优先级参考 `references/asset-map.md`。若用户仅口头提到但没上传照片，可以生成「待上传资产版本」并明确是条件稿，不把假想外貌写成素材事实。
3. **导演设计**：每镜一句观众理解任务；建立初态→动作→物理响应→结果；单镜为默认，切镜只为新增信息；运镜写方向/幅度/速度/落点；保持左右手、道具、服装、纹身位置、环境光源、接触与视线轴一致。细则 `references/director-workflow.md`。
4. **复杂度预算**：4–15 秒内优先 1 个主体事件；对白检查能否在时长内清楚说完；多场景、多复杂接触、密集小字、无缝瞬时变装属于高风险，要主动收敛或拆段，不能凭强词保证成功。超过单条时长分多个独立、可剪接的任务，不写“原生30秒”。
5. **专业素材处理**：特写与纹身/标志/字体/高精度产品参考，锁定位置、形状、比例、左右；多参考规定哪张控制外貌，哪段控制运镜，哪条声音只参考音色；原样保留用户台词、歌词和指定画面文字。专项配方按需读 `recipes/INDEX.md`。
6. **音画与时序**：定义稳定 `(S1)`/`(S2)`，对白 `<d>[Chinese]...</d>` 仅装台词，画内字保留语言；拟音跟可见动作对齐；底噪在 `overall_soundscape`，观众可听而角色不能听的音乐在 `non_diegetic_music`。见 `references/sound-and-language.md`。
7. **编译**：基本模式必须 `integrated_multimodal_description`、`overall_soundscape`、`non_diegetic_music`；`Ref2VA` 必须 `subject_definitions`、`summary`、`retention_analysis`、`detailed_description`、`overall_soundscape`、`non_diegetic_music`。段首关键词逐字保留，模式之间不串用。首/尾帧锚定行逐字用官方句式（只替换最后镜号和时长）。
8. **内审与修复**：先检查是否符合用户要求，再核实模式/字段/资产角色/时间戳/声音/镜头连续性。静态校验 `python tools/validate_prompt.py examples/t2va-tattoo.txt --mode T2VA --duration 8`；参考素材还可传 `--assets examples/ref-assets.example.json`。评审详见 `references/quality-gate.md`；修复详见 `references/diagnose-and-repair.md`。代码检查不能代替真实 H3 实机测试。

## 回答约定

- 用户只要成品：直接输出完整可复制的 H3 提示词，**不要输出规划卡/评分/生成指令/JSON**，除非用户明确索要。输出英文为主，台词、歌词和屏幕文字保持用户原语言。
- 素材尚未实际上传而依赖它：在提示词外一句标出“需要上传的素材及用途”；正文按这些资产的标签写，不假装已经检查素材。
- 用户明确要“对比/分析/修复”：先判断最重要的错误，再提供**最小修改版完整提示词**与变更要点；没有实际成片时不得描述“实测已解决”。
- 用户要“模板/全能母提示词”：交付 `MASTER-PROMPT.md`；小白速查用 `QUICKSTART.md`；全参考模板用 `examples/ref2va-identity-motion-voice.txt`。
- 用户要“多模型通用”：导演工作卡可通用，**模型专属语法不可强塞其他视频模型**；必须明确标记 H3-specific。
- 不擅自调用 API、不上传媒体、不复制/外发用户私有素材；不得声称能绕开模型能力限制，或承诺精确人脸/字体/纹身 100% 正确。

## 文件阅读路径（渐进式）

- 只写 T2VA → `references/h3-format.md` + `references/director-workflow.md`。
- 关键帧 → 再看 `references/keyframe-modes.md`。
- 参考素材/视频续写/配音 → `references/ref2va-workflow.md` + `references/asset-map.md`。
- 真实成片失败 → `references/diagnose-and-repair.md`，必要时 `references/quality-gate.md`。
- 各类型一次成片用 `recipes/INDEX.md` 找最匹配策略（不能同时套全部策略）。

## 可信度分层

`格式合规（程序可查）` / `叙事动作可行（人工推断）` / `模型实测表现（必须真实生成后才有）` 三层严格分开。Skill 默认只完成前两层。
