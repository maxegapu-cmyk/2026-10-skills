# 60秒上手（外发用）

直接说：“请用 H3 Omni Studio 写一条 H3 视频提示词：一个成年人在纹身工作室转动手臂，展示左前臂黑色几何纹身，8秒，写实，只要自然声。” → 选择 T2VA。

只提供一张**确定为第0秒画面**的照片 → I2VA；一张**确定为最终画面**的照片 → L2VA；给首尾两张确定帧图 → FL2VA；给“人物长相图 + 参考动作视频 + 参考声音” → Ref2VA。

视频续写通常需要附原始视频，选择 Ref2VA 并要求从源视频末尾状态接起；不是 T2VA 里写一句“延续上一段”就能锁住状态。

两种交付：① `SKILL.md` 在支持 Skill 的 Agent 里按需加载；② `MASTER-PROMPT.md` 复制进普通聊天窗口免安装。

命令检查：

```bash
python tools/validate_prompt.py examples/t2va-tattoo.txt --duration 8 --mode T2VA
python tools/validate_prompt.py examples/ref2va-identity-motion-voice.txt --duration 8 --mode Ref2VA --assets examples/ref-assets.example.json
python -m unittest discover -s tests -v
```

注：命令只查结构和矛盾，不会消耗 H3 额度或真实出片；本技能不会接收/上传私人媒体。
