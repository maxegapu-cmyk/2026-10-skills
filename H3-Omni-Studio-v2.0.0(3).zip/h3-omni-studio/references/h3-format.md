# H3 特有协议速查（2026-10-22 校对）

下面“字段、参考标签、对齐句式”属于 H3 **特定格式**；导演工艺部分则属泛用启发式。以官方新版本为最终真源；本页并非调用接口的 JSON API 说明。

## 1. 基础四模式共享正文

```text
integrated_multimodal_description: [Shot 1] ...

overall_soundscape: ...

non_diegetic_music: N/A
```

第一镜无起始时间。第二镜形如 `[Shot 2] At 00:03.500, the camera cuts to...`，随后第3、4镜依次编号和递增时刻。

- `T2VA` 首行直接为 `integrated_multimodal_description:`。
- `I2VA` 在首行加 `For the target video, at 0.00 seconds into the target video, <Picture 1> (from [Shot 1]) is fully referenced.`，**一空行**，再跟三字段。
- `FL2VA` 在首行加 `How the reference pictures align with the target video — Picture 1 (from Shot 1) aligns with the 0.00-second mark of the target video; Picture 2 (from Shot N) aligns with the S.SS-second mark of the target video.`，**一空行**，再跟三字段。
- `L2VA` 首行加 `How the reference pictures align with the target video — <Picture 1> (from [Shot N]) aligns with the S.SS-second mark of the target video.`，**一空行**，再跟三字段。

N 是实际最后一镜的索引，S.SS 是最终秒数，保留两位小数，比如 `8.00`。提示词描述时长不等于 API 参数已设置。

## 2. Ref2VA 六字段，不能跟基础三字段混用

```text
subject_definitions:
<Subject 1> is ... from <Picture 1>.
<Video 1> is the source video used for continuation.
<Audio 1> is a rhythm reference.

summary:
[video continuation + reference generation] ...

retention_analysis:
<Subject 1> (appears in [Shot 1]): fully_preserved - ...
<Video 1> (continuation source): partially_preserved - ...
<Audio 1>: reference - ...

detailed_description:
The target uses ... .
[Shot 1] ...

overall_soundscape: ...

non_diegetic_music: N/A
```

在 `subject_definitions` 中标签含义只能定义一次：`<Subject N>` 是画面中的可复用实体/属性，`<Picture N>` 是具体帧/构图锚，`<Video N>` 是源视频/时间结构，`<Audio N>` 是声音信号；普通图片仅用于角色外观时，只需在 `<Subject N>` 定义中引用 `<Picture N>`，不额外声明独立帧锚。`detailed_description` 的整体风格可写在 `[Shot 1]` 前一两句。

**视觉保留类型**：`fully_preserved`, `partially_preserved`, `attribute_transfer`, `weak_reference`。
**音频保留类型**：`fully_copy`, `partially_copy`, `reference`, `weak_reference`。
这些是任务意图标记，不是可保证成片忠实度的测量结果。

## 3. 对白与时空

发声者标 `(S1)` / `(S2)` 并持续复用；对白原文放 `<d>[Chinese]你好</d>` 或其它语言；旁白用 `says in an off-screen voiceover`，画内对应人物嘴唇不动；机位移动写实际方向、速度和幅度。切点 `At 00:03.000` 表示剪辑时间，不是 3 秒时长镜头。

## 4. 能力和安全区间

- 官方 H3 模式：T2VA / I2VA / FL2VA / L2VA / Ref2VA，时长约 4–15s，输出带音频。
- 官方全参考输入限制：图片≤9，视频≤3（各2–15s且合计≤15s），音频≤3（各2–15s且合计≤15s），混合文件≤12；不可仅音频作为 Ref2VA 唯一材料。
- 本地静态检查默认保守上限 7000 字符；如官网调整请对齐。实际参数如尺寸、比例、时长、素材 URL 要在支持的平台另外选择/传入；纯 Markdown 不是 API 请求。
- 对超长时长、多动作场景、精确字体/Logo/严密同步，优先多段视频、先做锚定图、剪辑或后期工艺。

来源：`SOURCES.md` 的 MiniMax 官方 repo `h3-prompt-writing` 及其 `base-en.txt`/`ref-en.txt`、MiniMax 官方 CLI 文档。仅为原创解释与必要的接口词汇速记，未打包第三方仓库原文。
