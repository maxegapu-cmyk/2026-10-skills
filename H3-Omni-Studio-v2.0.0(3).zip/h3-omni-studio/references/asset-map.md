# 参考资产登记卡（不可虚构素材）

每个用户素材记一个 ID、媒介类型、任务角色、允许改变的维度和不能改变的细节；若上传顺序改变，引用标签必须同步改变。

```json
{
  "mode": "Ref2VA",
  "duration": 8,
  "assets": [
    {"label": "Picture 1", "type": "image", "role": "identity", "description": "用户提供的角色正面图"},
    {"label": "Video 1", "type": "video", "role": "motion_only", "seconds": 5},
    {"label": "Audio 1", "type": "audio", "role": "voice_timbre_only", "seconds": 6}
  ]
}
```

- `identity` 锁谁；`style` 锁视觉语言；`scene` 锁地理/环境；`motion_only` 锁动作动力学；`camera_only` 锁运动方式；`video_source` 指明续写/编辑源；`voice_timbre_only` 只参考声色，不复制波形；`audio_copy` 才考虑复制源音频。
- 同一素材可被多处引用，但不要让两张参考抢同一人物的脸。若冲突，明确优先级：如 Picture1 脸与服装，Picture2 纹身位置，Video1 只取走路节奏。
- `role` 是本技能的**幕后规划词**，不是官方 API 字段；传真实模型时只发送 H3 要求的输入及结构化提示词。
- Ref2VA 参考素材必须实际存在。未上传时用条件稿写待上传的角色标签，不能作图像观察报告。

本地校验支持 `--assets` JSON 清单（仅查数量、时长、模式与引用的一致性，不会打开/上传文件）。素材清单单独保存，不要放进模型可复制正文。
