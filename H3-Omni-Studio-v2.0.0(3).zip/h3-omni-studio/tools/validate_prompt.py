#!/usr/bin/env python3
"""MiniMax H3 prompt static validator. Python standard library only.

Checks text/asset manifest consistency, not actual H3 model compliance, output, or fidelity.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from collections import Counter
from pathlib import Path
from typing import Any

BASE_FIELDS = ("integrated_multimodal_description", "overall_soundscape", "non_diegetic_music")
REF_FIELDS = ("subject_definitions", "summary", "retention_analysis", "detailed_description", "overall_soundscape", "non_diegetic_music")
MODES = ("T2VA", "I2VA", "FL2VA", "L2VA", "Ref2VA")

I2_START = "For the target video, at 0.00 seconds into the target video, <Picture 1> (from [Shot 1]) is fully referenced."
FL_PATTERN = re.compile(r"^How the reference pictures align with the target video — Picture 1 \(from Shot 1\) aligns with the 0\.00-second mark of the target video; Picture 2 \(from Shot (\d+)\) aligns with the (\d+\.\d{2})-second mark of the target video\.$")
L_PATTERN = re.compile(r"^How the reference pictures align with the target video — <Picture 1> \(from \[Shot (\d+)\]\) aligns with the (\d+\.\d{2})-second mark of the target video\.$")
FIELD_RE = re.compile(r"^([a-z][a-z0-9_]*):(?:\s*|$)", re.M)
SHOT_RE = re.compile(r"\[Shot\s+(\d+)\]")
CUT_RE = re.compile(r"^\s+At\s+(\d{2}):(\d{2})\.(\d{3}),\s*", re.S)
TAG_RE = re.compile(r"<(Subject|Picture|Video|Audio)\s+(\d+)>")
DEF_RE = re.compile(r"^\s*<(Subject|Picture|Video|Audio)\s+(\d+)>\s+", re.M)
DIALOGUE_RE = re.compile(r"<d>\[[A-Za-z][A-Za-z\-\s]*\]([^<>]+)</d>")


def detect_mode(s: str) -> str:
    if s.startswith("subject_definitions:"):
        return "Ref2VA"
    if s.startswith("For the target video,"):
        return "I2VA"
    if s.startswith("How the reference pictures align with the target video — Picture 1"):
        return "FL2VA"
    if s.startswith("How the reference pictures align with the target video — <Picture 1>"):
        return "L2VA"
    return "T2VA"


def _add(issues: list[dict], code: str, message: str) -> None:
    issues.append({"code": code, "message": message})


def validate_assets(manifest: dict, mode: str, duration: float | None) -> list[dict]:
    issues: list[dict] = []
    if not isinstance(manifest, dict):
        return [{"code": "ASSETS_SCHEMA", "message": "Asset manifest must be a JSON object."}]
    if manifest.get("mode") != mode:
        _add(issues, "ASSETS_MODE", f"Manifest mode {manifest.get('mode')!r} differs from {mode}.")
    if duration is not None and "duration" in manifest:
        try:
            if abs(float(manifest["duration"]) - duration) > .001:
                _add(issues, "ASSETS_DURATION", "Asset manifest duration does not match requested duration.")
        except (TypeError, ValueError):
            _add(issues, "ASSETS_DURATION", "Asset manifest duration must be numeric.")
    assets = manifest.get("assets")
    if not isinstance(assets, list):
        return issues + [{"code": "ASSETS_SCHEMA", "message": "Manifest assets must be a list."}]
    counts = Counter()
    labels = set()
    for i, a in enumerate(assets):
        if not isinstance(a, dict):
            _add(issues, "ASSET_ITEM", f"assets[{i}] must be an object.")
            continue
        kind = a.get("type")
        label = a.get("label", "")
        if kind not in ("image", "video", "audio"):
            _add(issues, "ASSET_TYPE", f"assets[{i}] invalid type: {kind!r}")
            continue
        counts[kind] += 1
        expected = {"image": "Picture", "video": "Video", "audio": "Audio"}[kind]
        match = re.fullmatch(r"(Picture|Video|Audio) ([1-9][0-9]*)", str(label))
        if not match or match.group(1) != expected:
            _add(issues, "ASSET_LABEL", f"assets[{i}] label {label!r} must look like {expected} N.")
        if label in labels:
            _add(issues, "DUPLICATE_ASSET", f"Duplicate asset label {label!r}.")
        labels.add(label)
        if mode == "Ref2VA" and kind in ("video", "audio"):
            try:
                seconds = float(a.get("seconds"))
                if not 2 <= seconds <= 15:
                    _add(issues, "ASSET_CLIP_DURATION", f"{label} seconds must be 2–15.")
            except (TypeError, ValueError):
                _add(issues, "ASSET_CLIP_DURATION", f"{label} must include numeric seconds for reference preflight.")
    if mode == "Ref2VA":
        for kind, cap in (("image", 9), ("video", 3), ("audio", 3)):
            if counts[kind] > cap:
                _add(issues, "ASSET_LIMIT", f"Too many {kind} assets ({counts[kind]}>{cap}).")
        if sum(counts.values()) > 12:
            _add(issues, "ASSET_LIMIT", "Ref2VA combined reference assets exceed 12 files.")
        if not (counts["image"] or counts["video"]):
            _add(issues, "AUDIO_ONLY_REF", "Ref2VA requires at least one image/video reference; audio alone is invalid.")
        for kind in ("video", "audio"):
            total = sum(float(a.get("seconds", 0)) for a in assets if isinstance(a, dict) and a.get("type") == kind and isinstance(a.get("seconds"), (int, float)))
            if total > 15 + .0001:
                _add(issues, "ASSET_TOTAL_SECONDS", f"Reference {kind} clips total {total}s; max 15s.")
    elif mode == "T2VA":
        if assets:
            _add(issues, "BASE_ASSETS", "T2VA should have no image/video/audio input assets.")
    else:
        expected_roles = {"I2VA": ["first_frame"], "FL2VA": ["first_frame", "last_frame"], "L2VA": ["last_frame"]}[mode]
        if counts["image"] != len(expected_roles) or counts["video"] or counts["audio"]:
            _add(issues, "KEYFRAME_ASSETS", f"{mode} requires {len(expected_roles)} image(s), with no video/audio reference inputs.")
        actual_roles = [a.get("role") for a in assets if isinstance(a, dict) and a.get("type") == "image"]
        if actual_roles != expected_roles:
            _add(issues, "KEYFRAME_ROLE", f"{mode} requires image roles in order {expected_roles}.")
    return issues


def check(text: str, *, mode: str = "auto", duration: float | None = None, assets: dict | None = None) -> dict[str, Any]:
    text = text.replace("\r\n", "\n").replace("\r", "\n").strip("\n")
    errors: list[dict] = []
    warnings: list[dict] = []
    detected = detect_mode(text)
    if mode != "auto" and mode != detected:
        _add(errors, "MODE_CONFLICT", f"Requested {mode} but prompt auto-detected {detected}.")
    actual_mode = mode if mode != "auto" else detected
    if not text.strip():
        _add(errors, "EMPTY", "Prompt is empty.")
    if len(text) > 7000:
        _add(errors, "PROMPT_LENGTH", f"Prompt is {len(text)} characters; conservative H3 limit is 7000.")
    if duration is None and assets and "duration" in assets:
        try:
            duration = float(assets["duration"])
        except (TypeError, ValueError):
            _add(errors, "DURATION", "Manifest duration must be numeric.")
    if duration is not None and not 4 <= duration <= 15:
        _add(errors, "DURATION", f"Duration {duration}s outside H3 4–15s range.")

    if actual_mode in ("I2VA", "FL2VA", "L2VA"):
        line, sep, rest = text.partition("\n")
        if not sep or not rest.startswith("\n"):
            _add(errors, "ALIGNMENT_SPACING", "Image alignment line must have one blank line before the core fields.")
        body = rest.lstrip("\n")
        if actual_mode == "I2VA":
            if line != I2_START:
                _add(errors, "ALIGNMENT", "I2VA first-line image alignment does not match the official exact phrase.")
            anchor = None
        else:
            match = (FL_PATTERN if actual_mode == "FL2VA" else L_PATTERN).fullmatch(line)
            if not match:
                _add(errors, "ALIGNMENT", f"{actual_mode} first line has invalid image alignment syntax.")
                anchor = None
            else:
                anchor = (int(match.group(1)), float(match.group(2)))
    else:
        body = text
        anchor = None
    top_headers = [m.group(1) for m in FIELD_RE.finditer(body)]
    expected = list(REF_FIELDS if actual_mode == "Ref2VA" else BASE_FIELDS)
    if top_headers != expected:
        _add(errors, "FIELD_ORDER", f"Found headers {top_headers!r}, required {expected!r}.")
    fields: dict[str, str] = {}
    matches = list(FIELD_RE.finditer(body))
    for idx, m in enumerate(matches):
        nxt = matches[idx+1].start() if idx+1 < len(matches) else len(body)
        fields[m.group(1)] = body[m.end():nxt].strip()
    for k in expected:
        if k in fields and not fields[k]:
            _add(errors, "EMPTY_FIELD", f"{k}: must not be empty.")
    main_key = "detailed_description" if actual_mode == "Ref2VA" else "integrated_multimodal_description"
    main = fields.get(main_key, "")
    if actual_mode != "Ref2VA" and main and not main.startswith("[Shot 1]"):
        _add(errors, "SHOT_ONE_POSITION", "Basic-mode integrated description must begin with [Shot 1].")
    raw_shots = list(SHOT_RE.finditer(main))
    numbers = [int(m.group(1)) for m in raw_shots]
    if numbers != list(range(1, len(numbers)+1)):
        _add(errors, "SHOT_SEQUENCE", f"Shot numbering invalid: {numbers!r}. Must be [1,2,...].")
    if not raw_shots:
        _add(errors, "SHOTS_MISSING", "No [Shot 1] in main visual section.")
    last_cut = 0
    cuts = []
    for i, item in enumerate(raw_shots):
        suffix = main[item.end():]
        if i == 0:
            if re.match(r"^\s+At\s+\d{2}:\d{2}\.\d{3}", suffix):
                _add(errors, "FIRST_SHOT_TIME", "First shot must not have a cut timestamp.")
            continue
        mm = CUT_RE.match(suffix)
        if not mm:
            _add(errors, "CUT_FORMAT", f"[Shot {numbers[i]}] must begin 'At 00:SS.mmm, ...'.")
            continue
        at = int(mm.group(1))*60+int(mm.group(2))+int(mm.group(3))/1000
        cuts.append(at)
        if at <= last_cut:
            _add(errors, "CUT_ORDER", "Cut times must be strictly increasing.")
        last_cut = at
        if duration is not None and at >= duration:
            _add(errors, "CUT_DURATION", f"Shot cut {at}s must be before end {duration}s.")
    if anchor is not None:
        n, at = anchor
        if numbers and n != numbers[-1]:
            _add(errors, "ANCHOR_SHOT", f"Image ending anchor refers to Shot {n}, but final shot is {numbers[-1]}.")
        if duration is not None and abs(at-duration) > .005:
            _add(errors, "ANCHOR_DURATION", f"Image ending anchor {at:.2f}s != duration {duration:.2f}s.")
        if not (4 <= at <= 15):
            _add(errors, "ANCHOR_DURATION", "Ending anchor outside 4–15s interval.")
    if "<d>" in text or "</d>" in text:
        if len(re.findall(r"<d>", text)) != len(re.findall(r"</d>", text)):
            _add(errors, "DIALOGUE_TAG", "Unbalanced <d>...</d> markup.")
        for block in re.findall(r"<d>.*?</d>", text, re.S):
            if not DIALOGUE_RE.fullmatch(block):
                _add(errors, "DIALOGUE_FORMAT", f"Invalid language-tagged dialogue: {block[:60]!r}.")
        if len(re.findall(r"<d>", text)) != len(re.findall(r"<d>.*?</d>", text, re.S)):
            _add(errors, "DIALOGUE_TAG", "At least one dialogue tag is malformed or nested.")
    if actual_mode == "Ref2VA":
        defs = fields.get("subject_definitions", "")
        retention = fields.get("retention_analysis", "")
        defined = {(k, n) for k, n in DEF_RE.findall(defs)}
        all_mentioned = {(k, n) for k, n in TAG_RE.findall(text)}
        source_labels = {(k, n) for k, n in TAG_RE.findall(defs)}
        for k, n in sorted(all_mentioned):
            if (k, n) not in defined and (k, n) not in source_labels:
                _add(errors, "UNRESOLVED_REFERENCE", f"<{k} {n}> used but not introduced in subject_definitions.")
        for k, n in sorted(defined):
            if k == "Picture":
                # A picture used only as a subordinate identity input does not need its own retention row.
                pass
            elif f"<{k} {n}>" not in retention:
                _add(errors, "MISSING_RETENTION", f"<{k} {n}> needs a retention_analysis relationship.")
        if "[" not in fields.get("summary", ""):
            _add(errors, "SUMMARY_TASK", "Ref2VA summary should open with [task type].")
        if re.search(r"\bfully_copy\b", retention) and not any(k == "Audio" for k, _ in defined):
            _add(errors, "AUDIO_COPY", "fully_copy used without a defined audio reference.")
        if not any(k in ("Picture", "Video") for k, _ in source_labels):
            _add(warnings, "NO_VISUAL_REF", "Ref2VA needs a real image/video asset; no visual source label was found.")
        if assets:
            labels = {a.get("label") for a in assets.get("assets", []) if isinstance(a, dict)}
            for k, n in sorted(source_labels):
                if k in ("Picture", "Video", "Audio") and f"{k} {n}" not in labels:
                    _add(errors, "MISSING_ASSET", f"Prompt references <{k} {n}> but manifest does not contain it.")
            for label in labels:
                if not isinstance(label, str):
                    continue
                category, _, number = label.partition(" ")
                if (category, number) not in source_labels:
                    _add(errors, "UNUSED_ASSET", f"Manifest has {label} not used anywhere in subject_definitions.")
        else:
            _add(warnings, "UNVERIFIED_ASSETS", "Ref2VA asset identities and durations were not checked; supply --assets to preflight.")
    else:
        if re.search(r"^\s*(subject_definitions|retention_analysis|detailed_description|summary):", body, re.M):
            _add(errors, "MIXED_MODE", "Base-mode prompt contains reference-mode field.")
    if assets is not None:
        errors.extend(validate_assets(assets, actual_mode, duration))
    if duration is None:
        _add(warnings, "DURATION_UNCHECKED", "Pass --duration to verify cut and anchor times against intended length.")
    return {"valid": not errors, "mode": actual_mode, "duration": duration,
            "shot_count": len(numbers), "cut_times": cuts, "prompt_characters": len(text),
            "errors": errors, "warnings": warnings}


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("prompt", type=Path, help="UTF-8 H3 prompt text file")
    ap.add_argument("--mode", choices=("auto",)+MODES, default="auto")
    ap.add_argument("--duration", type=float)
    ap.add_argument("--assets", type=Path, help="Optional asset-manifest JSON file, planning metadata only")
    ap.add_argument("--json", action="store_true", help="Machine-readable summary")
    a = ap.parse_args(argv)
    try:
        prompt = a.prompt.read_text(encoding="utf-8-sig")
        assets = json.loads(a.assets.read_text(encoding="utf-8-sig")) if a.assets else None
        result = check(prompt, mode=a.mode, duration=a.duration, assets=assets)
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"INPUT_ERROR: {exc}", file=sys.stderr)
        return 2
    if a.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print(f"{'PASS' if result['valid'] else 'FAIL'}  {result['mode']}  {result['shot_count']} shot(s)  {result['prompt_characters']} chars")
        for typ in ("errors", "warnings"):
            for x in result[typ]:
                print(f"{typ[:-1].upper()} {x['code']}: {x['message']}")
        print("NOTICE: Static validation only; model output and reference fidelity not measured.")
    return 0 if result["valid"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
