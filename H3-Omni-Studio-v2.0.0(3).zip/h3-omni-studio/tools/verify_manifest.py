#!/usr/bin/env python3
"""Verify a clean extracted H3 Omni Studio package against SHA-256 file manifest."""
import hashlib
import json
import sys
from pathlib import Path


def main():
    root=Path(__file__).resolve().parents[1]
    manifest_path=root/'PACKAGE-MANIFEST.json'
    if not manifest_path.is_file():
        print('FAIL: PACKAGE-MANIFEST.json absent',file=sys.stderr)
        return 1
    manifest=json.loads(manifest_path.read_text(encoding='utf8'))
    expected=manifest['files']
    found={str(p.relative_to(root)).replace('\\','/') for p in root.rglob('*') if p.is_file() and p.name!='PACKAGE-MANIFEST.json' and '__pycache__' not in p.parts}
    errors=[]
    if found!=set(expected):
        errors.append(f'file tree mismatch: extra={sorted(found-set(expected))}, missing={sorted(set(expected)-found)}')
    for rel, h in expected.items():
        p=root/rel
        if not p.is_file():
            continue
        if hashlib.sha256(p.read_bytes()).hexdigest()!=h:
            errors.append('hash mismatch: '+rel)
    if errors:
        print('FAIL', *errors,sep='\n',file=sys.stderr)
        return 1
    print(f'PASS: {len(expected)} file hashes match PACKAGE-MANIFEST.json')
    return 0


if __name__=='__main__':
    raise SystemExit(main())
