import copy
import importlib.util
import json
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("h3_validator", ROOT / "tools" / "validate_prompt.py")
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)


def example(name):
    return (ROOT / "examples" / name).read_text(encoding="utf-8")


class CoreTests(unittest.TestCase):
    def test_all_examples_pass(self):
        for path in sorted((ROOT / "examples").glob("*.txt")):
            with self.subTest(file=path.name):
                r=m.check(path.read_text(), duration=8)
                self.assertTrue(r["valid"], r["errors"])

    def test_base_four_modes(self):
        pairs=(('t2va-tattoo.txt','T2VA'), ('i2va-first-frame.txt','I2VA'), ('fl2va-dual-frame.txt','FL2VA'), ('l2va-last-frame.txt','L2VA'))
        for p,mode in pairs:
            with self.subTest(p=p):
                self.assertEqual(m.check(example(p), duration=8)["mode"], mode)

    def test_ref_mode(self):
        self.assertEqual(m.check(example('ref2va-identity-motion-voice.txt'), duration=8)['mode'], 'Ref2VA')

    def test_ref_assets_pass(self):
        a=json.loads((ROOT/'examples/ref-assets.example.json').read_text())
        self.assertTrue(m.check(example('ref2va-identity-motion-voice.txt'), duration=8, assets=a)['valid'])

    def test_asset_keyframes_good(self):
        for p, txt in [('i2va-first-frame.txt','i2va-assets.example.json'),('fl2va-dual-frame.txt','fl2va-assets.example.json'),('l2va-last-frame.txt','l2va-assets.example.json')]:
            with self.subTest(p=p):
                a=json.loads((ROOT/'examples'/txt).read_text())
                self.assertTrue(m.check(example(p),duration=8,assets=a)['valid'])

    def test_detect_mode(self):
        for filename in ('i2va-first-frame.txt', 'fl2va-dual-frame.txt', 'l2va-last-frame.txt', 'ref2va-video-continuation.txt'):
            self.assertNotEqual(m.detect_mode(example(filename)), 'T2VA')

    def test_ref_requires_assets_warn(self):
        x=m.check(example('ref2va-tattoo-detail.txt'), duration=8)
        self.assertIn('UNVERIFIED_ASSETS', [a['code'] for a in x['warnings']])

    def test_unmatched_assets_fail(self):
        a=json.loads((ROOT/'examples/ref-assets.example.json').read_text());a['assets'].pop()
        x=m.check(example('ref2va-identity-motion-voice.txt'),duration=8,assets=a)
        self.assertIn('MISSING_ASSET', [q['code'] for q in x['errors']])

    def test_empty(self):
        self.assertIn('EMPTY',[q['code'] for q in m.check('')['errors']])

    def test_mode_mismatch(self):
        x=m.check(example('t2va-tattoo.txt'),mode='Ref2VA',duration=8)
        self.assertFalse(x['valid'])

    def test_field_order(self):
        x=example('t2va-tattoo.txt').replace('overall_soundscape:', 'bad_sound_field:')
        self.assertIn('FIELD_ORDER',[q['code'] for q in m.check(x,duration=8)['errors']])

    def test_wrong_ref_schema(self):
        x=example('ref2va-tattoo-detail.txt').replace('detailed_description:', 'integrated_multimodal_description:')
        self.assertIn('FIELD_ORDER',[q['code'] for q in m.check(x,duration=8)['errors']])

    def test_alignment_wrong_i2(self):
        s=example('i2va-first-frame.txt').replace('0.00 seconds','0.10 seconds',1)
        self.assertIn('ALIGNMENT',[q['code'] for q in m.check(s,duration=8)['errors']])

    def test_alignment_wrong_fl_final(self):
        s=example('fl2va-dual-frame.txt').replace('8.00-second','7.00-second',1)
        self.assertIn('ANCHOR_DURATION',[q['code'] for q in m.check(s,duration=8)['errors']])

    def test_alignment_wrong_l_lastshot(self):
        s=example('l2va-last-frame.txt').replace('from [Shot 1]','from [Shot 2]',1)
        self.assertIn('ANCHOR_SHOT',[q['code'] for q in m.check(s,duration=8)['errors']])

    def test_alignment_blankline(self):
        s=example('i2va-first-frame.txt').replace('fully referenced.\n\n','fully referenced.\n',1)
        self.assertIn('ALIGNMENT_SPACING',[q['code'] for q in m.check(s,duration=8)['errors']])

    def test_duration_bad(self):
        self.assertIn('DURATION',[q['code'] for q in m.check(example('t2va-tattoo.txt'),duration=20)['errors']])

    def test_shot_nonsequential(self):
        s=example('t2va-tattoo.txt').replace('overall_soundscape:', '[Shot 3] At 00:03.000, the camera cuts to a bowl.\noverall_soundscape:',1)
        self.assertIn('SHOT_SEQUENCE',[q['code'] for q in m.check(s,duration=8)['errors']])

    def test_late_cut(self):
        s=example('t2va-tattoo.txt').replace('overall_soundscape:', '[Shot 2] At 00:08.000, the camera cuts to an arm.\noverall_soundscape:',1)
        self.assertIn('CUT_DURATION',[q['code'] for q in m.check(s,duration=8)['errors']])

    def test_cut_format(self):
        s=example('t2va-tattoo.txt').replace('overall_soundscape:', '[Shot 2] The shot cuts to an arm.\noverall_soundscape:',1)
        self.assertIn('CUT_FORMAT',[q['code'] for q in m.check(s,duration=8)['errors']])

    def test_first_shot_timestamp(self):
        s=example('t2va-tattoo.txt').replace('[Shot 1]','[Shot 1] At 00:00.000,',1)
        self.assertIn('FIRST_SHOT_TIME',[q['code'] for q in m.check(s,duration=8)['errors']])

    def test_dialogue_bad(self):
        s=example('t2va-dialogue.txt').replace('<d>[Chinese]','<d>')
        self.assertIn('DIALOGUE_FORMAT',[q['code'] for q in m.check(s,duration=8)['errors']])

    def test_dialogue_unclosed(self):
        s=example('t2va-dialogue.txt').replace('</d>','')
        self.assertIn('DIALOGUE_TAG',[q['code'] for q in m.check(s,duration=8)['errors']])

    def test_ref_undefined_subject(self):
        s=example('ref2va-tattoo-detail.txt').replace('The model slowly','<Subject 9> The model slowly')
        self.assertIn('UNRESOLVED_REFERENCE',[q['code'] for q in m.check(s,duration=8)['errors']])

    def test_ref_missing_retention(self):
        s=example('ref2va-tattoo-detail.txt').replace('<Subject 2> (appears in [Shot 1]):','Subject Two (appears in [Shot 1]):')
        self.assertIn('MISSING_RETENTION',[q['code'] for q in m.check(s,duration=8)['errors']])

    def test_ref_audio_only(self):
        a={'mode':'Ref2VA','duration':8,'assets':[{'label':'Audio 1','type':'audio','seconds':5}]}
        self.assertIn('AUDIO_ONLY_REF',[q['code'] for q in m.validate_assets(a,'Ref2VA',8)])

    def test_ref_video_total(self):
        a={'mode':'Ref2VA','duration':8,'assets':[{'label':'Picture 1','type':'image'},{'label':'Video 1','type':'video','seconds':9},{'label':'Video 2','type':'video','seconds':9}]}
        self.assertIn('ASSET_TOTAL_SECONDS',[q['code'] for q in m.validate_assets(a,'Ref2VA',8)])

    def test_ref_audio_total(self):
        a={'mode':'Ref2VA','duration':8,'assets':[{'label':'Picture 1','type':'image'},{'label':'Audio 1','type':'audio','seconds':10},{'label':'Audio 2','type':'audio','seconds':10}]}
        self.assertIn('ASSET_TOTAL_SECONDS',[q['code'] for q in m.validate_assets(a,'Ref2VA',8)])

    def test_ref_asset_count(self):
        a={'mode':'Ref2VA','duration':8,'assets':[{'label':f'Picture {i}','type':'image'} for i in range(1,11)]}
        self.assertIn('ASSET_LIMIT',[q['code'] for q in m.validate_assets(a,'Ref2VA',8)])

    def test_duplicate_assets(self):
        a={'mode':'Ref2VA','duration':8,'assets':[{'label':'Picture 1','type':'image'},{'label':'Picture 1','type':'image'}]}
        self.assertIn('DUPLICATE_ASSET',[q['code'] for q in m.validate_assets(a,'Ref2VA',8)])

    def test_invalid_keyframe_role(self):
        a={'mode':'I2VA','duration':8,'assets':[{'label':'Picture 1','type':'image','role':'last_frame'}]}
        self.assertIn('KEYFRAME_ROLE',[q['code'] for q in m.validate_assets(a,'I2VA',8)])

    def test_t2v_unexpected_assets(self):
        a={'mode':'T2VA','duration':8,'assets':[{'label':'Picture 1','type':'image'}]}
        self.assertIn('BASE_ASSETS',[q['code'] for q in m.validate_assets(a,'T2VA',8)])


    def test_positive_two_shot_t2va(self):
        r=m.check(example('t2va-two-shot-8s.txt'),duration=8)
        self.assertTrue(r['valid'],r['errors'])
        self.assertEqual(r['shot_count'],2)
        self.assertEqual(r['cut_times'],[4.0])

    def test_positive_two_shot_ref(self):
        r=m.check(example('ref2va-two-shot-8s.txt'),duration=8)
        self.assertTrue(r['valid'],r['errors'])
        self.assertEqual(r['shot_count'],2)

    def test_out_of_order_cuts(self):
        s=example('t2va-two-shot-8s.txt').replace('overall_soundscape:', '[Shot 3] At 00:02.000, the camera cuts to a pocket.\noverall_soundscape:',1)
        self.assertIn('CUT_ORDER',[q['code'] for q in m.check(s,duration=8)['errors']])

    def test_ref_limit_total_12(self):
        imgs=[{'label':f'Picture {i}', 'type':'image'} for i in range(1,10)]
        vids=[{'label':f'Video {i}', 'type':'video','seconds':3} for i in range(1,4)]
        aud=[{'label':'Audio 1','type':'audio','seconds':3}]
        a={'mode':'Ref2VA','duration':8,'assets':imgs+vids+aud}
        self.assertIn('ASSET_LIMIT',[q['code'] for q in m.validate_assets(a,'Ref2VA',8)])

    def test_ref_audio_clip_under_two(self):
        a={'mode':'Ref2VA','duration':8,'assets':[{'label':'Picture 1','type':'image'},{'label':'Audio 1','type':'audio','seconds':1}]}
        self.assertIn('ASSET_CLIP_DURATION',[q['code'] for q in m.validate_assets(a,'Ref2VA',8)])

    def test_prompts_are_below_limit(self):
        for p in (ROOT/'examples').glob('*.txt'):
            self.assertLessEqual(len(p.read_text()),7000,p.name)

    def test_source_integrity(self):
        for fn in ['SKILL.md','MASTER-PROMPT.md','README.md','SOURCES.md','LICENSE', 'references/h3-format.md']:
            self.assertTrue((ROOT/fn).exists(),fn)

    def test_version_and_all_modes_documented(self):
        s=(ROOT/'SKILL.md').read_text()
        self.assertIn('version: 2.0.0',s)
        for k in m.MODES:
            self.assertIn(k,s)

    def test_no_secret_markers_in_docs(self):
        # Narrow document-level credential leak check; not a substitute for review.
        combined='\n'.join(p.read_text(encoding='utf8') for p in ROOT.rglob('*.md'))
        for token in ('-----BEGIN PRIVATE KEY-----', 'sk-proj-', 'ghp_', 'AKIA'):
            self.assertNotIn(token,combined)


if __name__=='__main__':
    unittest.main()
