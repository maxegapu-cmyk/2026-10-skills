# 公开资料来源、原创界限与核验日期

核验日期：2026-10-22。以下均为公开网页，不携带其代码或长篇文档正文。

1. MiniMax H3 官方仓库及型号/输入限制： https://github.com/MiniMax-AI/MiniMax-H3
2. MiniMax H3 官方提示词 Skill： https://github.com/MiniMax-AI/MiniMax-H3/blob/main/skills/h3-prompt-writing/SKILL.md
3. 官方基础四模式格式： https://github.com/MiniMax-AI/MiniMax-H3/blob/main/skills/h3-prompt-writing/references/base-en.txt
4. 官方 Ref2VA 六字段格式： https://github.com/MiniMax-AI/MiniMax-H3/blob/main/skills/h3-prompt-writing/references/ref-en.txt
5. MiniMax CLI H3 媒体 preflight： https://github.com/MiniMax-AI/cli/blob/main/skill/h3-video/references/h3-video.md
6. 公开社区功能设计对照（不视为官方基准）： https://github.com/q2522879285-source/minimax-h3-prompting-skill-public

**使用方法**：仅采纳必要的官方字段、固定锚定句、约束事实与通用方案思路；所有正文、流程、示例、校验程序是独立编写，未复制 GitHub 仓库结构、历史、源码或第三方提示词正文。此包不包含任何用户私有的导演系统、个人知识库、私有提示词素材与历史附件。

引用官方接口名及其固定句式是兼容性必需；原始 MiniMax 商标和模型名归各自权利人所有，本项目无官方背书。
