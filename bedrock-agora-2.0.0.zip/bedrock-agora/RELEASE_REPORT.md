# Bedrock Agora 2.0.0 — 本地执行报告

日期：2026-10-23。**基于原 1.0.0 压缩包原文件继承升级**，不是创建重名新产品。保留原始 ZIP 文件，不覆盖。

## 原版与升级工作

- 原版唯一入口 `SKILL.md`；三个模式 `DECIDE / FORGE / BRIDGE`；原三个 CLI `forge_skill.py`、`validate_skill.py`、`audit_decision.py`、原 JSON 合同与示例均保留；修复 `forge_skill.py` 在 `python -I` 隔离运行时找不到同目录校验器的问题。
- 独立解压原版到与 frontmatter 名称相同的目录，实际运行 **21 项 unittest 全通过**。
- 新版本使第一性原理具体化为“目标—因果机制—必要条件—替代解释—证伪信号—可逆试验—决策变化”。新增 `references/first-principles-engine.md`、`scripts/audit_mechanisms.py`、`assets/mechanism-ledger-example.json` 和负例测试。
- 改进 FORGE 创作/升级：`references/upgrade-protocol.md`、`references/evaluation.md`；先建立基线并复现失败，再最小修复，保护旧版，测试/打包，并留下无 Skill/旧 Skill/新 Skill 的公平比较协议。
- 新增 `examples/first-principles-case.md`、`evals/semantic-v2.json`（12个**待执行**语义评测任务）；沿用 `references/skill-forge.md` 和原客服示例。
- `agents/openai.yaml` 更改默认触发提示，保留公开入口及结构。

## 已在开发目录实际运行

- 环境：Linux，Python 3.13.5，标准库，不需要第三方依赖。
- `python -I -B -m unittest discover -s tests -q`：**37项通过**，包含原21项与新16项。
- `python -I -B scripts/validate_skill.py .`：通过。
- `python -I -B scripts/audit_mechanisms.py assets/mechanism-ledger-example.json`：结构通过，明确打印**证据仍未独立核实**。
- 原 `forge_skill.py` 从非项目目录完成创建/拒绝覆盖测试；原 CLI 行为回归通过。

## 没有完成/不能声称的事项

- 没有在 Python 3.9 解释器真实运行；发布构建将另做 3.9 语法层验证，**不等于运行验证**。
- 没有真实 Claude Code、Codex 多模型联调与自动触发率测量，没有盲化人工评分、真实企业客户试验、任何“提高百分之几”的质量结论。
- 审查工具验证结构和事实来源字段的**存在性**，不能证明来源真实。

最终 ZIP 哈希、全部校验条目、干净目录重解压测试的实际结果见发布包外的 `DUAL_SKILLS_发布复验.md`。
