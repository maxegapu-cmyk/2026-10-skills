"""V2 contract regressions. These are deterministic tests, not LLM quality tests."""
import copy
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
from audit_mechanisms import audit
from forge_skill import validate_spec

class TestV2(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.sample = json.loads((ROOT / 'assets/mechanism-ledger-example.json').read_text(encoding='utf-8'))

    def test_sample_structure(self):
        errors, warnings = audit(self.sample)
        self.assertEqual([], errors)
        self.assertTrue(any('not independently verified' in w for w in warnings))

    def test_root_bad(self):
        self.assertTrue(audit(['bad'])[0])

    def test_no_claim_laundering(self):
        s=copy.deepcopy(self.sample)
        s['mechanisms'][0]['evidence_status']='source_checked'
        self.assertTrue(any('requires source' in x for x in audit(s)[0]))

    def test_missing_falsifier(self):
        s=copy.deepcopy(self.sample)
        s['mechanisms'][0]['failure_signal']='   '
        self.assertTrue(any('failure_signal' in x for x in audit(s)[0]))

    def test_missing_mechanism_mediator(self):
        s=copy.deepcopy(self.sample)
        s['mechanisms'][0]['mediator']=''
        self.assertTrue(any('mediator' in x for x in audit(s)[0]))

    def test_critical_preservation(self):
        s=copy.deepcopy(self.sample)
        s['mechanisms'][0].pop('preserve')
        self.assertTrue(any('preserve' in x for x in audit(s)[0]))

    def test_forged_decision(self):
        s=copy.deepcopy(self.sample)
        s['decision']['depends_on']='not-a-card'
        self.assertTrue(any('depends_on' in x for x in audit(s)[0]))

    def test_duplicates(self):
        s=copy.deepcopy(self.sample)
        s['mechanisms'].append(copy.deepcopy(s['mechanisms'][0]))
        self.assertTrue(any('duplicate mechanism id' in x for x in audit(s)[0]))

    def test_invalid_decision(self):
        s=copy.deepcopy(self.sample)
        s['decision']['state']='approved_already'
        self.assertTrue(any('decision.state' in x for x in audit(s)[0]))

    def test_unknown_evidence_status(self):
        s=copy.deepcopy(self.sample)
        s['mechanisms'][0]['evidence_status']='invented'
        self.assertTrue(any('evidence_status' in x for x in audit(s)[0]))

    def test_adversarial_bad_status_is_safe_error(self):
        s=copy.deepcopy(self.sample)
        s["mechanisms"][0]["evidence_status"]=["bad"]
        self.assertTrue(any("evidence_status invalid" in x for x in audit(s)[0]))

    def test_cli_negative_and_positive(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td) / 'fail.json'
            p.write_text('{"goal":"x"}', encoding='utf-8')
            c=subprocess.run([sys.executable,'-B',str(ROOT/'scripts/audit_mechanisms.py'),str(p)],capture_output=True,text=True,cwd=td)
            self.assertNotEqual(c.returncode,0)
            c=subprocess.run([sys.executable,'-B',str(ROOT/'scripts/audit_mechanisms.py'),str(ROOT/'assets/mechanism-ledger-example.json')],capture_output=True,text=True,cwd=td)
            self.assertEqual(c.returncode,0,c.stderr)
            self.assertIn('NOT verified',c.stdout)

    def test_semantic_cases_have_valid_types(self):
        cases=json.loads((ROOT/'evals/semantic-v2.json').read_text(encoding='utf-8'))['cases']
        self.assertGreaterEqual(len(cases),10)
        self.assertEqual(len(set(x['id'] for x in cases)),len(cases))
        for x in cases:
            self.assertIn(x['mode'],('DECIDE','FORGE','BRIDGE'))
            self.assertTrue(x['must'])
            self.assertTrue(x['must_not'])

    def test_backward_compatibility_original_spec(self):
        spec=json.loads((ROOT/'assets/skill-brief-example.json').read_text(encoding='utf-8'))
        self.assertEqual(spec, validate_spec(spec))

    def test_forge_from_isolated_foreign_cwd(self):
        with tempfile.TemporaryDirectory() as td:
            dst=Path(td)/"output"
            proc=subprocess.run([sys.executable,"-I","-B",str(ROOT/"scripts/forge_skill.py"),"--spec",str(ROOT/"assets/skill-brief-example.json"),"--out",str(dst)],cwd=td,capture_output=True,text=True)
            self.assertEqual(0,proc.returncode,proc.stderr)
            self.assertTrue((dst/"customer-service-triage/SKILL.md").exists())

    def test_original_modules_remain(self):
        for name in ('forge_skill.py','audit_decision.py','validate_skill.py'):
            self.assertTrue((ROOT/'scripts'/name).is_file())
        for mode in ('DECIDE','FORGE','BRIDGE'):
            self.assertIn(mode,(ROOT/'SKILL.md').read_text(encoding='utf-8'))

if __name__=='__main__':
    unittest.main()
