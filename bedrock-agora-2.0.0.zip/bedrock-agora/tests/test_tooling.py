"""Negative/positive deterministic tests; intentionally NOT model behavior tests."""
import copy
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"
sys.path.insert(0, str(SCRIPTS))
from forge_skill import emit, SpecError, validate_spec  # noqa
from validate_skill import check
from audit_decision import audit


def load(name):
    return json.loads((ROOT / "assets" / name).read_text(encoding="utf-8"))


class TestSkillFormat(unittest.TestCase):
    def test_release_skill_valid(self):
        self.assertEqual([], check(ROOT))

    def test_bad_name_and_broken_link(self):
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp) / "bad-name"
            p.mkdir()
            (p / "SKILL.md").write_text('---\nname: Invalid_Name\ndescription: "test"\n---\n\n[bad](references/absent.md)', encoding="utf-8")
            errors = check(p)
            self.assertTrue(any("invalid name" in x for x in errors))
            self.assertTrue(any("broken link" in x for x in errors))

    def test_placeholder_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp) / "placeholder"
            p.mkdir()
            (p / "SKILL.md").write_text('---\nname: placeholder\ndescription: "test"\n---\n\nTODO', encoding="utf-8")
            self.assertTrue(any("unfinished placeholders" in x for x in check(p)))


class TestForge(unittest.TestCase):
    def setUp(self):
        self.spec = load("skill-brief-example.json")

    def test_generate_and_validate(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder = emit(self.spec, Path(tmp))
            self.assertEqual([], check(folder))
            text = (folder / "SKILL.md").read_text(encoding="utf-8")
            self.assertIn("客户", text)
            self.assertIn("## 失败与退出", text)
            self.assertEqual(6, len(json.loads((folder / "assets" / "evals.json").read_text(encoding="utf-8"))))
            self.assertTrue((folder / "references" / "domain-rules.md").is_file())

    def test_refuse_overwrite(self):
        with tempfile.TemporaryDirectory() as tmp:
            emit(self.spec, Path(tmp))
            with self.assertRaisesRegex(SpecError, "refusing to overwrite"):
                emit(self.spec, Path(tmp))

    def test_prevent_reference_traversal(self):
        s = copy.deepcopy(self.spec)
        s["references"][0]["filename"] = "../../escape.md"
        with self.assertRaisesRegex(SpecError, "safe .md"):
            validate_spec(s)

    def test_need_all_test_kinds(self):
        s = copy.deepcopy(self.spec)
        s["tests"][4]["kind"] = "positive"
        with self.assertRaisesRegex(SpecError, "tests must include"):
            validate_spec(s)

    def test_reject_non_bool_required(self):
        s = copy.deepcopy(self.spec)
        s["inputs"][0]["required"] = "yes"
        with self.assertRaisesRegex(SpecError, "true/false"):
            validate_spec(s)

    def test_reject_duplicate_test_ids(self):
        s = copy.deepcopy(self.spec)
        s["tests"][1]["id"] = s["tests"][0]["id"]
        with self.assertRaisesRegex(SpecError, "unique"):
            validate_spec(s)

    def test_reject_nul_input(self):
        s = copy.deepcopy(self.spec)
        s["domain"] = "bad\x00injected"
        with self.assertRaisesRegex(SpecError, "NUL"):
            validate_spec(s)

    def test_no_residue_after_invalid_generate(self):
        with tempfile.TemporaryDirectory() as tmp:
            s = copy.deepcopy(self.spec)
            s["tests"][0]["kind"] = "unknown"
            with self.assertRaises(SpecError):
                emit(s, Path(tmp))
            self.assertFalse(list(Path(tmp).iterdir()))


class TestDecisionAudit(unittest.TestCase):
    def setUp(self):
        self.good = load("decision-example.json")

    def test_positive_synthetic_record(self):
        errors, warnings = audit(self.good)
        self.assertEqual([], errors)
        self.assertTrue(warnings)  # fictional data deliberately unverified

    def test_missing_baseline(self):
        s = copy.deepcopy(self.good)
        s["options"][0]["kind"] = "alternative"
        errors, _ = audit(s)
        self.assertTrue(any("baseline" in x for x in errors))

    def test_verified_requires_source(self):
        s = copy.deepcopy(self.good)
        s["evidence"][0]["kind"] = "verified"
        errors, _ = audit(s)
        self.assertTrue(any("requires source" in x for x in errors))

    def test_invalid_recommendation(self):
        s = copy.deepcopy(self.good)
        s["recommendation"]["option_id"] = "not-an-option"
        s["recommendation"]["stop_conditions"] = []
        errors, _ = audit(s)
        self.assertTrue(any("does not match" in x for x in errors))
        self.assertTrue(any("stop_conditions" in x for x in errors))

    def test_empty_options(self):
        s = copy.deepcopy(self.good)
        s["options"] = []
        errors, _ = audit(s)
        self.assertTrue(any("three options" in x for x in errors))

    def test_nonstring_option_id_safe_fail(self):
        s = copy.deepcopy(self.good)
        s["options"][0]["id"] = ["bad"]
        errs, _ = audit(s)
        self.assertTrue(any("missing id" in x for x in errs))

    def test_non_dict_safe_fail(self):
        errs, _ = audit([1, 2])
        self.assertTrue(errs)


class TestCommandLine(unittest.TestCase):
    def test_help_from_other_working_directory(self):
        with tempfile.TemporaryDirectory() as tmp:
            for script in ("forge_skill.py", "audit_decision.py", "validate_skill.py"):
                proc = subprocess.run([sys.executable, "-B", str(SCRIPTS / script), "--help"],
                                      cwd=tmp, capture_output=True, text=True, timeout=10)
                self.assertEqual(0, proc.returncode, (script, proc.stderr))

    def test_cli_missing_file_exits_nonzero(self):
        with tempfile.TemporaryDirectory() as tmp:
            proc = subprocess.run([sys.executable, "-B", str(SCRIPTS / "audit_decision.py"), "missing.json"],
                                  cwd=tmp, capture_output=True, text=True, timeout=10)
            self.assertNotEqual(0, proc.returncode)

    def test_generate_cli_from_elsewhere(self):
        with tempfile.TemporaryDirectory() as tmp:
            proc = subprocess.run([sys.executable, "-B", str(SCRIPTS / "forge_skill.py"), "--spec",
                                   str(ROOT / "assets" / "skill-brief-example.json"), "--out", str(Path(tmp) / "out")],
                                  cwd=tmp, capture_output=True, text=True, timeout=10)
            self.assertEqual(0, proc.returncode, proc.stderr)
            self.assertEqual([], check(Path(tmp) / "out" / "customer-service-triage"))


if __name__ == "__main__":
    unittest.main()
