#!/usr/bin/env python3
"""Structural audit of a first-principles mechanism ledger; does not fact-check."""
from __future__ import annotations
import argparse
import json
import sys
from pathlib import Path

STATUSES = {"source_checked", "user_report", "inference", "assumption", "unknown", "value"}

def filled(x):
    return isinstance(x, str) and bool(x.strip())

def audit(data):
    errors, warnings = [], []
    if not isinstance(data, dict):
        return ["root must be object"], []
    for f in ("goal", "success_observation", "baseline", "owner"):
        if not filled(data.get(f)):
            errors.append("missing " + f)
    constraints = data.get("constraints")
    if not isinstance(constraints, list) or not constraints or not all(filled(x) for x in constraints):
        errors.append("constraints must be nonempty strings")
    cards = data.get("mechanisms")
    if not isinstance(cards, list) or not cards:
        return errors + ["mechanisms must be a nonempty list"], warnings
    ids = []
    for i, card in enumerate(cards):
        if not isinstance(card, dict):
            errors.append("mechanisms[%d] must be object" % i)
            continue
        if not filled(card.get("id")):
            errors.append("mechanisms[%d].id missing" % i)
        else:
            ids.append(card["id"])
        for f in ("claim", "action", "mediator", "observable_effect", "necessary_condition",
                  "alternate_explanation", "failure_signal", "low_cost_test", "decision_change", "preserve"):
            if not filled(card.get(f)):
                errors.append("mechanisms[%d].%s missing" % (i, f))
        status = card.get("evidence_status")
        if not isinstance(status, str) or status not in STATUSES:
            errors.append("mechanisms[%d].evidence_status invalid" % i)
        if status == "source_checked" and not filled(card.get("source")):
            errors.append("mechanisms[%d] source_checked requires source locator" % i)
        if status in ("unknown", "assumption", "inference"):
            warnings.append("mechanisms[%d] is not independently verified" % i)
    if len(set(ids)) != len(ids):
        errors.append("duplicate mechanism id")
    verdict = data.get("decision")
    if not isinstance(verdict, dict):
        errors.append("decision object required")
    else:
        if verdict.get("state") not in ("act", "pilot", "pause", "reject"):
            errors.append("decision.state invalid")
        for f in ("reason", "stop_rule", "review_point"):
            if not filled(verdict.get(f)):
                errors.append("decision.%s missing" % f)
        if verdict.get("depends_on") not in ids:
            errors.append("decision.depends_on must match mechanism id")
    return errors, warnings

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("ledger", type=Path)
    args = p.parse_args()
    try:
        data = json.loads(args.ledger.read_text(encoding="utf-8-sig"))
        errors, warnings = audit(data)
    except (OSError, UnicodeError, json.JSONDecodeError) as ex:
        print("FAIL: %s" % ex, file=sys.stderr)
        return 1
    for w in warnings:
        print("WARNING: " + w)
    for err in errors:
        print("ERROR: " + err)
    print("PASS: ledger structurally valid (evidence NOT verified)" if not errors else "FAIL: ledger invalid")
    return bool(errors)

if __name__ == "__main__":
    sys.exit(main())
