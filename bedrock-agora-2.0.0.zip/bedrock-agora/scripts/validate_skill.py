#!/usr/bin/env python3
"""Dependency-free structural checker for portable Agent Skills.

This is intentionally NOT a behavioral or domain-correctness evaluator.
"""
from __future__ import annotations
import argparse
import json
import re
import sys
from pathlib import Path

NAME = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
LINK = re.compile(r"(?<!!)\[[^]]*\]\(([^)]+)\)")


def _scalar(value: str) -> str:
    value = value.strip()
    if not value:
        return ""
    if value.startswith('"'):
        try:
            parsed = json.loads(value)
            if isinstance(parsed, str):
                return parsed
        except json.JSONDecodeError:
            pass
    if value.startswith("'") and value.endswith("'"):
        return value[1:-1].replace("''", "'")
    return value


def check(path: Path) -> list[str]:
    errors: list[str] = []
    root = path.resolve()
    if not root.is_dir():
        return [f"not a skill directory: {path}"]
    entry = root / "SKILL.md"
    if not entry.is_file():
        return ["missing SKILL.md"]
    content = entry.read_text(encoding="utf-8-sig")
    match = re.match(r"\A---\s*\n(.*?)\n---\s*\n", content, flags=re.S)
    if not match:
        return ["SKILL.md missing frontmatter delimiters"]
    metadata: dict[str, str] = {}
    for line in match.group(1).splitlines():
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        found = re.fullmatch(r"([A-Za-z][A-Za-z0-9_-]*):\s*(.*?)\s*", line)
        if not found:
            errors.append("frontmatter must use single-line key: value fields")
            continue
        k, v = found.groups()
        if k in metadata:
            errors.append(f"duplicate field {k}")
        metadata[k] = _scalar(v)
    name = metadata.get("name", "")
    description = metadata.get("description", "")
    if not NAME.fullmatch(name) or len(name) > 64:
        errors.append("invalid name (lowercase hyphen-case, 1-64 chars)")
    if name != root.name:
        errors.append(f"name '{name}' must equal folder '{root.name}'")
    if not description or len(description) > 1024:
        errors.append("description must be 1-1024 characters")
    if not content[match.end():].strip():
        errors.append("SKILL.md body is empty")
    if re.search(r"(?:\bTODO\b|\bTBD\b|\[PLACEHOLDER\])", content, flags=re.I):
        errors.append("SKILL.md has unfinished placeholders")
    for target in LINK.findall(content):
        target = target.split("#")[0].strip()
        target = target.split()[0] if target else ""
        if not target or re.match(r"^[a-z]+://", target) or target.startswith("mailto:"):
            continue
        dest = (root / target).resolve()
        if not dest.is_relative_to(root):
            errors.append(f"out-of-tree link: {target}")
        elif not dest.exists():
            errors.append(f"broken link: {target}")
    return errors


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("path", type=Path)
    ap.add_argument("--json", action="store_true", help="Print machine-readable result")
    args = ap.parse_args()
    errs = check(args.path)
    if args.json:
        print(json.dumps({"ok": not errs, "errors": errs}, ensure_ascii=False, indent=2))
    else:
        print("PASS: skill structure valid" if not errs else "FAIL:\n" + "\n".join(f" - {e}" for e in errs))
    return 0 if not errs else 1


if __name__ == "__main__":
    sys.exit(main())
