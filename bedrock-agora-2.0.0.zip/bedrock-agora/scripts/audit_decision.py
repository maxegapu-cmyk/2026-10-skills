#!/usr/bin/env python3
"""Check decision-record coverage; never assert that the decision is correct."""
from __future__ import annotations
import argparse
import json
import sys
from pathlib import Path


FIELDS = ("question", "goal", "horizon", "decision_owner")


def nonempty(x):
    return isinstance(x, str) and bool(x.strip())


def audit(data):
    errors, warnings = [], []
    if not isinstance(data, dict):
        return ["root must be JSON object"], []
    for field in FIELDS:
        if not nonempty(data.get(field)):
            errors.append(f"missing {field}")
    if not isinstance(data.get("constraints"), list) or not data["constraints"]:
        errors.append("constraints must be nonempty list")
    evidence = data.get("evidence")
    if not isinstance(evidence, list) or not evidence:
        errors.append("evidence ledger required")
    else:
        for i, ev in enumerate(evidence):
            if not isinstance(ev, dict) or not nonempty(ev.get("claim")):
                errors.append(f"evidence[{i}] missing claim")
                continue
            if ev.get("kind") not in ("verified", "user_report", "assumption", "unknown", "inference"):
                errors.append(f"evidence[{i}].kind invalid")
            if ev.get("kind") == "verified" and not nonempty(ev.get("source")):
                errors.append(f"evidence[{i}] verified requires source")
    options = data.get("options")
    ids = []
    if not isinstance(options, list) or len(options) < 3:
        errors.append("at least three options required")
    else:
        for i, op in enumerate(options):
            if not isinstance(op, dict):
                errors.append(f"options[{i}] must be object")
                continue
            for f in ("id", "name", "mechanism", "upside", "downside", "reversibility", "minimum_test"):
                if not nonempty(op.get(f)):
                    errors.append(f"options[{i}] missing {f}")
            if op.get("kind") not in ("baseline", "pilot", "structural", "alternative"):
                errors.append(f"options[{i}].kind invalid")
            if nonempty(op.get("id")):
                ids.append(op["id"])
        if len(set(ids)) < len(ids):
            errors.append("option IDs must be unique")
        if not any(isinstance(x, dict) and x.get("kind") == "baseline" for x in options):
            errors.append("baseline / no-change option required")
    unknowns = data.get("unknowns")
    if not isinstance(unknowns, list) or not unknowns:
        errors.append("one or more unknowns and verification plans required")
    else:
        for i, row in enumerate(unknowns):
            if not isinstance(row, dict) or not all(nonempty(row.get(k)) for k in ("question", "impact", "test")):
                errors.append(f"unknowns[{i}] missing question/impact/test")
    rec = data.get("recommendation")
    if not isinstance(rec, dict):
        errors.append("recommendation object required")
    else:
        if rec.get("option_id") not in ids:
            errors.append("recommendation.option_id does not match any option")
        for f in ("reason", "review_date", "decision_gate"):
            if not nonempty(rec.get(f)):
                errors.append(f"recommendation missing {f}")
        if not isinstance(rec.get("stop_conditions"), list) or not rec["stop_conditions"]:
            errors.append("recommendation.stop_conditions required")
    if isinstance(evidence, list) and evidence and not any(isinstance(x, dict) and x.get("kind") in ("verified", "user_report") for x in evidence):
        warnings.append("all evidence is assumed/unknown/inferred; no grounded business recommendation may be asserted")
    return errors, warnings


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("record", type=Path)
    args = ap.parse_args()
    try:
        data = json.loads(args.record.read_text(encoding="utf-8-sig"))
        errors, warnings = audit(data)
    except (OSError, json.JSONDecodeError) as exc:
        print(f"FAIL: {exc}", file=sys.stderr)
        return 1
    for w in warnings:
        print("WARNING: " + w)
    for e in errors:
        print("ERROR: " + e)
    print("PASS: decision record structurally complete (not fact-checked)" if not errors else "FAIL: incomplete decision record")
    return 0 if not errors else 1


if __name__ == "__main__":
    sys.exit(main())
