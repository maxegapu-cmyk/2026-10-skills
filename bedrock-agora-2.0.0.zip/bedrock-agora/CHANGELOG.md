# Changelog

## 2.0.0 — 2026-10-23

- 从 **1.0.0 原版**升级，保留 DECIDE/FORGE/BRIDGE 和原有三个 CLI / JSON 合同与示例。
- 第一性原理落到可观察的因果机制、承重假设、反事实、可逆实验；增加独立结构检查器。
- FORGE 增加“复现失败→保护旧优点→最小修复→回归→同预算盲评→ZIP复验”的可靠升级流程。
- 新增跨领域贯穿示例、行为评测材料，禁止用自评分或纯格式检查冒充效果提升。
- 修复 `forge_skill.py` 在 `python -I` 隔离模式下无法导入同目录校验器的真实失败，新增外部工作目录回归；不增加第三方依赖。

## 1.0.0 — 2026-10-20

- Three modes: DECIDE, FORGE, BRIDGE. Decision audit, skill compilation and structural validation.
