# Bedrock Agora 2.0.0｜原点议事引擎

从 1.0.0 原产品继承升级，保持 DECIDE / FORGE / BRIDGE 三入口及原脚本调用兼容；默认中文，Python 3.9+ 标准库，公开教学/跨领域使用。

**安装**：将 `bedrock-agora/` 整个目录放在 `.claude/skills/bedrock-agora/` 或 `.agents/skills/bedrock-agora/`，入口 `SKILL.md`。没有联网也能读提示和运行确定性校验。

**触发示例**：
- `DECIDE：从第一性原理重新判断我们的员工培训问题`；
- `FORGE：为在线客服制作边界明确、能测试的 Skill`；
- `FORGE：读完旧版 Skill，先复现真实失败再升级，不能用自评分当证据`；
- `BRIDGE：先确认业务问题，再把稳定的流程做成 Skill`。

**真实工具**：
```bash
python scripts/validate_skill.py .
python scripts/audit_decision.py assets/decision-example.json
python scripts/audit_mechanisms.py assets/mechanism-ledger-example.json
python scripts/forge_skill.py --spec assets/skill-brief-example.json --out ./generated
python -B -m unittest discover -s tests -v
```

执行示例会在 `./generated` 创建新目录，不覆盖既有文件。脚本不做联网研究/模型推理/发布，不代表生成的 Skill 已在真实模型中成功触发。对比评测模板和外部验证边界见 `references/evaluation.md`。

升级证据与源资料在 `RELEASE_REPORT.md`、`references/source-notes.md`。MIT License。
