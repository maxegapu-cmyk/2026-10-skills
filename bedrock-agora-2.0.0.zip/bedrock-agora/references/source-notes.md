# 公开来源与研究脉络（2026-10-20 检索）

本项目文字、结构、代码为单独编写。下列资料用于查明公开 Skill 规范及决策思想的可用要点；**没有复制第三方仓库代码**。

## 工程规范

1. Agent Skills 官方开放规范：https://agentskills.io/specification ；仓库：https://github.com/agentskills/agentskills 。`SKILL.md` 结构、元数据约束、按需加载。
2. OpenAI 官方 Skill Creator：https://github.com/openai/skills/blob/main/skills/.system/skill-creator/SKILL.md 。支持把资源移至 references / scripts，避免正文浪费上下文。
3. Anthropic 官方 Skill Creator：https://github.com/anthropics/skills/blob/main/skills/skill-creator/SKILL.md 。技能质量需在具体任务上使用测试集迭代，结构验证只是第一步。

## GitHub 思维 Skill 对标

4. 第一性原理：https://github.com/awesome-skills/first-principles-skill —— 从问题、假设、底层事实向上推导；本项目要求额外落到真实决策与执行门槛。
5. 思维模型库：https://github.com/darnoux/mental-models-os —— 不把多个模型当作名词清单，按情境操作。
6. 预验尸：https://github.com/MADEVAL/Pre-Mortem-Skill —— 主动构造失败场景，本项目把止损信号与成本列为显式字段。
7. 有证据的辩论：https://github.com/Bluear7878/AI-Colosseum-Debate —— 参考独立阶段、有限辩论和裁决记录的概念；本项目不需要依赖多智能体运行环境。
8. 决策记录标准示例：https://adr.github.io/adr-templates/ —— 记录语境、备选方案、代价、后果。

## 方法与反证

9. Gary Klein, Performing a Project Premortem, Harvard Business Review (2007)：https://hbr.org/2007/09/performing-a-project-premortem 。失败前找反对理由的实践基础。
10. Stanford Encyclopedia of Philosophy, Abduction (2025 修订)：https://plato.stanford.edu/entries/abduction/ 。竞争解释不等于已证事实。
11. Stanford Encyclopedia of Philosophy, Science and Pseudo-Science：https://plato.stanford.edu/entries/pseudo-science/ 。波普尔证伪讨论针对经验命题；价值问题不能简单照搬。
12. Debate Only When Necessary (2025)：https://arxiv.org/abs/2504.05047 —— 按必要性启动辩论更经济；**论文效果依赖其具体评测设置，不能推论本 Skill 实际提升数值**。
13. Can LLM Agents Really Debate? (2025)：https://arxiv.org/abs/2511.07784 —— 多数压力可能妨碍独立纠错；因此不以“所有角色达成共识”作为正确标准。
14. NIST AI Risk Management Framework：https://www.nist.gov/itl/ai-risk-management-framework 。涉及企业 AI 或高风险业务场景参考其自愿性风险管理方向，而非充当合规认证。

## 能力边界

- 结构、脚本与示例可以本地运行验证。
- “公司重大决策质量”“模型多轮对谈能力”“任意行业成功率”不能由静态工具验证，必须用真实资料和对照实验。
- 参考资料只是研究线索，不构成商用许可自动授予；本包没有收录其代码。

## 2.0 再查证的公开工程思路（2026-10-23）

- [obra/superpowers](https://github.com/obra/superpowers) — 先确立真实问题，再实现与测试，强调在完成前验证；本包不照搬其强制多代理或必须先审批的流程。
- [anthropics/skills 的 skill-creator](https://github.com/anthropics/skills/blob/main/skills/skill-creator/SKILL.md) — 保持按需加载与基线/改进版对照评测；**没有在本次构建中宣称执行了真实模型盲评**。
- [phuryn/pm-skills strategy-red-team](https://github.com/phuryn/pm-skills/blob/main/pm-execution/skills/strategy-red-team/SKILL.md) — 将反方质询聚焦于承重假设、廉价验证与停止条件；Bedrock 保持决策与 Skill 构建为主，不成为纯反方 Skill。

外部灵感仅借用公开方法，全部新增文本、示例、Python 检查器均独立编写。未复制第三方代码/独创表述。
