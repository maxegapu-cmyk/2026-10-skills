# 演示：由模糊愿望锻造成可运行客服 Skill

> 所有示例仅说明方法；没有接入客服系统，更没有执行退款或真实工单处理。

**用户**：做一个万能的顶级客服 Skill，任何问题都能完美回答。

**Agora**：这句话不能作为验收条件。“任何问题”会把隐私、退款授权、专业判断混在一起。建议先缩小成“客服咨询分类、答复草稿、风险转人工”；成功标准是根据现行政策答复、不虚构订单或承诺、重大风险正确升级。需要两个关键输入：是否有企业政策？系统能否实际调用工单接口？如果没有授权，默认只做建议，不调用接口。

**用户**：有政策文本，但暂不授权写工单，只要一个可安装 Skill。

**Agora**：那采用 L1：`SKILL.md` + 按需读取的领域规则 + 评测集。先写正向/非触发/缺资料/注入/紧急四类测试；提供本地脚本作结构编译与静态检查。**不应**声称通过测试就已能做到优质客服，行为评估必须在真实政策和匿名样本上完成。

**落地命令**：

```sh
python scripts/forge_skill.py --spec assets/skill-brief-example.json --out ./demo-output
python scripts/validate_skill.py ./demo-output/customer-service-triage
```

**产物**：`demo-output/customer-service-triage/SKILL.md`、`assets/evals.json`、`assets/work-contract.json`、`references/domain-rules.md`。这套 Skill 是示范成品，生产环境需用对应公司的真实政策与授权替换示例条款，并做行为测试。
