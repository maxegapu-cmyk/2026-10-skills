#!/usr/bin/env python3
"""Dependency-free consistency checker for an Echo Street season planning manifest.

This checks JSON structure and cross references only. It cannot grade stories,
verify platform rules or prove child appropriateness/rights clearance.
"""
from __future__ import annotations
import argparse
import json
import re
import sys
from pathlib import Path

REQUIRED_EP_FIELDS = (
    "episode_id", "title", "audible_anomaly", "initial_reading",
    "reinterpreted_truth", "character_cost", "closure", "season_seed", "cue_ids"
)
REQUIRED_CUE_FIELDS = ("source", "distinctive_attribute", "first_episode")

def validate(data: object, min_episodes: int = 1) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    warnings: list[str] = []
    if not isinstance(data, dict):
        return ["root: expected a JSON object"], warnings
    if data.get("schema_version") != "1.0":
        errors.append("schema_version: expected '1.0'")
    if not isinstance(data.get("age_band"), str) or not data["age_band"].strip():
        errors.append("age_band: must be a nonempty string")
    track = data.get("release_track")
    if track not in ("children_member", "general", "unknown"):
        errors.append("release_track: choose children_member/general/unknown")
    if track == "children_member":
        warnings.append("children_member: consult the latest official rules; structural validation is not eligibility approval")
    episodes = data.get("episodes")
    cues = data.get("cues")
    if not isinstance(episodes, list):
        return errors + ["episodes: expected array"], warnings
    if not isinstance(cues, dict):
        return errors + ["cues: expected object"], warnings
    if len(episodes) < min_episodes:
        errors.append(f"episodes: expected at least {min_episodes}, found {len(episodes)}")
    known_ids: set[str] = set()
    known_titles: set[str] = set()
    cue_first_seen: dict[str, str] = {}
    used_cues: set[str] = set()
    for index, ep in enumerate(episodes, start=1):
        where = f"episodes[{index - 1}]"
        if not isinstance(ep, dict):
            errors.append(f"{where}: expected object")
            continue
        for field in REQUIRED_EP_FIELDS:
            v = ep.get(field)
            if field == "cue_ids":
                if not isinstance(v, list) or not v or any(not isinstance(x, str) or not x for x in v):
                    errors.append(f"{where}.{field}: expected nonempty array of IDs")
                continue
            if not isinstance(v, str) or not v.strip():
                errors.append(f"{where}.{field}: must be nonempty text")
        title = ep.get("title")
        if isinstance(title, str) and title.strip():
            if title in known_titles:
                errors.append(f"{where}.title: duplicate title {title!r}")
            known_titles.add(title)
        ep_id = ep.get("episode_id")
        if isinstance(ep_id, str):
            if not re.fullmatch(r"EP\d{2,3}", ep_id):
                errors.append(f"{where}.episode_id: use EP01/EP002 style")
            if ep_id in known_ids:
                errors.append(f"{where}.episode_id: duplicate {ep_id}")
            known_ids.add(ep_id)
        if isinstance(ep.get("cue_ids"), list):
            for cue_id in ep["cue_ids"]:
                if not isinstance(cue_id, str):
                    continue
                used_cues.add(cue_id)
                if isinstance(ep_id, str) and cue_id not in cue_first_seen:
                    cue_first_seen[cue_id] = ep_id
                if cue_id not in cues:
                    errors.append(f"{where}.cue_ids: unknown cue '{cue_id}'")
    for index, ep in enumerate(episodes, start=1):
        if isinstance(ep, dict) and ep.get("episode_id") != f"EP{index:02d}":
            errors.append(f"episodes[{index-1}].episode_id: expected EP{index:02d} in this ordered plan")
    for cue_id, cue in cues.items():
        if not re.fullmatch(r"[A-Z][A-Z0-9-]{1,16}", cue_id):
            errors.append(f"cues: invalid cue ID '{cue_id}'")
        if not isinstance(cue, dict):
            errors.append(f"cues.{cue_id}: expected object")
            continue
        for field in REQUIRED_CUE_FIELDS:
            if not isinstance(cue.get(field), str) or not cue[field].strip():
                errors.append(f"cues.{cue_id}.{field}: missing text")
        if cue.get("first_episode") not in known_ids:
            errors.append(f"cues.{cue_id}.first_episode: not found among episode IDs")
        elif cue_id in cue_first_seen and cue["first_episode"] != cue_first_seen[cue_id]:
            errors.append(f"cues.{cue_id}.first_episode: expected {cue_first_seen[cue_id]} (first actual use)")
        if cue_id not in used_cues:
            warnings.append(f"cues.{cue_id}: defined but unused")
    if len(episodes) > 0:
        warnings.append("Human review still required for fair clues, child safety, copyright, actual duration and listening experience")
    return errors, warnings


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("manifest", type=Path, help="UTF-8 planning manifest JSON")
    parser.add_argument("--min-episodes", type=int, default=1,
                        help="required number of episodes (choose 10 for a 10-episode season)")
    args = parser.parse_args(argv)
    if args.min_episodes < 1:
        parser.error("--min-episodes must be >= 1")
    try:
        data = json.loads(args.manifest.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        print(f"ERROR: cannot load manifest: {exc}", file=sys.stderr)
        return 2
    errors, warnings = validate(data, min_episodes=args.min_episodes)
    for message in errors:
        print("ERROR:", message)
    for message in warnings:
        print("NOTE: ", message)
    if errors:
        print(f"FAILED: {len(errors)} structural error(s)")
        return 1
    print(f"PASSED: structural checks ({len(data['episodes'])} episodes; {len(data['cues'])} cues). NOT an artistic/safety/platform review.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
