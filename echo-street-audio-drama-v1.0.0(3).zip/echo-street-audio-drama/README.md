# Echo Street｜儿童有声剧·反套路创作 Skill

**版本：v1.0.0｜2026-10-24｜原创示范不代表任何平台官方认证**

面向喜马拉雅儿童音频创作，输入一句需求也可得到具备声学证据的原创有声剧构思、可录制台本、可连载的角色/谜题账与审稿流程。最核心的差异是：**反转要能用同一段声音回听验证；正向价值必须有人付出代价并亲手修复；故事只凭听觉也能成立。**

## 安装

解压得到 `echo-street-audio-drama/` 整个目录，然后将目录放到支持 Agent Skills 的工具可发现的 Skills 路径中；使用时让代理加载 `SKILL.md` 或直接说“用 echo-street-audio-drama 创作儿童有声剧”。具体安装路径依 Codex/Claude 或其他 Agent Skills 客户端官方说明。该 Skill 不调用外部 API，不依赖外部 Python 库，音频需要另行真人或授权的 AI 演播制作。

## 3 个可直接下达的需求

**一键创作系列**：`请使用 echo-street-audio-drama，为喜马拉雅策划 10 集原创儿童有声剧，7–10 岁，反套路但不恐怖，先输出季总纲、听觉谜题账、角色弧线和第 1 集完整可录制台本。` 

**单集加强**：`用此 Skill 将下列梗概写成 9 分钟有声剧；必须先有可听见的证据，三观正但不说教，人物承担代价。给混音/音效 cue 表和人工审稿结论。` 

**诊断旧稿**：`逐场审查这份儿童剧本，只评审不要改原文件，重点查第一分钟听感、公平反转、儿童安全、听不懂的场景和价值说教。先给能否使用的判决，随后引用台词给最小改法。` 

## 内容目录

- `SKILL.md`：适用范围、选择路线、声音反转、价值表达、交付形式、失败回退。
- `references/story-engine.md`：儿童戏剧反套路与季谜机制。
- `references/aesthetic-charter.md`：句子级听觉审美、声音质地与去套路样例。
- `references/audio-production.md`：音频台本、音效角色、混音与时长估算。
- `references/platform-and-safety.md`：喜马拉雅官方规则来源与适用范围提示。
- `references/quality-gates.md`：红线、带证据的评价量表、真人试听和回归题。
- `assets/*`：专辑季总纲及单集台本模板。
- `examples/season-demo.md`：原创完整 10 集季纲（非整季完整剧本）。
- `examples/episode-01.md`：原创第一集完整录制文字台本（未实录）。
- `examples/season-manifest.json`：配套的 10 集声音线索数据账。
- `scripts/validate_story.py`：校验规划账的一致性，不审艺术内容。
- `tests/test_validator.py`：校验程序的正负向回归测试。

## 本地检查

```bash
python scripts/validate_story.py examples/season-manifest.json --min-episodes 10
python -m unittest discover -s tests -v
```

程序通过只表示**结构与引用一致**，绝不意味着原创性已法律核验、儿童听感经试播、完播效果验证、平台审核通过。最终提交和发布要通过真人试听/复核和平台当前规则检查。

## 版权和演示说明

文本为在本项目中独立撰写的原创示范。剧本创作者须另外确认制作/发布时的音乐、音效、人物肖像与声音权利；平台具体资格、合同与上架规则需按申报类别核实。本包不含任何个人创作私密库、客户资料、第三方 Skill 原文、付费素材或外部凭据。
