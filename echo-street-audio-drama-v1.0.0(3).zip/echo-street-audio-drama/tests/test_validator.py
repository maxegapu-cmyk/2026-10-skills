import copy
import json
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
from validate_story import validate  # noqa: E402


class ValidatorTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.manifest = json.loads((ROOT / 'examples/season-manifest.json').read_text(encoding='utf-8'))

    def assertInvalid(self, data, fragment):
        errors, _ = validate(data, min_episodes=10)
        self.assertTrue(any(fragment in e for e in errors), errors)

    def test_demo_passes_structure(self):
        errors, warnings = validate(self.manifest, min_episodes=10)
        self.assertEqual(errors, [])
        self.assertTrue(any('Human review' in w for w in warnings))

    def test_reject_duplicate_episode(self):
        data = copy.deepcopy(self.manifest)
        data['episodes'][3]['episode_id'] = 'EP01'
        self.assertInvalid(data, 'duplicate')

    def test_reject_unknown_cue(self):
        data = copy.deepcopy(self.manifest)
        data['episodes'][0]['cue_ids'].append('ZZ999')
        self.assertInvalid(data, 'unknown cue')

    def test_reject_missing_cost(self):
        data = copy.deepcopy(self.manifest)
        data['episodes'][0]['character_cost'] = '  '
        self.assertInvalid(data, 'character_cost')

    def test_reject_invalid_first_episode(self):
        data = copy.deepcopy(self.manifest)
        data['cues']['C02']['first_episode'] = 'EP99'
        self.assertInvalid(data, 'first_episode')

    def test_reject_non_object_root(self):
        errors, _ = validate([])
        self.assertTrue(errors)

    def test_reject_short_plan(self):
        data = copy.deepcopy(self.manifest)
        data['episodes'] = data['episodes'][:1]
        self.assertInvalid(data, 'expected at least 10')

    def test_report_child_member_rule_warning(self):
        data = copy.deepcopy(self.manifest)
        data['release_track'] = 'children_member'
        errors, warnings = validate(data, 10)
        self.assertEqual(errors, [])
        self.assertTrue(any('official' in w for w in warnings))

    def test_reject_duplicate_title(self):
        data = copy.deepcopy(self.manifest)
        data['episodes'][1]['title'] = data['episodes'][0]['title']
        self.assertInvalid(data, 'duplicate title')

    def test_reject_nonsequential_episodes(self):
        data = copy.deepcopy(self.manifest)
        data['episodes'][0]['episode_id'] = 'EP11'
        self.assertInvalid(data, 'expected EP01')

    def test_reject_mismatched_cue_first_use(self):
        data = copy.deepcopy(self.manifest)
        data['cues']['C02']['first_episode'] = 'EP02'
        self.assertInvalid(data, 'first actual use')

    def test_reject_nontyped_cues(self):
        data = copy.deepcopy(self.manifest)
        data['cues']['C01'] = []
        self.assertInvalid(data, 'expected object')

    def test_reject_missing_required_field(self):
        data = copy.deepcopy(self.manifest)
        del data['episodes'][0]['closure']
        self.assertInvalid(data, 'closure')


if __name__ == '__main__':
    unittest.main()
