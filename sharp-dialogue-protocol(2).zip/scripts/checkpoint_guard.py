#!/usr/bin/env python3
"""
checkpoint_guard.py - Deterministic state machine sentinel for sharp-dialogue-protocol.
Provides physical validation, circuit breaker failure tracking, versioned snapshots, and rollback.
"""

import os
import sys
import json
import yaml
import shutil
import hashlib
import argparse
from datetime import datetime, timezone
from pathlib import Path

DEFAULT_CANDIDATE_PATHS = [
    Path("artifacts/checkpoint.md"),
    Path("checkpoint.md"),
]

def locate_checkpoint(create_if_missing=False) -> Path:
    """Find existing checkpoint.md or return the canonical target."""
    for p in DEFAULT_CANDIDATE_PATHS:
        if p.exists():
            return p
    target = DEFAULT_CANDIDATE_PATHS[0]
    if create_if_missing:
        target.parent.mkdir(parents=True, exist_ok=True)
    return target

def parse_frontmatter(file_path: Path):
    if not file_path.exists():
        raise FileNotFoundError(f"Checkpoint file not found: {file_path}")
    text = file_path.read_text(encoding="utf-8")
    if not text.startswith("---"):
        raise ValueError("Missing YAML frontmatter opening '---'")
    parts = text.split("---", 2)
    if len(parts) < 3:
        raise ValueError("Malformed YAML frontmatter delimiters")
    raw_yaml = parts[1]
    body = parts[2]
    data = yaml.safe_load(raw_yaml) or {}
    return data, body

def dump_checkpoint(file_path: Path, data: dict, body: str):
    file_path.parent.mkdir(parents=True, exist_ok=True)
    yaml_str = yaml.dump(data, allow_unicode=True, sort_keys=False, default_flow_style=False)
    content = f"---\n{yaml_str}---\n{body.lstrip()}"
    file_path.write_text(content, encoding="utf-8")

def cmd_locate(args):
    path = locate_checkpoint(create_if_missing=args.create)
    print(str(path))
    return 0

def cmd_validate(args):
    path = Path(args.file) if args.file else locate_checkpoint()
    try:
        data, _ = parse_frontmatter(path)
        required_fields = ["status", "phase", "next_objective"]
        missing = [f for f in required_fields if f not in data]
        if missing:
            print(f"[VALIDATION_FAILED] Missing required YAML fields: {missing}", file=sys.stderr)
            return 1
        valid_phases = ["exploration", "convergence", "execution", "rollback"]
        if data.get("phase") not in valid_phases:
            print(f"[VALIDATION_FAILED] Phase '{data.get('phase')}' not in {valid_phases}", file=sys.stderr)
            return 1
        print(f"[VALIDATION_OK] {path} is valid (phase={data.get('phase')}, revision={data.get('revision', 1)})")
        return 0
    except Exception as e:
        print(f"[VALIDATION_ERROR] {e}", file=sys.stderr)
        return 1

def cmd_check_loop(args):
    cb_path = Path(".circuit_breaker.json")
    cb_data = {"fingerprint": "", "count": 0, "last_updated": ""}
    if cb_path.exists():
        try:
            cb_data = json.loads(cb_path.read_text(encoding="utf-8"))
        except Exception:
            pass

    current_fp = hashlib.sha256(args.fingerprint.strip().encode("utf-8")).hexdigest()[:16]
    now_iso = datetime.now(timezone.utc).isoformat()

    if cb_data.get("fingerprint") == current_fp:
        count = cb_data.get("count", 0) + 1
    else:
        count = 1

    cb_data = {
        "fingerprint": current_fp,
        "raw_prefix": args.fingerprint.strip()[:60],
        "count": count,
        "last_updated": now_iso
    }
    cb_path.write_text(json.dumps(cb_data, indent=2, ensure_ascii=False), encoding="utf-8")

    if count >= 2:
        print(f"[CIRCUIT_BREAKER_TRIGGERED] Failure threshold reached (count={count}) for fingerprint: {args.fingerprint[:50]}")
        print("ACTION_REQUIRED: Rollback to previous stable checkpoint and provide MVA alternative.")
        return 2
    else:
        print(f"[ATTEMPT_RECORDED] Failure recorded (count={count}). Allowed retries remaining: {2 - count}")
        return 0

def cmd_reset_loop(args):
    cb_path = Path(".circuit_breaker.json")
    if cb_path.exists():
        cb_path.unlink()
    print("[CIRCUIT_BREAKER_RESET] Error counter cleared.")
    return 0

def cmd_snapshot(args):
    path = locate_checkpoint()
    data, body = parse_frontmatter(path)
    cur_rev = int(data.get("revision", 1))
    next_rev = cur_rev + 1

    history_dir = path.parent / ".checkpoint_history"
    history_dir.mkdir(parents=True, exist_ok=True)
    backup_file = history_dir / f"v{cur_rev}.md"
    shutil.copy2(path, backup_file)

    data["revision"] = next_rev
    data["parent_revision"] = cur_rev
    data["updated_at"] = datetime.now(timezone.utc).isoformat()
    if args.message:
        data["last_message"] = args.message

    dump_checkpoint(path, data, body)
    print(f"[SNAPSHOT_CREATED] Archived v{cur_rev} to {backup_file}, advanced {path} to v{next_rev}")
    return 0

def cmd_rollback(args):
    path = locate_checkpoint()
    history_dir = path.parent / ".checkpoint_history"
    if not history_dir.exists():
        print("[ROLLBACK_FAILED] No .checkpoint_history directory found.", file=sys.stderr)
        return 1

    backups = sorted(history_dir.glob("v*.md"), key=lambda p: p.stat().st_mtime)
    if not backups:
        print("[ROLLBACK_FAILED] No historical snapshots available in history directory.", file=sys.stderr)
        return 1

    latest_backup = backups[-1]
    shutil.copy2(latest_backup, path)
    # Clear circuit breaker on successful rollback
    cmd_reset_loop(args)
    print(f"[ROLLBACK_SUCCESS] Restored {path} from {latest_backup.name}")
    return 0

def cmd_show(args):
    path = locate_checkpoint()
    data, body = parse_frontmatter(path)
    print(f"=== Checkpoint: {path} ===")
    print(f"Status:   {data.get('status')}")
    print(f"Phase:    {data.get('phase')}")
    print(f"Revision: {data.get('revision', 1)}")
    print(f"Updated:  {data.get('updated_at')}")
    print(f"Next Obj: {data.get('next_objective')}")
    print("--------------------------")
    return 0

def main():
    parser = argparse.ArgumentParser(description="Deterministic state guard for sharp-dialogue-protocol")
    subparsers = parser.add_subparsers(dest="command", required=True)

    p_locate = subparsers.add_parser("locate")
    p_locate.add_argument("--create", action="store_true")
    p_locate.set_defaults(func=cmd_locate)

    p_val = subparsers.add_parser("validate")
    p_val.add_argument("--file", type=str, default="")
    p_val.set_defaults(func=cmd_validate)

    p_loop = subparsers.add_parser("check-loop")
    p_loop.add_argument("--fingerprint", type=str, required=True, help="Error message or step signature")
    p_loop.set_defaults(func=cmd_check_loop)

    p_reset = subparsers.add_parser("reset-loop")
    p_reset.set_defaults(func=cmd_reset_loop)

    p_snap = subparsers.add_parser("snapshot")
    p_snap.add_argument("--message", type=str, default="")
    p_snap.set_defaults(func=cmd_snapshot)

    p_roll = subparsers.add_parser("rollback")
    p_roll.set_defaults(func=cmd_rollback)

    p_show = subparsers.add_parser("show")
    p_show.set_defaults(func=cmd_show)

    args = parser.parse_args()
    sys.exit(args.func(args))

if __name__ == "__main__":
    main()
