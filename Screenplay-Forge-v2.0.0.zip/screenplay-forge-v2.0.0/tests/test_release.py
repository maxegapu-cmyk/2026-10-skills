"""Pure stdlib, deterministically tests scorecards and the advisory scanner."""
from __future__ import annotations
import copy
import json
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
from validate_review import validate, WEIGHTS
from compare_reviews import compare
from script_lint import lint_text


def load(name):
    return json.loads((ROOT / 'examples' / name).read_text(encoding='utf8'))


class TestReports(unittest.TestCase):
    def setUp(self):
        self.old = load('原稿_评分.json')
        self.new = load('改稿_评分.json')

    def test_weights_sum_to_100(self):
        self.assertEqual(sum(WEIGHTS.values()), 100)

    def test_original_score_with_blockers(self):
        errors, r = validate(self.old)
        self.assertEqual(errors, [])
        self.assertEqual(r['score'], 47.6)
        self.assertEqual(r['status'], 'BLOCKED')

    def test_revised_score_with_no_false_release(self):
        errors, r = validate(self.new)
        self.assertEqual(errors, [])
        self.assertEqual(r['score'], 78.0)
        self.assertEqual(r['status'], 'REVISE')

    def test_comparison(self):
        r = compare(self.old, self.new)
        self.assertEqual(r['delta'], 30.4)
        self.assertEqual(r['dimension_delta']['genre'], 0)
        self.assertEqual(r['dimension_delta']['filmability'], 3)

    def test_missing_evidence_must_fail(self):
        bad = copy.deepcopy(self.new)
        bad['dimensions'][3]['evidence'] = ' '
        self.assertTrue(any('evidence' in err for err in validate(bad)[0]))

    def test_bad_score_bool_rejected(self):
        bad = copy.deepcopy(self.new)
        bad['dimensions'][2]['score'] = True
        self.assertTrue(any('score' in err for err in validate(bad)[0]))

    def test_above_five_rejected(self):
        bad = copy.deepcopy(self.new)
        bad['dimensions'][2]['score'] = 6
        self.assertTrue(validate(bad)[0])

    def test_duplicate_rejected(self):
        bad = copy.deepcopy(self.new)
        bad['dimensions'][2]['id'] = bad['dimensions'][1]['id']
        self.assertTrue(any('duplicate' in err for err in validate(bad)[0]))

    def test_na_requires_reason(self):
        bad = copy.deepcopy(self.new)
        bad['dimensions'][3]['score'] = None
        self.assertTrue(any('why_missing' in err for err in validate(bad)[0]))

    def test_partial_score_requires_equal_coverage_for_comparison(self):
        bad = copy.deepcopy(self.new)
        bad['dimensions'][3]['score'] = None
        bad['dimensions'][3]['why_missing'] = '相关前文缺失，无法判断'
        self.assertEqual(validate(bad)[0], [])
        with self.assertRaisesRegex(ValueError, 'N/A'):
            compare(self.old, bad)

    def test_blocker_forces_blocked(self):
        bad = copy.deepcopy(self.new)
        bad['blocking_issues'] = ['人设前后矛盾']
        self.assertTrue(any('force BLOCKED' in e for e in validate(bad)[0]))

    def test_blocked_requires_explanation(self):
        bad = copy.deepcopy(self.new)
        bad['status'] = 'BLOCKED'
        self.assertTrue(any('requires at least one' in e for e in validate(bad)[0]))

    def test_verified_requires_real_evidence(self):
        bad = copy.deepcopy(self.new)
        bad['status'] = 'PRODUCTION_VERIFIED'
        self.assertTrue(any('production_evidence' in e for e in validate(bad)[0]))

    def test_no_fake_assessor(self):
        bad = copy.deepcopy(self.new)
        bad['assessor_type'] = 'real_audience'
        self.assertTrue(any('editorial_estimate' in e for e in validate(bad)[0]))

    def test_non_object_rejected(self):
        errors, _ = validate([])
        self.assertTrue(errors)


class TestLint(unittest.TestCase):
    def test_empty_fails(self):
        self.assertEqual(lint_text('   ')[0]['code'], 'EMPTY')

    def test_abstract_performance_label_flagged(self):
        findings = lint_text('场：内景\n△宋秀霞奸诈地看着孩子。')
        self.assertTrue(any(x['code'] == 'LABEL_NOT_ACTION' for x in findings))

    def test_dense_action_flagged(self):
        findings = lint_text('场：内景\n△她猛地踢飞，撞到栏杆然后翻过去，坠落到吊灯上。')
        self.assertTrue(any(x['code'] == 'DENSE_ACTION' for x in findings))

    def test_well_scoped_action_not_flagged(self):
        findings = lint_text('场：内景\n△孩子停步。\n△奶奶慢慢抬头。')
        self.assertEqual(findings, [])

    def test_real_original_is_readable(self):
        src = (ROOT/'examples'/'付家老宅_原稿.txt').read_text(encoding='utf8')
        self.assertIn('乾坤逆转符',src)
        self.assertTrue(lint_text(src))


if __name__ == '__main__':
    unittest.main()

class TestSkillArtifact(unittest.TestCase):
    def test_skill_frontmatter_and_public_name(self):
        text = (ROOT / 'SKILL.md').read_text(encoding='utf8')
        self.assertTrue(text.startswith('---\nname: screenplay-forge\n'))
        self.assertIn('version: 2.0.0', text)

    def test_skill_references_all_resolve(self):
        import re
        text = (ROOT / 'SKILL.md').read_text(encoding='utf8')
        found = set(re.findall(r'(?:references|scripts|examples|tests)/[^\s`，、。：；（）]+\.(?:md|py)',text))
        self.assertGreaterEqual(len(found), 6)
        for item in found:
            self.assertTrue((ROOT / item).is_file(), item)

    def test_complete_worked_example_not_just_diagnosis(self):
        text = (ROOT/'examples'/'付家老宅_v2_全套示范.md').read_text(encoding='utf8')
        for expected in ('修订后的演员剧本', '宋秀霞', '付云舒', '乾坤逆转符', '从伤口', '反套路裁决', 'AI视频', '最强异议'):
            self.assertIn(expected, text)

    def test_public_origins_documented(self):
        text = (ROOT/'references'/'source-notes.md').read_text(encoding='utf8')
        self.assertIn('https://github.com/neopentane7/script-doctor',text)
        self.assertIn('没有复制',text)

    def test_no_wrong_legacy_version_refs(self):
        text = (ROOT/'README.md').read_text(encoding='utf8')
        self.assertIn('2.0.0',text)
        self.assertNotIn('v1_参照',text)
