#!/usr/bin/env python3
"""Screenplay Forge 2.0 scorecard validator (stdlib only).

Does NOT evaluate artistic quality or verify whether quoted evidence is true.
It validates report structure, score arithmetic and release-gate contradictions.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

WEIGHTS = {
    'genre': 10, 'conflict': 12, 'character': 10, 'causal': 12,
    'emotion': 10, 'information': 8, 'dialogue': 8, 'originality': 10,
    'payoff': 6, 'filmability': 10, 'efficiency': 4,
}
STATUSES = {'BLOCKED', 'REVISE', 'READY_FOR_PRODUCTION_TEST', 'PRODUCTION_VERIFIED'}


def validate(report: dict) -> tuple[list[str], dict]:
    errors: list[str] = []
    if not isinstance(report, dict):
        return ['root must be a JSON object'], {}
    dims = report.get('dimensions')
    if not isinstance(dims, list):
        return ['dimensions must be an array'], {}
    if len(dims) != len(WEIGHTS):
        errors.append(f'expect {len(WEIGHTS)} dimensions; got {len(dims)}')
    seen = set()
    points = 0.0
    covered_weight = 0
    for pos, dim in enumerate(dims):
        if not isinstance(dim, dict):
            errors.append(f'dimensions[{pos}] must be an object')
            continue
        ident = dim.get('id')
        if ident not in WEIGHTS:
            errors.append(f'dimensions[{pos}] unknown id {ident!r}')
            continue
        if ident in seen:
            errors.append(f'duplicate dimension id {ident}')
            continue
        seen.add(ident)
        score = dim.get('score')
        if score is None:
            if not isinstance(dim.get('why_missing'), str) or not dim['why_missing'].strip():
                errors.append(f'{ident}: N/A requires why_missing')
            continue
        if type(score) is not int or not 0 <= score <= 5:
            errors.append(f'{ident}: score must be integer 0..5 or null')
            continue
        for field in ('evidence', 'problem', 'action'):
            if not isinstance(dim.get(field), str) or not dim[field].strip():
                errors.append(f'{ident}: requires nonempty {field}')
        covered_weight += WEIGHTS[ident]
        points += score * WEIGHTS[ident] / 5
    missing = set(WEIGHTS) - seen
    if missing:
        errors.append('missing dimensions: ' + ', '.join(sorted(missing)))
    if covered_weight == 0:
        errors.append('all dimensions N/A: score unavailable')
    gate = report.get('status')
    if gate not in STATUSES:
        errors.append(f'invalid status {gate!r}')
    blockers = report.get('blocking_issues')
    if not isinstance(blockers, list) or any(not isinstance(item, str) or not item.strip() for item in blockers):
        errors.append('blocking_issues must be array of nonempty strings')
        blockers = []
    if blockers and gate != 'BLOCKED':
        errors.append('unresolved blocking_issues force BLOCKED status')
    if gate == 'BLOCKED' and not blockers:
        errors.append('BLOCKED requires at least one specific blocking_issue')
    if gate == 'PRODUCTION_VERIFIED':
        verification = report.get('production_evidence')
        if not isinstance(verification, str) or not verification.strip():
            errors.append('PRODUCTION_VERIFIED requires nonempty production_evidence')
    if report.get('assessor_type') != 'editorial_estimate':
        errors.append('assessor_type must be editorial_estimate (tool cannot claim real viewer studies)')
    if report.get('version') != '2.0.0':
        errors.append('version must be 2.0.0')
    out = {
        'score': round(points * 100 / covered_weight, 1) if covered_weight else None,
        'coverage_pct': round(covered_weight, 1),
        'status': gate,
        'eligible_for_overall_grade': covered_weight >= 80 and not errors,
    }
    return errors, out


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('report', type=Path, help='UTF-8 JSON scorecard file')
    parser.add_argument('--json', action='store_true', help='emit a machine-readable result')
    args = parser.parse_args(argv)
    try:
        record = json.loads(args.report.read_text(encoding='utf-8'))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        print(f'ERROR: {exc}', file=sys.stderr)
        return 2
    errors, result = validate(record)
    if args.json:
        print(json.dumps({'valid': not errors, 'errors': errors, **result}, ensure_ascii=False, indent=2))
    else:
        print('REPORT:', args.report.name)
        print('STATUS:', result.get('status'))
        print('SCORE:', result.get('score'), '| COVERAGE:', result.get('coverage_pct'))
        print('VALID' if not errors else 'INVALID: ' + '; '.join(errors))
    return 0 if not errors else 1


if __name__ == '__main__':
    sys.exit(main())
