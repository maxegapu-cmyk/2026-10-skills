#!/usr/bin/env python3
"""Compare two valid scorecards using the SAME 11 fixed rubric weights."""
from __future__ import annotations
import argparse
import json
import sys
from pathlib import Path
from validate_review import validate, WEIGHTS


def compare(first: dict, second: dict) -> dict:
    e1, m1 = validate(first)
    e2, m2 = validate(second)
    if e1 or e2:
        raise ValueError(f'invalid source scorecard: before={e1}; after={e2}')
    old = {d['id']: d['score'] for d in first['dimensions']}
    new = {d['id']: d['score'] for d in second['dimensions']}
    if {k for k, v in old.items() if v is None} != {k for k,v in new.items() if v is None}:
        raise ValueError('N/A dimensions differ; cross-version numeric comparison not allowed')
    delta = {ident: new[ident]-old[ident] for ident in WEIGHTS if old[ident] is not None}
    return {'before':m1, 'after':m2, 'delta':round(m2['score']-m1['score'],1), 'dimension_delta':delta,
            'disclaimer':'subjective editorial score difference; not verified effect on audience or generative models'}


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('before',type=Path)
    p.add_argument('after',type=Path)
    args=p.parse_args(argv)
    try:
        res=compare(json.loads(args.before.read_text(encoding='utf8')),json.loads(args.after.read_text(encoding='utf8')))
    except (ValueError,OSError,UnicodeError,json.JSONDecodeError) as exc:
        print('ERROR:',exc,file=sys.stderr)
        return 1
    print(json.dumps(res,ensure_ascii=False,indent=2))
    return 0

if __name__=='__main__': sys.exit(main())
