#!/usr/bin/env python3
"""Advisory script risk scanner; text patterns are not semantic film analysis."""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

ABSTRACT = ('阴险', '奸诈', '悲伤', '冷酷', '邪恶', '十分尴尬', '非常感动')
COMPLEX = ('飞', '踢', '甩', '撞', '坠', '冲', '翻', '射', '掉', '扑', '悬', '闪', '爆')
FACE = ('人物换脸', '身份漂移', '场景瞬变')


def lint_text(text: str) -> list[dict]:
    findings: list[dict] = []
    if not text.strip():
        return [{'line': 0, 'code': 'EMPTY', 'severity': 'error', 'message': '没有可检查的文本'}]
    for i, line in enumerate(text.splitlines(), 1):
        line = line.strip()
        if not line:
            continue
        # For normal Chinese action descriptions long lines often hide multiple actions.
        if line.startswith(('△', '▲', '动作：')):
            verbs = [v for v in COMPLEX if v in line]
            if len(verbs) >= 4:
                findings.append({'line': i, 'code': 'DENSE_ACTION', 'severity': 'advisory',
                                 'message': f'同一动作句包含{len(verbs)}类高动态动词，人工检查是否应拆镜'})
            if '一瞬间' in line and '同时' in line:
                findings.append({'line': i, 'code': 'SIMULTANEOUS', 'severity': 'advisory',
                                 'message': '“一瞬间”“同时”并用，可能模糊动作顺序'})
        terms = [w for w in ABSTRACT if w in line]
        if terms and ('（' in line or '(' in line or line.startswith('△')):
            findings.append({'line': i, 'code': 'LABEL_NOT_ACTION', 'severity': 'advisory',
                             'message': '发现抽象表演词：' + '、'.join(terms) + '；检查是否已有可拍行为'})
        if re.search(r'(突然){2,}|(猛地){2,}', line):
            findings.append({'line': i, 'code': 'REDUNDANCY', 'severity': 'advisory',
                             'message': '重复强度副词可能遮盖真正的动作变化'})
    if len(text) > 300 and not re.search(r'场[：:]|EXT\.|INT\.|场景[：:]', text, flags=re.I):
        findings.append({'line': 0, 'code': 'NO_SCENE_HEADING', 'severity': 'advisory',
                         'message': '未识别到场景头；若是文学叙事文本可以忽略'})
    return findings


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('script', type=Path)
    parser.add_argument('--json', action='store_true')
    args = parser.parse_args(argv)
    try:
        text = args.script.read_text(encoding='utf-8')
    except (OSError, UnicodeError) as exc:
        print(f'ERROR: {exc}', file=sys.stderr)
        return 2
    findings = lint_text(text)
    if args.json:
        print(json.dumps({'findings': findings, 'count': len(findings)}, ensure_ascii=False, indent=2))
    else:
        print(f'{args.script.name}: {len(findings)}条提示（非文学评分）')
        for item in findings:
            print(f"  L{item['line']} {item['code']}: {item['message']}")
    return 1 if any(f['severity'] == 'error' for f in findings) else 0


if __name__ == '__main__':
    sys.exit(main())
