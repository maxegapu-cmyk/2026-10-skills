# 外部开源参考与实现边界（核对日期：2026-10-18）

本项目独立撰写文档、原创建模与Python校验脚本；下列 GitHub 项目仅提供公开的方法方向和可检验的研究线索，**没有复制、捆绑或修改其源代码，也不依赖安装这些项目**。部分仓库规模较小，功能描述以其公开README为依据，未对其真实产出做实机基准比较。

1. https://github.com/neopentane7/script-doctor — 编剧/批评循环、结构化多维评分、达到上限即停止或停滞收敛等工作流方向。我们的评分权重与修改程序另行设计。
2. https://github.com/anishkatoch/script_intelligence — 剧本冲突、情绪、投入感、意见汇总等不同专业视角。我们只借鉴“单个角色聚焦一个问题”的思想，不直接用该应用程序。
3. https://github.com/Picrew/ConStory-Bench — 人物、事实、时间线、世界设定的持续一致性检查维度；本Skill用人工/LLM审阅清单，不声称复现benchmark。
4. https://github.com/EQ-bench/longform-writing-bench — 创意规划、批判修订、人物发展、长叙事连贯的评价；仅作为综合评价思路参考。
5. https://github.com/nshkrdotcom/fount — 候选稿差异审查、可审阅修改与最后决定机制；本Skill采用明确保留原稿和对照。
6. https://github.com/mattdaly/Fountain.js — Fountain结构化剧本格式与元素分离的背景方向；本包Python轻量审查器**不是**Fountain正式解析器，不宣称完全格式兼容。
7. https://github.com/lars76/story-evaluation-llm — 陈词滥调、人物动机、叙事逻辑与句式等多维主观评价项目；评分偏差与艺术主观性无法消除。
8. https://github.com/kirklasalle/CineMatrix — 分镜与预可视化的方向参考；本包不包含该工具与渲染组件。

**著作权提醒**：本包中的“付家老宅”情节材料基于用户提供的片段，作为用户委托的改稿与示范，不应把该情节对外作为本包原创公开故事资产。要公开发布纯净工具包，建议将示例替换为完全原创、非第三方素材。此发行版本保留案例以方便作者验收；转载案例前须确认相关版权及授权。
