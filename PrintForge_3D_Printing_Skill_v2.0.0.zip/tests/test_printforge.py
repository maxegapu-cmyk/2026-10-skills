from pathlib import Path
import json
import os
import shutil
import subprocess
import xml.etree.ElementTree as ET
import zipfile

import numpy as np
import pytest
import trimesh
from PIL import Image

from printforge.core import (demo_image, make_relief, load_mesh, report_mesh,
                             prepare_mesh, split_mesh, research_commons,NS)


def test_demo_pipeline(tmp_path):
    f=tmp_path/'icon.png';demo_image(f)
    a=make_relief(f,tmp_path/'out',width_mm=40,colors=3,pitch=1.0)
    assert a['mode']=='2.5d_color_relief'
    assert 2<=a['parts']<=4
    assert abs(a['width_mm']-40)<.1
    for fn in a['files']:
        assert Path(fn).is_file()
    for f in (tmp_path/'out').glob('*.stl'):
        m=trimesh.load(f)
        assert m.is_watertight and m.is_winding_consistent
        assert m.volume>0
    archive=tmp_path/'out'/'assembly_color.3mf'
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        root=ET.fromstring(z.read('3D/3dmodel.model'))
        assert root.get('unit')=='millimeter'
        meshes=root.findall('.//{%s}mesh'%NS)
        assert len(meshes)==a['parts']
        assert len(root.findall('.//{%s}base'%NS))==a['parts']
    assert json.loads((tmp_path/'out'/'audit.json').read_text())['source_sha256']


def test_input_image_bg_modes(tmp_path):
    f=tmp_path/'solid.png'
    Image.new('RGB',(50,75),(20,80,150)).save(f)
    a=make_relief(f,tmp_path/'plain',colors=1,background='none',width_mm=40,pitch=1.0)
    assert a['parts']==2
    f2=tmp_path/'alpha.png'
    Image.new('RGBA',(20,20),(0,0,0,0)).save(f2)
    with pytest.raises(ValueError,match='foreground'):
        make_relief(f2,tmp_path/'empty',background='alpha')


def test_reject_bad_inputs(tmp_path):
    f=tmp_path/'valid.png';demo_image(f)
    with pytest.raises(ValueError):make_relief(f,tmp_path/'bad',colors=99)
    with pytest.raises(ValueError):make_relief(f,tmp_path/'bad',width_mm=800)
    with pytest.raises(ValueError):make_relief(f,tmp_path/'bad',pitch=.05)
    with pytest.raises(ValueError):make_relief(f,tmp_path/'bad',background='unknown')


def test_prepare_mesh(tmp_path):
    src=tmp_path/'cube.stl'
    trimesh.creation.box(extents=[20,25,40]).export(src)
    rep=prepare_mesh(src,tmp_path/'prepared',height_mm=100)
    assert rep['after']['watertight']
    assert abs(rep['after']['dimensions'][2]-100)<.001
    assert abs(rep['after']['bounds'][0][2])<.001
    assert abs(rep['after']['bounds'][0][0]+rep['after']['bounds'][1][0])<.001


def test_reject_open_mesh(tmp_path):
    src=tmp_path/'open.stl'
    trimesh.Trimesh(vertices=[[0,0,0],[1,0,0],[0,1,0]],faces=[[0,1,2]]).export(src)
    with pytest.raises(ValueError,match='open/non-watertight'):
        prepare_mesh(src,tmp_path/'prepared')
    with pytest.raises(ValueError,match='open/non-watertight'):
        split_mesh(src,tmp_path/'split')


@pytest.mark.skipif(shutil.which('openscad') is None,reason='OpenSCAD not installed')
def test_split_with_pins(tmp_path):
    src=tmp_path/'box.stl'; trimesh.creation.box(extents=[40,30,60]).export(src)
    prepare_mesh(src,tmp_path/'norm',height_mm=60)
    rep=split_mesh(tmp_path/'norm'/'normalized_mm.stl',tmp_path/'parts',z_fraction=.5,
                   peg_points=[(-8,0),(8,0)],timeout=180)
    assert len(rep['parts'])==2 and rep['pegs']==2
    assert all(x['watertight'] for x in rep['parts'])
    lower=trimesh.load(tmp_path/'parts'/'lower.stl')
    upper=trimesh.load(tmp_path/'parts'/'upper_on_bed.stl')
    assert abs(lower.bounds[1,2]-35)<.02
    assert abs(upper.bounds[0,2])<.02
    assert (tmp_path/'parts'/'assembled_split.3mf').exists()


@pytest.mark.skipif(shutil.which('openscad') is None,reason='OpenSCAD not installed')
def test_split_no_pins_and_reject_bad_peg(tmp_path):
    src=tmp_path/'box.stl'; trimesh.creation.box(extents=[40,30,60]).export(src)
    rep=split_mesh(src,tmp_path/'parts',peg_points=[])
    assert all(x['watertight'] for x in rep['parts'])
    with pytest.raises(ValueError,match='outside the XY bounding box'):
        split_mesh(src,tmp_path/'bad',peg_points=[(100,100)])
    with pytest.raises(ValueError):
        split_mesh(src,tmp_path/'bad',z_fraction=.02)


class MockResponse:
    def raise_for_status(self):pass
    def json(self):
        info={'descriptionurl':'https://commons.wikimedia.org/wiki/File:example.png',
              'url':'https://upload.wikimedia.org/wikipedia/commons/e/example.png',
              'extmetadata':{
                 'LicenseShortName':{'value':'CC BY 4.0'},
                 'LicenseUrl':{'value':'https://creativecommons.org/licenses/by/4.0/'},
                 'Artist':{'value':'Example author'}}}
        page={'title':'File:example.png','imageinfo':[info]}
        return {'query':{'pages':{'10':page}}}

class MockSession:
    def get(self,url,**kwargs):
        assert url=='https://commons.wikimedia.org/w/api.php'
        assert kwargs['timeout']==15
        return MockResponse()


def test_refs_mock(tmp_path):
    f=tmp_path/'ref.json'
    obj=research_commons('helmet rear view',f,session=MockSession())
    assert len(obj['results'])==1
    assert obj['results'][0]['license_short']=='CC BY 4.0'
    assert f.exists()
    with pytest.raises(ValueError):research_commons('',f,session=MockSession())
