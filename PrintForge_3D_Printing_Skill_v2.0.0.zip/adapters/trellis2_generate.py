"""EXPERIMENTAL optional GPU adapter. Run inside upstream TRELLIS.2 environment.
Not tested in this delivery: requires its native CUDA toolchain and 24+ GB NVIDIA GPU.
Refer to upstream project at https://github.com/microsoft/TRELLIS.2
"""
import argparse
from pathlib import Path

def main():
    p=argparse.ArgumentParser()
    p.add_argument('image',help='Image or transparent PNG')
    p.add_argument('output_glb',help='Model output GLB path')
    p.add_argument('--target-faces',type=int,default=120000)
    p.add_argument('--texture-size',type=int,default=2048)
    args=p.parse_args()
    if not (10000<=args.target_faces<=600000): raise ValueError('face target 10k..600k')
    if args.texture_size not in (1024,2048,4096):raise ValueError('texture size 1024/2048/4096')
    from PIL import Image
    import o_voxel
    from trellis2.pipelines import Trellis2ImageTo3DPipeline
    pipeline=Trellis2ImageTo3DPipeline.from_pretrained('microsoft/TRELLIS.2-4B')
    pipeline.cuda()
    mesh=pipeline.run(Image.open(args.image).convert('RGBA'))[0]
    mesh.simplify(16777216)
    glb=o_voxel.postprocess.to_glb(
        vertices=mesh.vertices,faces=mesh.faces,attr_volume=mesh.attrs,
        coords=mesh.coords,attr_layout=mesh.layout,voxel_size=mesh.voxel_size,
        aabb=[[-0.5,-0.5,-0.5],[0.5,0.5,0.5]],
        decimation_target=args.target_faces,texture_size=args.texture_size,
        remesh=True,remesh_band=1,remesh_project=0,verbose=True)
    out=Path(args.output_glb);out.parent.mkdir(parents=True,exist_ok=True)
    glb.export(str(out),extension_webp=True)
    print('Model candidate written to',out)
    print('NEXT: run PrintForge inspect and prepare; inspect watertight; do not print unchecked.')
if __name__=='__main__':main()
