# PrintForge 2.0 — Printable asset pipeline (local, auditable)

**What is implemented and tested:** upload a PNG/photo → *2.5D multicolor raised relief* with STL per material, assembled 3MF, palette preview and audit; normalize a known watertight STL/OBJ/GLB/PLY to physical height; split normalized 3D mesh across horizontal Z plane with optional manually positioned pegs and sockets (OpenSCAD); retrieve Wikimedia Commons reference candidates and license metadata. Local UI optional.

**Not implemented / requires third-party tools:** guaranteed 360-degree 3D inferred from one picture; fully automatic object-semantic 3D color/body breakup; arbitrary seam planning; Bambu/Prusa slicer verification; GPU image-to-3D runs; machine G-code. A single photo cannot confirm unseen back geometry. Surface material and printable multicolor solids are different things.

## Install — Windows (beginner mode)
1. Install Python **3.11 or 3.12 (64-bit)** from python.org with Python Launcher. Put this ZIP in a short path like `C:\printforge` and unzip.
2. Double-click `install-windows.bat`; it creates its own `.venv` and installs the packages from `requirements-gui.txt`. Needs network access for first install. No model weights are silently downloaded.
3. Double-click `start-windows.bat`: a local web app opens at `http://127.0.0.1:7860` (or a different port assigned by Gradio). Select photo → color relief or upload 3D model → normalize/split.
4. Install [OpenSCAD](https://openscad.org/downloads.html) to enable 3D plane split. Restart terminal after PATH update. Alternative: use CLI `--openscad "C:\Program Files\OpenSCAD\openscad.exe"`.
5. Import the exported `assembly_color.3mf` into a slicer such as Bambu Studio, OrcaSlicer or PrusaSlicer. **Explicitly map each mesh to the intended real filament and slice/inspect before printing.** The material color field is a display/intention hint, not an AMS assignment guarantee. Never print directly from this program.

## Install — Linux/macOS
```bash
python3 -m venv .venv
. .venv/bin/activate
python -m pip install -r requirements-gui.txt
python -m printforge doctor
python -m printforge gui
```

## CLI walkthrough
```bash
# deterministic offline smoke test: produces 4 solids total: 1 base and 3 color surface solids
python -m printforge demo output/demo

# photo / logo relief, total 3 filament colors including base
python -m printforge relief front.png output/relief --width 120 --colors 3 --background auto

# online research (not used as geometry unless reviewed)
python -m printforge references "historic helmet rear view" output/research.json

# real geometry from a user-provided 3D generation tool or Blender
python -m printforge inspect soldier.glb
python -m printforge prepare soldier.glb output/soldier --height 150
python -m printforge split output/soldier/normalized_mm.stl output/split --at 0.48
# with known safe peg centers in mm after centering model x/y:
python -m printforge split output/soldier/normalized_mm.stl output/pegs --at 0.48 --pegs="-8,0;8,0" --peg-diameter 3 --peg-length 5 --clearance .2
```

## True image-to-3D adapter
This package does not bundle large model weights or silently download them.
- **Option A: TRELLIS.2** upstream https://github.com/microsoft/TRELLIS.2 — tested upstream only on Linux with NVIDIA >=24GB. Install upstream according to official instructions, run `python adapters/trellis2_generate.py input.png output.glb` **inside that upstream Python/CUDA environment**. This adapter is experimental and untested in this package. Verify model/license terms for your planned use.
- **Option B: photo-to-mesh** https://github.com/Hasasasaki/photo-to-mesh — separate Linux-tested Gradio UI, single/multi-view and explicit target scale. Export a GLB/STL, then use `printforge inspect/prepare/split` here. Its Hunyuan weights have separate territorial/commercial license terms.
- **Option C: 3mf-webCLI** https://github.com/tejaswigowda/3mf-webCLI — open the tool separately to cluster textured GLB colors into a composite 3MF. This is *not* equivalent to detachable solid bodies or engineered mating seams. Reopen in printer's slicer and inspect.

## Provenance / licenses
PrintForge source in this ZIP is original glue code (MIT, see LICENSE). It imports no upstream external copyrighted weights or source, and does not create an account at a hosted provider. External model licenses differ and must be independently reviewed. Wikimedia reference results can include noncommercial/share-alike/other obligations, and derivative uses may require separate permission. Packaging a 3MF does not grant design or trademark rights.

## Reliable print gates
- G0: subject/right/version and views captured; missing backside acknowledged.
- G1: visual identity silhouette/side profiles compared against refs.
- G2: geometry closed, mm dimensions, thin wall and unsupported features checked.
- G3: every intentionally detachable part is a closed volume and mechanical mating verified; test fit coupon.
- G4: slice preview shows actual printer/nozzle/material settings, support, bed fit, reasonable filament changes, no ghost bodies.
- G5: physical print and fit inspected. **G4/G5 never automatically pass in this package.**

For bundled test evidence and known shortcomings see `TEST_REPORT.md`.
