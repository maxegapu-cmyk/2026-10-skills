@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (
 echo Python launcher missing. Install Python 3.11 or 3.12 from python.org and enable py launcher.
 pause
 exit /b 1
)
py -3.12 -m venv .venv >nul 2>nul
if errorlevel 1 py -3.11 -m venv .venv >nul 2>nul
if errorlevel 1 (
 echo Could not create Python 3.11/3.12 environment. Please install Python 3.12 64-bit from python.org.
 pause
 exit /b 1
)
".venv\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 exit /b 1
".venv\Scripts\python.exe" -m pip install -r requirements-gui.txt
if errorlevel 1 (
 echo Installation failed. Review connection and Python version.
 pause
 exit /b 1
)
".venv\Scripts\python.exe" -m printforge doctor
pause
