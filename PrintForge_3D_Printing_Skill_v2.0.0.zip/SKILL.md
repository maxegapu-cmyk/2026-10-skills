---
name: printforge-3d-printing
version: 2.0.0
description: Evidence-first image and reference research into 3D-printable candidates. Supports 2.5D multicolor STL/3MF, existing GLB/STL dimension normalization, horizontal split, optional pegs, and safety audit. Never assert unseen backsides or slicer/device validation.
---

# PrintForge 2.0 — image / reference → physical 3D printing pipeline

## Trigger
Use for requests containing uploaded images, multi-view photographs, source reference searches, 3D meshing, 3MF multicolor slicing, printable part splitting, or 3D printer setup.

## Objective & the truth barrier
**Two distinct reconstruction problems.** A single image supports printable **embossed relief** without inventing hidden geometry. An independent true 360° object reconstruction requires a user-supplied mesh, photogrammetric views, or an external image-to-3D model. Existing app is not an AI model. A texture being colorful does not ensure separate physically printable color bodies. A closed manifold does not guarantee slicer success or real-world fit.

## Decision tree
1. If logo, sign, decorative plate or flat image -> `python -m printforge relief IMAGE OUTPUT` -> STL per color + composite 3MF. In-place multicolor printing or glue; check tiny islands.
2. If existing STL/OBJ/GLB/PLY -> `python -m printforge inspect INPUT`. Reject nonwatertight for direct print/split. Then `prepare INPUT OUTPUT --height 120` for mm scale. `split normalized_mm.stl OUTPUT --at 0.5` for a print-friendly seam. If precise pin XY positions are known, add `--pegs="-8,0;8,0"` and first verify seam cross-section. Physical fitting test required.
3. For true figurine based on a few photos -> source identification + provenance manifest; inspect front, side, rear, top views. Unseen areas MUST be labeled **inferred**, not faithful reconstruction. Choose the supported inference branch: TRELLIS.2 Linux+NVIDIA >=24GB (optional adapter), or an external working Hunyuan multi-view `photo-to-mesh` instance; optionally photogrammetry when photos cover the object. Import the produced GLB to `inspect` and `prepare`. Do not infer physical units from pixels alone.
4. For multicolor figurines -> semantic segmentation in Blender manually around physical seams (cloth, hair, visor, face, armor). Model the *interior solid volumes* per material, not merely texture-painted triangles; repair, boolean-cut mating faces, add pegs, and verify clearance. Use `3mf-webCLI` for an optional surface-color mapping stage but **not** as proof the material parts are self-supporting solids. Map physical filament slots in the slicer after import.
5. For models needing complex organic segmentation / support planning -> human Blender mesh edit and print dry-run are required; this program's native splitting supports only one Z plane, not arbitrary semantic segmentation.

## Reference process
- Search `python -m printforge references "OBJECT NAME rear view" research.json`; current offline tests mock MediaWiki API. Search results are reference *candidates* only; examine URL, license metadata, relative scale, and whether each view depicts the same object/revision. Cite references in project notes; never auto-download reference files from untrusted URLs.
- When supplied photo has copyright concerns, use for permitted personal tests only until rights established.
- Evidence matrix: front: user-original / license-confirmed / hypothesized; left; right; rear; base; dimensions. On conflict, prioritize user-confirmed object and primary reference, record uncertainty instead of averaging differences.

## Full 360° statue example (green armored sci-fi soldier)
**Non-factual illustrative design example**, not a claim a specific franchise design is licensed or dimensionally known. 150-mm PLA figurine, optional 4-color filament set (green shell, black undersuit, amber visor, gray gun), 0.4-mm nozzle.
1. Collect front, sides, back, and shield/gun photographs where legal, plus an independent height measurement. `references` for candidate secondary views. Create `evidence.json` with source/license/view/certainty.
2. Mask subject (avoid one image with busy background). Input separate clean views to multi-view-capable tool; do not feed conflicting costume versions. Generate GLB with the tool's native shape generator. Check camera views of original against shaded turntable output. Correct armor helmet proportions manually.
3. `inspect GLB`. If open: repair normals/remesh in Blender with visual compare; do not blindly close inside missing face or gun holes. `prepare GLB out --height 150`. Does not carry color information; keep color GLB separately as source-of-truth.
4. Material/physical splitting in Blender: choose fabrication seam surfaces first, not arbitrary face color clusters. Visor separate snapped inset, torso front/back split, arms pegged. Peg nominal 3 mm, socket 3.4 mm (0.2 mm radial clearance initial prototype) and 5-mm embed; verify the local material can accept these parameters.
5. Export green/amber/gray/black as watertight meshes aligned in one coordinate system. Assembly 3MF in slicing UI. Check no positive-volume overlaps, unsupported overhangs, 0.4-mm thin walls, overhang length, print orientation, correct raft/brim and individual part fit. Always print a 10-mm tolerance coupon before the full figurine.

## File policy
- Local-only default. Never upload user photos, faces, or proprietary assets to remote servers without user approval.
- Packaging output must include original IDs/dimensions, 3MF/STL candidates, audit, and manual slicer instructions. `3MF` is geometry + intent; not verified G-code. Do not send directly to physical printer without user-controlled slicer review.
- Never claim a non-manifold or open model has been repaired unless the measured post-repair mesh passes manifold checks.

## Failure exits
- No NVIDIA: use the 2.5D pipeline or import mesh from trusted existing software; do not secretly call a paid API.
- One image and complex back geometry: human review must approve inferred surface.
- Four AMS slots but five colors: reduce to 4 colors, group materials or plan manual swaps.
- Mesh nonwatertight: stop instead of auto-converting it into an allegedly printable asset.
- OpenSCAD unavailable: use CLI `prepare` only and install it independently for `split`.
- Need truly structural component: simple geometry and printer validation are insufficient; engineer/load-test the part separately.
