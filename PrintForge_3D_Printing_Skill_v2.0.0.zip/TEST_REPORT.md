# PrintForge 2.0 release-level validation

Validated 2026-10-09 in an isolated Linux container with Python 3.13.5, Pillow 12.3.0, NumPy 2.3.5, SciPy 1.17.0, scikit-image 0.26.0, Trimesh 4.11.1, OpenSCAD 2021.01. **These are the test environment versions**, not a Windows support certification. Windows launch scripts target Python 3.11 or 3.12; they were not executed under Windows.

## Proven implemented paths

- Local photo/transparent PNG -> complete manifold 2.5D base and color surface STL meshes, mm units, color-intent 3MF with root assembly, preview and structured QA report.
- Root 3MF ZIP CRC and XML validated and `trimesh.load` used to independently parse a generated package into 4 mesh parts.
- Known closed 3D cube -> normalized in physical height -> OpenSCAD planar split into two closed mesh bodies; tested two alignment pegs with 3-mm male diameter, 3.4-mm female bore and 5-mm length; upper shifted onto print bed.
- Single open triangle mesh -> guarded refusal; bad pin locations and out-of-range dimensions -> refusal.
- Wikimedia Commons reference query JSON parsing and attribution manifest tested using deterministic mocked API; **live network search unavailable/not tested in this release environment**.
- Local Gradio GUI construction tested with launch method mocked; **interactive browser, Windows, actual printer and actual slicer testing not performed**.
- Optional TRELLIS.2 CUDA adapter compiles but GPU inference not performed; its full production integration and model weights were not validated.

## Automated tests

`python -m pytest -q tests`: **8 passed** (geometry, materials package structure, invalid input, split, pegs, mocked reference API). Tests run from a fresh package extraction separately during release verification.

## Explicit limitations

This toolkit cannot prove the generated model is visually faithful from unseen views; cannot auto-make arbitrary anatomical or semantic subparts; does not certify nozzle/slicer compatibility, filament color mapping, adhesion, supports, resin tolerances, or dynamic/mechanical safety. 3MF standard `displaycolor` is presentation only and does not guarantee physical filament selection (3MF Core Specification). No user-owned real photos were supplied for a representative figurine test. Complex organic meshes and diverse printer profiles were not stress-tested; review in Blender and the printer's slicer is required.

## Release validation

A separate SHA-256 and clean-archive extraction test are recorded in `RELEASE_MANIFEST.txt` after packaging. The archive excludes development `.git` and caches. All results are *software preflight*, not proof of print quality.
