import argparse
import json
from pathlib import Path
import sys
from .core import make_relief,prepare_mesh,split_mesh,load_mesh,report_mesh,research_commons,demo_image

def main(argv=None):
    p=argparse.ArgumentParser(prog='python -m printforge',description='PrintForge 2.0: 2.5D image relief, mesh preparation, mechanical planar split, Commons reference search')
    sub=p.add_subparsers(dest='cmd',required=True)
    a=sub.add_parser('demo',help='Generate built-in example image, STL and 3MF');a.add_argument('outdir')
    a=sub.add_parser('relief',help='Image to colored relief print-ready candidate')
    a.add_argument('image');a.add_argument('outdir');a.add_argument('--width',type=float,default=100);a.add_argument('--colors',type=int,default=3)
    a.add_argument('--pitch',type=float,default=.5);a.add_argument('--base',type=float,default=2.0);a.add_argument('--detail',type=float,default=1.2)
    a.add_argument('--background',choices=('auto','alpha','white','none'),default='auto')
    a=sub.add_parser('prepare',help='Normalize imported 3D model to requested mm height');a.add_argument('mesh');a.add_argument('outdir');a.add_argument('--height',type=float,default=120)
    a=sub.add_parser('inspect',help='Inspect 3D mesh quality');a.add_argument('mesh')
    a=sub.add_parser('split',help='Planar Z-split of watertight 3D mesh (in mm)')
    a.add_argument('mesh');a.add_argument('outdir');a.add_argument('--at',type=float,default=.5)
    a.add_argument('--pegs',default='',help='Exact x,y coords, semicolon separated: -10,0;10,0')
    a.add_argument('--peg-diameter',type=float,default=3);a.add_argument('--peg-length',type=float,default=5)
    a.add_argument('--clearance',type=float,default=.2);a.add_argument('--openscad',default='openscad')
    a=sub.add_parser('references',help='Internet reference search via Wikimedia Commons');a.add_argument('query');a.add_argument('outfile');a.add_argument('--limit',type=int,default=6)
    sub.add_parser('doctor',help='Check install and basic dependencies')
    sub.add_parser('gui',help='Launch local visual Gradio interface')
    args=p.parse_args(argv)
    try:
        if args.cmd=='demo':
            image=Path(args.outdir)/'demo_rgba.png';image.parent.mkdir(parents=True,exist_ok=True)
            demo_image(image);r=make_relief(image,args.outdir)
        elif args.cmd=='relief':r=make_relief(args.image,args.outdir,width_mm=args.width,colors=args.colors,pitch=args.pitch,base_mm=args.base,detail_mm=args.detail,background=args.background)
        elif args.cmd=='prepare':r=prepare_mesh(args.mesh,args.outdir,height_mm=args.height)
        elif args.cmd=='inspect':r=report_mesh(load_mesh(args.mesh))
        elif args.cmd=='split':
            points=[]
            for item in args.pegs.split(';'):
                if not item.strip():continue
                xy=item.split(',')
                if len(xy)!=2:raise ValueError('--pegs must be: x,y;x,y')
                points.append((float(xy[0]),float(xy[1])))
            r=split_mesh(args.mesh,args.outdir,z_fraction=args.at,peg_points=points,peg_diameter=args.peg_diameter,peg_length=args.peg_length,clearance=args.clearance,openscad=args.openscad)
        elif args.cmd=='references':r=research_commons(args.query,args.outfile,limit=args.limit)
        elif args.cmd=='doctor':
            import shutil, PIL, numpy, scipy, skimage, trimesh
            r={'python':sys.version,'pillow':PIL.__version__,'numpy':numpy.__version__,'scipy':scipy.__version__,
               'skimage':skimage.__version__,'trimesh':trimesh.__version__,'openscad':shutil.which('openscad'),
               'gradio_gui':'optional; install pip install gradio'}
        else:
            from .gui import run_gui
            return run_gui()
        print(json.dumps(r,ensure_ascii=False,indent=2))
        return 0
    except Exception as e:
        print(f'ERROR [{type(e).__name__}]: {e}',file=sys.stderr)
        return 2
if __name__=='__main__':sys.exit(main())
