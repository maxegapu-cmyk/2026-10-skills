"""PrintForge 2.0: image->fabricable layered relief and mesh preparation.
This project intentionally never labels a mesh 'print-proven' without slicing and a test print.
"""
from __future__ import annotations
import hashlib
import json
import math
from pathlib import Path
import shutil
import subprocess
import tempfile
import xml.etree.ElementTree as ET
import zipfile

import numpy as np
from PIL import Image, ImageOps, ImageDraw
from scipy import ndimage
from skimage.measure import marching_cubes
import trimesh

NS = 'http://schemas.microsoft.com/3dmanufacturing/core/2015/02'
ET.register_namespace('', NS)

def q(s):
    return '{'+NS+'}'+s


def safe_outdir(directory):
    p=Path(directory).expanduser().resolve()
    p.mkdir(parents=True,exist_ok=True)
    if not p.is_dir():
        raise ValueError('Not a directory')
    return p


def to_color(rgb):
    return '#'+''.join(f'{int(x):02X}' for x in rgb[:3])


def write_3mf(parts, filename):
    """Core 3MF: one assembly with solid parts and base-material intent.
    Every entry: (part_name, mesh, (r,g,b)). No slicer-specific extruder claims.
    """
    if not parts:
        raise ValueError('No parts')
    model=ET.Element(q('model'),{'unit':'millimeter','{http://www.w3.org/XML/1998/namespace}lang':'en-US'})
    resources=ET.SubElement(model,q('resources'))
    basem=ET.SubElement(resources,q('basematerials'),{'id':'1'})
    for name, mesh, rgb in parts:
        ET.SubElement(basem,q('base'),{'name':str(name), 'displaycolor':to_color(rgb)})
    root_id=2+len(parts)
    for index,(name, mesh, rgb) in enumerate(parts):
        if len(mesh.faces)==0 or not np.isfinite(mesh.vertices).all():
            raise ValueError(f'Invalid part: {name}')
        obj=ET.SubElement(resources,q('object'),{'id':str(index+2), 'type':'model', 'pid':'1','pindex':str(index)})
        m=ET.SubElement(obj,q('mesh'))
        v=ET.SubElement(m,q('vertices'))
        for xyz in mesh.vertices:
            ET.SubElement(v,q('vertex'),dict(zip(('x','y','z'),(format(float(x),'.7g') for x in xyz))))
        faces=ET.SubElement(m,q('triangles'))
        for a,b,c in mesh.faces:
            ET.SubElement(faces,q('triangle'),{'v1':str(int(a)),'v2':str(int(b)),'v3':str(int(c))})
    assembly=ET.SubElement(resources,q('object'),{'id':str(root_id),'type':'model'})
    comps=ET.SubElement(assembly,q('components'))
    for i in range(len(parts)):
        ET.SubElement(comps,q('component'),{'objectid':str(i+2)})
    build=ET.SubElement(model,q('build'))
    ET.SubElement(build,q('item'),{'objectid':str(root_id)})
    xml=ET.tostring(model,encoding='utf-8',xml_declaration=True)
    contents=b'<?xml version="1.0" encoding="UTF-8"?>\n<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="model" ContentType="application/vnd.ms-package.3dmanufacturing-3dmodel+xml"/></Types>'
    rels=b'<?xml version="1.0" encoding="UTF-8"?>\n<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Target="/3D/3dmodel.model" Id="rel0" Type="http://schemas.microsoft.com/3dmanufacturing/2013/01/3dmodel"/></Relationships>'
    with zipfile.ZipFile(filename,'w',compression=zipfile.ZIP_DEFLATED) as z:
        z.writestr('[Content_Types].xml',contents)
        z.writestr('_rels/.rels',rels)
        z.writestr('3D/3dmodel.model',xml)
    with zipfile.ZipFile(filename,'r') as z:
        assert z.testzip() is None
        root=ET.fromstring(z.read('3D/3dmodel.model'))
        assert len(root.findall('.//'+q('mesh')))==len(parts)
    return str(filename)


def _mask_mesh(mask, z0, height, pitch):
    """Marching cubes of solid raster volume, closed mesh, mm units."""
    if mask.ndim!=2 or not mask.any():
        raise ValueError('Empty silhouette')
    nz=max(2,int(math.ceil(height/pitch)))
    vox=np.zeros((mask.shape[0]+2,mask.shape[1]+2,nz+2),dtype=np.uint8)
    vox[1:-1,1:-1,1:-1]=mask[:,:,None]
    verts,faces,_,_=marching_cubes(vox,0.5,spacing=(pitch,pitch,pitch),allow_degenerate=False)
    # Marching cubes arrays y,x,z. Map to 3D axis x,y,z. Center the mask in each pixel.
    vertices=np.column_stack(((verts[:,1]-.5)*pitch,
                              ((mask.shape[0]+.5)-verts[:,0])*pitch,
                              z0+(verts[:,2]-.5)*(height/nz)))
    mesh=trimesh.Trimesh(vertices=vertices,faces=faces,process=True)
    mesh.fix_normals()
    if not mesh.is_watertight:
        raise RuntimeError('Voxel surface not watertight; refusing export')
    return mesh


def _foreground(arr, alpha, mode, tol=30):
    if mode=='none': return np.ones(alpha.shape,dtype=bool)
    if mode=='alpha':
        return alpha>127
    if mode=='auto' and (alpha.min()<255):
        return alpha>127
    if mode not in ('auto','white'):
        raise ValueError('background must be auto, alpha, white or none')
    if mode=='white':
        near=np.linalg.norm(arr.astype(float)-np.array([255,255,255]),axis=2)<tol
    else:
        h,w=arr.shape[:2]
        b=np.concatenate((arr[0,:,:],arr[-1,:,:],arr[:,0,:],arr[:,-1,:]),axis=0)
        bg=np.median(b.astype(float),axis=0)
        near=np.linalg.norm(arr.astype(float)-bg,axis=2)<tol
    boundary=np.zeros(alpha.shape,dtype=bool)
    boundary[[0,-1],:]=True
    boundary[:,[0,-1]]=True
    exterior=ndimage.binary_propagation(near & boundary,mask=near)
    keep=~exterior
    frac=keep.mean()
    if mode=='auto' and (frac<.04 or frac>.97):
        return np.ones(alpha.shape,dtype=bool)
    return keep


def _resize_rgba(img,width_mm,pitch,max_side=384):
    w,h=img.size
    if max(w,h)<2:
        raise ValueError('Image too small')
    target_w=max(8,round(width_mm/pitch))
    s=min(1.0, max_side/max(target_w,round(h*target_w/w)))
    tw=max(8,round(target_w*s))
    th=max(8,round(h*tw/w))
    img=img.resize((tw,th),Image.Resampling.LANCZOS)
    return img,width_mm/tw


def make_relief(image_path, outdir, *, width_mm=100.0, colors=3,
                base_mm=2.0, detail_mm=1.2, pitch=.5,
                background='auto',min_island_mm2=1.5):
    image_path=Path(image_path)
    if not image_path.is_file():
        raise FileNotFoundError(image_path)
    if image_path.stat().st_size > 50*1024*1024:
        raise ValueError('Image exceeds 50 MB safety limit; resize externally')
    if not (20<=width_mm<=250) or not (1<=colors<=6):
        raise ValueError('Width 20..250 mm and colors 1..6 required')
    if not (1<=base_mm<=10 and .6<=detail_mm<=5 and .2<=pitch<=1.5):
        raise ValueError('Base 1..10, detail .6..5, pitch .2..1.5 required')
    outdir=safe_outdir(outdir)
    with Image.open(image_path) as im:
        if im.width*im.height>24_000_000:
            raise ValueError('Image exceeds 24 megapixels; resize externally')
        im=ImageOps.exif_transpose(im).convert('RGBA')
        im,pitch=_resize_rgba(im,width_mm,pitch)
        rgba=np.asarray(im)
    foreground=_foreground(rgba[:,:,:3],rgba[:,:,3],background)
    if foreground.sum()<16:
        raise ValueError('Image foreground too small: use --background none')
    rgb=rgba[:,:,:3]
    # Palette determined from visible object pixels only; deterministic quantization.
    # Quantize only the object; transparent surrounding pixels must not bias the palette.
    samples=rgb[foreground].reshape((1,-1,3))
    palette_source=Image.fromarray(samples).quantize(colors=colors,method=Image.Quantize.MEDIANCUT,dither=Image.Dither.NONE)
    p=palette_source.getpalette()
    pal_rgb=np.asarray(p,dtype=np.uint8).reshape((-1,3))[:colors]
    # Direct nearest-color assignment, bounded to 384x384. No image-source alpha contamination.
    dist=((rgb.astype(np.int16)[:,:,None,:]-pal_rgb.astype(np.int16)[None,None,:,:]).astype(np.int32)**2).sum(axis=-1)
    indices=dist.argmin(axis=2)
    items=[]
    for ind in np.unique(indices[foreground]):
        amount=int(((indices==ind)&foreground).sum())
        items.append((amount,int(ind),tuple(int(v) for v in p[3*int(ind):3*int(ind)+3])))
    items.sort(reverse=True)
    # Use dominant palette color as base: N-color printing, no extra filament.
    base_rgb=items[0][2]
    base=_mask_mesh(foreground,0,base_mm,pitch)
    parts=[('base',base,base_rgb)]
    colors_diag=[]
    for k,(area,ind,col) in enumerate(items):
        mask=(indices==ind)&foreground
        labs,count=ndimage.label(mask)
        counts=np.bincount(labs.flat)
        valid=np.where(counts*pitch*pitch>=min_island_mm2)[0]
        valid=valid[valid!=0]
        clean=np.isin(labs,valid)
        dropped=int(mask.sum()-clean.sum())
        if clean.any():
            part=_mask_mesh(clean,base_mm,detail_mm,pitch)
            parts.append((f'color_{k+1}_{to_color(col)[1:]}',part,col))
            colors_diag.append({'name':parts[-1][0], 'rgb':to_color(col),
                                'components':int(len(valid)),
                                'area_mm2':round(int(clean.sum())*pitch*pitch,2),
                                'dropped_pixels':dropped})
    if len(parts)==1:
        raise ValueError('No color features survived area filter')
    paths=[]
    for name,mesh,col in parts:
        dest=outdir/f'{name}.stl'
        mesh.export(dest)
        paths.append(str(dest))
    package=outdir/'assembly_color.3mf'
    write_3mf(parts,package)
    # Simple raster preview and legend, no fake claim of full 3D reconstruct.
    preview=np.full((foreground.shape[0],foreground.shape[1],3),255,dtype=np.uint8)
    for area,ind,col in items:
        preview[(indices==ind)&foreground]=col
    Image.fromarray(preview).save(outdir/'palette_preview.png')
    warnings=['This is a 2.5D embossed plaque, NOT inferred true 360-degree geometry.',
              '3MF colors denote material intent; map meshes to real filaments manually in the slicer.',
              'Peel/off-bed small color islands may be impractical for separately glued parts.',
              'Verify build plate fit, minimum stroke, wall thickness, filament changes and actual slice before printing.']
    if len(items)>4:
        warnings.append('More than four colors: check printer multi-material slots or arrange manual swaps.')
    report={'mode':'2.5d_color_relief','source':str(image_path),'width_mm':round(foreground.shape[1]*pitch,2),
            'height_mm':round(foreground.shape[0]*pitch,2),'z_mm':round(base_mm+detail_mm,2),
            'voxel_pitch_mm':round(pitch,4),'parts':len(parts),'color_regions':colors_diag,
            'warnings':warnings,'files':paths+[str(package)],'source_sha256':hashlib.sha256(image_path.read_bytes()).hexdigest()}
    (outdir/'audit.json').write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf-8')
    return report


def load_mesh(path):
    path=Path(path)
    if not path.is_file(): raise FileNotFoundError(path)
    if path.suffix.lower() not in ('.stl','.obj','.glb','.ply','.off'):
        raise ValueError('Supports STL OBJ GLB PLY OFF only')
    raw=trimesh.load(path,force='scene',process=True)
    # Flatten scene transforms. Not preserving texture; all texture edits are separate workflow.
    dump=raw.dump()
    meshes=[m for m in dump if isinstance(m,trimesh.Trimesh) and len(m.faces)>0]
    if not meshes:
        raise ValueError('No triangle geometry')
    result=trimesh.util.concatenate(meshes)
    if len(result.faces)>2_000_000:
        raise ValueError('Mesh > 2M faces: simplify first')
    result.remove_unreferenced_vertices()
    if not np.isfinite(result.vertices).all():
        raise ValueError('Non-finite geometry')
    return result


def report_mesh(mesh):
    return {'vertices':int(len(mesh.vertices)),'faces':int(len(mesh.faces)),
            'watertight':bool(mesh.is_watertight),'winding_consistent':bool(mesh.is_winding_consistent),
            'bounds':[[round(float(x),3) for x in line] for line in mesh.bounds],
            'dimensions': [round(float(x),3) for x in mesh.extents],
            'components':int(len(mesh.split(only_watertight=False))) if len(mesh.faces)<400000 else 'not_checked_large_mesh',
            'volume':round(float(mesh.volume),3) if mesh.is_watertight else None}


def prepare_mesh(mesh_path, outdir, *, height_mm=120, units='auto'):
    if not (10<=height_mm<=300):
        raise ValueError('height_mm must be 10..300')
    outdir=safe_outdir(outdir)
    mesh=load_mesh(mesh_path)
    before=report_mesh(mesh)
    if not mesh.is_watertight:
        raise ValueError('Mesh is open/non-watertight. Fix topology in Blender/MeshLab before print/split. No fake auto-repair.')
    # STL has no units. All formats are treated as arbitrary units until target height assigned.
    d=mesh.extents[2]
    if d<=0.0001: raise ValueError('Zero height mesh')
    mesh.apply_scale(height_mm/d)
    mesh.apply_translation(-np.array([mesh.bounds[:,0].mean(),mesh.bounds[:,1].mean(),mesh.bounds[0,2]]))
    mesh.fix_normals()
    dest=outdir/'normalized_mm.stl'
    mesh.export(dest)
    after=report_mesh(mesh)
    audit={'mode':'normalize_3d','source':str(mesh_path),'before':before,'after':after,
           'warning':'This is dimensional normalization, not verified full printability. STL has no native units; mm defined at slicer import. Appearance/materials are NOT preserved.'}
    (outdir/'audit_mesh.json').write_text(json.dumps(audit,indent=2,ensure_ascii=False),encoding='utf-8')
    return audit


def _scad_path(path):
    return str(Path(path).resolve().as_posix()).replace('\\','/').replace('"','\\"')


def split_mesh(mesh_path,outdir,*,z_fraction=.5,peg_points=None,peg_diameter=3.0,peg_length=5.0,clearance=.2,openscad='openscad',timeout=180):
    """Plane split with optional explicitly positioned alignment pegs.
    Uses OpenSCAD CGAL boolean ops; never automatically guesses hidden solid depth.
    """
    if not (0.10<=z_fraction<=.90): raise ValueError('z fraction must be 0.1..0.9')
    if not (1.5<=peg_diameter<=10 and 1<=peg_length<=15 and .1<=clearance<=.6):
        raise ValueError('Peg geometry outside safe prototype ranges')
    if shutil.which(openscad) is None: raise RuntimeError('OpenSCAD missing. Install OpenSCAD to use mesh splitting.')
    outdir=safe_outdir(outdir)
    mesh=load_mesh(mesh_path)
    if not mesh.is_watertight: raise ValueError('Cannot safely split an open/non-watertight mesh')
    if mesh.extents[2]<=1: raise ValueError('Model too thin along Z')
    source=outdir/'source_normalized.stl'
    # Input assumed mm, but move the bottom to Z=0.
    mesh.apply_translation([0,0,-mesh.bounds[0,2]])
    mesh.export(source)
    z=float(mesh.extents[2]*z_fraction)
    mn,mx=mesh.bounds
    bound=max(float(np.max(mesh.extents))*3,50.0)
    points=peg_points or []
    if len(points)>6: raise ValueError('Maximum 6 alignment pegs')
    for x,y in points:
        if not (mn[0]<x<mx[0] and mn[1]<y<mx[1]):
            raise ValueError('A peg lies outside the XY bounding box')
    if points and peg_length>min(z,mesh.extents[2]-z)*.75:
        raise ValueError('Peg too long relative to one of split halves')
    # Clip boxes unbounded in x/y, exact seam z.
    model=f'import("{_scad_path(source)}", convexity=10);'
    lower=f'intersection(){{{model} translate([{ -bound},{-bound},{-bound}]) cube([{2*bound},{2*bound},{bound+z}]);}}'
    upper=f'intersection(){{{model} translate([{-bound},{-bound},{z}]) cube([{2*bound},{2*bound},{bound}]);}}'
    pegs=' '.join(f'translate([{float(x):.6f},{float(y):.6f},{z-1:.6f}]) cylinder(h={peg_length+1:.6f},d={peg_diameter:.6f});' for x,y in points)
    sockets=' '.join(f'translate([{float(x):.6f},{float(y):.6f},{z-.01:.6f}]) cylinder(h={peg_length+.5:.6f},d={peg_diameter+2*clearance:.6f});' for x,y in points)
    shapes={'lower':f'union(){{ {lower} {pegs} }}',
            'upper_assembled':f'difference(){{ {upper} {sockets} }}'}
    generated=[]
    with tempfile.TemporaryDirectory(prefix='printforge_scad_') as td:
        for name,body in shapes.items():
            f=Path(td)/(name+'.scad')
            f.write_text(f'$fn=48;\n{body}\n',encoding='utf-8')
            dest=outdir/f'{name}.stl'
            try:
                proc=subprocess.run([openscad,'-o',str(dest),str(f)],capture_output=True,text=True,timeout=timeout)
            except subprocess.TimeoutExpired as e:
                raise RuntimeError('OpenSCAD timed out. Simplify dense mesh or increase timeout.') from e
            if proc.returncode!=0 or not dest.exists() or dest.stat().st_size<84:
                raise RuntimeError(f'OpenSCAD failed for {name}: {(proc.stderr or proc.stdout)[-1000:]}')
            part=load_mesh(dest)
            if not part.is_watertight or len(part.faces)==0:
                raise RuntimeError(f'{name} failed watertight validation; do not print')
            generated.append((name,part, (110,164,212) if name=='lower' else (222,152,82)))
    # Upper is exported in assembly frame; also write on-bed upper at z=0.
    upper_local=generated[1][1].copy()
    upper_local.apply_translation([0,0,-z])
    upper_local.export(outdir/'upper_on_bed.stl')
    write_3mf(generated,outdir/'assembled_split.3mf')
    report={'mode':'planar_mesh_split','split_z_mm':round(z,3),'pegs':len(points),'male_diameter_mm':peg_diameter,
            'diametral_socket_difference_mm':2*clearance,
            'parts':[{'name':name,**report_mesh(part)} for name,part,col in generated],
            'warnings':['Pins require manual placement inside solid material on BOTH sides of seam; XY bbox alone does not guarantee this.',
                        'Inspect sliced upper and lower; support, adhesion, and mechanical fit not validated physically.',
                        'Upper_on_bed.stl rests on the cut plane. assembled_split.3mf preserves assembled positions.']}
    (outdir/'audit_split.json').write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf-8')
    return report


def research_commons(query,outfile,limit=6,session=None):
    """Fetch search citations/rights metadata only, never auto-upload/source faces to providers."""
    if not query.strip() or len(query)>150: raise ValueError('Use a short reference search phrase')
    if not (1<=limit<=10): raise ValueError('Limit 1..10')
    import requests
    session=session or requests
    params={'action':'query','format':'json','generator':'search','gsrsearch':query,
            'gsrnamespace':'6','gsrlimit':str(limit),'prop':'imageinfo','iiprop':'url|extmetadata',
            'iiextmetadatafilter':'LicenseShortName|LicenseUrl|Artist|Credit|AttributionRequired|UsageTerms'}
    resp=session.get('https://commons.wikimedia.org/w/api.php',params=params,headers={'User-Agent':'PrintForgeSkill/2.0 (educational local tool)'},timeout=15)
    resp.raise_for_status()
    doc=resp.json()
    if 'error' in doc: raise RuntimeError(str(doc['error']))
    rows=[]
    for page in doc.get('query',{}).get('pages',{}).values():
        infos=page.get('imageinfo',[])
        if not infos: continue
        meta=infos[0].get('extmetadata',{})
        md={k:v.get('value','') for k,v in meta.items()}
        rows.append({'title':page.get('title'), 'description_page':infos[0].get('descriptionurl'),
                     'file_url':infos[0].get('url'),'license_short':md.get('LicenseShortName','UNKNOWN'),
                     'license_url':md.get('LicenseUrl',''),
                     'artist_html':md.get('Artist',''),
                     'attribution_required':md.get('AttributionRequired','UNKNOWN'),
                     'rights_must_be_checked':True})
    obj={'query':query,'retrieved_from':'Wikimedia Commons API','status':'reference candidates (not verified build blueprints)',
         'results':rows,'warning':'Image licenses, dimensions, viewpoint and subject identity need manual verification. Do not assume every reference allows commercial use.'}
    Path(outfile).parent.mkdir(parents=True,exist_ok=True)
    Path(outfile).write_text(json.dumps(obj,indent=2,ensure_ascii=False),encoding='utf-8')
    return obj


def demo_image(filepath):
    """Generate original geometric icon with alpha as deterministic regression fixture."""
    im=Image.new('RGBA',(180,200),(0,0,0,0)); d=ImageDraw.Draw(im)
    d.ellipse((15,15,165,165),fill=(28,79,152,255))
    d.rectangle((62,55,118,175),fill=(245,186,40,255))
    d.polygon([(45,65),(90,12),(135,65)], fill=(220,67,58,255))
    d.ellipse((78,75,103,100),fill=(255,255,255,255))
    im.save(filepath)
    return str(filepath)
