"""Optional local Gradio interface. Uses CLI-equivalent audited routines."""
from pathlib import Path
import tempfile
import json
import shutil
import zipfile

from .core import make_relief, prepare_mesh,split_mesh,research_commons

def _zip_artifacts(folder):
    p=Path(folder)
    bundle=p/'printforge_outputs.zip'
    with zipfile.ZipFile(bundle,'w',zipfile.ZIP_DEFLATED) as z:
        for f in p.rglob('*'):
            if f.is_file() and f!=bundle:
                z.write(f,f.relative_to(p))
    return str(bundle)


def _relief(image,width,colors,bg):
    if not image: raise ValueError('Please upload an image')
    out=Path(tempfile.mkdtemp(prefix='printforge_relief_'))
    r=make_relief(image,out,width_mm=float(width),colors=int(colors),background=bg)
    return str(out/'palette_preview.png'), _zip_artifacts(out),r


def _mesh(file,height,split_at,pegs):
    if not file: raise ValueError('Please upload a 3D model')
    out=Path(tempfile.mkdtemp(prefix='printforge_mesh_'))
    r=prepare_mesh(file,out,height_mm=float(height))
    if split_at:
        points=[]
        for item in pegs.split(';'):
            if not item.strip():continue
            xy=item.split(',')
            if len(xy)!=2: raise ValueError('Peg format: x,y;x,y in mm (after centering)')
            points.append((float(xy[0]),float(xy[1])))
        split_dir=out/'split'
        r2=split_mesh(out/'normalized_mm.stl',split_dir,z_fraction=.5,peg_points=points)
        r={'normalize':r,'split':r2}
    return _zip_artifacts(out),r


def _references(term):
    out=Path(tempfile.mkdtemp(prefix='printforge_refs_'))
    r=research_commons(term,out/'references.json')
    return str(out/'references.json'),r


def run_gui():
    try:
        import gradio as gr
    except ImportError as e:
        raise RuntimeError('GUI optional dependency missing: pip install -r requirements-gui.txt') from e
    with gr.Blocks(title='PrintForge 2.0 / 3D printing workflow') as app:
        gr.Markdown('## PrintForge 2.0 — Local 3D printing prep\n**Capabilities are separate:** photo → layered 2.5D color relief; imported real 3D → normalize/split; Wikimedia references → rights inspection. True AI 360° mesh requires an external image-to-3D engine.')
        with gr.Tab('Image → Color relief'):
            img=gr.Image(label='Upload PNG (transparent preferred) or photo',type='filepath')
            with gr.Row():
                width=gr.Slider(30,200,value=100,step=5,label='Finished width (mm)')
                colors=gr.Slider(1,6,value=3,step=1,label='Colors (including base)')
            bg=gr.Dropdown(['auto','alpha','white','none'],value='auto',label='Silhouette background')
            go=gr.Button('Generate STL + colored 3MF candidate',variant='primary')
            preview=gr.Image(label='Flat color plan')
            output=gr.File(label='Download STL / 3MF / audit ZIP')
            audit=gr.JSON(label='Geometry and risk report')
            go.click(_relief,[img,width,colors,bg],[preview,output,audit])
        with gr.Tab('Existing 3D → Print pieces'):
            mesh=gr.File(label='Upload GLB / OBJ / STL / PLY',file_types=['.glb','.obj','.stl','.ply'],type='filepath')
            height=gr.Slider(30,250,value=120,step=5,label='Target model height (mm)')
            split=gr.Checkbox(label='Make horizontal Z split with OpenSCAD installed',value=False)
            pegs=gr.Textbox(label='Optional manually measured peg centers, millimeters',placeholder='-8,0;8,0 (leave blank = no pegs)')
            run=gr.Button('Normalize / split / audit',variant='primary')
            z=gr.File(label='Model output ZIP')
            rpt=gr.JSON(label='Geometry report')
            run.click(_mesh,[mesh,height,split,pegs],[z,rpt])
        with gr.Tab('Web reference lookup'):
            term=gr.Textbox(label='Search Wikimedia Commons (reference candidates, not automatically used for reconstruction)',value='antique camera front rear side')
            search=gr.Button('Retrieve references + license metadata')
            refs=gr.File(label='References manifest JSON')
            refreport=gr.JSON(label='Sources and license fields')
            search.click(_references,[term],[refs,refreport])
    app.launch(server_name='127.0.0.1',share=False,inbrowser=True)
