#!/usr/bin/env bash
set -euo pipefail
SOURCE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DEST="${1:-$HOME/.agents/skills/libtv-director-suite}"
if [ "$SOURCE" = "$DEST" ]; then echo "Already at destination"; exit 0; fi
mkdir -p "$(dirname "$DEST")"
TMP="${DEST}.staging.$$"
if [ -e "$TMP" ]; then echo "Staging exists; abort" >&2; exit 1; fi
trap 'rm -rf "$TMP"' EXIT
cp -R "$SOURCE" "$TMP"
if [ -e "$DEST" ]; then
  BACKUP="${DEST}.backup.$(date +%Y%m%d%H%M%S).$$"
  mv "$DEST" "$BACKUP"
  echo "Previous installation saved at $BACKUP"
fi
mv "$TMP" "$DEST"
trap - EXIT
echo "Installed to $DEST"
