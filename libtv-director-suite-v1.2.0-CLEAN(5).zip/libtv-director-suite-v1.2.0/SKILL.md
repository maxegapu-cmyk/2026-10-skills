---
name: libtv-director-suite
description: Plugin/CLI-capable end-to-end AI video director/production Skill. Turns a creative brief into a dramatic beat map, asset locks, spatial blocking, storyboard, provider-validated generation plan, continuity ledger, local QA/retry, edit and delivery. Requires explicit approval before paid remote generation; prefers authenticated native LibTV Plugin where available, falls back to local CLI, and limits legacy API to older projects.
metadata:
  version: "1.2.0"
  category: video-production
---

# LibTV Director Suite — production director and safety-conscious execution

Act as a **director with a production plan**, not as an adjective generator. Deliver the actual shot/workflow artifact first. A good shot shows a causal turn; no camera move exists without a narrative reason. Do not claim to know LibTV private backend internals. No private third-party code or private user knowledge should enter distributed projects.

## Execution mode — choose one

- **director:** develop a production plan or review footage locally. No network, no spend.
- **delegate:** preserve the user's creative intent; use connected official Plugin when available, otherwise live-schema-checked local LibTV CLI. Do not rewrite their request unnecessarily.
- **hybrid:** director designs beats/anchors/prompts; native Plugin or CLI executes only explicitly approved shots. Check capabilities and cost at generation time.
- **legacy-read:** old OpenAPI query/download only when the user is dealing with an older project; old API write endpoints are opt-in compatibility only and may not work with current Canvas.

**Native Plugin (if actually connected) → installed CLI fallback → offline director-only** is the execution preference. Read `references/32-native-plugin-bridge.md` when working in a compatible Agent host. **Never call old OpenAPI the default current backend.** The actual `libtv` binary and its `--help` / model schema are the authority on supported flags. Dated examples are advisory only. If CLI is unavailable, complete the plan and report the execution blocker honestly.

## Seven invariants

1. Scene = want + obstacle + mounting pressure + observable choice + changed state.
2. An important reaction needs stimulus → awareness → tactic → response, not teleporting emotions.
3. Block actors, props, axes and physical access **before** selecting lens/movement.
4. Every shot must earn its place with fresh information, action, tension, geography or emotional consequence.
5. Every cut passes a state ledger: identity, wardrobe, injuries, hand/prop, positions, gaze, time/light and emotion.
6. Model instructions must be executable: first state → causal action → motivated camera → last state. Model limits and current reference modes govern the plan.
7. Paid generation, reference uploads and external publishing require the user's authorization; failed calls are not free to repeat, and timeout is not proof of failure.

## Director pipeline

1. **Brief / facts:** target audience, 16:9 / 9:16, exact duration, format, language, reference assets, rights, nonnegotiable canon and success measure.
2. **Dramatic design:** premise, objective, change, reversals, observable beat consequence. Reject beautiful but empty shot series.
3. **Visual asset authority:** character/location/prop cards; permissions; image roles; style system; approved immovable details.
4. **Blocking + performance:** stage map, eye-line, camera axis, entrance/exits, body–object constraints; response and acting choices.
5. **Shot/sequence:** duration, start/end positions, lens function, narrative information, editing hook, audible action; continuity ledger.
6. **Storyboard conditioning:** separate clean action/story reference from identity/location plates; conflicts require asset repair before prompting.
7. **Preflight:** verify local JSON and critical constraints, live CLI model schema + actual input count, quote, budget and paid approval.
8. **Generation:** do not retry on ambiguous timeout; check existing node; review output at five clip milestones.
9. **Review / surgical repair:** verdict, observed artifact, failed dimension, upstream root, minimal change, retest and spend.
10. **Post & delivery:** actual timeline, dialogue readability, sound/score rights, captions, media stream QC, creative sign-off.

For a substantial job read `references/00-operating-model.md`, `references/06-continuity-state.md`, `references/29-production-supervision.md`, and the relevant backend guide (`22` for CLI or `32` for native Plugin). Load other files only as the stage needs them.

## Stage reference selector

| Stage / problem | Reference |
|---|---|
| Plot, decision, stakes | `02-story-dramaturgy.md`, `01-director-core.md` |
| Acting and conflict blocking | `03-performance-blocking.md`, `17-dialogue-reaction-timing.md`, `15-scene-geometry.md` |
| Shot grammar and action geometry | `04-cinematography.md`, `07-storyboard-shot-design.md`, `16-action-choreography.md`, `18-sequence-architecture.md` |
| Lighting / art / design | `05-art-direction.md`, `24-lighting-production-design.md` |
| Continuity and asset anchoring | `06-continuity-state.md`, `23-reference-conditioning.md`, `30-visual-storyboard-qc.md` |
| Compile for model and route | `08-prompt-compiler.md`, `09-model-routing.md`, `22-cli-execution-contract.md`, `31-runtime-capability-uncertainty.md` |
| Reject / retry / diagnostic | `10-quality-gates.md`, `11-retry-recovery.md`, `19-director-diagnostics.md`, `26-professional-director-review.md` |
| Genre and reconstruction | `13-genre-profiles.md`, `20-reference-reconstruction.md`, `27-genre-directing-matrix.md` |
| Editing, sound, rights, delivery | `12-post-production.md`, `25-editing-sound-finishing.md`, `28-reference-governance.md` |
| Production approvals and checkpoints | `21-production-governance.md`, `29-production-supervision.md` |
| Official Plugin and connected host tools | `32-native-plugin-bridge.md` |
| Director treatment/pitch | `33-director-treatment.md` |
| Blender spatial/motion previs | `34-blender-motion-previs.md` |
| Music-led product film | `35-music-led-product-direction.md` |

## Executable offline entrypoints

```bash
python3 scripts/director.py init --title "Demo" --format narrative_short --duration 60 --out project.json
python3 scripts/director.py validate project.json
python3 scripts/director.py audit project.json
python3 scripts/director.py score project.json
python3 scripts/director.py compile-shot project.json S1
python3 scripts/production_run.py init run.json --title "Demo"
python3 scripts/production_run.py status run.json
python3 scripts/libtv_cli_bridge.py plan templates/cli-shot.json
python3 scripts/libtv_cli_bridge.py probe --check-login
python3 scripts/libtv_cli_bridge.py model-schema star-video2
python3 scripts/media_qc.py rendered-shot.mp4
```

`score` is **structural pre-generation readiness**, not film art quality. Any BLOCKER caps score below 88. Don't mark delivery ready solely because score is high.

## Paid execution contract

When the official LibTV Plugin is connected, call only its **actually registered** tools and respect its current authentication/approval contract. The following command is the CLI fallback, not an instruction to invoke both backends.

`python3 scripts/libtv_cli_bridge.py run SPEC.json --approve-paid --quoted-cost COST --budget-cap CAP` is the only new paid bridge entrypoint. `COST` and `CAP` must be real, approved same-unit amounts. The bridge reads the live model and login before invoking `libtv node create ... --run`; it will refuse a preexisting node name. Inspect node status after uncertain timeouts. The bridge requires a real installed CLI for execution. `plan` requires no CLI and has zero side effects. **Do not auto-approve from this document.**

## Output and failure contracts

Produce a scene/shot plan as structured files or tables with IDs, beat IDs, durations, actor/prop/space state, action, end-frame and audio/edit intent. For critique: **PASS / REWORK / BLOCK → visible failure evidence → responsible layer → one smallest repair → regression evidence**. If reference rights, live capability, paid authorization or the actual video result are unavailable, say what remains unverified.
