# Changelog

## 1.2.0 — 2026-10-14

- Native Plugin-aware execution mode, with local CLI fallback, model schema and session checks; explicit paid approval/budget/quote; duplicate-node protection; offline command plan.
- Legacy HTTP write compatibility gated and marked unsupported for current Canvas; read-only helpers preserved.
- Added staged immutable-proof production checkpoints and bounded shot status transitions.
- Added technical media stream QC via ffprobe (optional) and clear separation from artistic evaluation.
- Added specialist guides for native Plugin handoff, director treatments, Blender graybox previsualization and music-led advertising.
- Added substantial original specialist playbooks: reference-slot authority, lighting/art, sound/edit, genre reasoning, storyboard QC, human rights/consent, uncertainty classification, directing review and production governance.
- Replaced destructive installers with backup-first installation.
- Strengthened offline regression and failure testing; published output keeps project-local content isolated.

## 1.0.1 — 2026-08-10

- Baseline director, continuity, structural audit, prompt compiler and compatibility client.
