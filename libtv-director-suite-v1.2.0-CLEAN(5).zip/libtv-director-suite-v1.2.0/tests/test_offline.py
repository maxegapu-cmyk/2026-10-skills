import json, subprocess, sys, unittest, tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
DIR=ROOT/'scripts'/'director.py'
class Tests(unittest.TestCase):
    def runj(self,*args):
        p=subprocess.run([sys.executable,str(DIR),*map(str,args)],capture_output=True,text=True)
        return p, json.loads(p.stdout) if p.stdout.strip().startswith('{') else None
    def test_good_valid(self):
        p,j=self.runj('validate',ROOT/'tests/fixtures/good_project.json'); self.assertEqual(p.returncode,0); self.assertTrue(j['valid'])
    def test_bad_invalid(self):
        p,j=self.runj('validate',ROOT/'tests/fixtures/bad_project.json'); self.assertNotEqual(p.returncode,0); self.assertFalse(j['valid'])
    def test_good_audit(self):
        p,j=self.runj('audit',ROOT/'tests/fixtures/good_project.json'); self.assertEqual(p.returncode,0); self.assertTrue(j['pass']); self.assertEqual(j['findings'],[])
    def test_bad_audit(self):
        p,j=self.runj('audit',ROOT/'tests/fixtures/bad_project.json'); self.assertNotEqual(p.returncode,0); self.assertFalse(j['pass']); self.assertTrue(any(x['severity']=='BLOCKER' for x in j['findings']))
    def test_continuity_mismatch_blocked(self):
        d=json.loads((ROOT/'tests/fixtures/good_project.json').read_text(encoding='utf-8'))
        d['shots'][1]['continuity_in']['red_seal']='already destroyed and discarded'
        with tempfile.TemporaryDirectory() as td:
            f=Path(td)/'mismatch.json'; f.write_text(json.dumps(d,ensure_ascii=False),encoding='utf-8')
            p,j=self.runj('audit',f)
            self.assertNotEqual(p.returncode,0)
            self.assertTrue(any(x['code']=='CONTINUITY_MISMATCH' for x in j['findings']))
    def test_good_score(self):
        p,j=self.runj('score',ROOT/'tests/fixtures/good_project.json'); self.assertGreaterEqual(j['score'],88); self.assertEqual(j['blockers'],0)
    def test_bad_score(self):
        p,j=self.runj('score',ROOT/'tests/fixtures/bad_project.json'); self.assertLess(j['score'],60); self.assertFalse(j['ready'])
    def test_compile(self):
        p=subprocess.run([sys.executable,str(DIR),'compile-shot',str(ROOT/'tests/fixtures/good_project.json'),'S2'],capture_output=True,text=True); self.assertEqual(p.returncode,0); self.assertIn('END STATE',p.stdout); self.assertIn('red tamper seal',p.stdout)
    def test_init_has_governance(self):
        with tempfile.TemporaryDirectory() as td:
            out=Path(td)/'p.json'
            p=subprocess.run([sys.executable,str(DIR),'init','--title','x','--out',str(out)],capture_output=True,text=True)
            self.assertEqual(p.returncode,0); d=json.loads(out.read_text(encoding='utf-8')); self.assertIn('governance',d); self.assertIn('scene_geometry',d)
if __name__=='__main__': unittest.main()
