import importlib.util, os, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('libtv_client',ROOT/'scripts/libtv_client.py')
mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
class ClientOffline(unittest.TestCase):
    def test_extract_tool_result_urls(self):
        msgs=[{'role':'tool','content':'{"task_result":{"images":[{"previewPath":"https://libtv-res.liblib.art/a.png"}],"videos":[{"url":"https://libtv-res.liblib.art/b.mp4"}]}}'}]
        self.assertEqual(mod.extract_urls(msgs),['https://libtv-res.liblib.art/a.png','https://libtv-res.liblib.art/b.mp4'])
    def test_missing_key_fails_without_network(self):
        old=os.environ.pop('LIBTV_ACCESS_KEY',None)
        try:
            with self.assertRaises(RuntimeError): mod.key()
        finally:
            if old is not None: os.environ['LIBTV_ACCESS_KEY']=old
    def test_default_base_https(self):
        self.assertTrue(mod.BASE.startswith('https://'))
if __name__=='__main__': unittest.main()
