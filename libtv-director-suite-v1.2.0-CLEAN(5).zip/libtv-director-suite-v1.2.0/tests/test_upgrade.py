import importlib.util, json, os, subprocess, sys, tempfile, unittest, shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def module(name):
    p=ROOT/'scripts'/f'{name}.py'; spec=importlib.util.spec_from_file_location(name,p)
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
BRIDGE=module('libtv_cli_bridge')
RUN=module('production_run')

class CliBridgeTests(unittest.TestCase):
    def good(self):return json.loads((ROOT/'templates/cli-shot.json').read_text())
    def test_plan_is_offline(self):
        with tempfile.TemporaryDirectory() as t:
            spec=Path(t)/'shot.json';spec.write_text(json.dumps(self.good()))
            env=os.environ.copy();env['LIBTV_CLI_PATH']='/does/not/exist'
            p=subprocess.run([sys.executable,str(ROOT/'scripts/libtv_cli_bridge.py'),'plan',str(spec)],env=env,capture_output=True,text=True)
            self.assertEqual(p.returncode,0,p.stderr)
            data=json.loads(p.stdout)
            self.assertFalse(data['paid_action']);self.assertNotIn('--run',data['command_argv'])
    def test_arg_order_references(self):
        d=BRIDGE.load_spec(ROOT/'templates/cli-shot.json')
        cmd=BRIDGE.build_argv(d)
        idx=[i for i,x in enumerate(cmd) if x=='--left']
        self.assertEqual([cmd[i+1] for i in idx],d['reference_nodes'])
        self.assertEqual(cmd[:3],['libtv','node','create'])
    def test_reject_bad_reference_count(self):
        with tempfile.TemporaryDirectory() as t:
            d=self.good();d['reference_nodes']=[]
            file=Path(t)/'bad.json';file.write_text(json.dumps(d))
            with self.assertRaises(ValueError): BRIDGE.load_spec(file)
    def test_reject_untrusted_name(self):
        with tempfile.TemporaryDirectory() as t:
            d=self.good();d['node_name']='--run; rm -rf /'
            f=Path(t)/'bad.json';f.write_text(json.dumps(d))
            with self.assertRaises(ValueError): BRIDGE.load_spec(f)
    def test_paid_execution_denied_without_approval(self):
        with tempfile.TemporaryDirectory() as t:
            path=Path(t)/'shot.json';path.write_text(json.dumps(self.good()))
            p=subprocess.run([sys.executable,str(ROOT/'scripts/libtv_cli_bridge.py'),'run',str(path)],capture_output=True,text=True)
            self.assertNotEqual(p.returncode,0)
    def fake_cli(self,path, prior='missing'):
        script='''#!/usr/bin/env python3
import json,os,sys
args=sys.argv[1:]
log=os.environ.get("FAKE_CLI_LOG")
if args[:1]==["node"] and args[1:2]==["create"]:
    if log: open(log,"a").write(json.dumps(args)+"\\n")
    print("created");sys.exit(0)
if args[:1]==["node"] and len(args)==2:
    sys.stderr.write("RESPONSE\\n");sys.exit(1)
print("model or login ready");sys.exit(0)
'''.replace('RESPONSE', 'not found' if prior=='missing' else 'connection timeout')
        path.write_text(script);path.chmod(0o755)
    def test_fake_cli_paid_path(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t); f=root/'shot.json';f.write_text(json.dumps(self.good()))
            cli=root/'libtv';self.fake_cli(cli)
            log=root/'log'; env=os.environ.copy();env['LIBTV_CLI_PATH']=str(cli);env['FAKE_CLI_LOG']=str(log)
            p=subprocess.run([sys.executable,str(ROOT/'scripts/libtv_cli_bridge.py'),'run',str(f),
                '--approve-paid','--quoted-cost','1','--budget-cap','2'],capture_output=True,text=True,env=env)
            self.assertEqual(p.returncode,0,p.stderr)
            self.assertTrue(log.exists()); self.assertIn('--run',log.read_text())
    def test_inconclusive_existing_check_blocks_submit(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t); f=root/'shot.json';f.write_text(json.dumps(self.good()))
            cli=root/'libtv';self.fake_cli(cli,'timeout'); log=root/'log'
            env=os.environ.copy();env['LIBTV_CLI_PATH']=str(cli);env['FAKE_CLI_LOG']=str(log)
            p=subprocess.run([sys.executable,str(ROOT/'scripts/libtv_cli_bridge.py'),'run',str(f),
                '--approve-paid','--quoted-cost','1','--budget-cap','2'],capture_output=True,text=True,env=env)
            self.assertNotEqual(p.returncode,0);self.assertFalse(log.exists())

class RunStateTests(unittest.TestCase):
    def test_progress_and_stale_evidence(self):
        with tempfile.TemporaryDirectory() as t:
            f=Path(t)/'run.json';d=RUN.init('test');RUN.save(f,d)
            with self.assertRaises(ValueError):RUN.advance(d)
            proof=Path(t)/'brief.md';proof.write_text('approved proposal')
            RUN.record(d,'brief_approved',proof);RUN.advance(d)
            self.assertEqual(d['stage'],'DRAMA')
            RUN.record(d,'dramatic_beats',proof)
            proof.write_text('changed after approval')
            with self.assertRaises(ValueError):RUN.advance(d)
    def test_status_transition(self):
        d=RUN.init('x');self.assertIn('BRIEF',RUN.STAGES)
        with tempfile.TemporaryDirectory() as t:
            f=Path(t)/'r.json';RUN.save(f,d)
            cmd=[sys.executable,str(ROOT/'scripts/production_run.py'),'shot-status',str(f),'S1','PASS']
            self.assertNotEqual(subprocess.run(cmd,capture_output=True).returncode,0)
            for status in ['PLANNED','SUBMITTED','RENDERED','PASS']:
                self.assertEqual(subprocess.run(cmd[:-1]+[status],capture_output=True).returncode,0)
            self.assertEqual(RUN.read(f)['shots']['S1']['status'],'PASS')
    def test_budget_preconditions(self):
        d=RUN.init('x');
        with self.assertRaises(ValueError):
            for_change=RUN.advance(d)

class PackageChecks(unittest.TestCase):
    def test_markdown_assets_present(self):
        for name in ('22-cli-execution-contract.md','23-reference-conditioning.md','25-editing-sound-finishing.md','26-professional-director-review.md','31-runtime-capability-uncertainty.md'):
            self.assertTrue((ROOT/'references'/name).is_file())
    def test_cli_no_accidental_network_during_plan(self):
        d=BRIDGE.load_spec(ROOT/'templates/cli-shot.json')
        self.assertNotIn('--run',BRIDGE.build_argv(d))
    def test_legacy_write_gated(self):
        p=subprocess.run([sys.executable,str(ROOT/'scripts/libtv_client.py'),'send','hello'],capture_output=True,text=True)
        self.assertNotEqual(p.returncode,0);self.assertIn('Legacy API write disabled',p.stderr)

if __name__=='__main__':unittest.main()

class LegacyDownloadSafety(unittest.TestCase):
    def test_discard_private_network_result(self):
        m=module('libtv_client')
        payload=[{'role':'tool','content':json.dumps({'task_result':{'videos':[{'url':'http://127.0.0.1:8989/secrets.mp4'},{'url':'https://libtv-res.liblib.art/legit.mp4'}]}})}]
        self.assertEqual(m.extract_urls(payload),['https://libtv-res.liblib.art/legit.mp4'])
    def test_discard_wrong_host(self):
        m=module('libtv_client');self.assertFalse(m.media_url('https://libtv-res.liblib.art.attacker.invalid/result.mp4'))
