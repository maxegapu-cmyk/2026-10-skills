# LibTV Director Suite v1.2.0

Independent AI-video director and production-control Skill with optional native LibTV Plugin integration or local LibTV CLI fallback. This release prioritizes an **actually executable and testable path** over pretending to contain hidden LibTV server-side Agent code.

## What works offline

- Dramatic-structure and shot-state validation, structural readiness scoring, per-shot prompt compilation.
- Original directing playbooks across story, blocking, performance, action, camera, lighting, visual identity, reference conditioning, genre, sound/edit, rights, continuity, review and bounded retry.
- Production stage checkpoints with SHA256 evidence, budget gate and finite shot-state transitions.
- CLI command planning without API calls or payment.
- Local `ffprobe` technical inspection when installed; manual film/art QC remains mandatory.

## Live execution: native Plugin first, CLI fallback

If the host has the **official LibTV Plugin** installed and authenticated, discover its actual available tools and use them for provider-side operations; see `references/32-native-plugin-bridge.md`. The provider publishes installation instructions at its official Plugin page. Its Remote MCP/OAuth and bundled specialist features are **not** shipped or impersonated here.

Otherwise use the actual `libtv` command, logged in to the intended Canvas project; query its live model schema before using sample parameters. The package does **not** bundle proprietary executables, login keys, private model schemas or cloud render credits.

## Install

Unzip, then from the **extracted top-level package directory** run:

```bash
bash install.sh "$HOME/.agents/skills/libtv-director-suite"
# or on Windows PowerShell:
# .\install.ps1 -Destination "$HOME\.agents\skills\libtv-director-suite"
```

The installer backs up an existing installation instead of deleting it. Manual installation via copying the folder is also supported; preserve `SKILL.md` at skill root.

## Fast practical walkthrough

```bash
python3 scripts/director.py self-test
python3 -m unittest discover -s tests -v
python3 scripts/libtv_cli_bridge.py plan templates/cli-shot.json
python3 scripts/libtv_cli_bridge.py probe --check-login
python3 scripts/libtv_cli_bridge.py model-schema star-video2
```

Edit `templates/cli-shot.json` with the **current** model key/name, mode, existing reference nodes and validated parameters. The checked sample is not the same as verified current availability.

For production checkpoints:

```bash
python3 scripts/production_run.py init run.json --title "My Film"
python3 scripts/production_run.py proof run.json brief_approved brief-approved.md
python3 scripts/production_run.py advance run.json
python3 scripts/production_run.py status run.json
```

For generation, real quotes and a separately approved cap are required; `plan` never spends. After submitting a shot, record the existing node identity; if the process times out, **query the node before retrying**.

## Compatibility and limits

- A connected official Plugin and local CLI login were **not available in this build environment**, so provider-side live rendering was not tested. All documented current details are subject to local CLI confirmation.
- Historic OpenAPI is preserved only for old projects, with write operations locked behind an explicit opt-in.
- Media review of a generated film cannot be demonstrated without footage. Unit tests prove code paths and schema handling, not artistic taste.
- `config/model-registry.json` lists possible model families, not certified or live-enabled endpoints.

See `SKILL.md` for mode routing, `references/22-cli-execution-contract.md` for the current adapter, and `RELEASE_REPORT.md` for precise tested and untested boundaries.
