# Release verification — 1.2.0 (2026-10-14)

## Status

**Plugin-aware Skill runtime / offline release:** verified through unit, simulated CLI, local state and technical media tests after fresh unpacking. **Live LibTV account and paid model rendering:** not verified in this environment, not represented as completed.

## Verified scope

- Existing 1.0.1 director contracts and good/bad scene tests retain compatibility.
- Current Skill routes connected official Plugin operations only through discovered host tools (not tested here), or offers safe CLI `plan` mode without network/expenditure.
- Simulated `libtv` binary accepted create-node argument ordering, paid approval and cost gating; ambiguous node status correctly blocked creation.
- Legacy API write is disabled by default.
- Stage checkpoints reject missing or mutated SHA256 evidence and invalid shot-state skips.
- Package source, metadata and manifests are integrity-checked. Fresh extraction validation is required before release.
- A locally generated synthetic MP4 passed real `ffprobe` technical validation; artistic review remains unclaimed.
- 27 offline unit tests passed before final packaging; final release is also re-tested from a fresh ZIP extraction.

## Unverified and non-goals

- No claim of reconstructing the private LibTV backend Agent, copying its internal prompt catalog or including all Skills from unrelated repositories.
- An authenticated native Plugin, live provider credentials, active model list, current price, queue behavior, returned media download path and actual paid end-to-end production have not been exercised. A real local CLI session and funded account are required.
- Director readiness score is a structural gate, not a guaranteed grade of aesthetic quality. Actual video quality requires side-by-side trials with real renders.
- Any legal/source attribution obligations for future imported third-party code must be checked before incorporating it; this release is an independently written integration rather than a mirrored external repository.
