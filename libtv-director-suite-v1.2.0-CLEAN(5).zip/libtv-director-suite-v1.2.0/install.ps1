param([string]$Destination = "$HOME/.agents/skills/libtv-director-suite")
$ErrorActionPreference = 'Stop'
$Source = Split-Path -Parent $MyInvocation.MyCommand.Path
$Destination = [System.IO.Path]::GetFullPath($Destination)
if ($Source -eq $Destination) { Write-Output 'Already at destination'; exit 0 }
$Parent = Split-Path -Parent $Destination
New-Item -ItemType Directory -Force -Path $Parent | Out-Null
$Temp = "$Destination.staging.$PID"
if (Test-Path $Temp) { throw "Staging directory already exists: $Temp" }
try {
  Copy-Item -Recurse -Force -Path $Source -Destination $Temp
  if (Test-Path $Destination) {
    $Stamp = Get-Date -Format 'yyyyMMddHHmmss'
    $Backup = "$Destination.backup.$Stamp.$PID"
    Move-Item -Path $Destination -Destination $Backup
    Write-Output "Previous installation saved at $Backup"
  }
  Move-Item -Path $Temp -Destination $Destination
  Write-Output "Installed to $Destination"
} finally {
  if (Test-Path $Temp) { Remove-Item -Recurse -Force $Temp }
}
