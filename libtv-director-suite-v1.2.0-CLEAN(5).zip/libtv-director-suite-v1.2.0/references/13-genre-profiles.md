# Genre profiles

These are priority shifts, not rigid formulas.

## Narrative short / drama

Priority: character choice, reaction, relationship power, setup/payoff, continuity. Camera supports performance.

## Vertical short drama

Priority: immediate readable conflict, strong facial/reaction coverage, clean object/identity continuity, compressed beats, decisive episode-end state. Avoid empty speed.

## Cinematic film / trailer

Priority: world scale + character point of view + motif + escalation. Spectacle should change stakes or reveal world rules.

## MV

Priority: musical structure, visual motif development, performance identity, rhythmic transformation. Narrative causality may be looser but image progression must evolve.

## TVC / brand film

Priority: single proposition, product/brand role in causality, memorable visual proof, clean pack/product state, legal/brand constraints, end-card legibility.

## Product showcase

Priority: material truth, geometry, feature proof, lighting readability, continuity of product orientation. Camera move exists to reveal a feature.
