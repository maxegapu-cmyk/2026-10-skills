# Post-production

Editing should preserve causal comprehension.

## Cut on

- decision
- reaction completion
- action continuation
- gaze target
- sound cue
- reveal of consequence

## Rhythm

Shorter is not automatically faster. Perceived pace comes from information change. Hold long enough for recognition on critical reactions and irreversible evidence.

## Sound

Use sound to establish off-screen cause, bridge cuts, motivate attention, and create anticipation. Avoid wallpaper sound effects that do not alter perception.

## Final continuity pass

Before delivery inspect every cut for: position, screen direction, prop state, hand, wardrobe, light/time, emotional state, motion vector and audio continuity.
