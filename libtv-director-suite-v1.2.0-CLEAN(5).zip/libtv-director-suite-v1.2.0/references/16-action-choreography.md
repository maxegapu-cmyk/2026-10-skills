# Action choreography

Action is readable causality under time pressure. Do not treat it as a list of spectacular moves.

## Action unit

Build action from units:
**threat → perception → tactic → counter → consequence → new tactical problem**.

For each unit record:
- attacker/initiator
- target
- vector and distance
- prop/weapon state
- defensive option
- environmental obstacle
- who has positional advantage at the end

## Executability

Generated video degrades when one clip asks for too many independent body interactions. Prefer one dominant physical exchange plus one readable reaction per generation unit. Split complex choreography at state boundaries.

## Contact integrity

For contact actions, specify:
- which limb/hand/object initiates contact
- contact point
- direction of force
- body response
- where the object and bodies end

Do not use vague verbs such as 'they fight intensely' when the story depends on a specific action.

## Camera for action

Prioritize readable vectors and geography over constant camera motion. Use closer coverage for consequence/reaction, not to hide every spatial transition. A moving camera must preserve the audience's ability to understand who is where and what changed.

## Failure repair

If choreography mutates, reduce simultaneous events first. If identity fails during high motion, anchor with a stronger start frame/reference mode. If contact remains impossible, redesign the action rather than adding adjectives.
