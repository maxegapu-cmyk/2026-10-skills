# Fast-changing provider capabilities: never freeze guesses into rules

The agent must distinguish four classes of knowledge:

* **Verified now:** CLI responses or account-visible docs captured for the current environment.
* **Dated external test:** a community or vendor demonstration with timestamp and bounded model/mode.
* **Heuristic:** production strategy requiring local testing.
* **Unknown:** price, rights, availability, capability or output behavior not currently checked.

The model registry may suggest candidates but cannot authorize requests. At the moment of paid generation, re-check current schema for input modality, reference slots, duration, size, frame ratio, audio handling, output types and accepted keys. If an expected parameter is absent, stop; do not trial-and-error with a paid request.

Prefer capability routing by job: stable actor identity, exact first/last state, object interaction, dialogue/lip sync, scene complexity, duration, budget. Avoid global 'best model' rankings. Record both successes and failures on controlled fixed inputs to support future routing improvements; do not extrapolate one prompt to all genres.
