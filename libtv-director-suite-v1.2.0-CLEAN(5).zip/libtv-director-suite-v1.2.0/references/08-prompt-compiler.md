# Prompt compiler

The production plan is model-agnostic. Compile only approved state into generation prompts.

## Fixed compilation order

1. **Shot purpose / event** — what must become true in this shot.
2. **Subjects + identity locks** — who/what is present; immutable attributes only.
3. **Action + performance** — chronological observable behavior.
4. **Blocking / spatial coordinates** — starts, movement path, end relation, props/hands.
5. **Camera** — framing, angle, lens effect, movement, focus behavior.
6. **Lighting / production design** — only scene-relevant visual system.
7. **Continuity anchors** — inherited state that must not drift.
8. **Audio/dialogue** — if the model/channel supports it.
9. **Negative constraints** — only known failure risks, not giant generic negative lists.
10. **End-state anchor** — exact final frame/state required for the next shot.

## Prompt rules

- Chronology beats adjective density.
- Use concrete nouns and active verbs.
- Put critical constraints near the action they constrain.
- Do not repeat the same instruction in five synonyms.
- Do not ask for impossible simultaneous camera geometry.
- Do not mix style transfer with identity redesign.
- For exact continuity, explicitly mention first-frame and end-frame states.

## Compiler output

A good prompt can be read as a tiny shooting instruction. It should be possible to storyboard from the prompt without guessing what changes over time.
