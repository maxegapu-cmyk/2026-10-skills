# Rights, privacy, authenticity and reference governance

Record asset ID, creation/source, owner/permission, allowed edits, identity/voice consent, commercial use permission, expiry, sensitive information, and where used. If not known, label **unverified**, not approved. Generated images may still reproduce protectable elements and should be reviewed before external distribution.

Video reconstruction: separate observable camera/composition technique from protected creative expression. For a reference scene, extract lens effect, spatial relationships, pacing and lighting principles without automatically cloning an identifiable performer or copyrighted scene. Explicitly distinguish documentary evidence from AI dramatization.

Release scans must include entire extracted package tree and archives, not only README. Detect account secrets and system-specific private paths. A brand/service URL needed for functionality is acceptable when disclosed as a runtime dependency; references and credits should not be falsified. Independently authored text and code can be distributed without an attribution list, but imported third-party text/code must retain any legally required notices. Never disguise inherited licensing obligations as original ownership.
