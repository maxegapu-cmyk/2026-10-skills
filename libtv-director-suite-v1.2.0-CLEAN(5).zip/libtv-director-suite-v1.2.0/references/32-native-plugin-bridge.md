# Native LibTV Plugin integration (when connected)

A supported Agent host may have the **official LibTV Plugin**, connected through authenticated remote MCP. This is the preferred **live** execution method in such hosts. It is separate from this independent director Skill, which owns the creative and QC decisions. Do not fabricate tool names, schemas, scopes or OAuth state.

## Host discovery, in order

1. Check the host's actual connected Plugin/tool list for an authenticated LibTV capability.
2. If connected, inspect the tools' actual descriptions, schemas and available permissions. Select only supported operations; no undocumented raw HTTP requests.
3. Prepare a scoped request containing shot ID, purpose, asset references, exact state in/out, visual locks, and permitted changes. Keep private project notes out of the tool request.
4. Confirm current credits/charge and obtain explicit consent before any costly call. Account OAuth authentication by itself is **not** spending consent.
5. Capture the returned project/node/result identifiers in local run state. Never assert success before actual tool output.
6. If plugin not connected, fall back to the locally installed LibTV CLI after its own schema/login preflight. If neither exists, provide an offline production-ready plan.

## Where native Plugin fits

The native integration may offer provider-side generation, assets, a creative treatment/presentation workflow, scene management, Blender motion previews, and music-led advertising if those abilities are actually exposed in the user's connected version. These are **optional** provider abilities, not a claim that the standalone Skill ships them.

## No double execution

A host must choose **one execution backend per shot**. Do not submit the same paid node through Plugin and CLI in parallel. Cross-backend IDs and project visibility must be checked, not assumed. Record the execution backend in the shot ledger. On timeout query the same backend's existing task before any retry.

## Installation and update

Open the provider's official Plugin installation page from a browser, follow the current Codex marketplace/Plugin steps and authorize using your own account. On supported Codex clients the published package is named `libtv`; exact install steps can change, so use the live official instructions. Restart/reload tools after upgrading.
