# Sequence and multi-shot architecture

A sequence is not a bag of attractive shots. It is a chain of information and state transitions.

## Sequence spine

Define:
- opening question / unstable condition
- escalation steps
- midpoint or tactic change
- commitment / point of no easy return
- payoff or new problem
- final image that proves the state change

## Coverage hierarchy

Design coverage in this order:
1. indispensable proof shot
2. indispensable decision/reaction shot
3. geographic orientation shot if needed
4. action bridge / continuity shot
5. optional texture shot

Texture never outranks proof.

## Information economy

Each cut should do at least one of:
- answer a question
- create a stronger question
- transfer attention
- reveal consequence
- change scale or geography for a reason
- compress time while preserving causality

If two adjacent shots communicate the same fact at the same emotional level, combine or remove one.

## Boundary anchors

For AI-generated sequences, deliberately design first and last frame states. Adjacent shots should connect by at least one strong anchor: gaze, motion vector, prop state, body pose, composition, sound or lighting cue.

## Escalation

Escalation means the available choices become worse, narrower or more expensive—not merely that music gets louder or shots get closer.
