# Performance and blocking

## Performance ladder

Direct in observable layers:
1. intention: what the character is trying to get from the other person
2. tactic: threaten, soothe, hide, test, seduce, stall, intimidate, confess, escape
3. behavior: gaze, breath, hand tension, body orientation, pace, hesitation, object handling
4. reaction: what changes after new information lands

Avoid generic commands like 'very emotional' without behavior.

## Blocking before camera

Record:
- starting coordinates/relative positions
- facing directions and eyelines
- path of movement
- entry/exit points
- prop ownership and hand
- foreground/background relationships
- who controls center/height/distance

Power can be staged spatially: approach/retreat, standing/sitting, doorway control, obstruction, isolation, entering another person's space.

## Reaction priority

When a stimulus changes the scene, allocate visible reaction time. A reaction should have onset → recognition → decision. Do not cut directly from stimulus to unrelated action unless disorientation is intentional.

## Micro-continuity

If a hand touches a prop, track which hand. If a character crosses frame direction, preserve screen direction or motivate the reversal with a neutral/reorientation shot.
