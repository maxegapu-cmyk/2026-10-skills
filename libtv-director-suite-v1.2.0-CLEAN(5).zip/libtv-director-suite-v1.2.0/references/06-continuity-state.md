# Continuity state

Continuity is a state-transition problem, not a reminder sentence.

## Character lock

Track per character:
- identity geometry / defining features
- hair and facial hair
- wardrobe layers/accessories
- injuries/dirt/wetness
- carried props
- current emotional strategy
- current location and screen position

## Prop lock

Track: owner, hand/location, orientation, intact/broken/open/closed, clean/dirty/wet, visible evidence and whether the audience has already seen it.

## Shot boundary contract

Each shot stores:
- `continuity_in`: exact state required at first frame
- `continuity_out`: exact state created at last frame

The next shot must either consume `continuity_out` or declare a motivated discontinuity (time jump, location cut, montage, deliberate ellipsis).

## Screen direction

Track principal travel direction and eyelines. If reversing them, use a crossing-axis motivation, neutral angle, insert or clear geographic re-establishment.

## Continuity repair

When mismatch occurs, identify whether the error is identity, wardrobe, prop, spatial, temporal, lighting, emotional or motion-state. Repair only that layer unless multiple locks are corrupted.
