# Story and dramaturgy

## Dramatic spine fields

- protagonist
- present behavior / governing rule
- concrete want
- deeper need or unresolved contradiction
- obstacle / opposing force
- stakes if they do nothing
- pressure that collapses the old option
- decisive action
- irreversible consequence
- changed final state / final image

## Scene design

For each scene:
1. Entry condition: what the character believes/wants before the scene.
2. Active objective: something playable now, not 'feel sad'.
3. Opposition: person, system, environment, time, body, information or self-conflict.
4. Turn: new information or action that invalidates the current tactic.
5. Choice: observable action with a cost.
6. Exit condition: state after the choice.

## Compression rules for AI video

- Enter late; leave early.
- Merge exposition into conflict or object interaction.
- Give one beat one dominant action.
- Avoid more named characters than the shot duration can visually establish.
- Prefer a concrete prop or spatial threshold as the carrier of a decision.
- If a line repeats what the image already proves, cut the line.

## Dialogue

Dialogue should attack, defend, evade, bargain, reveal, misdirect or decide. Explanatory dialogue is a last resort.
