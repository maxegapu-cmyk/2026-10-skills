# Storyboard and shot design

## Required shot fields

- shot id / beat id
- duration
- narrative function
- subject and active verb
- performance/reaction
- blocking and spatial relation
- framing and angle
- camera movement (or explicitly static)
- lighting/environmental change if relevant
- continuity_in / continuity_out
- audio/dialogue cue

## Shot test

Before keeping a shot ask:
1. What new thing can the audience understand after this shot?
2. Why is this framing better than the previous framing for that information?
3. What must be true at its first frame?
4. What changes by its last frame?
5. Can the target model execute the action cleanly within the duration?

## Temporal design

For short generated clips, keep action topology simple: one dominant action, one clear reaction, one camera behavior. Split when the shot requires multiple independent state changes that the model may collapse.

## Transitions

Design transitions around continuity of motion, gaze, object, sound, shape, light or causal action — not random effects.
