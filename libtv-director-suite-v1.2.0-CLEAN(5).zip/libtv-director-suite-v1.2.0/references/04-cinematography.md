# Cinematography

Camera is a consequence of story information.

## Shot-function mapping

- reveal geography / danger relation → wide or motivated reframe
- read decision / recognition → medium close or close reaction
- object proof / irreversible trace → insert/detail with readable scale
- power imbalance → angle/height/foreground control only if it strengthens the beat
- pursuit/instability → motivated movement tied to subject velocity
- intimacy / trapped attention → stable closer coverage, reduced visual escape routes

## Movement rule

No camera move without a reason. A push-in should mark increasing attention/commitment; a pull-back should reveal isolation/context/loss; lateral tracking should preserve or expose spatial relation; orbiting is rarely justified by itself.

## Lens language

Use focal length as spatial behavior, not decoration:
- wider: stronger perspective, environment pressure, kinetic proximity
- normal: neutral spatial reading
- longer: compressed relation, isolation, surveillance, graphic control

Do not over-specify exact millimeters when the target model does not reliably honor them; preserve the intended spatial effect.

## Coverage economy

Prefer a shot that carries two compatible functions over two redundant shots. Do not change angle merely to create variety.
