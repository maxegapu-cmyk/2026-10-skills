# Music-led product film — precise sync and claim-safe finish

Define the product truth first: physical dimensions, logo/finish, mechanism, allowed claims, camera-safe reference angles and legal review. Music is a choreography clock, not a license to distort identity.

## Timing design

Make a phrase map: meter, tempo, beat timestamps, instrumental events, phrase starts and climaxes. At each phrase boundary choose a visible product action (fabric unfolding, rotation, assembly, fluid pour) or a shift in framing. Avoid 'one take' promises unless the action can occur on one consistent path. Use the actual measured performance recording or approved audio master, never a guessed BPM.

## Shot construction

First state: the product has stable geometry and label placement. Middle: motion follows a physically credible path with tactile forces, reflections, friction and material behavior. End state: hero composition with readable product ID/feature and space for accurate composited text. For a single take, track camera/world coordinates through the whole timeline and identify where the model is likely to invent a hidden cut.

## Audio and rights

Verify composition and recording rights separately. If an original generated/performed track is requested, keep stems and timing reference. Do not redistribute bundled third-party score or recording assets merely because they appeared in an example. Mix for dialogue/feature intelligibility where applicable and check soundtrack sync against the final rendered timeline, not just the draft storyboard.

Grade by product accuracy, feature comprehension, musical synchronization, camera continuity and brand-safe delivery, not merely visual polish.
