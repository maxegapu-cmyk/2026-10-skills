# Production supervision and stage handoffs

## Nine handoffs

Brief → Dramaturgy → Asset locks → Spatial blocking → Storyboard → Paid preflight → Generation → Media review → Edit & delivery. Each handoff has an owner (the host Agent may fulfill several roles) and independently checkable proof. A validator passing is necessary but not sufficient for creative approval.

Use `scripts/production_run.py`: initialize run; record an evidence file under the expected key; advance only after proof hashes are intact. Evidence is immutable by hash, so overwriting a storyboard invalidates the checkpoint until reapproved. Record scoped budget quote and explicit approval before any generating stage. Shot statuses may move `PLANNED → SUBMITTED → RENDERED → PASS` or go through `FAIL → PLANNED` after repair; no free jump from FAIL to PASS.

## Change control

A major story/character/style change invalidates downstream storyboards and generation prompts. A prop color correction can be a local update, but every downstream shot that displays that prop must be flagged. Keep a decision log: what changed, why, affected shot IDs, assets frozen, retest needed. Never use 'automatic self-improvement' as a license to rewrite locked goals.

## Cost policy

Estimate a range only from platform-visible quotes. Reserve approved cap, record each render, stop before exceeding cap. Use lower-cost drafts only if the actual model supports them; a lower resolution is not guaranteed cheaper. Avoid false confidence around refunds, queue latency or model availability.
