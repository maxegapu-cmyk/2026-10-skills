# Reference-driven reconstruction

A reference is evidence, not a command to clone. Extract transferable production logic while keeping the new work differentiated.

## Decompose the reference

Analyze separately:
- hook mechanism
- scene/beat structure
- average shot duration and rhythm
- framing progression
- camera behavior
- performance intensity
- visual hierarchy
- lighting and palette logic
- transition grammar
- sound/music relationship
- title/subtitle/graphic behavior

## Preserve vs replace

Explicitly mark:
- structural principles worth preserving
- subject matter that must change
- distinctive protected expression that should not be copied
- production constraints imposed by available models/assets

## Reconstruction test

The new work should produce a similar *viewing function* (pace, clarity, escalation, visual discipline) without reproducing unique characters, dialogue, exact shot sequence, logos or signature protected elements.
