# Production governance

Director quality includes knowing when not to generate.

## Preflight

Before paid generation confirm:
- delivery promise is explicit
- script/beat/shot state passes structural gates
- assets/rights are available
- model mode matches hardest shot requirement
- estimated attempts and fallback path exist
- expensive hero shots are not being used for exploration

## Approval boundaries

Human approval is recommended before:
- changing the creative premise
- replacing a locked character/brand identity
- materially changing claims in factual/commercial work
- escalating budget beyond the agreed cap
- discarding an accepted scene and restarting upstream

## Decision log

Record meaningful choices as: problem → options → chosen path → reason → evidence/result. Do not log trivial internal steps.

## Delivery promise

At final review compare output against what was promised, not against what the pipeline happened to generate. A technically valid render that misses the promised story, product, duration or identity is a failure.
