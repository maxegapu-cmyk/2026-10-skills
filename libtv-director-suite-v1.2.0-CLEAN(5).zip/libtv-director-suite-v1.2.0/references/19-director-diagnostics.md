# Director diagnostics

Use this when a result is technically competent but feels flat, random or 'AI-made'. Diagnose before rewriting.

## Flat scene

Symptoms: beautiful shots, no tension, interchangeable order.
Likely cause: no objective/obstacle/turn or no costly choice.
Repair: identify one decision that changes state; rebuild coverage around its evidence.

## Mechanical scene

Symptoms: action follows prompt literally but characters feel like puppets.
Likely cause: missing stimulus-registration-decision-reaction chain.
Repair: add behavioral preparation and reaction; remove redundant locomotion.

## Music-video syndrome

Symptoms: constant camera motion, pose changes, inserts and lighting shifts without story logic.
Likely cause: variety was optimized instead of information.
Repair: assign every shot a narrative function; delete shots with duplicate function.

## Geography collapse

Symptoms: people teleport, exits switch sides, props jump hands.
Likely cause: no explicit state map or boundary contract.
Repair: freeze scene geometry and continuity_in/out; regenerate only affected shots.

## Prompt bloat

Symptoms: contradictory style/camera/action instructions; model ignores key action.
Likely cause: production plan was dumped into one prompt.
Repair: compile only the current shot, chronological actions first, critical locks adjacent to the action.

## False cinematicity

Symptoms: shallow depth of field, anamorphic flare, handheld movement, slow motion—yet no stronger storytelling.
Likely cause: cinematic vocabulary substituted for directing.
Repair: strip ornamental camera/style instructions; restore only those that make the dramatic fact clearer.
