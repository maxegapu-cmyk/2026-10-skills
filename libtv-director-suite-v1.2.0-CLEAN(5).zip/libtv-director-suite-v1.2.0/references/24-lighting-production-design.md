# Lighting and production design that communicate story

## Design contract

Lock the scene's era, materials, weather, practical light sources, major color relationships, character wardrobe silhouette and spatial landmarks. The art direction must show what changed in the story: a previously pristine room becomes disturbed; authority is exposed by furniture placement; a reflective surface reveals someone before the protagonist notices. 'Beautiful' is not a valid causal function by itself.

Lighting must use a believable source: window side, streetlamp, fluorescent ceiling, fireplace, mobile screen or motivated offscreen spill. Specify direction, softness, intensity relative to background, falloff and motivated color temperature; don't pile 'cinematic rim light, volumetric, bloom' everywhere. Lock source placement across shots to prevent faces flipping key light side when crossing the axis.

## Before generating each scene

Create three entries: `lighting_source_map`, `set_landmarks`, `material_behavior`. Check reflections, wet surfaces, transparent objects and exposure changes. During dialogue reverses, preserve time-of-day and key-light continuity while allowing motivated close-up cheats. Establish silhouette readability at target viewing size, not just full-resolution stills.

## Failure cases and repair

* **A face looks pasted on:** reference lighting inconsistent → reconcile direction/exposure of character asset and plate before rerender.
* **Everything glows:** competing practicals + aggressive global bloom → remove unsupported light sources and define one hierarchy.
* **Wardrobe morphs:** inconsistent reference authority → mark asset ID, lock costume pieces and show a stable character plate.
* **World feels generic:** no design meaning → choose 2–3 story-specific objects whose positions/states the audience can track.

Separate visual design sign-off from video model fidelity checks; technical sharpness is not art direction.
