# Model and generation-mode routing

Route by capability, not brand loyalty. Model names are volatile; see the dated registry in `config/model-registry.json`.

## Choose generation mode first

- **text-to-video**: no stable identity asset needed, broad concept/exploration.
- **first-frame image-to-video**: preferred default when identity/composition must be anchored and the shot has a clear starting state.
- **first+last frame**: use when exact endpoint/transition continuity matters and both boundary frames can be defined.
- **reference-image video**: use when recurring character/location identity matters more than a fixed first-frame composition.
- **video-to-video / action transfer**: use when motion choreography is the source of truth.

## Capability dimensions

Score candidate models on: identity fidelity, prompt obedience, complex motion, camera obedience, start/end-frame control, multi-character stability, duration, native audio/lipsync, resolution, latency, cost, moderation fit.

## Routing policy

1. Eliminate models that cannot express the required control mode.
2. Prefer the model whose strongest axis matches the hardest shot constraint.
3. Use cheaper/faster models for design exploration; reserve high-cost models for approved hero shots.
4. If a shot fails twice for the same model-capability reason, change generation mode/model rather than endlessly rewriting wording.
