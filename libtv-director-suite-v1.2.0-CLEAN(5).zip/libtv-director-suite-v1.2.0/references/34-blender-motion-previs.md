# Blender motion previs → generative video

Use a temporary graybox scene when shot geography and camera trajectory are too complex for text. The purpose is motion truth: actor paths, set size, camera moves, speed changes and lens/field of view, not final appearance.

## Pipeline

1. Block key spatial landmarks with proportional primitives and assign persistent asset IDs.
2. Add characters as rigs or labeled stand-ins, with measured scale, start/end positions and facing.
3. Define camera trajectory, horizon, approximate focal length/FOV, height, path and speed curve.
4. Play the shot at delivery frame rate; prove actor–camera occlusion and collisions make sense.
5. Export start, middle and end preview images/video with stable timing, not raw scene secrets.
6. Verify provider supports the intended conditioning mode before upload; use preview frames as camera/motion constraints while authorized character/location plates control identity and art.
7. Review generated clip against the proxy path and reaction beats. If space fails, repair Blender blocking before rewriting ornate prompts.

Don't assume a plugin includes Blender installation or can execute scripts without local setup. Never auto-run arbitrary downloaded Blender scripts; inspect dependencies, paths, file writes and asset licenses before running. Treat simulation preview as a different source of truth from final film quality.
