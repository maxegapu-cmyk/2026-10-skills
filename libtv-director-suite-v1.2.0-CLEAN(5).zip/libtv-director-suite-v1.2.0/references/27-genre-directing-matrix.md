# Genre-specific directing logic (load only one or two profiles)

Use genre to choose **information rhythm and audience contract**, not an adjective list.

**Science fiction / war:** terrain, logistics, sensory overload and command hierarchy must constrain tactics; establish geography before complex action; machinery has momentum, reaction time and consequences. Scale is earned by human-scale reference and audible distance, not simply vast backgrounds.

**Horror / cosmic dread:** define what is known vs suspected; hold meaningful offscreen space; let sound or character attention anticipate reveal. Avoid using a jump scare to pay off a contradiction. The unknown must remain causally consistent.

**Fantasy / historical:** fix material culture, political roles, costume function and world rules. Magic should have visible cost or limitations when narrative depends on it. Historical facts and fictional invention should not be blurred.

**Romance / relationship drama:** stage who approaches, retreats, watches and breaks eye contact; use objects and pauses to show agency. The climax is a changed choice, not just a glamorous closeup. Actor reactions matter more than camera drift.

**Short-form high-retention narrative:** first beat must introduce a specific tension or unresolved question without misrepresenting the content. Every escalation supplies new information, not recycled shouting. Resolve or intentionally defer the promised payoff.

**Product/TVC:** prioritize accurate product identity and claims. Lock package geometry, brand marks, interfaces and legal copy as composited assets rather than trusting generative video for precise text. Test the hero feature legibility and compliant CTA.

**MV:** beat map, phrase boundaries and recurrent visual motif govern cutting. A lyric is not always literal imagery; music-driven visual transformation should stay spatially and stylistically legible.

**Documentary/reconstruction:** mark sourced fact vs illustrative generation, avoid invented archival evidence, preserve provenance and obtain rights. Use exact graphic overlays for dates, stats and charts.

Choose one delivery success test for each genre before storyboard creation; do not grade all formats by 'cinematic feeling'.
