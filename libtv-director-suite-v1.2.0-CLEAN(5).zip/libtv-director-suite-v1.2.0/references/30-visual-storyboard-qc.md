# Storyboard and preview review

## Three-board system

1. **Narrative board:** each panel identifies a dramatic function and an observable state transition.
2. **Clean generation board:** camera/action pose frames with irrelevant markings removed, plus separate identity/location anchor plates.
3. **Continuity board:** the first/last frame and physical state of each final clip, including nearest cut boundaries.

A nine-panel board is a convenient UI representation, not a law. Use as many panels as necessary for the real sequence. If a model treats the collage as a single literal image, switch to one shot per conditioning image; verify rather than assume multipanel interpretation.

Storyboard contract per shot: ID; beat ID; duration; character and prop IDs; spatial axis; camera position/trajectory; principal action; reaction beat; first frame; last frame; expected edit point; reference priority; allowed variance. Use stable shot identifiers so corrected variants don't break the master edit map.

Pass/fail: no overwritten figure identity, no arbitrary object invention, no text labels in generated picture unless intentionally composited, no mirrored geography without established transition, no invisible story beat. Final review is on rendered footage, not storyboard aesthetics.
