# Quality gates

## Gate A — story/directing

Pass only if the scene has a legible objective, obstacle, turn, choice and changed state; the decisive visual fact is visible without narration.

## Gate B — visual continuity

Pass only if identity, wardrobe, prop state, location geometry, screen direction, light/time and first/last-frame state are compatible with neighboring shots.

## Gate C — motion/performance

Pass only if the intended action occurs in the right order, reactions are readable, anatomy is stable enough, and camera motion does not contradict subject motion.

## Gate D — technical

Pass only if duration, crop/aspect, resolution, text/logo requirements, audio and file integrity meet delivery constraints.

## 100-point pre-generation rubric

- directing intent: 20
- dramatic causality: 20
- shot design: 20
- continuity: 15
- performance/blocking: 10
- technical feasibility: 10
- QA/recovery readiness: 5

Recommended expensive-generation threshold: **88**. This is a local quality policy, not an official LibTV score.
