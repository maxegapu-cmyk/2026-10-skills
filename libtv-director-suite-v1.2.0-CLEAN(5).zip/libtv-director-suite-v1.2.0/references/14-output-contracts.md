# Output contracts

## Beat output

`ID | objective | obstacle | turn | decision/action | consequence | visual proof`

## Shot output

`SHOT_ID | duration | narrative_function | subject/action | performance | blocking | camera | continuity_in | continuity_out | audio`

## QA output

`verdict | failed_dimension | evidence | consequence | smallest_fix | upstream_change_required`

## Generation handoff

Send only:
- current shot purpose
- current shot prompt
- required reference assets
- immutable continuity locks
- expected end state
- technical parameters

Do not flood the generation model with the entire screenplay unless needed.
