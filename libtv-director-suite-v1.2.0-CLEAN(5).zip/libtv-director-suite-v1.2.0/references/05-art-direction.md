# Art direction and visual system

Global visual design should be compact and reusable.

Freeze:
- medium / realism level
- era and production-design logic
- dominant material language
- color relationships (not just color names)
- lighting logic by time/location
- texture / grain / cleanliness
- costume silhouette and hero identifiers
- environment motifs

Separate **identity locks** from **style variables**. A style change must not mutate face/body/wardrobe identity unless explicitly requested.

For recurring locations, maintain a location card: layout, doors/windows, major furniture, light sources, landmark props, direction of travel, day/time state.
