# Director review board — decisions rather than keyword coverage

Review scene / sequence / whole film independently. No average score can excuse a critical continuity failure.

| Dimension | Reviewer question | Evidence | Blocking failure |
|---|---|---|---|
| Dramaturgy | Is the choice forced by a changed situation? | Beat → consequence on-screen | Beat depends on narration instead of visible choice |
| Acting | Can the audience read stimulus → assessment → tactic? | Observable reaction before action | Instant or contradictory emotional jump |
| Blocking | Can actions occur in the established space? | Map, anchors, entrance/exit | Impossible positions or body/object teleport |
| Camera | What audience information does framing expose or hide? | Shot function | Decorative motion hides decisive action |
| Continuity | Are identity, hand, prop state, light and direction carried? | Boundary ledger | Unmotivated prop, outfit or injury change |
| Time | Can the action and dialogue physically fit? | Read time, handles | Complex multi-action compressed into impossible seconds |
| Editing | Do cuts establish direction, intent and aftermath? | Timeline with causal cut reasons | Action consequence absent |
| Sound | Does sound clarify space and emotion? | Stems, transient placement | Speech not intelligible |
| Rights/safety | Are reference assets and voices authorized? | consent/rights ledger | No permission for identity/voice use |

## Critical stop conditions

Wrong character, unsafe or unauthorized identity reproduction, inconsistent key plot object, physical impossibility in the narrative hinge, misleading synthetic real-world claim, paid generation without authorization, absent source rights or no verifiable output. Mark these as blockers, not small deductions.

## Review return schema

`{shot_id, verdict: PASS|REWORK|BLOCK, category, observable_evidence, upstream_layer, smallest_fix, preserved_assets, estimated_cost_scope, retest}`. Never write 'try improving the prompt' without identifying the mechanism of failure.

## Evaluation integrity

Structural validator checks fields and local consistency. Separate applied tests check director judgment, including counterexamples where a beautiful but causally empty sequence must fail. Keep evaluation answer keys outside distributed runtime so benchmark answers are not fed back into the agent as recipes.
