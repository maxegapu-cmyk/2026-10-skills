# LibTV CLI execution contract (runtime-verified)

## Two control planes, no confusion

The **director** owns decisions: dramatic intent, beat map, asset locks, camera, prompt, QC. The **executor** owns current capability discovery, asset upload, node creation, render status and retrieval. CLI-first is the default. The legacy HTTP adapter is disabled for writing unless manually overridden; do not rely on it for current Canvas projects.

## Proof ladder

1. `libtv --version` and `libtv --help`: is the local binary installed?
2. `libtv account info`: is the local session authenticated? Never echo or commit login tokens.
3. `libtv model <model-key>`: read the live model schema. Distinguish query `modelKey` from submitted `modelName`.
4. `libtv node --help` / `libtv node create --help`: confirm exact flags on the installed version.
5. Inspect project and reference-node existence. Keep project UUID, node names and reference order in local state, not in the cinematic prompt.
6. Build a no-cost command plan via `python3 scripts/libtv_cli_bridge.py plan templates/cli-shot.json`.
7. Obtain visible provider price, explicit human approval and spending cap. Never invent a quote.
8. Before creation, inspect the desired node name. A timed-out submit is **unknown**, not a failed job. Query existing node before retrying.
9. Consume only verified output media. Inputs and outputs can coexist in node structures; validate the returned stream/media.

## Reference slot semantics

The usable reference order is **model- and mode-scoped**, not a universal truth. For supported multi-reference image2video in a historical controlled test: clean storyboard/action frame first; locked character image second; scene layout third; prop reference afterward. Verify live mode schema and actual output; single-frame, start/end-frame and mixed audio-video modes have different slot contracts. Never force 9 references when fewer serve the shot.

The storyboard should encode scene geometry and action, not be a tiny illegible textual instruction sheet. Clean metadata (numbers, arrows, legend) before conditioning if the generator copies graphic annotations into frames. Review the cleaned image because image-editing can silently change acting or objects.

## Current sample vs live truth

The included sample spec uses model key `star-video2`, model name `StarVideo 2.0`, image2video, 720p and 8 seconds because these were documented in a dated public CLI test. This is **not** a claim that the same choices are current, available or optimal today. Query the installed CLI, update the JSON, and verify the live schema before spending. Provider model pricing and API rules are volatile.

## Exact commands

```bash
python3 scripts/libtv_cli_bridge.py plan templates/cli-shot.json
python3 scripts/libtv_cli_bridge.py probe --check-login
python3 scripts/libtv_cli_bridge.py model-schema star-video2
python3 scripts/libtv_cli_bridge.py node-status scene01_shot01_preview
# Only after human approval and checking provider-displayed price:
python3 scripts/libtv_cli_bridge.py run shot01.json --approve-paid --quoted-cost 50 --budget-cap 100
```

`50` and `100` above are **syntax placeholders**, not rates or recommendations. Omit run until you have real values. The bridge never executes paid generation from `plan` and uses argument arrays, not shell string interpolation.

If no binary is installed, deliver validated director plan and CLI instructions, not a fabricated render status.
