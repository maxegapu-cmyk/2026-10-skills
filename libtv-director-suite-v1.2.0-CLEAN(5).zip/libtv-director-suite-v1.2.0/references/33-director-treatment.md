# Director treatment and presentation deliverable

A director treatment converts the brief into a compact **decision record**, not a collage of generic inspiration. For an editable 16:9 presentation, keep the story's key uncertainties visible rather than asserting premature certainty.

## Recommended page sequence

1. Film promise, audience, length and impact.
2. Logline, dramatic question and ending shift.
3. Lead characters: what each wants, hides, fears; stakes and on-screen acting evidence.
4. Visual world: reference mood, production-design constraints and no-go motifs.
5. Spatial strategy: important sets, axes, entrances/exits, camera direction and lighting.
6. Sequence arc: beats, changing status/pressure and shot emphasis.
7. Show 3–6 hero-frame storyboards: opening information, turning point, final state; caption with shot function, not adjectives.
8. Performance and sound: reaction timing, silence, Foley and music hierarchy.
9. Production feasibility: reference asset readiness, model modes verified, expensive/hard shots, cost cap.
10. Approval decisions: alternatives, unsettled risks and exact next step.

Use real, permission-cleared image assets; label mockups and unrendered frames. Never claim a speculative storyboard is an actual LibTV rendered sample. Export the requested document or slide format if tools support it; if not, provide structured page-by-page content without pretending to create editable files.
