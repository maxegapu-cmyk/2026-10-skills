# Retry and recovery

Never retry blindly.

## Failure taxonomy

- S: story/intent failure
- I: identity failure
- C: continuity/spatial failure
- A: action/performance failure
- K: camera failure
- V: visual/art-direction failure
- T: technical/model limitation

## Repair ladder

1. Preserve all passing dimensions.
2. Rewrite only the failing instruction or state field.
3. Simplify action topology if the model collapsed multiple events.
4. Change generation mode if boundary control is the problem.
5. Change model if the failure matches a model capability ceiling.
6. Roll upstream only if the shot itself is structurally impossible or the global lock is wrong.

Record attempt, diagnosis, change, result. Two identical failures with no hypothesis change is not iteration; it is gambling.
