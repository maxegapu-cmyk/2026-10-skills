# Director core

Directing is the conversion of invisible intention into visible behavior over time.

## Scene equation

**desire + resistance + pressure + choice = change**

The audience should be able to infer the emotional or strategic change from action, reaction, spatial behavior, object handling and camera emphasis — not from a paragraph explaining it.

## Strong beat tests

A beat is strong when at least one changes:
- knowledge
- power
- commitment
- relationship distance
- physical access/escape
- possession/control of an object
- moral position
- perceived risk

A beat is weak when it merely repeats mood, exposition or locomotion.

## Irreversibility

Prefer choices that leave evidence: a broken seal, sent message, discarded badge, opened door, surrendered weapon, public confession, crossed boundary, missed train, destroyed object. Physical evidence makes abstract choice cinematic.

## Visual priority

For every beat identify the single visual fact the audience must not miss. Compose coverage around that fact. Everything else is secondary.
