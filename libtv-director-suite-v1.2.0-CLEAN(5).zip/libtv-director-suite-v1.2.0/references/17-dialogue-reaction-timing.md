# Dialogue, reaction and timing

Dialogue consumes visible time. Every spoken line competes with action, reaction and camera comprehension.

## Timing budget

For each shot budget separately:
- orientation time
- line delivery
- listener reaction
- physical action
- camera transition/reframe
- end-state hold needed for the cut

If the sum is unrealistic, shorten dialogue or split the shot. Do not accelerate performance until it feels unnatural just to preserve text.

## Reaction chain

A meaningful stimulus should normally produce:
1. arrival of stimulus
2. registration
3. internal evaluation visible through behavior
4. decision
5. response

The duration can be tiny, but deleting the chain often makes characters look robotic.

## Dialogue function

Every line should have a playable function: provoke, conceal, test, bargain, command, seduce, evade, confess, threaten, reassure, misdirect, decide. If a line only explains an image already visible, prefer the image.

## Subtext

Direct the discrepancy between spoken line and behavior. Example structure: words concede, body blocks the exit; words reassure, hand hides evidence. This is more filmable than asking for 'subtle complex emotion'.

## Turn ownership

Know who owns the scene before and after each exchange. A reaction shot is justified when it transfers information, power or commitment—not simply because another person spoke.
