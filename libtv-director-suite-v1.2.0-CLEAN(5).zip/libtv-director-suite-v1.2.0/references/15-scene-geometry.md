# Scene geometry and staging

A scene should be drawable as a map before it is shot. If the director cannot explain the spatial relation, a video model will invent it.

## Geometry map

For each scene establish:
- entrances, exits and hard thresholds
- important foreground / midground / background zones
- fixed landmarks that orient the audience
- who owns the center, doorway, height advantage or escape path
- where every critical prop begins
- principal eyeline axis and travel axis
- safe camera zones and any deliberate axis crossing

## Staging progression

Blocking should change with dramatic power. Use spatial verbs: approach, yield, intercept, corner, separate, cross, block, reveal, retreat, occupy, abandon.

A useful progression is:
1. establish stable relation
2. introduce pressure into the geometry
3. force a reposition or denied path
4. make a choice visible through movement or refusal to move
5. end on a new spatial fact

## Threshold directing

Doors, elevators, cars, gates, desks, beds, weapons, phones, badges and other boundaries can externalize a decision. Track which side of the threshold each character occupies before and after the beat.

## Reorientation rule

If a cut risks confusing left/right, foreground/background or destination, spend a short shot on reorientation rather than trying to repair confusion with dialogue.
