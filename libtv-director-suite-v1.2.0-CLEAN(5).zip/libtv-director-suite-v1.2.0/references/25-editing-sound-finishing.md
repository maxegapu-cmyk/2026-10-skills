# Edit, sound and delivery: separate temporal truth from clip generation

The timeline is a single ordered sequence of shots with unique IDs, source paths, source in/out, final in/out, audio cues, subtitles and transitions. Do not use the source filename as a timeline ID. Reserve handles before transitions; an 8-second generated clip is not necessarily 8 seconds usable.

## Edit logic

Choose cuts from **information flow** (what audience already knows), **movement flow** (direction and action match), **gaze** (who reacts to what), **sound bridges**, and **emotional pressure**. Do not add dissolves to conceal missing causal beats. Match action/eyeline before stylized grading.

## Sound layers

Treat dialogue, room tone/ambience, Foley, designed effects, music and silence as separate tracks. Fix dialogue intelligibility before music polish. A door latch heard before a door opens may be intentional anticipation; log intentional offsets. Avoid voice timbre drift across cuts: use one approved speaker reference with permission. Do not assume `enableSound=off` guarantees a silent file or sound-on guarantees usable dialogue: inspect streams.

## Timing/QC

For speaking shots, obtain a real read or forced-alignment duration; preserve micro-pauses and reaction time. For an action scene, sound must follow contact/impacts at a causally coherent frame. Technical output: verify resolution/aspect, length, actual streams, codec compatibility, loudness, no black frames, caption timing, missing media and rights. Use `scripts/media_qc.py` for first-pass file metadata only; **it cannot judge artistic quality**.

Delivery contract: master video; optional clean picture; split audio stems; subtitles; shot cue list; edit decision list; source/rights manifest; unresolved issues. Do not mark DELIVERY complete until a human or qualified QC agent actually checks the rendered master.
