# Reference conditioning and scene-to-video conversion

**Decision:** choose text2video only if the shot tolerates identity drift and no important visual state needs preservation; use single image to animate one fixed design; first/last image when the exit state must be exact; multi-reference when identity, camera plan and environment each need distinct authorities; mixed-media only when current model schema supports those modalities.

## Reference-precedence record

Define for each input: `(node_name, role, authority, allowed_to_change)`. Example: story frame controls camera/action but must not overwrite a face; character portrait controls face/wardrobe, not furniture; location reference controls geometry/light direction, not acting; prop reference controls marks, colors and physical state.

Conflicts are a blocker. When a storyboard depicts a blue jacket but the approved character is in a tan coat, do not silently ask the model to average: edit the storyboard or explicitly state which reference is authoritative. Do not substitute AI-generated faces for identifiable real people without consent.

## Short shot preflight

Record exact opening frame: positions, orientation, limb state and props. List at most one main action arc and one emotional reaction arc per short shot. Give the model a camera path that does not contradict the characters' movement. Describe a **positive target state**; long negative inventories can increase accidental inclusion. Define ending frame so the next shot can pick up.

Review at 0%, 25%, 50%, 75%, 100% of the clip for new objects, clothing morph, duplicated anatomy, reversed screen direction, sudden camera teleport, action omissions and unmotivated cut. Record failure types rather than vague feedback such as 'bad vibe'.

## Local repair ladder

1. Fix a wrong reference slot or dirty storyboard **before** modifying prompt prose.
2. Fix mismatched story/action/time budget **before** raising resolution.
3. Reduce simultaneous interactions and break at a stable continuity boundary.
4. Re-render only the failing shot, retaining seed/settings when supported; never claim a seed guarantees identical output.
5. If repeated failure with fixed inputs, switch generation mode or model after live capability check; log the tradeoff and cost.

Do not create paid retry loops without a human-approved budget and retry cap.
