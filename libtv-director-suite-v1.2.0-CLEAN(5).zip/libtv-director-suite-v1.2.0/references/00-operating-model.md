# Operating model

## Production state machine

`BRIEF -> DRAMATIC_SPINE -> BEATS -> LOCKS -> BLOCKING -> SHOTS -> PROMPTS -> ASSETS -> CLIPS -> EDIT -> DELIVERY`

A downstream stage may read upstream state; it may not silently rewrite it. If a downstream failure exposes a bad upstream decision, record the rollback reason explicitly and return to the smallest responsible stage.

## Roles (logical, not mandatory separate agents)

- Creative Director: premise, audience promise, tone, non-negotiables.
- Writer/Story Editor: causality, compression, setup/payoff, dialogue economy.
- Director: performance, blocking, shot purpose, emotional legibility.
- Art Director: visual system and asset locks.
- Cinematographer: lens/framing/movement/light motivated by beat.
- Continuity Supervisor: state ledger across shots.
- Prompt Compiler: translates approved direction into model-facing instructions.
- Technical Director: chooses generation mode/model capability.
- QA: judges story legibility, identity, continuity, motion, artifacts.
- Editor/Sound: timing, transitions, sonic causality.

Do not spawn roles just to look sophisticated. One host model may perform all roles sequentially if it preserves the contracts.

## Checkpoints

Use human confirmation only when the choice is high-cost or materially changes the work: premise/ending, hero design, global visual language, major storyboard direction, paid generation batch, final cut. Minor repairs should not force a full stop.

## Artifact rule

Each stage produces one authoritative artifact. Later stages reference it by ID. Never have two conflicting 'final' versions in active state.
