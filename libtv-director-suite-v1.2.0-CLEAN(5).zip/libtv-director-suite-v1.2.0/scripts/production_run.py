#!/usr/bin/env python3
"""Deterministic resumable production checkpoint manager, no API/network access."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import tempfile
import sys

STAGES = ('BRIEF','DRAMA','ASSETS','BLOCKING','STORYBOARD','PREFLIGHT','GENERATING','REVIEW','EDIT','DELIVERY')
PROOF = {
 'DRAMA': ('brief_approved',),
 'ASSETS': ('dramatic_beats',),
 'BLOCKING': ('asset_locks',),
 'STORYBOARD': ('geometry_and_blocking',),
 'PREFLIGHT': ('shot_plan',),
 'GENERATING': ('preflight_pass','spend_approved'),
 'REVIEW': ('render_inventory',),
 'EDIT': ('shot_review_pass',),
 'DELIVERY': ('edit_qc_pass','rights_confirmed')
}

def timestamp(): return datetime.now(timezone.utc).isoformat()

def checksum(value): return hashlib.sha256(value.encode('utf-8')).hexdigest()

def read(path):
    d=json.loads(Path(path).read_text(encoding='utf-8'))
    if d.get('schema_version')!=1 or d.get('stage') not in STAGES or not isinstance(d.get('proof'),dict):
        raise ValueError('invalid production run state')
    return d

def save(path, doc):
    f=Path(path); f.parent.mkdir(parents=True,exist_ok=True)
    fd,name=tempfile.mkstemp(prefix='.run-',dir=str(f.parent))
    try:
        with os.fdopen(fd,'w',encoding='utf-8') as h:
            json.dump(doc,h,ensure_ascii=False,indent=2); h.write('\n'); h.flush(); os.fsync(h.fileno())
        os.replace(name,f)
    finally:
        if os.path.exists(name): os.unlink(name)

def init(title):
    return {'schema_version':1,'title':title,'stage':'BRIEF','proof':{},'cost':{'approved_cap':None,'quoted':None,'spent_reported':None},
            'shots':{},'events':[{'at':timestamp(),'type':'run_created','stage':'BRIEF'}]}

def record(d, key, path):
    if not key.replace('_','').isalnum(): raise ValueError('invalid proof key')
    p=Path(path)
    if not p.is_file() or p.stat().st_size==0:
        raise ValueError('evidence file must exist and be nonempty')
    h=hashlib.sha256(p.read_bytes()).hexdigest()
    d['proof'][key]={'path':str(p.resolve()),'sha256':h}
    d['events'].append({'at':timestamp(),'type':'proof_recorded','key':key,'sha256':h})

def advance(d):
    i=STAGES.index(d['stage'])
    if i==len(STAGES)-1: raise ValueError('delivery already reached')
    destination=STAGES[i+1]
    missing=[]
    for proof in PROOF.get(destination,()):
        v=d['proof'].get(proof, {})
        p=Path(v.get('path',''))
        if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=v.get('sha256'):
            missing.append(proof)
    if missing: raise ValueError('missing/stale evidence for '+destination+': '+', '.join(missing))
    if destination=='GENERATING':
        cap=d['cost']['approved_cap']; quote=d['cost']['quoted']
        if not isinstance(cap,(float,int)) or not isinstance(quote,(float,int)) or not 0<quote<=cap:
            raise ValueError('paid stage requires recorded visible quote and explicit approved cap')
    d['stage']=destination
    d['events'].append({'at':timestamp(),'type':'stage_entered','stage':destination})


def main():
    ap=argparse.ArgumentParser(); sp=ap.add_subparsers(dest='cmd',required=True)
    a=sp.add_parser('init'); a.add_argument('file'); a.add_argument('--title',required=True)
    a=sp.add_parser('status'); a.add_argument('file')
    a=sp.add_parser('proof'); a.add_argument('file'); a.add_argument('key'); a.add_argument('evidence_path')
    a=sp.add_parser('budget'); a.add_argument('file'); a.add_argument('--approved-cap',type=float,required=True); a.add_argument('--quoted',type=float,required=True)
    a=sp.add_parser('advance'); a.add_argument('file')
    a=sp.add_parser('shot-status'); a.add_argument('file'); a.add_argument('shot_id'); a.add_argument('status',choices=['PLANNED','SUBMITTED','RENDERED','PASS','FAIL']); a.add_argument('--note',default='')
    args=ap.parse_args()
    try:
        if args.cmd=='init':
            if Path(args.file).exists(): raise ValueError('run state already exists: refusing overwrite')
            d=init(args.title)
        else: d=read(args.file)
        if args.cmd=='proof': record(d,args.key,args.evidence_path)
        elif args.cmd=='budget':
            if not 0<args.quoted<=args.approved_cap: raise ValueError('quote must be positive and <= approved cap')
            d['cost']['approved_cap']=args.approved_cap; d['cost']['quoted']=args.quoted
            d['events'].append({'at':timestamp(),'type':'budget_confirmed','approved_cap':args.approved_cap,'quoted':args.quoted})
        elif args.cmd=='advance': advance(d)
        elif args.cmd=='shot-status':
            if len(args.shot_id)>120 or not args.shot_id.strip(): raise ValueError('bad shot ID')
            previous=d['shots'].get(args.shot_id,{}).get('status')
            allowed={None:{'PLANNED'},'PLANNED':{'SUBMITTED','FAIL'},'SUBMITTED':{'RENDERED','FAIL'},'RENDERED':{'PASS','FAIL'},'FAIL':{'PLANNED'},'PASS':set()}
            if args.status not in allowed.get(previous,set()):
                raise ValueError(f'invalid shot state transition {previous} -> {args.status}')
            d['shots'][args.shot_id]={'status':args.status,'note':args.note}
            d['events'].append({'at':timestamp(),'type':'shot_status','shot_id':args.shot_id,'status':args.status})
        if args.cmd!='status': save(args.file,d)
        print(json.dumps(d if args.cmd=='status' else {'ok':True,'stage':d['stage'],'events':len(d['events'])},ensure_ascii=False,indent=2))
    except (ValueError,OSError,json.JSONDecodeError) as e:
        print(json.dumps({'ok':False,'error':str(e)},ensure_ascii=False),file=sys.stderr);sys.exit(2)
if __name__=='__main__': main()
