#!/usr/bin/env python3
"""Offline director preflight: initialize, validate, audit, score and compile shots."""
import argparse, json, re, sys
from pathlib import Path

REQUIRED_CREATIVE=["premise","protagonist","want","stakes","dramatic_question","change","ending_image"]
BEAT_FIELDS=["objective","obstacle","turn","decision","consequence"]
SHOT_FIELDS=["narrative_function","subject","action","performance","blocking","framing","camera_move","continuity_in","continuity_out"]


def load(p): return json.loads(Path(p).read_text(encoding="utf-8"))
def save(p,x): Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
def nonempty(v): return v not in (None,"",[],{})
def norm(v): return re.sub(r"\s+"," ",str(v).strip().lower())

def compatible(a,b):
    """Loose boundary check: exact or one state description contains the other."""
    if isinstance(a,(dict,list)) or isinstance(b,(dict,list)): return a == b
    x,y=norm(a),norm(b)
    return x==y or (len(x)>=3 and x in y) or (len(y)>=3 and y in x)

def init_project(title,fmt,duration,ratio):
    return {
      "meta":{"title":title,"format":fmt,"target_duration_sec":duration,"aspect_ratio":ratio,"status":"BRIEF"},
      "delivery":{"audience":"","language":"","must_have":[],"must_not":[],"source_assets":[]},
      "creative":{"premise":"","protagonist":"","want":"","need":"","stakes":"","dramatic_question":"","change":"","ending_image":""},
      "style":{"medium":"","visual_world":"","camera_language":"","lighting":"","texture":""},
      "scene_geometry":{"landmarks":[],"entrances":[],"exits":[],"principal_axis":"","travel_direction":""},
      "characters":[],"locations":[],"props":[],"beats":[],"shots":[],
      "governance":{"budget_cap":None,"approval_required_for":["premise_change","identity_change","budget_overrun"]},
      "decision_log":[],
      "qa":{"retry_policy":"local_only","generation_threshold":88,"notes":[]}
    }

def validate(p):
    e=[]
    for k in ["meta","creative","style","characters","locations","beats","shots","qa"]:
        if k not in p: e.append(f"missing top-level field: {k}")
    if e: return e
    if not p["meta"].get("title"): e.append("meta.title is empty")
    if p["meta"].get("target_duration_sec",0)<=0: e.append("meta.target_duration_sec must be > 0")
    ids=set()
    for b in p["beats"]:
        if not b.get("id"): e.append("beat without id"); continue
        if b["id"] in ids: e.append(f"duplicate id: {b['id']}")
        ids.add(b["id"])
        for f in BEAT_FIELDS:
            if not nonempty(b.get(f)): e.append(f"beat {b['id']} missing {f}")
    shot_ids=set()
    for s in p["shots"]:
        sid=s.get("id")
        if not sid: e.append("shot without id"); continue
        if sid in shot_ids: e.append(f"duplicate shot id: {sid}")
        shot_ids.add(sid)
        if s.get("beat_id") and s["beat_id"] not in ids: e.append(f"shot {sid} references unknown beat {s['beat_id']}")
        if s.get("duration",0)<=0: e.append(f"shot {sid} duration must be >0")
        for f in SHOT_FIELDS:
            if not nonempty(s.get(f)): e.append(f"shot {sid} missing {f}")
    return e

def issue(code,severity,message,where="project",repair=""):
    return {"code":code,"severity":severity,"where":where,"message":message,"repair":repair}

def audit(p):
    out=[]
    for err in validate(p):
        out.append(issue("SCHEMA", "BLOCKER", err, repair="complete the missing/invalid structural field"))
    c=p.get("creative",{})
    for k in REQUIRED_CREATIVE:
        if not nonempty(c.get(k)):
            out.append(issue("DIRECTING_SPINE","BLOCKER",f"creative.{k} is empty",f"creative.{k}","freeze the dramatic spine before shot generation"))
    beats=p.get("beats",[])
    if not beats:
        out.append(issue("NO_BEATS","BLOCKER","no dramatic beats",repair="create objective → obstacle → turn → decision → consequence beats"))
    shots=p.get("shots",[])
    if not shots:
        out.append(issue("NO_SHOTS","BLOCKER","no shots",repair="design shots from beat functions, not from visual variety"))
    # Duration feasibility
    target=float(p.get("meta",{}).get("target_duration_sec",0) or 0)
    total=sum(float(s.get("duration",0) or 0) for s in shots)
    if target>0 and shots:
        delta=abs(total-target)/target
        if delta>0.20:
            out.append(issue("DURATION","BLOCKER",f"shot total {total:.1f}s differs from target {target:.1f}s by {delta:.0%}",repair="rebudget shot durations before generation"))
        elif delta>0.08:
            out.append(issue("DURATION","WARN",f"shot total {total:.1f}s differs from target {target:.1f}s by {delta:.0%}",repair="check dialogue/action timing margin"))
    # Beat coverage
    covered={s.get("beat_id") for s in shots if s.get("beat_id")}
    for b in beats:
        if b.get("id") and b.get("id") not in covered:
            out.append(issue("UNCOVERED_BEAT","BLOCKER",f"beat {b['id']} has no shot",b['id'],"assign at least one shot that proves the beat change"))
    # Shot semantic/continuity checks
    prev=None
    prev_func=None
    for i,s in enumerate(shots):
        sid=s.get("id",f"shot#{i+1}")
        if not nonempty(s.get("end_state")):
            out.append(issue("NO_END_STATE","BLOCKER","shot has no explicit end_state",sid,"define the exact last-frame/state handoff"))
        if str(s.get("camera_move","")).strip()=="":
            out.append(issue("CAMERA_UNSET","WARN","camera behavior is unspecified",sid,"choose motivated movement or explicitly static"))
        func=norm(s.get("narrative_function",""))
        if prev_func and func and func==prev_func:
            out.append(issue("DUPLICATE_FUNCTION","WARN","adjacent shots have identical narrative function",sid,"combine them or differentiate the information/change"))
        prev_func=func or prev_func
        # crude action-topology warning: catches overloaded clauses, not a semantic verdict
        action=str(s.get("action", ""))
        event_markers=len(re.findall(r"[,;；，]|\bthen\b|\band then\b|随后|然后|接着|紧接着",action,flags=re.I))
        if event_markers>=5 and float(s.get("duration",0) or 0)<=8:
            out.append(issue("ACTION_DENSITY","WARN",f"dense action topology ({event_markers+1} clauses in {s.get('duration')}s)",sid,"split at a state boundary or simplify simultaneous actions"))
        if prev is not None and not s.get("motivated_discontinuity"):
            a=prev.get("continuity_out",{}) if isinstance(prev.get("continuity_out",{}),dict) else {}
            b=s.get("continuity_in",{}) if isinstance(s.get("continuity_in",{}),dict) else {}
            for key in sorted(set(a).intersection(b)):
                if not compatible(a[key],b[key]):
                    out.append(issue("CONTINUITY_MISMATCH","BLOCKER",f"{key}: previous out={a[key]!r}, next in={b[key]!r}",sid,"repair only this continuity layer or declare a motivated discontinuity"))
        prev=s
    # Governance / retry
    retry=p.get("qa",{}).get("retry_policy")
    if retry not in ("local_only","diagnose_then_retry"):
        out.append(issue("RETRY_POLICY","WARN","retry policy is not local/diagnostic",repair="preserve passing dimensions and retry only the diagnosed failure"))
    return out

def score(p):
    detail={}
    c=p.get("creative",{})
    detail["directing_intent"]=round(20*sum(nonempty(c.get(x)) for x in REQUIRED_CREATIVE)/len(REQUIRED_CREATIVE),1)
    beats=p.get("beats",[])
    if beats:
        n=sum(sum(nonempty(b.get(f)) for f in BEAT_FIELDS) for b in beats)
        detail["dramatic_causality"]=round(20*n/(len(beats)*len(BEAT_FIELDS)),1)
    else: detail["dramatic_causality"]=0
    shots=p.get("shots",[])
    if shots:
        n=sum(sum(nonempty(s.get(f)) for f in ["narrative_function","action","framing","camera_move","end_state"]) for s in shots)
        detail["shot_design"]=round(20*n/(len(shots)*5),1)
        n=sum(sum(nonempty(s.get(f)) for f in ["continuity_in","continuity_out"]) for s in shots)
        has_locks=bool(p.get("characters") or p.get("locations") or p.get("props"))
        detail["continuity"]=round(min(15,12*n/(len(shots)*2)+(3 if has_locks else 0)),1)
        n=sum(sum(nonempty(s.get(f)) for f in ["performance","blocking"]) for s in shots)
        detail["performance_blocking"]=round(10*n/(len(shots)*2),1)
    else:
        detail.update({"shot_design":0,"continuity":0,"performance_blocking":0})
    meta=p.get("meta",{}); target=meta.get("target_duration_sec",0) or 0
    total=sum(float(s.get("duration",0) or 0) for s in shots)
    duration_ok=target>0 and shots and abs(total-target)/target<=0.20
    technical_parts=[nonempty(meta.get("aspect_ratio")), target>0, duration_ok]
    detail["technical_feasibility"]=round(10*sum(technical_parts)/3,1)
    qa=p.get("qa",{})
    detail["qa_recovery"]=5 if qa.get("retry_policy") in ("local_only","diagnose_then_retry") and qa.get("generation_threshold") else 2 if qa else 0
    raw=round(sum(detail.values()),1)
    findings=audit(p)
    blockers=sum(x["severity"]=="BLOCKER" for x in findings)
    warnings=sum(x["severity"]=="WARN" for x in findings)
    # Structural completeness is not artistic quality. Blockers cap readiness so filled text cannot game the gate.
    capped=min(raw, 79.0) if blockers else raw
    threshold=p.get("qa",{}).get("generation_threshold",88)
    return {"score":capped,"raw_completeness":raw,"detail":detail,"threshold":threshold,"ready":capped>=threshold and blockers==0,"blockers":blockers,"warnings":warnings,"score_scope":"structural pre-generation readiness; not a claim of artistic quality"}

def compile_shot(s):
    parts=[]
    def add(label,val):
        if nonempty(val): parts.append(f"{label}: {json.dumps(val,ensure_ascii=False) if isinstance(val,(dict,list)) else val}")
    add("SHOT PURPOSE",s.get("narrative_function"))
    add("SUBJECT",s.get("subject"))
    add("ACTION",s.get("action"))
    add("PERFORMANCE",s.get("performance"))
    add("BLOCKING",s.get("blocking"))
    cam="; ".join(str(x) for x in [s.get("framing"),s.get("angle"),s.get("lens_effect"),s.get("camera_move")] if nonempty(x)); add("CAMERA",cam)
    add("LIGHTING / WORLD",s.get("lighting"))
    add("CONTINUITY IN",s.get("continuity_in"))
    add("AUDIO / DIALOGUE",s.get("audio"))
    add("NEGATIVE CONSTRAINTS",s.get("negative_constraints"))
    add("END STATE / NEXT-SHOT ANCHOR",s.get("end_state") or s.get("continuity_out"))
    return "\n".join(parts)

def self_test():
    base=Path(__file__).resolve().parent.parent/"tests"/"fixtures"
    gp=load(base/"good_project.json"); bp=load(base/"bad_project.json")
    g=score(gp); b=score(bp); ga=audit(gp); ba=audit(bp)
    ok=g["score"]>=88 and g["blockers"]==0 and b["score"]<60 and len(ba)>0 and not validate(gp)
    print(json.dumps({"good":g,"good_audit":ga,"bad":b,"bad_audit_count":len(ba),"pass":ok},ensure_ascii=False,indent=2)); return 0 if ok else 1

def main():
    ap=argparse.ArgumentParser(); sp=ap.add_subparsers(dest="cmd",required=True)
    a=sp.add_parser("init"); a.add_argument("--title",required=True); a.add_argument("--format",default="narrative_short"); a.add_argument("--duration",type=int,default=60); a.add_argument("--ratio",default="16:9"); a.add_argument("--out",default="project.json")
    a=sp.add_parser("validate"); a.add_argument("project")
    a=sp.add_parser("audit"); a.add_argument("project")
    a=sp.add_parser("score"); a.add_argument("project")
    a=sp.add_parser("compile-shot"); a.add_argument("project"); a.add_argument("shot_id")
    sp.add_parser("self-test")
    args=ap.parse_args()
    if args.cmd=="init": save(args.out,init_project(args.title,args.format,args.duration,args.ratio)); print(args.out)
    elif args.cmd=="validate":
        e=validate(load(args.project)); print(json.dumps({"valid":not e,"errors":e},ensure_ascii=False,indent=2)); sys.exit(1 if e else 0)
    elif args.cmd=="audit":
        findings=audit(load(args.project)); print(json.dumps({"pass":not any(x['severity']=='BLOCKER' for x in findings),"findings":findings},ensure_ascii=False,indent=2)); sys.exit(1 if any(x['severity']=='BLOCKER' for x in findings) else 0)
    elif args.cmd=="score": print(json.dumps(score(load(args.project)),ensure_ascii=False,indent=2))
    elif args.cmd=="compile-shot":
        p=load(args.project); s=next((x for x in p.get("shots",[]) if x.get("id")==args.shot_id),None)
        if not s: raise SystemExit(f"shot not found: {args.shot_id}")
        print(compile_shot(s))
    else: sys.exit(self_test())
if __name__=="__main__": main()
