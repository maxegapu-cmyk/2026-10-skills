#!/usr/bin/env python3
"""Verify a packaged release file manifest and entrypoint, including checksums."""
import hashlib
import json
from pathlib import Path
import sys
root=Path(__file__).resolve().parent.parent
required=['SKILL.md','README.md','VERSION','config/model-registry.json',
          'scripts/director.py','scripts/libtv_cli_bridge.py','scripts/production_run.py',
          'scripts/media_qc.py','references/22-cli-execution-contract.md',
          'references/26-professional-director-review.md','MANIFEST.json']
missing=[x for x in required if not (root/x).is_file()]
errors=[]
if missing: errors.append('missing files: '+', '.join(missing))
if not (root/'SKILL.md').read_text(encoding='utf-8').startswith('---\n'):
    errors.append('SKILL.md missing YAML frontmatter')
version=(root/'VERSION').read_text(encoding='utf-8').strip()
if ('version: "'+version+'"') not in (root/'SKILL.md').read_text(encoding='utf-8'):
    errors.append('skill version mismatch')
if (root/'MANIFEST.json').is_file():
    manifest=json.loads((root/'MANIFEST.json').read_text(encoding='utf-8'))
    if manifest.get('version')!=version: errors.append('manifest version mismatch')
    actual={str(p.relative_to(root)).replace('\\','/'):p for p in root.rglob('*') if p.is_file() and p.name!='MANIFEST.json' and '__pycache__' not in p.parts}
    listed={item['path']:item for item in manifest.get('files',[])}
    for name in sorted(actual.keys() ^ listed.keys()): errors.append('manifest tree mismatch: '+name)
    for name in actual.keys() & listed.keys():
        p=actual[name]; entry=listed[name]; sha=hashlib.sha256(p.read_bytes()).hexdigest()
        if sha!=entry.get('sha256') or p.stat().st_size!=entry.get('bytes'):
            errors.append('manifest checksum mismatch: '+name)
report={'pass':not errors,'version':version,'required_missing':missing,'errors':errors,'verified_files':len(listed) if (root/'MANIFEST.json').is_file() else 0}
print(json.dumps(report,ensure_ascii=False,indent=2))
sys.exit(0 if not errors else 1)
