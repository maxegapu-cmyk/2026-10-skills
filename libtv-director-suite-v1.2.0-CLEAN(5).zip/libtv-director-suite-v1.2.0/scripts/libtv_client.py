#!/usr/bin/env python3
"""LEGACY OpenAPI adapter, read-only preferred. Prefer the current CLI bridge.
Compatibility only: do not assume this endpoint works with current LibTV canvas.
"""
import argparse, json, mimetypes, os, re, sys, uuid, urllib.request, urllib.error, urllib.parse
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed

BASE = os.environ.get("OPENAPI_IM_BASE", os.environ.get("IM_BASE_URL", "https://im.liblib.tv")).rstrip("/")
CANVAS = "https://www.liblib.tv/canvas?projectId="

def key():
    k=os.environ.get("LIBTV_ACCESS_KEY","").strip()
    if not k: raise RuntimeError("LIBTV_ACCESS_KEY is not set")
    return k

def headers(json_body=True):
    h={"Authorization":f"Bearer {key()}"}
    if json_body: h["Content-Type"]="application/json"
    return h

def request(method,path,body=None,timeout=60,headers_override=None):
    data=None
    if body is not None and not isinstance(body,(bytes,bytearray)):
        data=json.dumps(body,ensure_ascii=False).encode("utf-8")
    else: data=body
    req=urllib.request.Request(BASE+path,data=data,method=method,headers=headers_override or headers())
    try:
        with urllib.request.urlopen(req,timeout=timeout) as r:
            raw=r.read().decode("utf-8")
            return json.loads(raw) if raw else {}
    except urllib.error.HTTPError as e:
        raw=e.read().decode("utf-8",errors="replace") if e.fp else ""
        raise RuntimeError(f"HTTP {e.code}: {raw}") from e
    except urllib.error.URLError as e:
        raise RuntimeError(f"Network error: {e.reason}") from e

def send(message="",session_id=""):
    body={}
    if session_id: body["sessionId"]=session_id
    if message: body["message"]=message
    d=request("POST","/openapi/session",body).get("data",{})
    if d.get("projectUuid"): d["projectUrl"]=CANVAS+d["projectUuid"]
    return d

def query(session_id,after_seq=0):
    p=f"/openapi/session/{session_id}"+(f"?afterSeq={after_seq}" if after_seq else "")
    return request("GET",p).get("data",{})

def change_project():
    return request("POST","/openapi/session/change-project",{}).get("data",{})

def upload(path):
    p=Path(path)
    if not p.is_file(): raise RuntimeError(f"File not found: {p}")
    mime=mimetypes.guess_type(str(p))[0] or "application/octet-stream"
    if not (mime.startswith("image/") or mime.startswith("video/")):
        raise RuntimeError(f"Unsupported file type: {mime}; image/video only")
    boundary="----DirectorSuite"+uuid.uuid4().hex
    parts=[]
    def add(x): parts.append(x if isinstance(x,bytes) else x.encode())
    add(f"--{boundary}\r\n"); add('Content-Disposition: form-data; name="accessKey"\r\n\r\n'); add(key()+"\r\n")
    add(f"--{boundary}\r\n"); add(f'Content-Disposition: form-data; name="file"; filename="{p.name}"\r\n'); add(f"Content-Type: {mime}\r\n\r\n"); parts.append(p.read_bytes()); add("\r\n")
    add(f"--{boundary}--\r\n")
    h={"Authorization":f"Bearer {key()}","Content-Type":f"multipart/form-data; boundary={boundary}"}
    return request("POST","/openapi/upload",b"".join(parts),timeout=120,headers_override=h).get("data",{})

URL_RE=re.compile(r'https://libtv-res\.liblib\.art/[^\s"\'<>]+\.(?:png|jpg|jpeg|webp|mp4|mov|webm)',re.I)
def media_url(url):
    """Only accept known legacy result host; block internal/redirect destinations."""
    try:
        u=urllib.parse.urlsplit(url)
        return u.scheme=="https" and u.hostname=="libtv-res.liblib.art" and not u.username and not u.password and (u.port in (None,443))
    except Exception: return False

def extract_urls(messages):
    out=[]
    for m in messages:
        c=m.get("content","")
        if not isinstance(c,str): continue
        if m.get("role")=="tool":
            try:
                tr=json.loads(c).get("task_result",{})
                for x in tr.get("images",[]):
                    if x.get("previewPath"): out.append(x["previewPath"])
                for x in tr.get("videos",[]):
                    u=x.get("previewPath") or x.get("url")
                    if u: out.append(u)
            except Exception: pass
        out.extend(URL_RE.findall(c))
    return list(dict.fromkeys(u for u in out if media_url(u)))

class SafeMediaRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        if not media_url(newurl): raise RuntimeError("media redirect host rejected")
        return super().redirect_request(req,fp,code,msg,headers,newurl)

def download_one(url,path):
    if not media_url(url): raise RuntimeError("untrusted media URL")
    req=urllib.request.Request(url,headers={"User-Agent":"LibTV-Director-Suite/1.0"})
    with urllib.request.build_opener(SafeMediaRedirect()).open(req,timeout=90) as r, open(path,"wb") as f:
        while True:
            b=r.read(1024*64)
            if not b: break
            f.write(b)
    return str(path)

def download(session_id,out_dir,workers=5):
    urls=extract_urls(query(session_id).get("messages",[]))
    od=Path(out_dir); od.mkdir(parents=True,exist_ok=True)
    jobs=[]
    for i,u in enumerate(urls,1):
        ext=Path(u.split("?")[0]).suffix or ".bin"
        jobs.append((u,od/f"{i:02d}{ext}"))
    ok=[]; err=[]
    with ThreadPoolExecutor(max_workers=workers) as ex:
        futs={ex.submit(download_one,u,p):(u,p) for u,p in jobs}
        for f,(u,p) in futs.items():
            try: ok.append(f.result())
            except Exception as e: err.append({"url":u,"error":str(e)})
    return {"downloaded":sorted(ok),"errors":err,"total":len(ok)}

def main():
    ap=argparse.ArgumentParser()
    sp=ap.add_subparsers(dest="cmd",required=True)
    ap.add_argument("--allow-legacy-write", action="store_true", help="Explicitly acknowledge old API compatibility and potential side effects")
    a=sp.add_parser("send"); a.add_argument("message",nargs="?",default=""); a.add_argument("--session-id",default="")
    a=sp.add_parser("query"); a.add_argument("session_id"); a.add_argument("--after-seq",type=int,default=0)
    sp.add_parser("change-project")
    a=sp.add_parser("upload"); a.add_argument("file")
    a=sp.add_parser("download"); a.add_argument("session_id"); a.add_argument("--output-dir",default="./libtv_results"); a.add_argument("--workers",type=int,default=5)
    args=ap.parse_args()
    try:
        if args.cmd in ("send","upload","change-project") and not args.allow_legacy_write:
            raise RuntimeError("Legacy API write disabled. Use current LibTV CLI; to override explicitly pass --allow-legacy-write before subcommand")
        if args.cmd=="send": r=send(args.message,args.session_id)
        elif args.cmd=="query": r=query(args.session_id,args.after_seq)
        elif args.cmd=="change-project": r=change_project()
        elif args.cmd=="upload": r=upload(args.file)
        else: r=download(args.session_id,args.output_dir,args.workers)
        print(json.dumps(r,ensure_ascii=False,indent=2))
    except Exception as e:
        print(json.dumps({"error":str(e)},ensure_ascii=False),file=sys.stderr); sys.exit(1)
if __name__=="__main__": main()
