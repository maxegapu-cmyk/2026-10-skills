#!/usr/bin/env python3
"""CLI-first adapter. Safe by default; paid remote actions require explicit approval.
No private server endpoints or undocumented automation are used.
"""
import argparse
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys

ALLOWED_RATIOS = {'16:9','9:16','1:1','4:3','3:4','21:9','adaptive'}
ALLOWED_MODES = {'text2video','singleImage2video','frames2video','image2video','mixed2video'}
NAME_PATTERN = re.compile(r'^[^\x00-\x1f]{1,120}$')


def executable():
    candidate = os.environ.get('LIBTV_CLI_PATH', '').strip() or shutil.which('libtv')
    if not candidate:
        raise RuntimeError('LibTV CLI missing. Install it from the provider, then set LIBTV_CLI_PATH or PATH. No paid request made.')
    p = Path(candidate).expanduser()
    if not p.is_file():
        raise RuntimeError('LibTV CLI binary not found: ' + str(p))
    return str(p)


def invoke(argv, timeout=30):
    proc = subprocess.run(argv, capture_output=True, text=True, timeout=timeout,
                          check=False, errors='replace')
    return {'exit_code': proc.returncode, 'stdout': proc.stdout[-16000:],
            'stderr': proc.stderr[-5000:]}


def check_name(value, field):
    if not isinstance(value, str) or not NAME_PATTERN.fullmatch(value) or value.strip()!=value or value.startswith('-'):
        raise ValueError(f'{field}: invalid name')


def load_spec(path):
    d = json.loads(Path(path).read_text(encoding='utf-8'))
    if not isinstance(d, dict):
        raise ValueError('shot specification must be a JSON object')
    required = ('node_name','model_key','model_name','mode','prompt','ratio','resolution','duration_sec','reference_nodes')
    missing = [x for x in required if x not in d]
    if missing:
        raise ValueError('missing: '+', '.join(missing))
    for k in ('node_name','model_key','model_name'):
        check_name(d[k], k)
    if d['mode'] not in ALLOWED_MODES:
        raise ValueError('unsupported mode; inspect current model schema')
    if d['ratio'] not in ALLOWED_RATIOS:
        raise ValueError('unknown aspect ratio; inspect current model schema')
    if not isinstance(d['duration_sec'], int) or isinstance(d['duration_sec'], bool) or not 1 <= d['duration_sec'] <= 120:
        raise ValueError('duration must be a positive integer <=120; current model schema may be narrower')
    if not isinstance(d['resolution'],str) or not re.fullmatch(r'\d{3,4}p|4k', d['resolution']):
        raise ValueError('invalid resolution; inspect current model schema')
    if not isinstance(d['prompt'],str) or not d['prompt'].strip() or len(d['prompt']) > 20000:
        raise ValueError('prompt missing or exceeds 20,000 characters')
    refs=d['reference_nodes']
    if not isinstance(refs,list) or len(refs)>15 or any(not isinstance(x,str) for x in refs):
        raise ValueError('reference_nodes must be a list of up to 15 names')
    for x in refs: check_name(x,'reference_node')
    count = len(refs)
    limits = {'text2video': (0,0), 'singleImage2video': (1,1), 'frames2video': (1,2), 'image2video': (1,9), 'mixed2video': (1,15)}
    lo,hi=limits[d['mode']]
    if not lo<=count<=hi:
        raise ValueError(f'{d["mode"]} accepts {lo}–{hi} incoming references (advisory; verify live schema)')
    if len(set(refs))!=len(refs):
        raise ValueError('duplicate reference node name')
    if d.get('enable_sound','off') not in ('on','off'):
        raise ValueError('enable_sound must be on/off')
    return d


def build_argv(spec, binary='libtv', execute=False):
    cmd=[binary,'node','create',spec['node_name'],'-t','video',
         '--prompt',spec['prompt']]
    for ref in spec['reference_nodes']:
        cmd.extend(['--left',ref])
    for key,value in [('model',spec['model_name']),('modeType',spec['mode']),
                      ('ratio',spec['ratio']),('resolution',spec['resolution']),
                      ('duration',spec['duration_sec']),('enableSound',spec.get('enable_sound','off'))]:
        cmd.extend(['-s',f'{key}={value}'])
    if execute: cmd.append('--run')
    return cmd


def safe_display(command):
    # JSON array, rather than executable shell text, avoids shell interpolation.
    return json.dumps(command,ensure_ascii=False)


def main():
    ap=argparse.ArgumentParser(description='LibTV CLI bridge — no paid call without explicit approval')
    sp=ap.add_subparsers(dest='action', required=True)
    p=sp.add_parser('probe'); p.add_argument('--check-login', action='store_true')
    p=sp.add_parser('model-schema'); p.add_argument('model_key')
    p=sp.add_parser('node-status'); p.add_argument('node_name')
    p=sp.add_parser('plan'); p.add_argument('spec')
    p=sp.add_parser('run'); p.add_argument('spec'); p.add_argument('--approve-paid',action='store_true')
    p.add_argument('--budget-cap',type=float); p.add_argument('--quoted-cost',type=float)
    args=ap.parse_args()
    try:
        if args.action in ('plan','run'):
            spec=load_spec(args.spec)
            if args.action=='plan':
                # No local CLI dependency for a plan artifact.
                print(json.dumps({'ready_for_cli_preflight':True,'paid_action':False,
                    'command_argv':build_argv(spec),
                    'verification_needed':['CLI installed and logged in','current model schema',
                       'unique node name','visible price and approval','input reference nodes']},ensure_ascii=False,indent=2))
                return
        bin_path=executable()
        if args.action=='probe':
            result={'found':True,'version':invoke([bin_path,'--version']),
                    'help':invoke([bin_path,'--help'])}
            if args.check_login: result['login']=invoke([bin_path,'account','info'])
            print(json.dumps(result,ensure_ascii=False,indent=2)); return
        if args.action=='model-schema':
            check_name(args.model_key,'model_key')
            print(json.dumps(invoke([bin_path,'model',args.model_key]),ensure_ascii=False,indent=2)); return
        if args.action=='node-status':
            check_name(args.node_name,'node_name')
            print(json.dumps(invoke([bin_path,'node',args.node_name]),ensure_ascii=False,indent=2)); return
        # Paid generation can create charges and duplicate assets. Fail closed.
        if not args.approve_paid:
            raise RuntimeError('Paid generation is locked: require --approve-paid after human approval')
        if args.budget_cap is None or args.quoted_cost is None or args.budget_cap<=0 or args.quoted_cost<=0 or args.quoted_cost>args.budget_cap:
            raise RuntimeError('Need a positive platform-displayed --quoted-cost <= approved --budget-cap; never guess a price')
        for check in ([bin_path,'account','info'],[bin_path,'model',spec['model_key']]):
            r=invoke(check)
            if r['exit_code']:
                raise RuntimeError('CLI login/model schema preflight failed; no paid action made')
        # Do not risk double-submission after an ambiguous timeout.
        prior=invoke([bin_path,'node',spec['node_name']])
        if prior['exit_code']==0:
            raise RuntimeError('Node name already exists; inspect its status instead of creating a duplicate')
        # A CLI error is NOT proof of nonexistence: network/auth errors must not create duplicate jobs.
        missing_text=(prior.get('stderr','')+' '+prior.get('stdout','')).lower()
        if not any(token in missing_text for token in ('not found','does not exist','not exist','不存在','未找到','未发现')):
            raise RuntimeError('Existing-node check inconclusive; refuse paid create until the CLI explicitly reports node missing')
        command=build_argv(spec,bin_path,execute=True)
        result=invoke(command, timeout=180)
        print(json.dumps({'submitted_command':safe_display(command),'result':result,
                          'instruction':'If a command times out, query the existing node before any retry.'},ensure_ascii=False,indent=2))
        if result['exit_code']: sys.exit(1)
    except (ValueError,RuntimeError,subprocess.TimeoutExpired,OSError,json.JSONDecodeError) as exc:
        print(json.dumps({'ok':False,'error':str(exc),'charged': 'unknown; check existing node before retry' if isinstance(exc,subprocess.TimeoutExpired) else False},ensure_ascii=False),file=sys.stderr)
        sys.exit(2)
if __name__=='__main__': main()
