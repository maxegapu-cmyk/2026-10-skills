#!/usr/bin/env python3
"""Local technical clip inspection using ffprobe if available. No hidden assumptions."""
import argparse
import json
from pathlib import Path
import shutil
import subprocess
import sys


def probe(file):
    p=Path(file)
    if not p.is_file(): raise ValueError('clip does not exist')
    if p.stat().st_size==0: raise ValueError('clip file is empty')
    bin=shutil.which('ffprobe')
    if not bin: raise RuntimeError('ffprobe missing: cannot claim technical QC pass')
    cp=subprocess.run([bin,'-v','error','-show_entries','format=duration,size:stream=index,codec_type,width,height,avg_frame_rate,sample_rate', '-of','json',str(p)],capture_output=True,text=True,timeout=40)
    if cp.returncode: raise RuntimeError('ffprobe: '+cp.stderr.strip()[:300])
    d=json.loads(cp.stdout); streams=d.get('streams',[])
    video=[s for s in streams if s.get('codec_type')=='video']
    duration=float(d.get('format',{}).get('duration',0) or 0)
    failures=[]
    if not video: failures.append('no decodable video stream')
    if duration<=0: failures.append('missing/nonpositive clip duration')
    if video and (video[0].get('width',0)<320 or video[0].get('height',0)<240): failures.append('video resolution below QC floor')
    return {'file':str(p),'duration_sec':round(duration,3),'streams':streams,'pass':not failures,
            'technical_failures':failures,'creative_qc':'NOT EVALUATED — separately review story, identity, performance, motion, continuity and audio'}


def main():
    ap=argparse.ArgumentParser();ap.add_argument('clip');args=ap.parse_args()
    try:
        r=probe(args.clip); print(json.dumps(r,ensure_ascii=False,indent=2));sys.exit(0 if r['pass'] else 1)
    except Exception as e:
        print(json.dumps({'pass':False,'error':str(e)},ensure_ascii=False),file=sys.stderr);sys.exit(2)
if __name__=='__main__':main()
