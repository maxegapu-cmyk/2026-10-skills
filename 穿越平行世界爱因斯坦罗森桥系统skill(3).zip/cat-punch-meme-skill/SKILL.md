# Cat Punch Meme Skill

Version: 1.0.0
Skill ID: cat-punch-meme
Purpose: Generate highly expressive, funny "cat punching / cat paw smack" reaction memes and sticker-style images from a short user idea, optional cat reference image, optional target reference image, and optional caption.

## 1. Core Goal
Transform a minimal request such as:
- "猫拳揍他"
- "这只猫一拳把老板打飞"
- "做成微信表情包，配字：少废话"
into a production-ready image-generation prompt for a punchy, readable, meme-grade result.

The finished image should read instantly at thumbnail size:
1. cat is the visual protagonist;
2. the paw strike is unmistakable;
3. impact timing is clear;
4. expression is funny rather than disturbing;
5. caption remains readable and supports the joke.

## 2. Default Mode
DEFAULT_MODE = CAT_PAW_SMACK
DEFAULT_TONE = slapstick, absurd, non-graphic, high-energy
DEFAULT_OUTPUT = square meme / sticker
DEFAULT_ASPECT = 1:1
DEFAULT_BACKGROUND = simple high-contrast background or transparent-style cutout composition
DEFAULT_TEXT = none unless user supplies copy or asks for copy generation

## 3. Input Contract
Accept any subset of:
- CAT_REFERENCE: optional image or description of the cat
- TARGET_REFERENCE: optional image or description of the person/character being hit
- ACTION: punch / slap / double-paw barrage / uppercut / flying paw / table-side smack / off-screen paw
- INTENSITY: 1-5
- EMOTION: angry / deadpan / smug / shocked / unhinged / cute-but-violent / bossy
- CAPTION: exact text, or ask the Skill to generate one
- STYLE: realistic cat photo / reaction meme / chibi / manga / 3D cartoon / emoji sticker / retro internet meme
- BACKGROUND: transparent / clean studio / room / office / classroom / game UI parody / custom
- OUTPUT_USE: WeChat sticker / QQ sticker / social post / comment reply / thumbnail / sticker pack

If the user supplies only one short sentence, infer the remaining fields conservatively and proceed without asking unless identity-specific or exact-copy details are essential.

## 4. Identity & Reference Rules
When CAT_REFERENCE is provided:
- preserve coat pattern, eye color, face shape, ear shape, body size, and recognizable quirks;
- do not genericize the cat into a different breed;
- exaggeration may affect pose and expression, not core identity.

When TARGET_REFERENCE is provided:
- preserve recognizability where technically feasible;
- do not accidentally merge the target's face with the cat;
- keep the impact comedic and non-graphic;
- avoid blood, open wounds, broken bones, teeth flying, or realistic severe injury unless the user explicitly asks for a fictional non-real-person stylized scene and policy permits it.

## 5. Visual Priority Stack
Priority order:
P1. Cat identity / cat readability
P2. Paw-to-target contact clarity
P3. Comedic impact silhouette
P4. Facial reaction
P5. Caption readability
P6. Background detail

Never sacrifice P1-P4 for decorative detail.

## 6. Action Grammar

### A. SINGLE_PAW_SMACK — Single Paw Smack
Use when the joke should feel sudden and clean.
- cat torso slightly rotated
- striking paw extended across frame
- paw pad / fur direction visible
- target head or upper body recoils away from contact
- one strong impact burst, motion streak, or squash-and-stretch cue

### B. RAPID_BARRAGE — Rapid Cat-Punch Barrage
Use for "连续猫拳 / 欧拉猫拳 / 疯狂输出".
- 2-5 readable paw afterimages maximum
- target stays readable
- dominant paw path must have one clear direction
- do not create a tangled many-limb mutation

### C. UPPERCUT_PAW — Uppercut Paw
- low-to-high diagonal paw trajectory
- target chin/head lifts in exaggerated slapstick arc
- cat expression calm or smug for contrast

### D. FLYING_PAW — Flying Paw
- cat body airborne or lunging
- strong diagonal composition
- target recoils in opposite diagonal
- use only one dominant impact point

### E. TINY_CAT_BIG_HUMAN — Tiny Cat vs Big Human
For maximum comedy:
- cat may occupy only 25-40% frame area
- impact can still launch/recoil the much larger target
- preserve absurd power contrast

## 7. Impact Design Rules
The hit must be readable without text.
Use 2-4 of the following, not all at once:
- cheek/head squash at contact
- head recoil angle
- hair/clothing lag
- one impact starburst
- short directional speed lines
- displaced glasses/hat (optional)
- tiny debris such as paper, keyboard keycaps, snack crumbs (contextual)
- exaggerated body lean

Avoid:
- gore
- realistic trauma
- anatomical breakage
- excessive debris that hides the action
- more than one ambiguous contact point

## 8. Expression Logic
Cat expression presets:
- DEADPAN_EXECUTIONER: expressionless face + devastating paw
- SMUG_WINNER: half-lidded eyes + slight grin
- TINY_FURY: ears back + wide pupils + tiny angry mouth
- OFFICE_BOSS: unimpressed + one-paw correction
- CUTE_OVERKILL: adorable round eyes + absurdly powerful hit

Target reactions:
- shocked
- offended
- spinning recoil
- frozen disbelief
- dramatic anime reaction
- defeated deadpan

No realistic agony unless explicitly requested and appropriate.

## 9. Caption Engine
If the user asks for text but gives none, generate 1-3 short options, favoring 2-8 Chinese characters for sticker readability.

Caption styles:
- Command: "少废话" / "闭嘴" / "醒醒"
- Retort: "你再说一遍？" / "就你话多"
- Workplace: "改需求是吧" / "又开会？"
- Gaming: "还敢送？" / "这也能空？"
- Cute menace: "乖一点" / "听话"

Rules:
- one punchline only;
- avoid long sentences unless user explicitly wants poster format;
- place text away from the paw-contact region;
- maintain strong contrast and thick readable type.

## 10. Style Presets

### PHOTO_MEME
Realistic cat photography, slightly exaggerated physics, crisp freeze-frame, internet reaction meme energy.

### STICKER_CUTOUT
Clean subject cutout, thick outline, simplified background, transparent or pseudo-transparent composition, oversized readable caption.

### MANGA_IMPACT
Manga speed lines, impact burst, exaggerated recoil, strong black-and-white or limited-color graphic treatment.

### 3D_TOY
High-detail 3D cartoon cat, soft fur, toy-like but premium rendering, dramatic squash-and-stretch.

### RETRO_NET_MEME
Compressed early-internet aesthetic, intentionally crude caption layout, funny low-fi energy while keeping subjects readable.

## 11. Prompt Compiler
Compile requests into this structure:

[FORMAT]
Square 1:1 reaction meme / sticker composition, instantly readable at thumbnail size.

[CAT]
Describe cat identity and expression first.

[ACTION]
Describe one dominant paw action with exact direction and contact point.

[TARGET]
Describe target pose and recoil, keeping identity separate from cat.

[IMPACT]
Add only selected slapstick cues.

[COMPOSITION]
Specify cat side, target side, paw travel direction, camera distance, crop.

[STYLE]
Apply selected preset.

[TEXT]
Exact caption, position, font treatment, or no text.

[LOCKS]
Preserve cat identity; no extra limbs; no face merge; no gore; no broken anatomy; no unreadable text; no clutter over impact point.

## 12. Default Production Prompt Template
Use this as the internal final prompt skeleton:

"Create a square 1:1 high-impact cat reaction meme. The cat is the clear protagonist. Preserve the cat's recognizable identity, coat markings, eye color and face shape. Freeze the exact comedic moment when the cat delivers a powerful [ACTION] with its [LEFT/RIGHT] front paw from [DIRECTION] into the target's [CONTACT_POINT]. The target recoils dramatically in the opposite direction with exaggerated but non-graphic slapstick physics. Keep one clean, readable contact point. Add [2-4 IMPACT CUES]. Cat expression: [CAT_EXPRESSION]. Target reaction: [TARGET_REACTION]. Composition: [CAT_POSITION], [TARGET_POSITION], medium-close framing, strong silhouette separation, uncluttered background. Style: [STYLE_PRESET]. Caption: '[CAPTION]' in large bold readable Chinese type placed [TEXT_POSITION], not covering faces or paw impact. No gore, no blood, no broken bones, no extra paws, no fused faces, no duplicated subjects, no malformed anatomy, no unreadable text, no unnecessary background clutter."

## 13. Auto-Decision Rules
If user says "猫拳揍人":
- choose SINGLE_PAW_SMACK
- INTENSITY = 3
- CAT_EXPRESSION = DEADPAN_EXECUTIONER
- TARGET_REACTION = shocked recoil
- STYLE = STICKER_CUTOUT unless reference is photorealistic, then PHOTO_MEME

If user says "狠狠揍 / 暴揍 / 疯狂猫拳":
- use RAPID_BARRAGE
- cap visible paw afterimages at 4
- keep it slapstick and non-graphic

If user asks "做一套":
Generate 6-12 variants with different actions/captions while preserving the same cat identity and visual system.

## 14. Sticker Pack Mode
For a reusable pack, keep these constants fixed across all images:
- same cat identity
- same outline thickness / render style
- same typeface treatment
- same crop scale
- same caption placement zones

Recommended 8-pack:
1. 少废话 — single smack
2. 醒醒 — forehead paw
3. 你再说一遍？ — raised-paw threat
4. 改需求是吧 — office smack
5. 还敢送？ — gaming barrage
6. 走你 — flying paw
7. 给我回来 — hook-like paw pull gesture, non-injurious
8. 乖一点 — cute deadpan tap with absurd impact burst

## 15. Quality Gate
Before returning a final generation prompt, check:
- Can the paw-contact moment be understood with text hidden?
- Is the cat still recognizable?
- Is there exactly one dominant action?
- Are limbs anatomically plausible enough for the chosen style?
- Is the target reaction funny rather than gruesome?
- Is caption short and readable?
- Does the image still work at small sticker size?

If any answer is no, revise before output.

## 16. User-Facing Output Format
Default response should be compact:
1. Mode name
2. Final generation prompt
3. Optional negative prompt / lock line
4. If user requested a pack, provide the full variant matrix

Do not lecture the user about theory unless asked.
