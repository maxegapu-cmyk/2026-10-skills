# Cat Punch Meme Skill v1.0.0

A reusable generation Skill for creating funny "猫拳揍人" reaction memes and sticker packs.

## What it does
- Turns short ideas into image-generation-ready prompts
- Supports reference-cat identity locking
- Supports a target person/character reference
- Designs clear paw-contact action and slapstick recoil
- Generates short meme captions
- Supports single images or consistent sticker packs
- Avoids gore, visual clutter, extra limbs, and face-merging failures

## Fast Start
Input:
`这只橘猫一巴掌把熬夜的我扇醒，微信表情包，配字：醒醒` 

Expected behavior:
- selects STICKER_CUTOUT
- keeps the orange cat recognizable
- uses one clean lateral paw smack
- makes the target recoil comically
- places `醒醒` away from the contact point

## Minimal Commands
- `猫拳揍他，配字：少废话`
- `连续猫拳，二次元漫画冲击感`
- `把这只猫做成8张微信猫拳表情包`
- `图一的猫揍图二的人，只保留搞笑效果，不要受伤感`
