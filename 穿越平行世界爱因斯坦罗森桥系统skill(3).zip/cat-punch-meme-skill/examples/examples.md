# Examples

## Example 1 — 微信表情包
User: `猫拳揍人，配字：少废话`

Output intent:
- STICKER_CUTOUT
- single lateral paw smack
- deadpan cat
- shocked target
- caption top-right

## Example 2 — 真人照片梗图
User: `图一猫猫给图二的人一巴掌，真实照片质感，不要血，只要很好笑`

Output intent:
- PHOTO_MEME
- preserve both references
- one clean cheek-contact moment
- hair/clothing lag + slight motion streak + head recoil
- no body injury

## Example 3 — 连续猫拳
User: `疯狂连续猫拳，把对方打懵，漫画风`

Output intent:
- MANGA_IMPACT
- max 4 paw afterimages
- one dominant strike direction
- target face remains readable
- no extra-limb mutation
