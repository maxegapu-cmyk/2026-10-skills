import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  Activity,
  Boxes,
  Command,
  Download,
  Grid3X3,
  Library,
  Search,
  Settings,
  Sparkles,
  X,
} from "lucide-react";
import { useCentralSkillsStore } from "@/stores/centralSkillsStore";
import { filterMatrixRows } from "@/control-center/matrix";
import { useControlLocale } from "@/control-center/useControlLocale";
import { movePaletteIndex } from "@/control-center/palette";

interface ControlCommandPaletteProps {
  open: boolean;
  onClose: () => void;
}

const destinations = [
  { path: "/overview", label: "Overview", zh: "总览", icon: Activity },
  { path: "/central", label: "Library", zh: "技能库", icon: Library },
  { path: "/matrix", label: "Platform Matrix", zh: "平台矩阵", icon: Grid3X3 },
  { path: "/health", label: "Health", zh: "健康检查", icon: Sparkles },
  { path: "/collections", label: "Workspaces", zh: "工作区", icon: Boxes },
  { path: "/import", label: "Import Hub", zh: "导入中心", icon: Download },
  { path: "/settings", label: "Settings", zh: "设置", icon: Settings },
] as const;

export function ControlCommandPalette({ open, onClose }: ControlCommandPaletteProps) {
  const navigate = useNavigate();
  const inputRef = useRef<HTMLInputElement>(null);
  const [query, setQuery] = useState("");
  const [activeIndex, setActiveIndex] = useState(0);
  const skills = useCentralSkillsStore((state) => state.skills);
  const { text } = useControlLocale();

  useEffect(() => {
    if (!open) return;
    setQuery("");
    setActiveIndex(0);
    const frame = window.requestAnimationFrame(() => inputRef.current?.focus());
    return () => window.cancelAnimationFrame(frame);
  }, [open]);

  const matchingDestinations = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return destinations;
    return destinations.filter((item) => `${item.label} ${item.zh}`.toLowerCase().includes(q));
  }, [query]);

  const matchingSkills = useMemo(
    () => filterMatrixRows(skills, query).slice(0, query.trim() ? 8 : 5),
    [query, skills],
  );

  const paletteItems = useMemo(
    () => [
      ...matchingDestinations.map((item) => ({ key: `route:${item.path}`, path: item.path })),
      ...matchingSkills.map((skill) => ({ key: `skill:${skill.id}`, path: `/skill/${encodeURIComponent(skill.id)}` })),
    ],
    [matchingDestinations, matchingSkills],
  );

  const go = useCallback((path: string) => {
    navigate(path);
    onClose();
  }, [navigate, onClose]);

  useEffect(() => {
    if (!open) return;
    setActiveIndex((current) => paletteItems.length === 0 ? -1 : Math.min(Math.max(current, 0), paletteItems.length - 1));
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        event.preventDefault();
        onClose();
      } else if (event.key === "ArrowDown") {
        event.preventDefault();
        setActiveIndex((current) => movePaletteIndex(current, 1, paletteItems.length));
      } else if (event.key === "ArrowUp") {
        event.preventDefault();
        setActiveIndex((current) => movePaletteIndex(current, -1, paletteItems.length));
      } else if (event.key === "Enter" && activeIndex >= 0 && paletteItems[activeIndex]) {
        event.preventDefault();
        go(paletteItems[activeIndex].path);
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [activeIndex, go, onClose, open, paletteItems]);

  if (!open) return null;

  return (
    <div className="scc-command-backdrop" role="presentation" onMouseDown={onClose}>
      <section
        className="scc-command"
        role="dialog"
        aria-modal="true"
        aria-label={text("Command palette", "命令面板")}
        onMouseDown={(event) => event.stopPropagation()}
      >
        <div className="scc-command-search">
          <Search size={18} />
          <input
            ref={inputRef}
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder={text("Search pages and skills…", "搜索页面与技能…")}
          />
          <button className="scc-icon-button" onClick={onClose} aria-label={text("Close", "关闭")}>
            <X size={16} />
          </button>
        </div>

        <div className="scc-command-body">
          {matchingDestinations.length > 0 && (
            <div className="scc-command-section">
              <div className="scc-command-label">{text("Navigate", "导航")}</div>
              {matchingDestinations.map((item, index) => {
                const Icon = item.icon;
                return (
                  <button key={item.path} className={`scc-command-item ${activeIndex === index ? "is-active" : ""}`} onMouseEnter={() => setActiveIndex(index)} onClick={() => go(item.path)}>
                    <span className="scc-command-icon"><Icon size={16} /></span>
                    <span>{text(item.label, item.zh)}</span>
                    <span className="scc-command-hint">↵</span>
                  </button>
                );
              })}
            </div>
          )}

          {matchingSkills.length > 0 && (
            <div className="scc-command-section">
              <div className="scc-command-label">{text("Skills", "技能")}</div>
              {matchingSkills.map((skill, index) => {
                const itemIndex = matchingDestinations.length + index;
                return (
                <button key={skill.id} className={`scc-command-item ${activeIndex === itemIndex ? "is-active" : ""}`} onMouseEnter={() => setActiveIndex(itemIndex)} onClick={() => go(`/skill/${encodeURIComponent(skill.id)}`)}>
                  <span className="scc-command-icon"><Command size={16} /></span>
                  <span className="scc-command-copy">
                    <strong>{skill.name}</strong>
                    <small>{skill.description || text("No description", "暂无描述")}</small>
                  </span>
                  <span className="scc-command-hint">{skill.linked_agents.length}</span>
                </button>
                );
              })}
            </div>
          )}

          {matchingDestinations.length === 0 && matchingSkills.length === 0 && (
            <div className="scc-empty-compact">{text("No matching commands or skills.", "没有匹配的命令或技能。")}</div>
          )}
        </div>
      </section>
    </div>
  );
}
