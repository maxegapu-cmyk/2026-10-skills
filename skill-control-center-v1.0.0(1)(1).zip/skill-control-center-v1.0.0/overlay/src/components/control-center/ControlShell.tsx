import { useCallback, useEffect, useMemo, useState } from "react";
import { NavLink, Outlet, useLocation } from "react-router-dom";
import {
  Activity,
  Boxes,
  Command,
  Compass,
  Download,
  Grid3X3,
  Library,
  Menu,
  PackageSearch,
  RefreshCw,
  Settings,
  ShieldCheck,
  X,
} from "lucide-react";
import { useCentralSkillsStore } from "@/stores/centralSkillsStore";
import { usePlatformStore } from "@/stores/platformStore";
import { ControlCommandPalette } from "@/components/control-center/ControlCommandPalette";
import { buildHealthReport } from "@/control-center/health";
import { getTargetAgents } from "@/control-center/matrix";
import { useControlLocale } from "@/control-center/useControlLocale";
import "@/control-center/control-center.css";

const navItems = [
  { to: "/overview", en: "Overview", zh: "总览", icon: Activity },
  { to: "/central", en: "Library", zh: "技能库", icon: Library },
  { to: "/matrix", en: "Platform Matrix", zh: "平台矩阵", icon: Grid3X3 },
  { to: "/health", en: "Health", zh: "健康检查", icon: ShieldCheck },
  { to: "/collections", en: "Workspaces", zh: "工作区", icon: Boxes },
  { to: "/discover", en: "Discover", zh: "发现", icon: Compass },
  { to: "/import", en: "Import Hub", zh: "导入中心", icon: Download },
  { to: "/marketplace", en: "Marketplace", zh: "市场", icon: PackageSearch },
] as const;

export function ControlShell() {
  const location = useLocation();
  const [paletteOpen, setPaletteOpen] = useState(false);
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const { text } = useControlLocale();

  const initializePlatforms = usePlatformStore((state) => state.initialize);
  const rescanPlatforms = usePlatformStore((state) => state.rescan);
  const agents = usePlatformStore((state) => state.agents);
  const skillsByAgent = usePlatformStore((state) => state.skillsByAgent);
  const platformLoading = usePlatformStore((state) => state.isLoading);
  const loadCentralSkills = useCentralSkillsStore((state) => state.loadCentralSkills);
  const skills = useCentralSkillsStore((state) => state.skills);
  const centralLoading = useCentralSkillsStore((state) => state.isLoading);

  useEffect(() => {
    void Promise.all([initializePlatforms(), loadCentralSkills()]);
  }, [initializePlatforms, loadCentralSkills]);

  useEffect(() => {
    const handleShortcut = (event: KeyboardEvent) => {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k") {
        event.preventDefault();
        setPaletteOpen(true);
      }
    };
    window.addEventListener("keydown", handleShortcut);
    return () => window.removeEventListener("keydown", handleShortcut);
  }, []);

  useEffect(() => setMobileNavOpen(false), [location.pathname]);

  const health = useMemo(() => buildHealthReport(skills, agents, skillsByAgent), [agents, skills, skillsByAgent]);
  const targetAgents = useMemo(() => getTargetAgents(agents), [agents]);
  const detectedAgents = targetAgents.filter((agent) => agent.is_detected && agent.is_enabled).length;

  const refresh = useCallback(async () => {
    if (isRefreshing) return;
    setIsRefreshing(true);
    try {
      await Promise.all([rescanPlatforms(), loadCentralSkills()]);
    } finally {
      setIsRefreshing(false);
    }
  }, [isRefreshing, loadCentralSkills, rescanPlatforms]);

  const loading = platformLoading || centralLoading;

  return (
    <div className="scc-shell">
      <aside className={`scc-sidebar ${mobileNavOpen ? "is-open" : ""}`}>
        <div className="scc-brand-row">
          <NavLink to="/overview" className="scc-brand">
            <img src="/control-center.svg" alt="" aria-hidden="true" />
            <span>
              <strong>Skill Control Center</strong>
              <small>{text("Agent skill operations", "Agent 技能运维中心")}</small>
            </span>
          </NavLink>
          <button className="scc-icon-button scc-mobile-only" onClick={() => setMobileNavOpen(false)} aria-label={text("Close navigation", "关闭导航")}>
            <X size={18} />
          </button>
        </div>

        <button className="scc-command-trigger" onClick={() => setPaletteOpen(true)}>
          <span><Command size={16} /> {text("Quick find", "快速查找")}</span>
          <kbd>⌘K</kbd>
        </button>

        <nav className="scc-nav" aria-label={text("Main navigation", "主导航")}>
          {navItems.map((item) => {
            const Icon = item.icon;
            return (
              <NavLink key={item.to} to={item.to} className={({ isActive }) => `scc-nav-item ${isActive ? "is-active" : ""}`}>
                <Icon size={17} />
                <span>{text(item.en, item.zh)}</span>
                {item.to === "/health" && health.summary.high > 0 && <span className="scc-nav-badge danger">{health.summary.high}</span>}
              </NavLink>
            );
          })}
        </nav>

        <div className="scc-sidebar-section">
          <div className="scc-sidebar-label">{text("Platforms", "平台")}</div>
          <div className="scc-platform-shortcuts">
            {targetAgents.slice(0, 8).map((agent) => (
              <NavLink key={agent.id} to={`/platform/${encodeURIComponent(agent.id)}`} className={({ isActive }) => `scc-platform-shortcut ${isActive ? "is-active" : ""}`}>
                <span className={`scc-status-dot ${agent.is_detected && agent.is_enabled ? "online" : "offline"}`} />
                <span>{agent.display_name}</span>
                <small>{skillsByAgent[agent.id] ?? 0}</small>
              </NavLink>
            ))}
          </div>
        </div>

        <div className="scc-sidebar-footer">
          <div className="scc-mini-status">
            <span><strong>{skills.length}</strong>{text(" skills", " 个技能")}</span>
            <span><strong>{detectedAgents}</strong>{text(" active", " 个活动平台")}</span>
          </div>
          <NavLink to="/settings" className={({ isActive }) => `scc-nav-item compact ${isActive ? "is-active" : ""}`}>
            <Settings size={17} />
            <span>{text("Settings", "设置")}</span>
          </NavLink>
        </div>
      </aside>

      {mobileNavOpen && <button className="scc-mobile-scrim" onClick={() => setMobileNavOpen(false)} aria-label={text("Close navigation", "关闭导航")} />}

      <div className="scc-main">
        <header className="scc-topbar">
          <button className="scc-icon-button scc-mobile-only" onClick={() => setMobileNavOpen(true)} aria-label={text("Open navigation", "打开导航")}>
            <Menu size={19} />
          </button>
          <div className="scc-topbar-context">
            <span className="scc-live-dot" />
            <span>{loading ? text("Scanning workspace…", "正在扫描工作区…") : text("Workspace synchronized", "工作区已同步")}</span>
          </div>
          <div className="scc-topbar-actions">
            <button className="scc-toolbar-button" onClick={() => setPaletteOpen(true)}><Command size={15} /> {text("Command", "命令")}</button>
            <button className="scc-toolbar-button" onClick={() => void refresh()} disabled={isRefreshing}>
              <RefreshCw size={15} className={isRefreshing ? "is-spinning" : ""} /> {text("Rescan", "重新扫描")}
            </button>
          </div>
        </header>
        <main className="scc-content"><Outlet /></main>
      </div>

      <ControlCommandPalette open={paletteOpen} onClose={() => setPaletteOpen(false)} />
    </div>
  );
}
