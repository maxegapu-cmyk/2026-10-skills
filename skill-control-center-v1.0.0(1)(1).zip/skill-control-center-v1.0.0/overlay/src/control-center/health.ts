export type HealthSeverity = "high" | "medium" | "low";

export type HealthIssueCode =
  | "duplicate-name"
  | "missing-description"
  | "not-deployed"
  | "unknown-link"
  | "missing-path"
  | "inactive-platform-with-skills";

export interface HealthSkill {
  id: string;
  name: string;
  description?: string | null;
  canonical_path?: string | null;
  file_path?: string | null;
  linked_agents?: string[] | null;
}

export interface HealthAgent {
  id: string;
  display_name?: string | null;
  is_enabled?: boolean;
  is_detected?: boolean;
}

export interface HealthIssue {
  id: string;
  code: HealthIssueCode;
  severity: HealthSeverity;
  title: string;
  detail: string;
  skillId?: string;
  skillName?: string;
  agentId?: string;
}

export interface HealthSummary {
  totalSkills: number;
  totalDeployments: number;
  high: number;
  medium: number;
  low: number;
}

export interface HealthReport {
  issues: HealthIssue[];
  summary: HealthSummary;
}

const normalizeName = (value: string) =>
  value
    .normalize("NFKC")
    .toLowerCase()
    .replace(/[^\p{L}\p{N}]+/gu, "");

const hasText = (value?: string | null) => Boolean(value?.trim());

export function buildHealthReport(
  skills: HealthSkill[],
  agents: HealthAgent[],
  skillsByAgent: Record<string, number> = {},
): HealthReport {
  const issues: HealthIssue[] = [];
  const agentIds = new Set(agents.map((agent) => agent.id));
  const duplicateBuckets = new Map<string, HealthSkill[]>();

  for (const skill of skills) {
    const key = normalizeName(skill.name);
    const bucket = duplicateBuckets.get(key) ?? [];
    bucket.push(skill);
    duplicateBuckets.set(key, bucket);

    if (!hasText(skill.description)) {
      issues.push({
        id: `missing-description:${skill.id}`,
        code: "missing-description",
        severity: "medium",
        title: "Missing description",
        detail: `${skill.name} has no usable description.`,
        skillId: skill.id,
        skillName: skill.name,
      });
    }

    if (!hasText(skill.canonical_path) && !hasText(skill.file_path)) {
      issues.push({
        id: `missing-path:${skill.id}`,
        code: "missing-path",
        severity: "high",
        title: "Missing skill path",
        detail: `${skill.name} has neither a canonical path nor a source file path.`,
        skillId: skill.id,
        skillName: skill.name,
      });
    }

    const linkedAgents = skill.linked_agents ?? [];
    if (linkedAgents.length === 0) {
      issues.push({
        id: `not-deployed:${skill.id}`,
        code: "not-deployed",
        severity: "medium",
        title: "Not deployed",
        detail: `${skill.name} is present in the central library but is not linked to any platform.`,
        skillId: skill.id,
        skillName: skill.name,
      });
    }

    for (const agentId of linkedAgents) {
      if (!agentIds.has(agentId)) {
        issues.push({
          id: `unknown-link:${skill.id}:${agentId}`,
          code: "unknown-link",
          severity: "high",
          title: "Unknown platform link",
          detail: `${skill.name} references platform “${agentId}”, but that platform is not registered.`,
          skillId: skill.id,
          skillName: skill.name,
          agentId,
        });
      }
    }
  }

  for (const [, bucket] of duplicateBuckets) {
    if (bucket.length < 2) continue;
    const names = bucket.map((skill) => skill.name).join(", ");
    for (const skill of bucket) {
      issues.push({
        id: `duplicate-name:${skill.id}`,
        code: "duplicate-name",
        severity: "high",
        title: "Possible duplicate skill",
        detail: `${skill.name} collides with another normalized skill name in this library (${names}).`,
        skillId: skill.id,
        skillName: skill.name,
      });
    }
  }

  for (const agent of agents) {
    const deployedCount = skillsByAgent[agent.id] ?? skills.reduce(
      (count, skill) => count + ((skill.linked_agents ?? []).includes(agent.id) ? 1 : 0),
      0,
    );
    const inactive = agent.is_enabled === false || agent.is_detected === false;
    if (inactive && deployedCount > 0) {
      issues.push({
        id: `inactive-platform-with-skills:${agent.id}`,
        code: "inactive-platform-with-skills",
        severity: "high",
        title: "Skills linked to inactive platform",
        detail: `${agent.display_name ?? agent.id} has ${deployedCount} linked skill${deployedCount === 1 ? "" : "s"} while disabled or not detected.`,
        agentId: agent.id,
      });
    }
  }

  const severityRank: Record<HealthSeverity, number> = { high: 0, medium: 1, low: 2 };
  issues.sort((a, b) => severityRank[a.severity] - severityRank[b.severity] || a.title.localeCompare(b.title));

  return {
    issues,
    summary: {
      totalSkills: skills.length,
      totalDeployments: skills.reduce((sum, skill) => sum + (skill.linked_agents?.length ?? 0), 0),
      high: issues.filter((issue) => issue.severity === "high").length,
      medium: issues.filter((issue) => issue.severity === "medium").length,
      low: issues.filter((issue) => issue.severity === "low").length,
    },
  };
}
