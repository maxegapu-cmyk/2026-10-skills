import { useTranslation } from "react-i18next";

export function useControlLocale() {
  const { i18n } = useTranslation();
  const isZh = i18n.language?.toLowerCase().startsWith("zh") ?? false;
  return {
    isZh,
    text: (english: string, chinese: string) => (isZh ? chinese : english),
  };
}
