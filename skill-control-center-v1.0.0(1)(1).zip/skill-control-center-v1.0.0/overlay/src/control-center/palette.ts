export function movePaletteIndex(current: number, delta: number, count: number): number {
  if (count <= 0) return -1;
  const base = current < 0 || current >= count ? 0 : current;
  return (base + delta + count) % count;
}
