export interface MatrixSkill {
  id: string;
  name: string;
  description?: string | null;
  source?: string | null;
  linked_agents?: string[] | null;
  read_only_agents?: string[] | null;
}

export interface MatrixAgent {
  id: string;
  display_name?: string | null;
  is_enabled?: boolean;
  is_detected?: boolean;
}

const searchable = (value: string) =>
  value
    .normalize("NFKC")
    .toLowerCase()
    .replace(/[^\p{L}\p{N}]+/gu, " ")
    .trim();

export function countDeployments(skills: MatrixSkill[]): number {
  return skills.reduce((sum, skill) => sum + (skill.linked_agents?.length ?? 0), 0);
}

export function filterMatrixRows<T extends MatrixSkill>(skills: T[], query: string): T[] {
  const terms = searchable(query).split(/\s+/).filter(Boolean);
  if (terms.length === 0) return skills;

  return skills.filter((skill) => {
    const haystack = searchable(
      [skill.name, skill.description ?? "", skill.id, skill.source ?? ""].join(" "),
    );
    return terms.every((term) => haystack.includes(term));
  });
}


export function takeMatrixRows<T>(rows: T[], limit: number): T[] {
  if (!Number.isFinite(limit) || limit <= 0) return [];
  return rows.slice(0, Math.floor(limit));
}

export function getTargetAgents<T extends MatrixAgent>(agents: T[]): T[] {
  return agents.filter((agent) => agent.id !== "central");
}

export function deploymentCoverage(skill: MatrixSkill, targetAgentIds: string[]): number {
  if (targetAgentIds.length === 0) return 0;
  const linked = new Set(skill.linked_agents ?? []);
  const deployed = targetAgentIds.reduce((sum, agentId) => sum + (linked.has(agentId) ? 1 : 0), 0);
  return deployed / targetAgentIds.length;
}

export interface DeploymentGap<T extends MatrixSkill = MatrixSkill> {
  skill: T;
  missingAgentIds: string[];
}

export function findDeploymentGaps<T extends MatrixSkill>(
  skills: T[],
  targetAgentIds: string[],
  limit = 6,
): DeploymentGap<T>[] {
  if (targetAgentIds.length === 0 || limit <= 0) return [];
  return skills
    .map((skill, index) => {
      const linked = new Set(skill.linked_agents ?? []);
      return { skill, missingAgentIds: targetAgentIds.filter((agentId) => !linked.has(agentId)), index };
    })
    .filter((entry) => entry.missingAgentIds.length > 0)
    .sort((a, b) => b.missingAgentIds.length - a.missingAgentIds.length || a.index - b.index)
    .slice(0, Math.floor(limit))
    .map(({ skill, missingAgentIds }) => ({ skill, missingAgentIds }));
}


export type DeploymentDirection = "install" | "uninstall";
export interface DeploymentPair { skillId: string; agentId: string }

export function buildDeploymentPairs(
  skills: MatrixSkill[],
  skillIds: string[],
  agentIds: string[],
  direction: DeploymentDirection,
): { pairs: DeploymentPair[]; skippedReadOnly: DeploymentPair[] } {
  const skillMap = new Map(skills.map((skill) => [skill.id, skill]));
  const pairs: DeploymentPair[] = [];
  const skippedReadOnly: DeploymentPair[] = [];

  for (const skillId of skillIds) {
    const skill = skillMap.get(skillId);
    if (!skill) continue;
    const linked = new Set(skill.linked_agents ?? []);
    const readOnly = new Set(skill.read_only_agents ?? []);
    for (const agentId of agentIds) {
      const needsChange = direction === "install" ? !linked.has(agentId) : linked.has(agentId);
      if (!needsChange) continue;
      const pair = { skillId, agentId };
      if (readOnly.has(agentId)) {
        skippedReadOnly.push(pair);
        continue;
      }
      pairs.push(pair);
    }
  }

  return { pairs, skippedReadOnly };
}
