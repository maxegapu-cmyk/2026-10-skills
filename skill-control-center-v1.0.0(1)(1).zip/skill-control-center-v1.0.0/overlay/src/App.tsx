import { Navigate, Route, Routes } from "react-router-dom";
import { ControlShell } from "@/components/control-center/ControlShell";
import { ControlOverviewView } from "@/pages/ControlOverviewView";
import { ControlHealthView } from "@/pages/ControlHealthView";
import { PlatformMatrixView } from "@/pages/PlatformMatrixView";
import { ImportHubView } from "@/pages/ImportHubView";
import { PlatformView } from "@/pages/PlatformView";
import { CentralSkillsView } from "@/pages/CentralSkillsView";
import { SkillDetailPage } from "@/pages/SkillDetailPage";
import { CollectionsListView } from "@/pages/CollectionsListView";
import { MarketplaceView } from "@/pages/MarketplaceView";
import { SettingsView } from "@/pages/SettingsView";
import { DiscoverView } from "@/pages/DiscoverView";
import { ObsidianVaultView } from "@/pages/ObsidianVaultView";

function App() {
  return (
    <Routes>
      <Route path="/" element={<ControlShell />}>
        <Route index element={<Navigate to="/overview" replace />} />
        <Route path="overview" element={<ControlOverviewView />} />
        <Route path="central" element={<CentralSkillsView />} />
        <Route path="matrix" element={<PlatformMatrixView />} />
        <Route path="health" element={<ControlHealthView />} />
        <Route path="import" element={<ImportHubView />} />
        <Route path="platform/:agentId" element={<PlatformView />} />
        <Route path="skill/:skillId" element={<SkillDetailPage />} />
        <Route path="collections" element={<CollectionsListView />} />
        <Route path="marketplace" element={<MarketplaceView />} />
        <Route path="discover" element={<DiscoverView />} />
        <Route path="discover/:projectPath" element={<DiscoverView />} />
        <Route path="obsidian/:vaultId" element={<ObsidianVaultView />} />
        <Route path="settings" element={<SettingsView />} />
        <Route path="*" element={<Navigate to="/overview" replace />} />
      </Route>
    </Routes>
  );
}

export default App;
