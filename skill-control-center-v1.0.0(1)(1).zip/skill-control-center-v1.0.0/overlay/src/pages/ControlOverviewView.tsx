import { useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { Activity, ArrowRight, Boxes, Grid3X3, Library, ShieldAlert, Sparkles } from "lucide-react";
import { useCentralSkillsStore } from "@/stores/centralSkillsStore";
import { usePlatformStore } from "@/stores/platformStore";
import { buildHealthReport } from "@/control-center/health";
import { countDeployments, findDeploymentGaps, getTargetAgents } from "@/control-center/matrix";
import { useControlLocale } from "@/control-center/useControlLocale";

export function ControlOverviewView() {
  const navigate = useNavigate();
  const { text } = useControlLocale();
  const skills = useCentralSkillsStore((state) => state.skills);
  const agents = usePlatformStore((state) => state.agents);
  const skillsByAgent = usePlatformStore((state) => state.skillsByAgent);

  const targetAgents = useMemo(() => getTargetAgents(agents), [agents]);
  const health = useMemo(() => buildHealthReport(skills, agents, skillsByAgent), [agents, skills, skillsByAgent]);
  const deployments = useMemo(() => countDeployments(skills), [skills]);
  const recent = useMemo(
    () => [...skills].sort((a, b) => Date.parse(b.updated_at || b.created_at || b.scanned_at) - Date.parse(a.updated_at || a.created_at || a.scanned_at)).slice(0, 6),
    [skills],
  );
  const activeAgents = targetAgents.filter((agent) => agent.is_detected && agent.is_enabled);
  const deploymentGaps = useMemo(
    () => findDeploymentGaps(skills, activeAgents.map((agent) => agent.id), 5),
    [activeAgents, skills],
  );

  return (
    <div className="scc-page">
      <section className="scc-hero">
        <div>
          <span className="scc-eyebrow"><Sparkles size={14} /> {text("OPERATIONS OVERVIEW", "运维总览")}</span>
          <h1>{text("One control plane for every agent skill.", "一套控制面，管理所有 Agent Skill。")}</h1>
          <p>{text("See library health, deployment coverage and platform state without jumping between agent-specific folders.", "无需在各个平台目录之间来回切换，一眼看清技能库健康度、部署覆盖和平台状态。")}</p>
        </div>
        <div className="scc-hero-actions">
          <button className="scc-primary-button" onClick={() => navigate("/matrix")}><Grid3X3 size={16} /> {text("Open matrix", "打开矩阵")}</button>
          <button className="scc-secondary-button" onClick={() => navigate("/import")}><Boxes size={16} /> {text("Import skills", "导入技能")}</button>
        </div>
      </section>

      <section className="scc-stat-grid">
        <button className="scc-stat-card" onClick={() => navigate("/central")}>
          <span className="scc-stat-icon"><Library size={18} /></span>
          <strong>{skills.length}</strong><small>{text("Central skills", "中央技能")}</small>
        </button>
        <button className="scc-stat-card" onClick={() => navigate("/matrix")}>
          <span className="scc-stat-icon"><Grid3X3 size={18} /></span>
          <strong>{deployments}</strong><small>{text("Deployments", "部署关系")}</small>
        </button>
        <button className="scc-stat-card" onClick={() => navigate("/matrix")}>
          <span className="scc-stat-icon"><Activity size={18} /></span>
          <strong>{activeAgents.length}<em>/{targetAgents.length}</em></strong><small>{text("Active platforms", "活动平台")}</small>
        </button>
        <button className={`scc-stat-card ${health.summary.high > 0 ? "has-risk" : ""}`} onClick={() => navigate("/health")}>
          <span className="scc-stat-icon"><ShieldAlert size={18} /></span>
          <strong>{health.issues.length}</strong><small>{text("Health findings", "健康问题")}</small>
        </button>
      </section>

      <section className="scc-dashboard-grid">
        <article className="scc-panel scc-panel-wide">
          <div className="scc-panel-header">
            <div><span className="scc-eyebrow">{text("PLATFORM COVERAGE", "平台覆盖")}</span><h2>{text("Where your skills are deployed", "技能部署到哪里")}</h2></div>
            <button className="scc-text-button" onClick={() => navigate("/matrix")}>{text("Manage", "管理")} <ArrowRight size={14} /></button>
          </div>
          <div className="scc-coverage-list">
            {targetAgents.length === 0 ? <div className="scc-empty-compact">{text("No platforms registered yet.", "尚未注册平台。")}</div> : targetAgents.map((agent) => {
              const count = skillsByAgent[agent.id] ?? 0;
              const percentage = skills.length === 0 ? 0 : Math.min(100, Math.round((count / skills.length) * 100));
              return (
                <button key={agent.id} className="scc-coverage-row" onClick={() => navigate(`/platform/${encodeURIComponent(agent.id)}`)}>
                  <span className={`scc-status-dot ${agent.is_detected && agent.is_enabled ? "online" : "offline"}`} />
                  <span className="scc-coverage-name"><strong>{agent.display_name}</strong><small>{agent.global_skills_dir}</small></span>
                  <span className="scc-coverage-bar"><i style={{ width: `${percentage}%` }} /></span>
                  <span className="scc-coverage-count">{count}</span>
                </button>
              );
            })}
          </div>
        </article>

        <article className="scc-panel">
          <div className="scc-panel-header"><div><span className="scc-eyebrow">{text("HEALTH", "健康")}</span><h2>{text("Needs attention", "需要处理")}</h2></div></div>
          <div className="scc-health-score">
            <div className={`scc-score-orb ${health.summary.high > 0 ? "risk" : "good"}`}><strong>{health.summary.high}</strong><small>{text("high", "高风险")}</small></div>
            <div className="scc-health-breakdown">
              <span><i className="high" /> {health.summary.high} {text("high", "高")}</span>
              <span><i className="medium" /> {health.summary.medium} {text("medium", "中")}</span>
              <span><i className="low" /> {health.summary.low} {text("low", "低")}</span>
            </div>
          </div>
          <button className="scc-secondary-button full" onClick={() => navigate("/health")}>{text("Review findings", "查看问题")}</button>
        </article>

        <article className="scc-panel">
          <div className="scc-panel-header">
            <div><span className="scc-eyebrow">{text("DEPLOYMENT GAPS", "部署缺口")}</span><h2>{text("Skills missing from active platforms", "尚未覆盖全部活动平台")}</h2></div>
          </div>
          <div className="scc-gap-list">
            {deploymentGaps.map(({ skill, missingAgentIds }) => (
              <button key={skill.id} className="scc-gap-row" onClick={() => navigate("/matrix")}>
                <span><strong>{skill.name}</strong><small>{text(`${missingAgentIds.length} platform${missingAgentIds.length === 1 ? "" : "s"} missing`, `缺少 ${missingAgentIds.length} 个平台`)}</small></span>
                <ArrowRight size={14} />
              </button>
            ))}
            {deploymentGaps.length === 0 && (
              <div className="scc-empty-compact">{activeAgents.length === 0 ? text("No active platforms to compare yet.", "当前没有可比较的活动平台。") : text("All central skills cover every active platform.", "所有中央技能均已覆盖全部活动平台。")}</div>
            )}
          </div>
        </article>

        <article className="scc-panel scc-panel-wide">
          <div className="scc-panel-header"><div><span className="scc-eyebrow">{text("RECENT LIBRARY", "最近技能")}</span><h2>{text("Recently touched skills", "最近变动的技能")}</h2></div></div>
          <div className="scc-recent-grid">
            {recent.map((skill) => (
              <button key={skill.id} className="scc-recent-card" onClick={() => navigate(`/skill/${encodeURIComponent(skill.id)}`)}>
                <span className="scc-recent-letter">{skill.name.slice(0, 1).toUpperCase()}</span>
                <span><strong>{skill.name}</strong><small>{skill.description || text("No description", "暂无描述")}</small></span>
                <em>{skill.linked_agents.length}</em>
              </button>
            ))}
            {recent.length === 0 && <div className="scc-empty-compact">{text("Your central library is empty.", "中央技能库目前为空。")}</div>}
          </div>
        </article>
      </section>
    </div>
  );
}
