import { useMemo, useState } from "react";
import { Check, Eraser, Grid3X3, Search, Undo2, UploadCloud } from "lucide-react";
import { toast } from "sonner";
import { invoke, isTauriRuntime } from "@/lib/tauri";
import { useCentralSkillsStore } from "@/stores/centralSkillsStore";
import { usePlatformStore } from "@/stores/platformStore";
import { buildDeploymentPairs, filterMatrixRows, getTargetAgents, takeMatrixRows } from "@/control-center/matrix";
import { useControlLocale } from "@/control-center/useControlLocale";

type Pair = { skillId: string; agentId: string };
type UndoState = { direction: "install" | "uninstall"; pairs: Pair[] } | null;

async function settleWithConcurrency<T>(items: T[], worker: (item: T) => Promise<void>, concurrency = 8) {
  let cursor = 0;
  const successful: T[] = [];
  const failed: Array<{ item: T; error: unknown }> = [];
  const runners = Array.from({ length: Math.min(concurrency, items.length) }, async () => {
    while (cursor < items.length) {
      const current = items[cursor++];
      try {
        await worker(current);
        successful.push(current);
      } catch (error) {
        failed.push({ item: current, error });
      }
    }
  });
  await Promise.all(runners);
  return { successful, failed };
}

export function PlatformMatrixView() {
  const { text } = useControlLocale();
  const [query, setQuery] = useState("");
  const [selectedSkills, setSelectedSkills] = useState<Set<string>>(new Set());
  const [selectedAgents, setSelectedAgents] = useState<Set<string>>(new Set());
  const [busy, setBusy] = useState(false);
  const [undo, setUndo] = useState<UndoState>(null);
  const [rowLimit, setRowLimit] = useState(120);

  const skills = useCentralSkillsStore((state) => state.skills);
  const agents = useCentralSkillsStore((state) => state.agents);
  const loadCentralSkills = useCentralSkillsStore((state) => state.loadCentralSkills);
  const togglePlatformLink = useCentralSkillsStore((state) => state.togglePlatformLink);
  const refreshCounts = usePlatformStore((state) => state.refreshCounts);

  const targets = useMemo(() => getTargetAgents(agents), [agents]);
  const rows = useMemo(() => filterMatrixRows(skills, query), [query, skills]);
  const visibleRows = useMemo(() => takeMatrixRows(rows, rowLimit), [rowLimit, rows]);

  const toggleSkillSelection = (skillId: string) => setSelectedSkills((current) => {
    const next = new Set(current); next.has(skillId) ? next.delete(skillId) : next.add(skillId); return next;
  });
  const toggleAgentSelection = (agentId: string) => setSelectedAgents((current) => {
    const next = new Set(current); next.has(agentId) ? next.delete(agentId) : next.add(agentId); return next;
  });

  const candidatePairs = (direction: "install" | "uninstall") => {
    const skillIds = selectedSkills.size ? [...selectedSkills] : rows.map((skill) => skill.id);
    const agentIds = selectedAgents.size ? [...selectedAgents] : targets.filter((agent) => agent.is_enabled).map((agent) => agent.id);
    return buildDeploymentPairs(skills, skillIds, agentIds, direction);
  };

  const executePairs = async (direction: "install" | "uninstall", pairs: Pair[]) => {
    if (!isTauriRuntime()) throw new Error(text("Bulk deployment requires the desktop runtime.", "批量部署需要桌面端运行环境。"));
    const outcome = await settleWithConcurrency(pairs, async (pair) => {
      if (direction === "install") await invoke("install_skill_to_agent", { skillId: pair.skillId, agentId: pair.agentId, method: "auto" });
      else await invoke("uninstall_skill_from_agent", { skillId: pair.skillId, agentId: pair.agentId });
    });
    await Promise.all([loadCentralSkills(), refreshCounts()]);
    return outcome;
  };

  const runBulk = async (direction: "install" | "uninstall") => {
    const plan = candidatePairs(direction);
    const { pairs, skippedReadOnly } = plan;
    if (pairs.length === 0) {
      toast.info(skippedReadOnly.length
        ? text("Every requested change is read-only and was skipped.", "请求的变更全部为只读关系，已跳过。")
        : text("Nothing to change for this selection.", "当前选择没有需要变更的关系。"));
      return;
    }
    if (direction === "uninstall" && !window.confirm(text(`Remove ${pairs.length} deployment links?`, `确认移除 ${pairs.length} 个部署关系？`))) return;
    setBusy(true);
    try {
      const outcome = await executePairs(direction, pairs);
      setUndo(outcome.successful.length ? { direction, pairs: outcome.successful } : null);
      if (outcome.failed.length > 0 || skippedReadOnly.length > 0) {
        toast.warning(text(
          `${outcome.successful.length} updated, ${outcome.failed.length} failed, ${skippedReadOnly.length} read-only skipped. Successful changes can still be undone.`,
          `成功更新 ${outcome.successful.length} 个，失败 ${outcome.failed.length} 个，只读跳过 ${skippedReadOnly.length} 个；已成功的部分仍可撤销。`,
        ));
      } else {
        toast.success(text(`${outcome.successful.length} deployment links updated.`, `已更新 ${outcome.successful.length} 个部署关系。`));
      }
    } catch (error) {
      await Promise.all([loadCentralSkills(), refreshCounts()]).catch(() => undefined);
      toast.error(String(error));
    } finally { setBusy(false); }
  };

  const undoLast = async () => {
    if (!undo || busy) return;
    setBusy(true);
    try {
      const outcome = await executePairs(undo.direction === "install" ? "uninstall" : "install", undo.pairs);
      if (outcome.failed.length > 0) {
        setUndo({ direction: undo.direction, pairs: outcome.failed.map((entry) => entry.item) });
        toast.warning(text(
          `${outcome.successful.length} reversed, ${outcome.failed.length} still need retry.`,
          `已撤销 ${outcome.successful.length} 个，仍有 ${outcome.failed.length} 个需要重试。`,
        ));
      } else {
        setUndo(null);
        toast.success(text("Last bulk action reversed.", "已撤销上一次批量操作。"));
      }
    } catch (error) { toast.error(String(error)); } finally { setBusy(false); }
  };

  return (
    <div className="scc-page scc-matrix-page">
      <header className="scc-page-header">
        <div><span className="scc-eyebrow"><Grid3X3 size={14} /> {text("PLATFORM MATRIX", "平台矩阵")}</span><h1>{text("Deploy many skills without opening many folders.", "不用逐个平台点开，批量完成技能部署。")}</h1><p>{text("Rows are central skills. Columns are agent platforms. Click a cell for a single link, or select rows and columns for bulk operations.", "行是中央技能，列是 Agent 平台；单击格子切换单个部署，也可以选择多行多列批量处理。")}</p></div>
      </header>

      <div className="scc-matrix-toolbar">
        <label className="scc-search-field"><Search size={16} /><input value={query} onChange={(event) => { setQuery(event.target.value); setRowLimit(120); }} placeholder={text("Filter skills…", "筛选技能…")} /></label>
        <div className="scc-selection-summary">{selectedSkills.size || rows.length} × {selectedAgents.size || targets.filter((agent) => agent.is_enabled).length}</div>
        <button className="scc-secondary-button" disabled={busy} onClick={() => void runBulk("install")}><UploadCloud size={16} /> {text("Deploy", "部署")}</button>
        <button className="scc-secondary-button danger" disabled={busy} onClick={() => void runBulk("uninstall")}><Eraser size={16} /> {text("Remove", "移除")}</button>
        <button className="scc-icon-button bordered" disabled={!undo || busy} onClick={() => void undoLast()} title={text("Undo last bulk action", "撤销上一次批量操作")}><Undo2 size={16} /></button>
      </div>

      <div className="scc-matrix-wrap">
        <table className="scc-matrix">
          <thead><tr><th className="scc-sticky-col"><label className="scc-check-label"><input type="checkbox" checked={rows.length > 0 && rows.every((skill) => selectedSkills.has(skill.id))} onChange={(event) => setSelectedSkills(event.target.checked ? new Set(rows.map((skill) => skill.id)) : new Set())} /> <span>{text("Skill", "技能")}</span></label></th>{targets.map((agent) => <th key={agent.id}><button className={`scc-platform-head ${selectedAgents.has(agent.id) ? "is-selected" : ""}`} onClick={() => toggleAgentSelection(agent.id)}><span className={`scc-status-dot ${agent.is_detected && agent.is_enabled ? "online" : "offline"}`} /><strong>{agent.display_name}</strong><small>{agent.is_enabled ? text("enabled", "已启用") : text("disabled", "已停用")}</small></button></th>)}</tr></thead>
          <tbody>{visibleRows.map((skill) => {
            const linked = new Set(skill.linked_agents);
            return <tr key={skill.id}><td className="scc-sticky-col"><label className="scc-skill-row-label"><input type="checkbox" checked={selectedSkills.has(skill.id)} onChange={() => toggleSkillSelection(skill.id)} /><span><strong>{skill.name}</strong><small>{skill.description || text("No description", "暂无描述")}</small></span></label></td>{targets.map((agent) => {
              const isLinked = linked.has(agent.id);
              const isReadOnly = skill.read_only_agents?.includes(agent.id) ?? false;
              return <td key={agent.id}><button className={`scc-matrix-cell ${isLinked ? "is-linked" : ""} ${isReadOnly ? "is-read-only" : ""}`} disabled={busy || isReadOnly} title={isReadOnly ? text("Read-only platform link", "只读平台关系") : undefined} onClick={() => void togglePlatformLink(skill.id, agent.id).then(refreshCounts).catch((error) => toast.error(String(error)))} aria-label={`${skill.name} → ${agent.display_name}`}><span>{isLinked ? <Check size={16} /> : null}</span></button></td>;
            })}</tr>;
          })}</tbody>
        </table>
        {rows.length === 0 && <div className="scc-empty-state">{text("No skills match this filter.", "没有技能符合当前筛选。")}</div>}
        {rows.length > visibleRows.length && (
          <div className="scc-matrix-load-more">
            <span>{text(`Showing ${visibleRows.length} of ${rows.length} skills`, `当前显示 ${visibleRows.length} / ${rows.length} 个技能`)}</span>
            <button className="scc-secondary-button" onClick={() => setRowLimit((current) => current + 120)}>
              {text("Load 120 more", "再加载 120 个")}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
