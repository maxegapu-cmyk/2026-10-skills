import { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { FolderSearch, Github, PackageSearch, Radar, UploadCloud } from "lucide-react";
import { GitHubRepoImportWizard } from "@/components/marketplace/GitHubRepoImportWizard";
import { useCentralSkillsStore } from "@/stores/centralSkillsStore";
import { useMarketplaceStore } from "@/stores/marketplaceStore";
import { usePlatformStore } from "@/stores/platformStore";
import { useControlLocale } from "@/control-center/useControlLocale";

export function ImportHubView() {
  const navigate = useNavigate();
  const { text } = useControlLocale();
  const [repoUrl, setRepoUrl] = useState("");
  const [wizardOpen, setWizardOpen] = useState(false);
  const githubImport = useMarketplaceStore((state) => state.githubImport);
  const previewGitHubRepoImport = useMarketplaceStore((state) => state.previewGitHubRepoImport);
  const importGitHubRepoSkills = useMarketplaceStore((state) => state.importGitHubRepoSkills);
  const resetGitHubImport = useMarketplaceStore((state) => state.resetGitHubImport);
  const centralSkills = useCentralSkillsStore((state) => state.skills);
  const agents = useCentralSkillsStore((state) => state.agents);
  const loadCentralSkills = useCentralSkillsStore((state) => state.loadCentralSkills);
  const installSkill = useCentralSkillsStore((state) => state.installSkill);
  const refreshCounts = usePlatformStore((state) => state.refreshCounts);

  const importedSkillIds = useMemo(
    () => new Set(githubImport.importResult?.importedSkills.map((skill) => skill.importedSkillId) ?? []),
    [githubImport.importResult],
  );
  const installableSkills = useMemo(() => centralSkills.filter((skill) => importedSkillIds.has(skill.id)), [centralSkills, importedSkillIds]);

  return (
    <div className="scc-page">
      <header className="scc-page-header"><div><span className="scc-eyebrow"><UploadCloud size={14} /> {text("IMPORT HUB", "导入中心")}</span><h1>{text("One front door for bringing skills in.", "所有技能导入，只走一个入口。")}</h1><p>{text("Import a GitHub repository with preview and conflict handling, scan projects, or browse registries without hunting through different pages.", "GitHub 仓库可先预览并处理冲突，也可以扫描项目或浏览注册源，不再到处找入口。")}</p></div></header>

      <section className="scc-import-grid">
        <button className="scc-import-card featured" onClick={() => setWizardOpen(true)}><span className="scc-import-icon"><Github size={24} /></span><strong>{text("GitHub repository", "GitHub 仓库")}</strong><p>{text("Preview SKILL.md files, resolve duplicates, import selected skills, then deploy immediately.", "预览 SKILL.md、解决重复冲突、选择性导入，并可立即部署。")}</p><em>{text("Recommended", "推荐")}</em></button>
        <button className="scc-import-card" onClick={() => navigate("/discover")}><span className="scc-import-icon"><FolderSearch size={24} /></span><strong>{text("Project scan", "项目扫描")}</strong><p>{text("Discover skills already living inside local projects and promote them into the central library.", "发现本地项目内已有的技能，并提升到中央技能库。")}</p></button>
        <button className="scc-import-card" onClick={() => navigate("/marketplace")}><span className="scc-import-icon"><PackageSearch size={24} /></span><strong>{text("Registries", "注册源")}</strong><p>{text("Browse existing registries and install curated skills from configured sources.", "浏览已有注册源，从配置好的来源安装技能。")}</p></button>
        <button className="scc-import-card" onClick={() => navigate("/central")}><span className="scc-import-icon"><Radar size={24} /></span><strong>{text("Library intake", "技能库入口")}</strong><p>{text("Review everything already in ~/.agents/skills/ before deciding where it should deploy.", "先检查 ~/.agents/skills/ 中已有内容，再决定部署目标。")}</p></button>
      </section>

      <GitHubRepoImportWizard
        open={wizardOpen}
        onOpenChange={setWizardOpen}
        repoUrl={repoUrl}
        onRepoUrlChange={setRepoUrl}
        preview={githubImport.preview}
        previewError={githubImport.error}
        isPreviewLoading={githubImport.isPreviewLoading}
        isImporting={githubImport.isImporting}
        importResult={githubImport.importResult}
        onPreview={() => previewGitHubRepoImport(repoUrl)}
        onImport={(selections) => importGitHubRepoSkills(repoUrl, selections)}
        onReset={resetGitHubImport}
        launcherLabel={text("Import Hub", "导入中心")}
        availableAgents={agents}
        installableSkills={installableSkills}
        onInstallImportedSkill={async (skillId, agentIds, method) => {
          await installSkill(skillId, agentIds, method);
          await refreshCounts();
        }}
        onAfterImportSuccess={async () => {
          await Promise.all([loadCentralSkills(), refreshCounts()]);
        }}
        onOpenCentral={() => navigate("/central")}
      />
    </div>
  );
}
