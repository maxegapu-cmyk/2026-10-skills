import { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { AlertTriangle, ArrowRight, CheckCircle2, RefreshCw, ShieldCheck } from "lucide-react";
import { useCentralSkillsStore } from "@/stores/centralSkillsStore";
import { usePlatformStore } from "@/stores/platformStore";
import { buildHealthReport, type HealthSeverity } from "@/control-center/health";
import { useControlLocale } from "@/control-center/useControlLocale";

export function ControlHealthView() {
  const navigate = useNavigate();
  const { text } = useControlLocale();
  const [severity, setSeverity] = useState<"all" | HealthSeverity>("all");
  const [refreshing, setRefreshing] = useState(false);
  const skills = useCentralSkillsStore((state) => state.skills);
  const loadCentralSkills = useCentralSkillsStore((state) => state.loadCentralSkills);
  const agents = usePlatformStore((state) => state.agents);
  const skillsByAgent = usePlatformStore((state) => state.skillsByAgent);
  const refreshCounts = usePlatformStore((state) => state.refreshCounts);

  const report = useMemo(() => buildHealthReport(skills, agents, skillsByAgent), [agents, skills, skillsByAgent]);
  const issues = severity === "all" ? report.issues : report.issues.filter((issue) => issue.severity === severity);

  const refresh = async () => {
    setRefreshing(true);
    try { await Promise.all([loadCentralSkills(), refreshCounts()]); } finally { setRefreshing(false); }
  };

  return (
    <div className="scc-page">
      <header className="scc-page-header">
        <div><span className="scc-eyebrow"><ShieldCheck size={14} /> {text("HEALTH CENTER", "健康中心")}</span><h1>{text("Find deployment problems before they become surprises.", "在异常变成事故前，把它们找出来。")}</h1><p>{text("Checks duplicate names, missing metadata, unknown platform references, undeployed skills and inactive platform links.", "检查重复技能、缺失元数据、失效平台引用、未部署技能和非活动平台关联。")}</p></div>
        <button className="scc-secondary-button" onClick={() => void refresh()} disabled={refreshing}><RefreshCw size={16} className={refreshing ? "is-spinning" : ""} /> {text("Run checks", "重新检查")}</button>
      </header>

      <section className="scc-health-summary-row">
        {(["high", "medium", "low"] as const).map((level) => (
          <button key={level} className={`scc-health-summary ${level} ${severity === level ? "is-selected" : ""}`} onClick={() => setSeverity(severity === level ? "all" : level)}>
            <strong>{report.summary[level]}</strong><span>{level === "high" ? text("High priority", "高优先级") : level === "medium" ? text("Medium", "中优先级") : text("Low", "低优先级")}</span>
          </button>
        ))}
        <button className={`scc-health-summary neutral ${severity === "all" ? "is-selected" : ""}`} onClick={() => setSeverity("all")}><strong>{report.issues.length}</strong><span>{text("All findings", "全部问题")}</span></button>
      </section>

      <section className="scc-panel">
        <div className="scc-panel-header"><div><span className="scc-eyebrow">{text("FINDINGS", "检查结果")}</span><h2>{severity === "all" ? text("All issues", "全部问题") : `${severity.toUpperCase()} · ${issues.length}`}</h2></div></div>
        {issues.length === 0 ? (
          <div className="scc-empty-state"><CheckCircle2 size={32} /><strong>{text("No findings in this filter", "这个筛选下没有问题")}</strong><p>{text("Your current skill graph looks clean here.", "当前技能关系在这一项上是干净的。")}</p></div>
        ) : (
          <div className="scc-finding-list">
            {issues.map((issue) => (
              <button key={issue.id} className="scc-finding-row" onClick={() => issue.skillId ? navigate(`/skill/${encodeURIComponent(issue.skillId)}`) : issue.agentId ? navigate(`/platform/${encodeURIComponent(issue.agentId)}`) : undefined}>
                <span className={`scc-severity-icon ${issue.severity}`}><AlertTriangle size={16} /></span>
                <span className="scc-finding-copy"><strong>{issue.title}</strong><small>{issue.detail}</small><em>{issue.code}</em></span>
                {(issue.skillId || issue.agentId) && <ArrowRight size={15} />}
              </button>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
