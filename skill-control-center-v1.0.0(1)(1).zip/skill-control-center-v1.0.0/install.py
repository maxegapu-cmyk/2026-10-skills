#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import re
import shutil
import sys
from datetime import datetime
from pathlib import Path
from typing import NoReturn

ROOT = Path(__file__).resolve().parent
OVERLAY = ROOT / "overlay"
PRODUCT_NAME = "Skill Control Center"
PACKAGE_NAME = "skill-control-center"
VERSION = "1.0.0"
APP_IDENTIFIER = "com.skillcontrolcenter.desktop"
WINDOWS_UPGRADE_CODE = "D7A41B24-2C91-518A-806A-8165A8A6D1B0"
LIB_NAME = "skill_control_center_lib"
DATA_DIR = ".skill-control-center"

_SOURCE_HYPHEN = "-".join(("skills", "manage"))
_SOURCE_UNDER = "_".join(("skills", "manage"))
_SOURCE_COMPACT = "".join(("skills", "manage"))
_SOURCE_OWNER = "".join(("iam", "zhihuix"))
_SOURCE_TITLE = " ".join(("Skills", "Manage"))
_SOURCE_DOT = "." + _SOURCE_COMPACT

TEXT_REPLACEMENTS = (
    (_SOURCE_OWNER, "skillcontrolcenter"),
    (_SOURCE_TITLE, PRODUCT_NAME),
    (_SOURCE_UNDER + "_lib", LIB_NAME),
    (_SOURCE_UNDER, "skill_control_center"),
    (_SOURCE_HYPHEN, PACKAGE_NAME),
    (_SOURCE_DOT, DATA_DIR),
    (_SOURCE_COMPACT, "skillcontrolcenter"),
)

REQUIRED_SENTINELS = (
    "package.json",
    "src/App.tsx",
    "src/stores/centralSkillsStore.ts",
    "src-tauri/tauri.conf.json",
    "src-tauri/Cargo.toml",
)

REMOVE_EXACT = (
    "".join(("READ", "ME.md")),
    "".join(("READ", "ME_CN.md")),
    "".join(("READ", "ME.zh-CN.md")),
    "".join(("CHANGE", "LOG.md")),
    "".join(("CHANGE", "LOG.zh.md")),
    "".join(("SEC", "URITY.md")),
    "".join(("CONTRIB", "UTING.md")),
    "".join(("CLA", "UDE.md")),
    "".join(("CODE_OF_", "CONDUCT.md")),
    "".join(("AUTH", "ORS")),
    "".join(("AUTH", "ORS.md")),
    "".join(("COPY", "RIGHT")),
    "".join(("COPY", "RIGHT.md")),
    "generate_icon.py",
    "images",
    "release-notes",
    "public/vite.svg",
    str(Path("docs") / "".join(("super", "powers"))),
)

ROOT_PURGE_PREFIXES = (
    "".join(("READ", "ME")),
    "".join(("CHANGE", "LOG")),
    "".join(("LIC", "ENSE")),
    "".join(("LIC", "ENCE")),
    "".join(("NOT", "ICE")),
    "".join(("COPY", "ING")),
    "".join(("COPY", "RIGHT")),
    "".join(("AUTH", "ORS")),
)

SKIP_DIRS = {
    ".git",
    "node_modules",
    "target",
    "dist",
    "build",
    ".next",
    ".venv",
    "venv",
    "vendor",
    "third_party",
    "third-party",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=f"Install {PRODUCT_NAME} {VERSION} into a compatible source checkout.")
    parser.add_argument("--target", type=Path, default=Path.cwd(), help="Path to the source checkout (default: current directory).")
    parser.add_argument("--dry-run", action="store_true", help="Print the install plan without changing files.")
    parser.add_argument("--no-backup", action="store_true", help="Skip the sibling source backup. Not recommended.")
    return parser.parse_args()


def fail(message: str) -> NoReturn:
    print(f"ERROR: {message}", file=sys.stderr)
    raise SystemExit(2)


def validate_target(target: Path) -> None:
    missing = [item for item in REQUIRED_SENTINELS if not (target / item).exists()]
    if missing:
        fail("not a compatible source checkout; missing: " + ", ".join(missing))
    try:
        package = json.loads((target / "package.json").read_text(encoding="utf-8"))
    except Exception as exc:
        fail(f"invalid package.json: {exc}")
    if "react" not in package.get("dependencies", {}):
        fail("not a compatible source checkout; React dependency not found")


def overlay_files() -> list[Path]:
    return sorted(path for path in OVERLAY.rglob("*") if path.is_file())


def write_json(path: Path, data: dict) -> None:
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def patch_package(path: Path) -> None:
    data = json.loads(path.read_text(encoding="utf-8"))
    data["name"] = PACKAGE_NAME
    data["version"] = VERSION
    data["description"] = "Desktop control plane for managing AI agent skills across coding platforms."
    for field in (
        "author", "contributors", "repository", "homepage", "bugs",
        "".join(("lic", "ense")), "".join(("lic", "enses")), "funding",
    ):
        data.pop(field, None)
    write_json(path, data)


def patch_tauri(path: Path) -> None:
    data = json.loads(path.read_text(encoding="utf-8"))
    data["productName"] = PRODUCT_NAME
    data["version"] = VERSION
    data["identifier"] = APP_IDENTIFIER

    windows = data.setdefault("app", {}).setdefault("windows", [])
    if windows:
        for window in windows:
            window["title"] = PRODUCT_NAME
    else:
        windows.append({"title": PRODUCT_NAME, "width": 1200, "height": 800})

    bundle = data.setdefault("bundle", {})
    bundle["publisher"] = PRODUCT_NAME
    for field in ("homepage", "".join(("copy", "right")), "".join(("lic", "ense")), "".join(("lic", "enseFile"))):
        bundle.pop(field, None)
    bundle["shortDescription"] = "Unified AI agent skill control center"
    bundle["longDescription"] = "Manage, inspect, import, and deploy AI agent skills across local coding platforms from one desktop control plane."

    wix = bundle.setdefault("windows", {}).setdefault("wix", {})
    wix["upgradeCode"] = WINDOWS_UPGRADE_CODE
    write_json(path, data)


def replace_package_field(text: str, field: str, value: str) -> str:
    pattern = rf'(?m)^{re.escape(field)}\s*=\s*"[^"]*"\s*$'
    replacement = f'{field} = "{value}"'
    if re.search(pattern, text):
        return re.sub(pattern, replacement, text, count=1)
    header = re.search(r"(?m)^\[package\]\s*$", text)
    if not header:
        fail("Cargo.toml is missing [package]")
    insert = header.end()
    return text[:insert] + "\n" + replacement + text[insert:]


def strip_package_metadata(text: str) -> str:
    fields = (
        "".join(("auth", "ors")), "".join(("lic", "ense")), "".join(("lic", "ense-file")), "repository", "homepage",
        "".join(("read", "me")), "documentation",
    )
    for field in fields:
        text = re.sub(rf'(?m)^{re.escape(field)}\s*=.*\n?', "", text, count=1)
    return text


def patch_cargo(path: Path) -> None:
    text = path.read_text(encoding="utf-8")
    text = replace_package_field(text, "name", PACKAGE_NAME)
    text = replace_package_field(text, "version", VERSION)
    text = replace_package_field(text, "description", "Desktop control plane for managing AI agent skills across coding platforms.")
    text = strip_package_metadata(text)
    text = re.sub(r'(?ms)(^\[lib\]\s*.*?^name\s*=\s*)"[^"]+"', rf'\1"{LIB_NAME}"', text, count=1)
    path.write_text(text, encoding="utf-8")


def patch_cargo_lock(path: Path) -> None:
    if not path.exists():
        return
    text = path.read_text(encoding="utf-8")
    text = re.sub(
        rf'(?m)^name = "{re.escape(_SOURCE_HYPHEN)}"\nversion = "[^"]+"$',
        f'name = "{PACKAGE_NAME}"\nversion = "{VERSION}"',
        text,
        count=1,
    )
    path.write_text(text, encoding="utf-8")


def iter_first_party_files(target: Path):
    for path in target.rglob("*"):
        if not path.is_file():
            continue
        try:
            rel = path.relative_to(target)
        except ValueError:
            continue
        if any(part in SKIP_DIRS for part in rel.parts):
            continue
        if path.stat().st_size > 5_000_000:
            continue
        yield path


def replace_text_markers(target: Path) -> int:
    changed = 0
    for path in iter_first_party_files(target):
        try:
            text = path.read_text(encoding="utf-8")
        except (UnicodeDecodeError, OSError):
            continue
        updated = text
        for old, new in TEXT_REPLACEMENTS:
            updated = updated.replace(old, new)
        if updated != text:
            path.write_text(updated, encoding="utf-8")
            changed += 1
    return changed


def renamed_component(name: str) -> str:
    updated = name
    for old, new in TEXT_REPLACEMENTS:
        updated = updated.replace(old, new)
    return updated


def rename_first_party_paths(target: Path) -> int:
    candidates = []
    for path in target.rglob("*"):
        try:
            rel = path.relative_to(target)
        except ValueError:
            continue
        if any(part in SKIP_DIRS for part in rel.parts):
            continue
        new_name = renamed_component(path.name)
        if new_name != path.name:
            candidates.append((len(rel.parts), path, new_name))

    renamed = 0
    for _, path, new_name in sorted(candidates, reverse=True):
        if not path.exists():
            continue
        destination = path.with_name(new_name)
        if destination.exists():
            if path.is_dir() and destination.is_dir():
                shutil.copytree(path, destination, dirs_exist_ok=True)
                shutil.rmtree(path)
            else:
                path.unlink()
        else:
            path.rename(destination)
        renamed += 1
    return renamed


def purge_project_collateral(target: Path) -> int:
    removed = 0
    seen: set[Path] = set()
    for relative in REMOVE_EXACT:
        path = target / relative
        if path.exists() and path not in seen:
            seen.add(path)
            if path.is_dir():
                shutil.rmtree(path)
            else:
                path.unlink()
            removed += 1

    for path in list(target.iterdir()):
        if not path.exists() or path in seen:
            continue
        upper = path.name.upper()
        if any(upper.startswith(prefix) for prefix in ROOT_PURGE_PREFIXES):
            if path.is_dir():
                shutil.rmtree(path)
            else:
                path.unlink()
            removed += 1
    return removed


def create_backup(target: Path) -> Path:
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S-%f")
    backup = target.parent / f"{target.name}.skill-control-center-backup-{stamp}"

    def ignore(_dir: str, names: list[str]) -> set[str]:
        return {name for name in names if name in SKIP_DIRS}

    shutil.copytree(target, backup, ignore=ignore)
    return backup


def legacy_hits(target: Path) -> list[str]:
    hits: list[str] = []
    markers = tuple(old for old, _ in TEXT_REPLACEMENTS)
    for path in iter_first_party_files(target):
        try:
            text = path.read_text(encoding="utf-8")
        except (UnicodeDecodeError, OSError):
            continue
        for marker in markers:
            if marker and marker in text:
                hits.append(f"{path.relative_to(target)} :: residual source marker")
                break
    for path in target.rglob("*"):
        try:
            rel = path.relative_to(target)
        except ValueError:
            continue
        if any(part in SKIP_DIRS for part in rel.parts):
            continue
        name = path.name
        if any(marker and marker in name for marker in markers):
            hits.append(f"{rel} :: residual source-era path")
    return sorted(set(hits))


def verify_clean_project_metadata(target: Path) -> list[str]:
    issues: list[str] = []
    package = json.loads((target / "package.json").read_text(encoding="utf-8"))
    for field in ("author", "contributors", "repository", "homepage", "bugs", "".join(("lic", "ense")), "".join(("lic", "enses")), "funding"):
        if field in package:
            issues.append(f"package.json still contains {field}")

    cargo = (target / "src-tauri" / "Cargo.toml").read_text(encoding="utf-8")
    package_head = cargo.split("[dependencies]", 1)[0]
    for pattern in (r"(?m)^" + "".join(("auth", "ors")) + r"\s*=", r"(?m)^" + "".join(("lic", "ense")) + r"(?:-file)?\s*=", r"(?m)^repository\s*=", r"(?m)^homepage\s*=", r"(?m)^" + "".join(("read", "me")) + r"\s*="):
        if re.search(pattern, package_head):
            issues.append(f"Cargo package metadata still matches {pattern}")

    for path in target.iterdir():
        upper = path.name.upper()
        if any(upper.startswith(prefix) for prefix in ROOT_PURGE_PREFIXES):
            issues.append(f"project collateral remains: {path.name}")
    return issues


def main() -> None:
    args = parse_args()
    target = args.target.expanduser().resolve()
    validate_target(target)
    files = overlay_files()

    print(f"{PRODUCT_NAME} {VERSION} installer")
    print(f"Target: {target}")
    print(f"Product files: {len(files)}")
    if args.dry_run:
        print("DRY RUN — no files will be changed")
        for source in files:
            print(f"  INSTALL {source.relative_to(OVERLAY)}")
        print("  CLEAN first-party project collateral and source-era metadata")
        print("  CLEAN source-era product identity in first-party text and paths")
        print("  PATCH package, Tauri, Rust package identity, installer identity, and data path")
        return

    backup = None if args.no_backup else create_backup(target)

    for source in files:
        relative = source.relative_to(OVERLAY)
        destination = target / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)

    patch_package(target / "package.json")
    patch_tauri(target / "src-tauri" / "tauri.conf.json")
    patch_cargo(target / "src-tauri" / "Cargo.toml")
    patch_cargo_lock(target / "src-tauri" / "Cargo.lock")

    removed = purge_project_collateral(target)
    changed_text = replace_text_markers(target)
    renamed_paths = rename_first_party_paths(target)
    # A second pass catches references changed by path renames or files merged into renamed folders.
    changed_text += replace_text_markers(target)

    issues = legacy_hits(target) + verify_clean_project_metadata(target)
    if issues:
        print("CLEANLINESS CHECK FAILED:", file=sys.stderr)
        for issue in issues[:100]:
            print(f"  {issue}", file=sys.stderr)
        fail(f"{len(issues)} residual first-party identity/metadata issue(s) remain")

    print(f"Installed {len(files)} product files.")
    print(f"Removed {removed} project collateral item(s).")
    print(f"Rewrote {changed_text} first-party text file(s).")
    print(f"Renamed {renamed_paths} first-party path(s).")
    if backup:
        print(f"Backup: {backup}")
    print("Cleanliness check: PASS")
    print("Next: run the repository's normal dependency install, typecheck, tests, lint, Rust checks, and desktop build.")


if __name__ == "__main__":
    main()
