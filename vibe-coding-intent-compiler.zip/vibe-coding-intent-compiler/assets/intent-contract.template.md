# Intent Contract

> 对简单任务可内部使用，不必把模板完整展示给用户。

## Outcome
最终用户可观察到的结果：

## Current State
当前事实/已有实现：

## Requested Delta
本次具体变化：

## Invariants / Preserve Set
不能破坏的东西：

## Non-goals
这次明确不做：

## Assumptions
可接受的默认值与仍未验证事实：

## Acceptance Criteria
- [ ] 
- [ ] 

## Verification Plan
- Criterion 1 → evidence:
- Criterion 2 → evidence:

## Execution Boundary
DESIGN_LOCKED / READY / BUILD / PATCH
