#!/usr/bin/env python3
from pathlib import Path
import re, sys, yaml

ROOT = Path(__file__).resolve().parents[1]
SKILL = ROOT / "SKILL.md"
REQUIRED = [
    ROOT / "references/interpretation.md",
    ROOT / "references/change-control.md",
    ROOT / "references/verification.md",
    ROOT / "references/evaluation.md",
    ROOT / "assets/intent-contract.template.md",
    ROOT / "evals/cases.yaml",
]

errors = []
text = SKILL.read_text(encoding="utf-8")
if not text.startswith("---\n"):
    errors.append("SKILL.md must start with YAML frontmatter")
else:
    try:
        _, fm, body = text.split("---", 2)
        meta = yaml.safe_load(fm)
    except Exception as e:
        errors.append(f"frontmatter parse failed: {e}")
        meta, body = {}, ""

    name = meta.get("name", "") if isinstance(meta, dict) else ""
    desc = meta.get("description", "") if isinstance(meta, dict) else ""
    if not re.fullmatch(r"[a-z0-9]+(?:-[a-z0-9]+)*", name):
        errors.append("name must be kebab-case")
    if name != ROOT.name:
        errors.append(f"name {name!r} must match folder {ROOT.name!r}")
    if len(name) > 64:
        errors.append("name exceeds 64 characters")
    if not desc or len(desc) > 1024:
        errors.append("description must be 1..1024 characters")

for p in REQUIRED:
    if not p.exists():
        errors.append(f"missing required file: {p.relative_to(ROOT)}")

# Internal links from SKILL.md must exist.
for rel in re.findall(r"`((?:references|assets|evals)/[^`]+)`", text):
    if not (ROOT / rel).exists():
        errors.append(f"broken referenced path: {rel}")

# Guardrails central to this skill.
required_phrases = [
    "DESIGN_LOCKED",
    "最窄充分改动",
    "Delta Patch Protocol",
    "Acceptance Criteria",
    "Verification Plan",
    "不抹掉用户工作",
]
for phrase in required_phrases:
    if phrase not in text:
        errors.append(f"missing core guardrail: {phrase}")

# Eval set sanity.
eval_path = ROOT / "evals/cases.yaml"
if eval_path.exists():
    try:
        data = yaml.safe_load(eval_path.read_text(encoding="utf-8"))
        cases = data.get("cases", [])
        if len(cases) < 10:
            errors.append("eval set should contain at least 10 representative cases")
        ids = [c.get("id") for c in cases]
        if len(ids) != len(set(ids)):
            errors.append("eval case ids must be unique")
    except Exception as e:
        errors.append(f"eval YAML parse failed: {e}")

if errors:
    print("FAIL")
    for e in errors:
        print("-", e)
    sys.exit(1)

print("PASS")
print(f"skill={ROOT.name}")
print(f"files={sum(1 for p in ROOT.rglob('*') if p.is_file())}")
print(f"skill_lines={len(text.splitlines())}")
