"""Offline acceptance and negative regression tests for the storyboard linter."""
import copy
import json
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from validate_board import validate  # noqa: E402


class StoryboardValidationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.valid = json.loads((ROOT / "examples" / "shotlist.json").read_text(encoding="utf-8"))

    def probe(self, modifier, needle=None):
        data = copy.deepcopy(self.valid)
        modifier(data)
        errors, warnings = validate(data)
        self.assertTrue(errors, f"expected errors, got warnings={warnings}")
        if needle:
            self.assertTrue(any(needle in e for e in errors), errors)

    def test_original_example_pass(self):
        errors, warnings = validate(self.valid)
        self.assertEqual([], errors)
        self.assertEqual([], warnings)

    def test_template_pass(self):
        template = json.loads((ROOT / "assets" / "shot-schema-example.json").read_text(encoding="utf-8"))
        self.assertEqual([], validate(template)[0])

    def test_wrong_total(self):
        self.probe(lambda x: x["meta"].update(duration_frames=600), "末镜结束帧")

    def test_gap(self):
        self.probe(lambda x: x["shots"][1].update(start_frame=100), "空洞")

    def test_overlap(self):
        self.probe(lambda x: x["shots"][1].update(start_frame=91), "重叠")

    def test_duplicate_id(self):
        self.probe(lambda x: x["shots"][1].update(id="S01"), "重复")

    def test_backwards_time(self):
        self.probe(lambda x: x["shots"][2].update(end_frame=1), "区间")

    def test_missing_camera_path(self):
        self.probe(lambda x: x["shots"][4]["camera"].update(path=""), "camera.path")

    def test_missing_video_prompt(self):
        self.probe(lambda x: x["shots"][2].update(video_prompt=""), "video_prompt")

    def test_unknown_direction(self):
        self.probe(lambda x: x["shots"][1].update(screen_direction="SIDEWAYS"), "screen_direction")

    def test_unbridged_reverse_axis(self):
        self.probe(lambda x: x["shots"][1].update(screen_direction="R2L"), "运动方向逆转")

    def test_cross_axis_without_bridge(self):
        self.probe(lambda x: x["shots"][1].update(axis_reset=True), "跨轴")

    def test_cross_axis_with_bridge(self):
        data = copy.deepcopy(self.valid)
        data["shots"][1].update(axis_reset=True, axis_reset_bridge="此镜中摄影机可见地跨越主角运动轴线")
        self.assertEqual([], validate(data)[0])

    def test_orbit_warning(self):
        data = copy.deepcopy(self.valid)
        data["shots"][4]["camera"]["move"] = "360 orbit"
        e, w = validate(data)
        self.assertEqual([], e)
        self.assertTrue(any("全周环绕" in msg for msg in w))

    def test_motion_without_trigger_warning(self):
        data = copy.deepcopy(self.valid)
        data["shots"][4]["camera"]["trigger"] = "无"
        e, w = validate(data)
        self.assertEqual([], e)
        self.assertTrue(any("触发" in msg for msg in w))

    def test_unhashable_id_does_not_crash(self):
        self.probe(lambda x: x["shots"][2].update(id=["bad"]), "id 为空")

    def test_invalid_shot_not_crash(self):
        self.probe(lambda x: x["shots"].__setitem__(2, None))

    def test_unhashable_screen_dir_does_not_crash(self):
        self.probe(lambda x: x["shots"][1].update(screen_direction={"oops": 1}), "screen_direction")

    def test_unhashable_handoff_type_does_not_crash(self):
        self.probe(lambda x: x["shots"][2]["handoff"].update(type=["oops"]), "handoff")

    def test_missing_meta(self):
        self.probe(lambda x: x.pop("meta"), "meta")

    def test_shots_empty(self):
        self.probe(lambda x: x.update(shots=[]), "shots")


if __name__ == "__main__":
    unittest.main()
