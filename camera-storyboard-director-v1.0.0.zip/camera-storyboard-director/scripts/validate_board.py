#!/usr/bin/env python3
"""Offline storyboard continuity and timeline linter. Python stdlib only.

Usage: python scripts/validate_board.py examples/shotlist.json
Exit code 0 if no errors; 1 on errors; 2 on invalid input/IO.
Warnings do not fail; no aesthetics or video generation checks are claimed.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

ALLOWED_DIRECTIONS = {"L2R", "R2L", "STATIC", "DEPTH", "NA"}
ALLOWED_HANDOFFS = {"cut", "cut-on-action", "match-cut", "continuous", "sound-bridge", "hold"}
ALLOWED_SHOT_SIZES = {"ECU", "CU", "MCU", "MS", "MLS", "WS", "EWS", "OTS", "POV", "INSERT"}
LOCKED = {"locked", "static", "none"}


def _text(value: object) -> bool:
    return isinstance(value, str) and bool(value.strip())


def validate(board: object) -> tuple[list[str], list[str]]:
    errors, warnings = [], []
    if not isinstance(board, dict):
        return ["顶层必须是 JSON 对象"], warnings
    meta = board.get("meta")
    shots = board.get("shots")
    if not isinstance(meta, dict):
        return ["缺少 meta 对象"], warnings
    if not isinstance(shots, list) or not shots:
        return ["shots 必须为非空数组"], warnings

    fps, total = meta.get("fps"), meta.get("duration_frames")
    if type(fps) is not int or not 1 <= fps <= 240:
        errors.append("meta.fps 必须为 1..240 的整数")
    if type(total) is not int or total <= 0:
        errors.append("meta.duration_frames 必须为正整数")
    for f in ("title", "aspect_ratio", "model"):
        if not _text(meta.get(f)):
            errors.append(f"meta.{f} 缺少非空文字")

    previous = None
    ids = set()
    for i, shot in enumerate(shots):
        tag = f"shot[{i}]"
        if not isinstance(shot, dict):
            errors.append(f"{tag} 必须为对象")
            continue
        sid = shot.get("id")
        if not _text(sid):
            errors.append(f"{tag}.id 为空")
        elif sid in ids:
            errors.append(f"{tag}.id 重复：{sid}")
        if _text(sid):
            ids.add(sid)
        tag = f"{tag}({sid or '?'})"
        start, end = shot.get("start_frame"), shot.get("end_frame")
        if type(start) is not int or type(end) is not int or not (0 <= start < end):
            errors.append(f"{tag} 需要有效的整数区间 [start_frame, end_frame)")
        if i == 0 and start != 0:
            errors.append(f"{tag} 时间线未从 0 帧起始")
        if isinstance(previous, dict) and isinstance(start, int) and isinstance(previous.get("end_frame"), int):
            if start != previous["end_frame"]:
                errors.append(f"{tag} 与上一镜间存在时间重叠或空洞")
        for key in ("story_beat", "viewer_gain", "actor_path", "start_state", "end_state", "video_prompt", "first_frame_prompt", "fallback"):
            if not _text(shot.get(key)):
                errors.append(f"{tag}.{key} 缺少非空文字")
        if not isinstance(shot.get("shot_size"), str) or shot.get("shot_size") not in ALLOWED_SHOT_SIZES:
            errors.append(f"{tag}.shot_size 不在允许的景别枚举")
        direction = shot.get("screen_direction")
        if not isinstance(direction, str) or direction not in ALLOWED_DIRECTIONS:
            errors.append(f"{tag}.screen_direction 无效")
        axis = shot.get("axis_id")
        if not _text(axis):
            errors.append(f"{tag}.axis_id 为空")
        if type(shot.get("axis_reset")) is not bool:
            errors.append(f"{tag}.axis_reset 必须为 boolean")

        camera = shot.get("camera")
        if not isinstance(camera, dict):
            errors.append(f"{tag}.camera 必须为对象")
        else:
            for key in ("move", "origin", "path", "destination", "trigger", "speed", "purpose", "depth_layers"):
                if not _text(camera.get(key)):
                    errors.append(f"{tag}.camera.{key} 缺少非空文字")
            move = str(camera.get("move", "")).lower().strip()
            if move not in LOCKED:
                if str(camera.get("trigger", "")).strip().lower() in ("none", "无", "n/a", "无明确触发"):
                    warnings.append(f"{tag} 动态镜头缺可观察触发点，可能沦为装饰运动")
                if str(camera.get("purpose", "")).strip().lower() in ("none", "无", "n/a"):
                    errors.append(f"{tag} 运镜叙事收益没有说明")
                if any(marker in move for marker in ("360", "三百六十", "spin")):
                    warnings.append(f"{tag} 全周环绕身份/空间漂移风险高，建议局部替代")
        handoff = shot.get("handoff")
        if not isinstance(handoff, dict) or not isinstance(handoff.get("type"), str) or handoff.get("type") not in ALLOWED_HANDOFFS or not _text(handoff.get("to_next")):
            errors.append(f"{tag}.handoff 需要 type + to_next")

        if previous is not None and isinstance(previous, dict):
            prev_dir, prev_axis = previous.get("screen_direction"), previous.get("axis_id")
            if (direction in ("L2R", "R2L") and prev_dir in ("L2R", "R2L")
                    and direction != prev_dir and axis == prev_axis and shot.get("axis_reset") is False):
                errors.append(f"{tag} 同轴线运动方向逆转，但未声明跨轴桥接")
            if shot.get("axis_reset") and not _text(shot.get("axis_reset_bridge")):
                errors.append(f"{tag} 跨轴时必须解释桥接镜头/连续跨轴轨迹")
            # A continuous take requires a state anchor the director can inspect.
            if isinstance(previous.get("handoff"), dict) and previous["handoff"].get("type") == "continuous":
                if not _text(previous.get("end_state")) or not _text(shot.get("start_state")):
                    errors.append(f"{tag} 伪一镜到底：缺前镜终态/本镜初态")
        previous = shot

    if shots and isinstance(shots[-1], dict) and type(total) is int:
        if shots[-1].get("end_frame") != total:
            errors.append(f"末镜结束帧 {shots[-1].get('end_frame')} != 总片长 {total}")
    if type(total) is int and type(fps) is int and fps:
        if total > fps * 180:
            warnings.append("总时长超过 180 秒：建议分场景输出，避免长上下文稀释连续性")
    return errors, warnings


def main(args: list[str]) -> int:
    if len(args) != 1:
        print("用法: python scripts/validate_board.py <storyboard.json>", file=sys.stderr)
        return 2
    try:
        board = json.loads(Path(args[0]).read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        print(f"ERROR 输入不可读：{exc}", file=sys.stderr)
        return 2
    errors, warnings = validate(board)
    for w in warnings:
        print("WARN:", w)
    for e in errors:
        print("ERROR:", e)
    print(f"结果: {len(errors)} error(s), {len(warnings)} warning(s)")
    if not errors:
        print("PASS: 结构/时间线/部分轴线规则通过；不代表已通过实拍或审美测试。")
    return 1 if errors else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
