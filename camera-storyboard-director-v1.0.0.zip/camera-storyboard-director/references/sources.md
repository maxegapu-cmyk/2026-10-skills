# 调研入口与独立设计声明（2026-10-16）

本 Skill 内容、流程、术语组织和示例均为独立撰写，未复制第三方 Skill 文本、代码或保密资料。以下项目仅用于了解公开领域现有实践和边界；请自行核对第三方协议、接口更新。

- Agent Skills 官方规范： https://agentskills.io/specification
- 剧本转分镜方向示例： https://github.com/Git-Nicolai/script-to-storyboard
- 影视导演方向示例： https://github.com/cajias/agentic-video-skills
- 参考/场次连续性方向示例： https://github.com/toyme/storyboard-skill
- AI 影视摄影提示词方向： https://github.com/fal-ai-community/skills/tree/main/skills/cinematography
- 时序/动作链方向： https://github.com/scenario-labs/skills/tree/main/skills/scenario-seedance-storyboard
- Seedance 2.0 官方发布： https://seed.bytedance.com/en/blog/seedance-2-0-official-launch
- Seedance 2.0 官方提示词： https://docs.volcengine.com/docs/ark/seedance-2-0-prompt-guide?lang=zh
- Seedance 2.5 官方提示词： https://docs.volcengine.com/docs/ark/seedance-2-5-prompt-guide?lang=zh
- Seedance 2.5 官方能力/限制： https://docs.volcengine.com/docs/ark/seedance-2-5?lang=zh
- Google Veo 3.1 官方指南： https://cloud.google.com/blog/products/ai-machine-learning/ultimate-prompting-guide-for-veo-3-1
- Google 首尾帧说明： https://docs.cloud.google.com/vertex-ai/generative-ai/docs/video/generate-videos-from-first-and-last-frames
- Runway Gen-4 官方指南： https://help.runwayml.com/hc/en-us/articles/39789879462419-Gen-4-Video-Prompting-Guide

关键判断：公开工具常能输出镜头类型/描述，但从剧本→“观众信息差”→空间调度→有理由的相机位移→衔接→可观测验收这条链才是本 Skill 针对普通分镜平庸问题的重点。优秀程度仍须依具体剧本、素材、模型输出和导演评价实测。
