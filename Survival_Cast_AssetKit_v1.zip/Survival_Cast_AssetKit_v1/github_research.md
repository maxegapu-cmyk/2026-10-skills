# GitHub 开源资料取舍（2026-10-17 检索）

以下仓库只用作研究参考，**本包没有复制它们的代码、提示词模板或训练数据**。

1. **SFHQ-T2I dataset**：https://github.com/SelfishGene/SFHQ-T2I-dataset
   - 仓库说明包含 122,726 张合成脸以及配套提示词，还公开 `face_prompt_utils.py` 进行多维随机脸部属性采样。
   - 有用的是**差异化维度**：年龄、脸部构造、配饰、表情、发型、环境变量；应独立采样而不是“给所有人套一个帅哥脸”。
   - 注意：原作者称其合成数据减少肖像权风险，但这不代表所有模型、权重、输出都能无条件用于商业项目，应按来源授权核实。
2. **CharacterCraft**：https://github.com/kappter/CharacterCraft
   - 人物档案通过 Physical、Psychological、Background、Motivations 等维度分开，支持人物比较。
   - 可借鉴**身份、外貌、行动动机分离**：人物能否成为好角色，不能由颜值决定。
3. **NPC Generator**：https://github.com/FyefoxxM/npc-generator
   - 文档介绍人格、职业、秘密、情节钩子和特质互斥检查。
   - 有用的是**角色内在冲突**和职业来源，并非直接照搬 D&D 世界观、族群分类或概率配比。
4. **ComfyUI Character Prompt Builder**：https://github.com/euan-gwd/comfyui-character-prompt-builder
   - 开放脸型、眼、发型、皮肤细节等模块化控制字段。
   - 有用的是面部特征参数化；本包把可重复的固定身份特征独立为锚点，而不是每回重新随机。
5. **PuLID (official)**：https://github.com/ToTheBeginning/PuLID
   - 官方角色身份条件生成方案，项目 README 包含 SDXL 和 FLUX 分支；是生成不同角度同脸时可进一步考虑的工具。
   - 注意不同分支、底模、显存环境兼容性不同；并不是“贴一个参考脸就100%一样”。
6. **PhotoMaker (official)**：https://github.com/TencentARC/PhotoMaker
   - 官方基于 ID embedding 的个人化生成方案，README 提到 PhotoMaker V2。
   - 与 PuLID 类似，提供身份参考路线，但需单独查选用底模、节点与权重许可；本包不自带模型。
7. **Character Photoset & Video Workflow Generator**：https://github.com/SciensOne/comfyui-workflow-generator
   - 以角色、动作、位置配置和身份参考生成工作流，内容面向 ComfyUI 批处理。
   - 可借鉴**先用一份角色数据生成多种镜头**，避免重复手写 18×4 个相互漂移的提示词。

本包的设计取舍：借鉴公开项目的“维度覆盖、数据一致性、身份参考”方向，独立编写面向真实电影群像的原创字段、原创演员库和原创脚本。没有下载或混入任何 GitHub 模型、演员图片或私人系统。
