#!/usr/bin/env python3
"""Compile original survival-thriller character data into per-image prompts.
Pure standard library; no model/API invocation.
"""
import argparse
import json
from pathlib import Path

BASE = Path(__file__).resolve().parent
SHOT = {
    'portrait': ('Straight-out-of-camera casting portrait photograph, chest-up, front-facing camera at subject eye level.',
                 'Framing includes full head, neck and shoulders; face fully visible. A composed, unperformed moment.'),
    'threequarter': ('Natural unretouched casting portrait, chest-up at a three-quarter angle, camera at subject eye level.',
                     'Subject turns about 35 degrees to their left, showing both eyes and the contour of the nose and jaw. Do not modify bone structure.'),
    'profile': ('Unretouched casting identity reference photo of the same person in a clean left side profile.',
                'Exactly a 90-degree head turn to subject left, not three-quarter; visible ear, forehead, nasal bridge and chin silhouette. One head only.'),
    'fullbody': ('Unretouched full-length casting photograph of the exact same adult, standing in a neutral relaxed stance.',
                 'Include shoes, both hands and complete body with anatomically plausible scale. Head occupies a small but recognizable part of frame.'),
    'expression': ('Natural unretouched chest-up film continuity still of the exact same adult.',
                   'Capture a fleeting psychologically plausible emotion with coordinated eyes, brows and mouth, not a theatrical pose.'),
}
EMOTIONS = {
  'guarded':'guarded; the mouth almost replies, shoulders slightly tightened',
  'fear':'restrained fear; rapid breath just stopped, lower eyelids tense, lips only slightly parted',
  'relief':'brief relief; a slight release in the mouth and brow, not a broad smile',
  'anger':'contained anger; compressed lips, barely narrowed eyes, no exaggerated snarl',
  'exhaustion':'quiet exhaustion; heavier eyelids and lower posture, no artificial sweat coat',
}

def compose(roster, c, shot, wardrobe, emotion):
  f,b=c['face'],c['body']
  core = [
   SHOT[shot][0],
   f"One original fictional {c['age']}-year-old {c['gender']}, {c['heritage']}, named {c['name']} in production metadata only; no text appears on the image.",
   f"Face identity: {f['face_shape']}; {f['eyes']}; {f['nose']}; {f['mouth']}; {f['jaw']}.",
   f"Skin: {f['skin_tone']}; {', '.join(f['skin_reality'])}. Organic localized texture without uniform digital noise.",
   f"Persistent facial identity: {f['asymmetry']}; {f['hair']}. Do not remodel these in different views.",
   f"Body: about {b['height_cm']} cm tall; {b['build']}; {b['posture']}; {b['hands']}.",
   f"Everyday grooming: {c['grooming']}. Personal unposed micro-gesture: {c['micro_behavior']}.",
  ]
  if wardrobe=='civilian':
    core.append(f"Wardrobe: {c['civilian_clothes']}. Natural drape, seam tension and wear consistent with the material.")
  else:
    u=roster['uniform']
    core.append(f"Wardrobe is the SAME across all participants: {u['design']}; {u['fabric']}; {u['color']}; {u['identifier']}; {u['footwear']}. Realistic fabric pressure and wrinkles. No invented emblems or large numerals.")
  core += [SHOT[shot][1]]
  if shot=='expression':
    core.append('The emotion is ' + EMOTIONS[emotion] + '. No change in hairstyle, face, outfit, age, makeup, or wardrobe continuity.')
  else:
    core.append('Expression neutral to lightly watchful; no performed menace, glossy fashion posing, or forced smile.')
  core += [
    roster['look_bible']['camera_reference'],roster['look_bible']['lighting'],roster['look_bible']['background'],
    roster['look_bible']['skin_policy'],
    'Normal human anatomy, non-identical left/right eyelids, plausible teeth, actual flyaway hairs, honest neck-and-hand age, no floating accessories.',
    'Never depict an actor or a recognizable character from an existing TV series. No logos, no captions, no graphic frames, no watermark.',
    'NEGATIVE: CGI, illustration, anime, glamour lighting, porcelain waxy skin, beauty filter, hyper-sharp pores, overcorrected facial symmetry, plastic hair, mannequin, face-swap artifacts, synthetic bokeh, beauty-commercial portrait.'
  ]
  return ' '.join(core)

def main():
  p=argparse.ArgumentParser(description='Write consistent character image prompts from cast_18.json')
  p.add_argument('--cast', default=str(BASE/'cast_18.json'))
  p.add_argument('--id', default='all', help='C001 etc or all')
  p.add_argument('--shot',choices=[*SHOT,'all'],default='all')
  p.add_argument('--wardrobe',choices=['civilian','uniform'],default='uniform')
  p.add_argument('--emotion',choices=list(EMOTIONS),default='guarded')
  p.add_argument('--out', default=str(BASE/'generated_prompts'))
  args=p.parse_args()
  r=json.loads(Path(args.cast).read_text(encoding='utf-8'))
  people=[c for c in r['characters'] if args.id=='all' or c['id']==args.id]
  if not people:
    p.error(f'Character ID not found: {args.id}')
  out=Path(args.out);out.mkdir(parents=True,exist_ok=True)
  shots=[s for s in SHOT if s!='expression'] if args.shot=='all' else [args.shot]
  for c in people:
    for shot in shots:
      suffix=f'_{args.emotion}' if shot=='expression' else ''
      dest=out/f"{c['id']}_{shot}_{args.wardrobe}{suffix}.txt"
      dest.write_text(compose(r,c,shot,args.wardrobe,args.emotion)+'\n',encoding='utf-8')
  print(f'{len(people)*len(shots)} prompts written to {out}')

if __name__=='__main__':main()
