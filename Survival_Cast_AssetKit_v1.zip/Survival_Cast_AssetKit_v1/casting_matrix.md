# 18 人角色阵容速览

下面的人物是**虚构成年演员资产设定**，不是对参考图片里的真人身份或性格作判断。

| ID | 角色 | 性别 / 年龄 | 外形类型 | 观众第一感觉 | 3个固定脸/发型锚点 | 戏剧反差 |
|---|---|---|---|---|---|---|
| C001 | 余岚（硬碰硬的守护者） | 女 / 35 | 粗粝型 | 说话短促、看起来不好接近 | broad blunt jaw；high left eyebrow；short untidy braided ponytail | 最能打却会在孩子哭时手足无措 |
| C002 | 陆振河（沉默的重锤） | 男 / 48 | 粗粝型 | 不爱解释、喜欢动手修东西 | crooked old nose bridge；slightly drooped right eyelid；thick neck and shaved grey stubble | 身形吓人但会把食物偷偷留给弱者 |
| C003 | 林初禾（温柔外表的赌徒） | 女 / 24 | 出众型 | 礼貌笑容、说话轻声 | right-heavy smile；one freckle near left cheekbone；one ear usually tucked behind dark chestnut hair | 精致的外表下有非常强的风险偏好 |
| C004 | 彭伟民（不起眼的旁观者） | 男 / 40 | 普通生活型 | 人群里没人会记住的普通男人 | modest hairline recession；wide fleshy nose；soft chin and slightly fuller left cheek | 软弱只是表象；关键时刻会挡在最前面 |
| C005 | 韩知远（善于计算的鹰） | 女 / 32 | 出众型 | 说话慢、观察精准 | chin-length blunt black bob；slightly bent long nose；left eye more open than right | 擅长布局却不擅长处理感情 |
| C006 | 池成宇（反应很快的野犬） | 男 / 25 | 非典型外貌 | 总像随时准备逃跑 | wide-set eyes；overgrown shaggy black fringe；small overlapped canine tooth | 嘴上爱耍狠，真正的暴力令他发抖 |
| C007 | 赵桂梅（被轻视的母亲） | 女 / 58 | 普通生活型 | 嗓门大、手脚利索 | wide mouth and rotated front tooth；low grey-dark bun；sun spots near cheekbones | 被当成后勤时能看见所有人的漏洞 |
| C008 | 高牧（衣冠楚楚的风险客） | 男 / 43 | 粗粝型 | 总显得很有礼貌 | imperfect side part and thinning crown；deep right smile crease；prominent chin crease | 外表规整，内心恐慌到失眠 |
| C009 | 许青禾（狡黠但不冷血的狐狸） | 女 / 22 | 非典型外貌 | 言语轻佻、总先笑 | smoky copper hair with dark roots；arched left eyebrow；wide slightly uneven smile | 看似最擅欺骗，却最守一条古怪诺言 |
| C010 | 陶世安（谨慎的老教师） | 男 / 64 | 普通生活型 | 温和得近乎没有攻击性 | salt-and-pepper hair combed back；right lower-lid droop；pointed chin with loose jawline | 最遵守规定的人最早识破游戏规则的漏洞 |
| C011 | 周奕衡（耀眼的软弱者） | 男 / 29 | 出众型 | 看起来可靠而乐观 | cowlick at crown；left nostril narrower；wide face with slightly recessed left jaw | 高大健美却不敢做残酷决定 |
| C012 | 魏素敏（疲倦的救助者） | 女 / 46 | 普通生活型 | 耐心、做事麻利 | tiny right-cheek dimple；loose low ponytail；under-eye shadows and hooded eyes | 照顾陌生人很自然，却不敢接家人的电话 |
| C013 | 夏若妍（形象完整的破碎者） | 女 / 36 | 出众型 | 精明得体、始终礼貌 | right mouth corner lower at rest；long dark loose waves；tiny pigmentation near chin | 最擅长维护形象却最先崩溃 |
| C014 | 郑道勋（怕死的快腿） | 男 / 24 | 普通生活型 | 幽默又话多 | slightly close-set eyes；right ear more prominent；uneven cropped hair with grown side patch | 总说要跑的人偏偏留下来救人 |
| C015 | 范国梁（被误认的恶人） | 男 / 54 | 非典型外貌 | 寡言、表情常显凶 | small left eye under heavy lid；old flattened nose；uneven grey temple patch | 看着最凶的人甚至从没打过架 |
| C016 | 邵秋（精确的孤狼） | 女 / 30 | 粗粝型 | 冷静、很少废话 | sparse left brow tail；longer hair on right side；angular cheekbones with tiny nose bump | 习惯独行却特别记得每个同伴的生日 |
| C017 | 杜向真（不被看好的工匠） | 女 / 44 | 普通生活型 | 说话粗但从不拖延 | broad pear-shaped face；tiny healed chin cut；short crop greying at sideburns | 擅修机械，却不知道如何安慰哭泣的人 |
| C018 | 莫其宁（表面无害的记忆者） | 男 / 28 | 普通生活型 | 客气少话、略显笨拙 | extra fold on left upper lid；flyaway at right temple；long pear-oval soft face | 记忆力好却总假装没听见秘密 |

## 群像比率（示例，不是硬标准）

- 普通生活型：7人；出众型：4人；粗粝型：4人；非典型外貌：3人。男女各9人，年龄22–64岁。
- 视觉身份不等于人物好坏。相貌、阶层、人格、能力必须能交叉组合，否则只是套模板。
- 选角只挑**结构差异够大**的人；相似的脸再添一个痣并不能解决撞脸。
