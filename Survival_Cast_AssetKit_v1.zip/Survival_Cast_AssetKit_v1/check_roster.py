#!/usr/bin/env python3
"""Schema validation plus simple ensemble guardrails. `pip install jsonschema` once."""
import json
from pathlib import Path
from collections import Counter
from jsonschema import Draft202012Validator

ROOT=Path(__file__).resolve().parent
r=json.loads((ROOT/'cast_18.json').read_text(encoding='utf-8'))
s=json.loads((ROOT/'roster.schema.json').read_text(encoding='utf-8'))
errs=list(Draft202012Validator(s).iter_errors(r))
if errs:
 for e in errs: print('SCHEMA FAIL:', '/'.join(map(str,e.absolute_path)),e.message)
 raise SystemExit(1)
people=r['characters']
ids=[p['id'] for p in people]
names=[p['name'] for p in people]
anchor_sets=[tuple(x.lower().strip() for x in p['identity_anchors']) for p in people]
for desc,l in [('IDs',ids),('names',names),('anchor sets',anchor_sets)]:
 if len(set(l))!=len(l): raise SystemExit(f'FAIL: duplicate {desc}')
lanes=Counter(p['casting_lane'] for p in people)
genders=Counter(p['gender'] for p in people)
if lanes['everyday']<len(people)*0.3: raise SystemExit('FAIL: everyday people too rare')
if len(lanes)<3: raise SystemExit('FAIL: cast diversity collapsed')
if min(p['age'] for p in people)<18: raise SystemExit('FAIL: cast must be adults')
print('PASS schema, unique IDs, names & anchor sets, adult ages, ensemble diversity')
print('Characters:',len(people),'Casting:',dict(lanes),'Gender:',dict(genders),
      'Age:',min(p['age'] for p in people),'-',max(p['age'] for p in people))
print('NOTE: This validates metadata, NOT true photorealism, face-lock success, or actual image quality.')
