# 项目持续写作/交接/恢复规范

## 状态唯一指针与文件职责

```
project/
  project_state.json     # 唯一阶段、当前集数、已锁定决策、目标、下一动作
  audience_brief.md      # 观众、类型和制作条件
  story_bible.md         # 作者确认的人物与世界故事圣经
  outline.md             # 15集大纲及各集状态
  continuity.json        # 有ID的关键事实/知情范围/道具/承诺和时间线
  episodes/EP01.md       # 单集剧本（不可跳号覆盖）
  HANDOFF.md             # 下次/换模型恢复入口
```

`project_state.json`保存里程碑、SHA-256、上游依赖快照与用户明确批准过的特定版本。**旧版approved布尔值只用于迁移参考，绝不判定当前版本已批准**。`checkpoint`只是文件完成/结构可过，不代表编审；`approve --user-confirmed`必须是真实已获用户确认，不能由AI代替授权。

## 更新顺序

1. 写完新稿时先落盘到目标文件，校验文件内容存在。
2. 检查前一集→新一集：主角目标、人物关系、伤病、场景道具、证物来源、秘密知情范围、日夜时序。
3. 更新 `continuity.json` 里对应事实 ID、首次建立场号、真假/误认、知情范围与后续改变；用 `impact --fact-id` 追踪可能受影响的场次。
4. 写 `HANDOFF.md` ：最近成果/关键更改/风险/下一动作。
5. 调 `checkpoint` 原子更新 `project_state.json` 的SHA-256、依赖快照和历史（文档不被改写）；只有用户明确批准后调 `approve`。`status`一眼区分当前版批准/待审/上游需要复核。

## 恢复口令

“继续第N集”：先读状态指针，读 `story_bible.md`、`outline.md`、`continuity.json`，再读上集文件。若未锁定方向，先补流程而不是造“已确认”故事。

“另一个模型接手”：以项目文件为准，不能靠猜测往事；交接首屏先写**不可更动的设定、最新状态、未决问题、下一动作**。模型若无法访问磁盘，用户需要提供文件/压缩包或粘贴HANDOFF。

## 最小可续写状态包（无写盘权限时）

```
PROJECT_STATE
阶段：大纲已批准；已完成到EP04；下一步：EP05
锁定：主角____；目标____；对手____；剧情终局____
未决：第3集的证据仍在____手上
待复核：素材授权、实际单集时长
HANDOFF
前情不可更动：____
第4集末状态：____
第5集必须兑现：____
```

不要说“已保存到本地”除非确实执行了写入并检查。`scripts/project_cli.py`提供结构初始化、静态验证与安全检查点；它不具备自动提炼剧情事实的能力。

## 变更传播与恢复

示例命令：`python scripts/project_cli.py impact --project ./my-drama --changed bible`（列出已存在的后续成果；**不改写**）；`python scripts/project_cli.py impact --project ./my-drama --fact-id PROP47`（列出手工登记的相关场号）。`python scripts/project_cli.py status --project ./my-drama` 查看 `checkpoint_current`、`stale_dependencies` 和 `current_version_approved`。对正文的无声手改会使旧哈希失效；上游稿改动则让依赖它的稿件需要复核。

**旧项目迁移**：先复制整个工作区并留备份。`continuity.json`加 `facts: []` 和 `schema_version: 1.1`；旧稿的布尔 approved/approved_episodes 不自动升级。逐稿复查实际文件，跑检查与checkpoint，只有用户再次明确确认时才登记新版批准。凡完成但未确认的内容显示为 `content_pending_review`。

**局限**：SHA-256只感知文件字节变化，不理解语义；上游在下游首次checkpoint之前的改变没有可比较的历史快照；`review_if_changed`由作者维护，可能漏掉潜在依赖；JSON结构有效不意味着账本与实际剧情匹配。须另读正文检查。
