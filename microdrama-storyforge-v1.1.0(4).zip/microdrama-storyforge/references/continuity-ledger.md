# 连续性账本 v1.1 — 用事实 ID 找回因果，而不是凭记忆续写

`continuity.json` 沿用旧版人物、道具、秘密、伏笔等栏目，新增轻量 `facts[]`。无需数据库。每个关键事实只记**一条有ID的断言**；同一断言改变时更新该条 `changed_by`，必要时新建派生 ID。工具验证字段合法性，不会自动阅读剧本来证明事实真伪。

```json
{
  "id": "PROP47",
  "kind": "prop",
  "statement": "47号洗衣单的顾客联右角被撕掉，店内存根仍完整",
  "epistemic_status": "objective",
  "established": {"episode": 1, "scene": 2},
  "knowledge": {
    "as_of": {"episode": 2, "scene": 2},
    "knows": ["叶禾", "梁姨"],
    "does_not_know": ["罗梅"]
  },
  "changed_by": [
    {"at": {"episode": 2, "scene": 2}, "change": "叶禾从票夹中取出完整存根，梁姨当场确认右角形状",
     "knowledge_after": {"knows": ["叶禾", "梁姨"], "does_not_know": ["罗梅"]}}
  ],
  "review_if_changed": ["EP01:1-2", "EP02:2-2", "大纲EP03", "伏笔:洗衣单编号"]
}
```

- `kind`: character/prop/secret/promise/world/event/relationship；人物状态、证物去向、秘密和未兑现承诺至少应覆盖。
- `epistemic_status`: `objective`=叙事世界中可证实，`belief`=人物暂时判断，`mistaken`=剧本明确的误认。误认**不能**在回忆里被写成旁白认证的事实。
- `established`: 断言首次在剧本中被建立的位置（集/场）；不用“第3集左右”。
- `knowledge.knows` 表示当前场次之前**已知晓这条说法**；若该事实是belief或mistaken，则仅代表知道/相信这一说法，不代表客观为真。`as_of`指本行知情范围的截止场。`does_not_know`只列对剧情关键、已确认不知道的人，不必填全剧所有人。
- `changed_by`: 事实状态、公开程度或人物认识发生变化时，把事件/场号/实际变化记上；涉及知情范围变化附 `knowledge_after`。随后更新最外层 `knowledge` 到最新场。
- `review_if_changed`: 手工记录依赖此事实的场号/大纲/承诺，供 `impact --fact-id` 检索；不是自动静态依赖分析，记录可能漏项。

先记“剧本看得见的证据”，再记录人物自己推断的因果；隐瞒者不能无故知道他未目睹的谈话。更新顺序：正文 → 核对与前文冲突 → 更新facts/人物道具 → checkpoint（记录对应文件哈希及上游快照） → 如用户明确批准才approve。

旧项目 `continuity.json` 缺 `facts` 时，先**备份**，再加 `"facts": []` 并把 schema_version 调为 `1.1`；`project_state.json` 旧布尔批准仍保留作历史提示，但必须经现版checkpoint+用户approve才能绑定哈希。CLI不隐式修改旧项目。

**实际验证：**参看 `examples/laundry-47/continuity.json`。可用 `python scripts/project_cli.py validate --project examples/laundry-47 --mode continuity` 查结构；`impact --project examples/laundry-47 --fact-id PROP47` 查其对后续场次的波及。换会话时需要同时提供这些文件和两集正文，接手人按 ID 回到证据场。
