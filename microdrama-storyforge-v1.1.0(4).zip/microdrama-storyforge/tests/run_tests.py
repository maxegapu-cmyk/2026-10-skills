#!/usr/bin/env python3
"""Dependency-free regression suite. Run from any working directory."""
from pathlib import Path
import ast
import hashlib
import shutil
import json
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / 'scripts'))
from project_cli import (init_project, checkpoint, approve, check_project, check_outline,
                         check_episode, check_continuity, check_milestone, project_status,
                         artifact_status, impact, visible_chars, load_state)
from validate_skill import validate
from verify_example import verify as verify_example
from project_cli import impact


def ep_text(n, footer=True, dialogue=True):
    part = ('第{}集 谁拿了秤\n{}-1 菜市场 早/内景\n人物：陈青、老罗\n'
            '△ 老罗把秤放到台面。陈青挡住秤盘，发现封条被换过。\n').format(n, n)
    if dialogue:
        part += '陈青（盯着封条）：昨天不是这张。\n老罗（把手缩回去）：我只负责收东西。\n'
    else:
        part += ('△ 陈青拍下封条上的四位数字，把放大照片和昨夜的手写账条摆成一排。\n'
                 '△ 老罗伸手去碰手机，又停住，转身用报纸盖住最边上的旧秤。\n'
                 '无对白理由：观众仅凭照片对照和老罗的遮挡动作读出他在隐瞒。\n')
    part += '△ 陈青拿出手机，记下封条编码。\n'
    return part + ('（第{}集 完）\n'.format(n) if footer else '')


def write_concepts(project):
    value = '# 原创方案\n'
    for key, setting in zip('ABC', ('老城花店的冷库账目', '合租房中的假房东争议', '流动修伞摊的旧物失窃')):
        value += ('## 方案{}\n{}，主角通过手里的工作记录反查责任，发现亲近的人也可能在冒险；'
                  '临时的证物一旦公开，会引出失去信任的代价。\n').format(key, setting)
    value += '## 唯一推荐\n推荐老城花店，因为有限场地能显示人情和具体损失。\n'
    (project / 'concepts.md').write_text(value, encoding='utf-8')


def write_bible(project):
    value = ('# 故事圣经\n'
             '## 核心一句话\n为了保住供父亲复健的花店，店主必须证明冷库账单是被有意篡改，但公开证据可能伤害保护她的人。\n'
             '## 主角：想要/真正需要/缺点/资源/底线/改变\n她想保住店面，更需要学会请求帮助；习惯全扛，手上有进货单但拿不到后台权限。\n'
             '## 对手：想要/能做到/不能做到/害怕/合理反制\n对方想躲过库存追责，能调班却不能接触独立的监控备份，害怕同时失去工作和家人信任。\n'
             '## 季度终局承诺\n最终公开核对账目，主角与帮忙隐瞒的朋友说清责任，保住真正值得保住的互信。\n')
    (project / 'story_bible.md').write_text(value, encoding='utf-8')


def write_opening(project):
    value = ('# 开场\n## 方案A\n'
             '△ 店员掀开冷库门，地上一排花桶漂着水。店主蹲下翻出坏掉的郁金香，一张打印单正被水推到排水口。'
             '她冲过去按住单据，电话那头说今天要直接扣掉她三天的工资。\n'
             '## 推荐与原因\n选择可见损失与限时扣款，人物立刻采取行动。\n'
             '## 最终开场锁定\n锁定水中账单镜头，剪入电话里的扣款通知。\n')
    (project / 'opening.md').write_text(value, encoding='utf-8')


def write_outline(project):
    rows = ['# 全季大纲',
            '| 集 | 标题 | 压力 | 目标 | 行动 | 阻碍 | 反转 | 代价 | 尾钩 | 场景 | 预算 |',
            '|---|---|---|---|---|---|---|---|---|---|---|']
    for i in range(1, 16):
        rows.append('| {} | 旧秤{} | 失去摊位 | 找到原始订单 | 核对封条编码 | 合作伙伴隐瞒 | 旧账单映出漏洞 | 互信受损 | 新的证人出现 | 菜市场 | 2333 |'.format(i, i))
    (project / 'outline.md').write_text('\n'.join(rows), encoding='utf-8')


class StoryforgeTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.project = Path(self.temp.name) / 'project'
        init_project(self.project)
    def tearDown(self):
        self.temp.cleanup()
    def ep(self, n=1, text=None):
        (self.project / 'episodes' / 'EP{:02d}.md'.format(n)).write_text(text or ep_text(n), encoding='utf-8')

    def test_manifest(self):
        self.assertEqual(validate(), [])

    def test_python39_grammar_parse(self):
        for path in (ROOT / 'scripts').glob('*.py'):
            ast.parse(path.read_text(encoding='utf-8'), filename=str(path), feature_version=(3, 9))

    def test_init_safe_no_overwrite(self):
        fn = self.project / 'story_bible.md'
        fn.write_text('人工改写', encoding='utf-8')
        with self.assertRaisesRegex(ValueError, '拒绝覆盖'):
            init_project(self.project)
        self.assertEqual(fn.read_text(encoding='utf-8'), '人工改写')

    def test_empty_milestone_checkpoint_rejected(self):
        for stage, filename in [('concept', 'concepts.md'), ('bible', 'story_bible.md'), ('opening', 'opening.md')]:
            fn = self.project / filename
            fn.write_text('# 已完成\n\n', encoding='utf-8')
            with self.subTest(stage=stage), self.assertRaisesRegex(ValueError, '未通过'):
                checkpoint(self.project, stage, None, '')
        self.assertFalse(load_state(self.project)['history'])

    def test_placeholder_milestone_rejected(self):
        for stage in ('concept', 'bible', 'opening'):
            with self.subTest(stage=stage):
                self.assertTrue(check_milestone(self.project, stage))

    def test_nonempty_milestones_checkpoint(self):
        write_concepts(self.project); write_bible(self.project); write_opening(self.project)
        for stage in ('concept', 'bible', 'opening'):
            self.assertEqual(check_milestone(self.project, stage), [])
            checkpoint(self.project, stage, None, '')
        self.assertEqual(len(load_state(self.project)['checkpoints']), 3)

    def test_outline_placeholder_rejected(self):
        self.assertFalse(check_project(self.project, 'outline')['ok'])

    def test_outline_complete(self):
        write_outline(self.project)
        self.assertTrue(check_project(self.project, 'outline')['ok'])
        checkpoint(self.project, 'outline', None, '')
        self.assertNotIn('outline', load_state(self.project)['approvals'])

    def test_episode_checkpoint_separate_from_approval(self):
        self.ep()
        self.assertTrue(check_project(self.project, 'episode', 1, 0)['ok'])
        checkpoint(self.project, 'episode', 1, '初稿')
        self.assertEqual(load_state(self.project)['completed_episodes'], [1])
        self.assertEqual(artifact_status(self.project, load_state(self.project), 'episode:01')['status'], 'content_pending_review')

    def test_episode_missing_action(self):
        self.ep(text=ep_text(1).replace('△', '※'))
        self.assertIn('scene_action', [p['code'] for p in check_episode(self.project, 1, min_chars=0)[0]])

    def test_episode_scene_number(self):
        self.ep(text=ep_text(1).replace('1-1 菜市场', '2-1 菜市场'))
        self.assertIn('scene_episode_mismatch', [p['code'] for p in check_episode(self.project, 1, min_chars=0)[0]])

    def test_silent_scene_with_visual_logic_allowed(self):
        self.ep(text=ep_text(1, dialogue=False))
        self.assertTrue(check_project(self.project, 'episode', 1, 0)['ok'])
        checkpoint(self.project, 'episode', 1, '默剧')

    def test_silent_scene_without_reason_rejected(self):
        self.ep(text=ep_text(1, dialogue=False).replace('无对白理由：', '注释：'))
        self.assertIn('silent_scene_unsupported', [p['code'] for p in check_episode(self.project, 1, min_chars=0)[0]])

    def test_episode_missing_footer(self):
        self.ep(text=ep_text(1, footer=False))
        self.assertIn('episode_footer', [p['code'] for p in check_episode(self.project, 1, min_chars=0)[0]])

    def test_final_does_not_assert_content_approved(self):
        result = check_project(self.project, 'final', min_chars=0)
        self.assertFalse(result['ok'])
        self.assertEqual(result['content_review'], 'not_performed')
        self.assertIn('episode_missing', [p['code'] for p in result['issues']])

    def test_checkpoint_needs_complete(self):
        with self.assertRaisesRegex(ValueError, '未通过'):
            checkpoint(self.project, 'outline', None, '')
        with self.assertRaisesRegex(ValueError, '未通过'):
            checkpoint(self.project, 'episode', 3, '')

    def test_handoff_append_preserves_handwritten(self):
        self.ep()
        original = (self.project / 'HANDOFF.md').read_text(encoding='utf-8')
        checkpoint(self.project, 'episode', 1, '')
        self.assertTrue((self.project / 'HANDOFF.md').read_text(encoding='utf-8').startswith(original))

    def test_confirm_required(self):
        self.ep(); checkpoint(self.project, 'episode', 1, '')
        with self.assertRaisesRegex(ValueError, '明确确认'):
            approve(self.project, 'episode', 1, '', False)
        approve(self.project, 'episode', 1, '用户批准', True)
        self.assertEqual(artifact_status(self.project, load_state(self.project), 'episode:01')['status'], 'current_version_approved')

    def test_approval_bound_to_hash_edited_draft_becomes_unapproved(self):
        self.ep(); checkpoint(self.project, 'episode', 1, '')
        approve(self.project, 'episode', 1, '同意', True)
        self.ep(text=ep_text(1).replace('昨天不是', '我记得昨天不是'))
        result = artifact_status(self.project, load_state(self.project), 'episode:01')
        self.assertFalse(result['current_version_approved'])
        self.assertEqual(result['status'], 'needs_checkpoint')
        with self.assertRaisesRegex(ValueError, '尚未checkpoint'):
            approve(self.project, 'episode', 1, '', True)
        checkpoint(self.project, 'episode', 1, '修改稿')
        self.assertEqual(artifact_status(self.project, load_state(self.project), 'episode:01')['status'], 'content_pending_review')

    def test_recheckpoint_identical_content_preserves_real_approval(self):
        self.ep(); checkpoint(self.project, 'episode', 1, '')
        approve(self.project, 'episode', 1, '', True)
        checkpoint(self.project, 'episode', 1, '')
        self.assertTrue(artifact_status(self.project, load_state(self.project), 'episode:01')['current_version_approved'])

    def test_change_upstream_flags_existing_downstream(self):
        write_concepts(self.project); write_bible(self.project); write_outline(self.project); write_opening(self.project); self.ep()
        for stage in ('concept', 'bible', 'outline', 'opening'):
            checkpoint(self.project, stage, None, '')
        checkpoint(self.project, 'episode', 1, '')
        approve(self.project, 'episode', 1, '', True)
        (self.project / 'story_bible.md').write_text((self.project / 'story_bible.md').read_text(encoding='utf-8') + '\n主角不再相信店长。', encoding='utf-8')
        status = artifact_status(self.project, load_state(self.project), 'episode:01')
        self.assertEqual(status['status'], 'requires_upstream_review')
        self.assertIn('bible', status['stale_dependencies'])
        self.assertIn('episode:01', impact(self.project, 'bible')['existing_downstream_to_review'])
        self.assertTrue((self.project / 'episodes' / 'EP01.md').read_text(encoding='utf-8').startswith('第1集'))
        with self.assertRaisesRegex(ValueError, '上游设定变更'):
            approve(self.project, 'episode', 1, '', True)
        checkpoint(self.project, 'episode', 1, '人工复核上游变化')
        self.assertEqual(artifact_status(self.project, load_state(self.project), 'episode:01')['status'], 'content_pending_review')
        approve(self.project, 'episode', 1, '用户基于新故事圣经再次确认', True)
        self.assertTrue(artifact_status(self.project, load_state(self.project), 'episode:01')['current_version_approved'])

    def test_episode1_edit_flags_episode2(self):
        self.ep(1); self.ep(2)
        checkpoint(self.project, 'episode', 1, '')
        checkpoint(self.project, 'episode', 2, '')
        self.ep(1, ep_text(1).replace('不是这张', '不是原来那张'))
        status = artifact_status(self.project, load_state(self.project), 'episode:02')
        self.assertIn('episode:01', status['stale_dependencies'])

    def test_continuity_missing(self):
        (self.project / 'continuity.json').unlink()
        self.assertIn('continuity_missing', [p['code'] for p in check_project(self.project, 'continuity')['issues']])

    def test_continuity_invalid_json(self):
        (self.project / 'continuity.json').write_text('garbage', encoding='utf-8')
        self.assertIn('continuity_parse', [p['code'] for p in check_project(self.project, 'continuity')['issues']])
        self.ep()
        with self.assertRaisesRegex(ValueError, '未通过'):
            checkpoint(self.project, 'episode', 1, '')

    def test_continuity_bad_schema(self):
        (self.project / 'continuity.json').write_text('{}', encoding='utf-8')
        self.assertIn('continuity_schema', [p['code'] for p in check_continuity(self.project)])

    def test_continuity_knowledge_conflict(self):
        data = json.loads((self.project / 'continuity.json').read_text(encoding='utf-8'))
        data['facts'] = [{'id':'SECRET01','kind':'secret','statement':'冰柜钥匙在老罗家',
                          'epistemic_status':'belief','established':{'episode':1,'scene':1},
                          'knowledge':{'knows':['老罗'],'does_not_know':['老罗'], 'as_of':{'episode':1,'scene':1}},
                          'changed_by':[],'review_if_changed':['EP02:2-1']}]
        (self.project / 'continuity.json').write_text(json.dumps(data, ensure_ascii=False), encoding='utf-8')
        self.assertIn('continuity_knowledge_conflict', [p['code'] for p in check_continuity(self.project)])

    def test_old_boolean_approval_never_valid_as_current(self):
        self.ep(); checkpoint(self.project, 'episode', 1, '')
        data = load_state(self.project)
        data['approved_episodes'] = [1]
        data['approvals'] = {}
        (self.project / 'project_state.json').write_text(json.dumps(data), encoding='utf-8')
        self.assertFalse(artifact_status(self.project, load_state(self.project), 'episode:01')['current_version_approved'])
        self.assertTrue(project_status(self.project)['legacy_unbound_approval_present'])

    def test_failure_does_not_create_false_history(self):
        self.ep(text=ep_text(1, footer=False))
        data_before = (self.project / 'project_state.json').read_bytes()
        hand_before = (self.project / 'HANDOFF.md').read_bytes()
        with self.assertRaisesRegex(ValueError, '未通过'):
            checkpoint(self.project, 'episode', 1, '失败')
        self.assertEqual(data_before, (self.project / 'project_state.json').read_bytes())
        self.assertEqual(hand_before, (self.project / 'HANDOFF.md').read_bytes())

    def test_out_of_range(self):
        with self.assertRaisesRegex(ValueError, '1到15'):
            checkpoint(self.project, 'episode', 99, '')


    def test_python39_parso_grammar_when_available(self):
        try:
            import parso
        except ImportError:
            self.skipTest('parso optional; real Python3.9 runtime unavailable')
        grammar = parso.load_grammar(version='3.9')
        for path in (ROOT / 'scripts').glob('*.py'):
            issues = list(grammar.iter_errors(grammar.parse(path.read_text(encoding='utf-8'), error_recovery=True)))
            self.assertEqual(issues, [], str(path))

    def test_fact_impact_no_mutation(self):
        src = ROOT / 'examples' / 'laundry-47'
        before = {p.relative_to(src): hashlib.sha256(p.read_bytes()).hexdigest() for p in src.rglob('*') if p.is_file()}
        result = impact(src, fact_id='PROP47')
        self.assertIn('EP01:1-2', result['review_if_changed'])
        after = {p.relative_to(src): hashlib.sha256(p.read_bytes()).hexdigest() for p in src.rglob('*') if p.is_file()}
        self.assertEqual(before, after)

    def test_fact_impact_unknown_rejected(self):
        src = ROOT / 'examples' / 'laundry-47'
        with self.assertRaisesRegex(ValueError, '未找到'):
            impact(src, fact_id='NO_SUCH_FACT')

    def test_recovery_in_clean_directory(self):
        src = ROOT / 'examples' / 'laundry-47'
        dst = Path(self.temp.name) / 'fresh_recovery'
        shutil.copytree(src, dst)
        self.assertEqual(verify_example(dst), [])
        state = load_state(dst)
        self.assertFalse(state['approvals'])
        self.assertTrue(artifact_status(dst, state, 'episode:02')['checkpoint_current'])

    def test_final_structural_pass_is_not_approval(self):
        st = load_state(self.project)
        st['format']['episode_count'] = 2
        st['format']['target_total_visible_characters'] = 300
        (self.project / 'project_state.json').write_text(json.dumps(st, ensure_ascii=False), encoding='utf-8')
        rows = ['# 简版大纲', '| 集 | 标题 | 压力 | 目标 | 行动 | 阻碍 | 反转 | 代价 | 尾钩 | 场景 | 预算 |',
                '|---|---|---|---|---|---|---|---|---|---|---|']
        for n in (1, 2):
            rows.append('| {} | 展开 | 失误 | 核实 | 去查 | 受阻 | 找到线索 | 留下问题 | 继续核对 | 后间 | 150 |'.format(n))
            self.ep(n)
        (self.project / 'outline.md').write_text('\n'.join(rows), encoding='utf-8')
        result = check_project(self.project, 'final', min_chars=0)
        self.assertTrue(result['format_valid'], result['issues'])
        self.assertEqual(result['content_review'], 'not_performed')
        self.assertEqual(result['audience_validation'], 'not_performed')
        self.assertFalse(load_state(self.project)['approvals'])

    def test_sample_untampered(self):
        self.assertEqual(verify_example(), [])

    def test_episode_template_text_rejected(self):
        self.ep(text=ep_text(1).replace('谁拿了秤', '【正式标题】'))
        self.assertIn('episode_placeholder', [i['code'] for i in check_episode(self.project, 1, min_chars=0)[0]])

    def test_continuity_requires_as_of(self):
        obj = json.loads((ROOT / 'examples' / 'laundry-47' / 'continuity.json').read_text(encoding='utf-8'))
        del obj['facts'][0]['knowledge']['as_of']
        (self.project / 'continuity.json').write_text(json.dumps(obj, ensure_ascii=False), encoding='utf-8')
        self.assertIn('continuity_knowledge_as_of', [i['code'] for i in check_continuity(self.project)])

    def test_char_count(self):
        self.assertEqual(visible_chars('主角：来\n 去。'), 6)


if __name__ == '__main__':
    unittest.main(verbosity=2)
