#!/usr/bin/env python3
"""Microdrama Storyforge local project ledger/structural checks.

Python 3.9+ syntax, standard library only. Structural checks do NOT judge artistic merit,
chain of evidence, rights, platform acceptance, or user approvals.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import sys
import tempfile
from typing import Any

ROOT = Path(__file__).resolve().parent.parent
ASSETS = ROOT / 'assets'
EP_HEAD = re.compile(r'^第\s*0*(\d+)\s*集\s+\S+', re.M)
SCENE = re.compile(r'^(\d+)-(\d+)\s+(.+)$')
END = re.compile(r'^（第\s*0*(\d+)\s*集\s*完）\s*$')
DIALOGUE = re.compile(r'^[^\s△#（）|]{1,24}(?:（[^（）\n]{1,28}）)?：\S+')
SOURCE_PATHS = {
    'project_state.template.json': 'project_state.json',
    'story_bible.template.md': 'story_bible.md',
    'concepts.template.md': 'concepts.md',
    'outline.template.md': 'outline.md',
    'opening.template.md': 'opening.md',
    'continuity.template.json': 'continuity.json',
    'audience_brief.template.md': 'audience_brief.md',
    'HANDOFF.template.md': 'HANDOFF.md',
}
STAGE_FILES = {'concept': 'concepts.md', 'bible': 'story_bible.md',
               'outline': 'outline.md', 'opening': 'opening.md'}
INVALID_CELL = {'', '-', '—', '待定', '待填写', '【待定】', '[待定]', '待写', 'TBD', 'TODO'}
REQUIRED_CONTINUITY = {'schema_version': str, 'timeline': list, 'characters': dict,
                       'props': dict, 'secrets': dict, 'foreshadowing': list,
                       'unresolved_problems': list, 'locked_events': list, 'facts': list}
KINDS = {'character', 'prop', 'secret', 'promise', 'world', 'event', 'relationship'}
EPISTEMIC = {'objective', 'belief', 'mistaken'}


def visible_chars(value: str) -> int:
    """Non-whitespace Unicode code points, including punctuation and section heads."""
    return sum(not c.isspace() for c in value)


def issue(level: str, code: str, detail: str) -> dict:
    return {'level': level, 'code': code, 'detail': detail}


def now_utc() -> str:
    return datetime.now(timezone.utc).isoformat(timespec='seconds')


def digest(path: Path) -> str:
    if not path.is_file():
        return 'MISSING'
    return hashlib.sha256(path.read_bytes()).hexdigest()


def atomically_write_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile('w', encoding='utf-8', dir=path.parent,
                                     prefix='.tmp-storyforge-', suffix='.json', delete=False) as f:
        temp = Path(f.name)
        json.dump(obj, f, indent=2, ensure_ascii=False)
        f.write('\n')
        f.flush()
        os.fsync(f.fileno())
    try:
        os.replace(str(temp), str(path))
    finally:
        if temp.exists():
            temp.unlink()


def load_state(project: Path) -> dict:
    path = project / 'project_state.json'
    if not path.is_file():
        raise ValueError('找不到状态文件，请先运行 init')
    try:
        state = json.loads(path.read_text(encoding='utf-8'))
    except (OSError, json.JSONDecodeError) as e:
        raise ValueError('状态JSON无效：{}'.format(e)) from e
    if not isinstance(state, dict) or not isinstance(state.get('format'), dict):
        raise ValueError('project_state.json缺少format对象')
    fmt = state['format']
    n, total = fmt.get('episode_count', 15), fmt.get('target_total_visible_characters', 35000)
    if isinstance(n, bool) or not isinstance(n, int) or not 1 <= n <= 100:
        raise ValueError('format.episode_count须为1至100整数')
    if isinstance(total, bool) or not isinstance(total, int) or total < 0:
        raise ValueError('format.target_total_visible_characters须为非负整数')
    for key, expected in [('history', list), ('completed_episodes', list)]:
        if not isinstance(state.get(key, []), expected):
            raise ValueError('状态文件{}类型错误'.format(key))
    # Legacy v1 approvals are historical hints only; they lack hashes and cannot
    # authorize CURRENT files. Don't rewrite the state just by inspecting it.
    return state


def artifact_path(project: Path, key: str) -> Path:
    if key in STAGE_FILES:
        return project / STAGE_FILES[key]
    m = re.fullmatch(r'(episode|review):(\d{2})', key)
    if m:
        return project / 'episodes' / 'EP{}.md'.format(m.group(2))
    raise ValueError('无法识别里程碑{}'.format(key))


def stage_key(stage: str, episode: int | None) -> str:
    if stage in STAGE_FILES:
        if episode is not None:
            raise ValueError('此阶段不能附带 --episode')
        return stage
    if stage in {'episode', 'review'} and episode is not None:
        return '{}:{:02d}'.format(stage, episode)
    raise ValueError('不支持阶段，或缺少--episode')


def upstream(key: str) -> list:
    if key == 'concept':
        return []
    if key == 'bible':
        return ['concept']
    if key == 'outline':
        return ['concept', 'bible']
    if key == 'opening':
        return ['concept', 'bible', 'outline']
    m = re.fullmatch(r'(episode|review):(\d{2})', key)
    if m:
        ep = int(m.group(2))
        base = ['concept', 'bible', 'outline']
        base.append('opening' if ep == 1 else 'episode:{:02d}'.format(ep - 1))
        if m.group(1) == 'review':
            base.append('episode:{:02d}'.format(ep))
        return base
    raise ValueError('无效的里程碑{}'.format(key))


def capture_dependencies(project: Path, key: str) -> dict:
    return {parent: digest(artifact_path(project, parent)) for parent in upstream(key)}


def check_continuity(project: Path) -> list:
    path = project / 'continuity.json'
    if not path.is_file():
        return [issue('error', 'continuity_missing', '缺少continuity.json')]
    try:
        obj = json.loads(path.read_text(encoding='utf-8'))
    except (OSError, json.JSONDecodeError) as e:
        return [issue('error', 'continuity_parse', '连续性JSON无法解析：{}'.format(e))]
    if not isinstance(obj, dict):
        return [issue('error', 'continuity_schema', '连续性根对象必须是字典')]
    errors = []
    for field, typ in REQUIRED_CONTINUITY.items():
        if not isinstance(obj.get(field), typ):
            errors.append(issue('error', 'continuity_schema', '{}必须存在且为{}'.format(field, typ.__name__)))
    if errors:
        return errors
    seen = set()
    for idx, fact in enumerate(obj['facts']):
        name = 'facts[{}]'.format(idx)
        if not isinstance(fact, dict):
            errors.append(issue('error', 'continuity_fact', '{}必须为对象'.format(name)))
            continue
        ident, statement = fact.get('id'), fact.get('statement')
        if not isinstance(ident, str) or not re.fullmatch(r'[A-Za-z][A-Za-z0-9_-]{1,40}', ident):
            errors.append(issue('error', 'continuity_id', '{}.id无效'.format(name)))
        elif ident in seen:
            errors.append(issue('error', 'continuity_duplicate', '重复事实id {}'.format(ident)))
        else:
            seen.add(ident)
        if not isinstance(statement, str) or len(statement.strip()) < 4:
            errors.append(issue('error', 'continuity_statement', '{}.statement为空或过短'.format(name)))
        if fact.get('kind') not in KINDS:
            errors.append(issue('error', 'continuity_kind', '{}.kind须为{}'.format(name, sorted(KINDS))))
        if fact.get('epistemic_status') not in EPISTEMIC:
            errors.append(issue('error', 'continuity_epistemic', '{}.epistemic_status无效'.format(name)))
        loc = fact.get('established')
        if not valid_location(loc):
            errors.append(issue('error', 'continuity_established', '{}.established需要集数和场号'.format(name)))
        knowledge = fact.get('knowledge')
        if not isinstance(knowledge, dict) or not all(isinstance(knowledge.get(k), list) and
                all(isinstance(x, str) and x.strip() for x in knowledge[k])
                for k in ('knows', 'does_not_know')):
            errors.append(issue('error', 'continuity_knowledge', '{}.knowledge须包含两个人物列表'.format(name)))
        elif set(knowledge['knows']) & set(knowledge['does_not_know']):
            errors.append(issue('error', 'continuity_knowledge_conflict', '{}同一人不能既知又不知'.format(name)))
        if isinstance(knowledge, dict) and not valid_location(knowledge.get('as_of')):
            errors.append(issue('error', 'continuity_knowledge_as_of', '{}.knowledge.as_of要注明截止集场'.format(name)))
        changes = fact.get('changed_by')
        if not isinstance(changes, list) or any(not isinstance(x, dict) or
                not valid_location(x.get('at')) or
                not isinstance(x.get('change'), str) or not x['change'].strip() for x in changes):
            errors.append(issue('error', 'continuity_changed_by', '{}.changed_by须为带位置及变化的列表'.format(name)))
        if isinstance(changes, list):
            for change in changes:
                if isinstance(change, dict) and 'knowledge_after' in change:
                    ka = change['knowledge_after']
                    if not isinstance(ka, dict) or not isinstance(ka.get('knows'), list) or not isinstance(ka.get('does_not_know'), list):
                        errors.append(issue('error', 'continuity_change_knowledge', '{}.changed_by.knowledge_after无效'.format(name)))
        affects = fact.get('review_if_changed')
        if not isinstance(affects, list) or any(not isinstance(x, str) or not x.strip() for x in affects):
            errors.append(issue('error', 'continuity_review', '{}.review_if_changed须为引用列表'.format(name)))
    return errors


def valid_location(loc: Any) -> bool:
    if not isinstance(loc, dict):
        return False
    ep, scene = loc.get('episode'), loc.get('scene')
    return isinstance(ep, int) and not isinstance(ep, bool) and ep > 0 and isinstance(scene, int) and not isinstance(scene, bool) and scene > 0


def section_content(text: str, heading: str) -> str:
    rx = re.compile(r'^##\s+' + re.escape(heading) + r'[^\n]*\n(.*?)(?=^##\s+|\Z)', re.M | re.S)
    m = rx.search(text)
    if not m:
        return ''
    content = m.group(1)
    content = re.sub(r'【[^】]*】|\[[^\]]*\]|<!--.*?-->', ' ', content, flags=re.S)
    content = re.sub(r'(?im)^\s*(?:未选定|未锁定|待定|暂无|待确认|tbd|todo).*$', '', content)
    return content.strip()


def check_milestone(project: Path, stage: str, episode_count: int = 15) -> list:
    if stage == 'outline':
        return check_outline(project, episode_count)
    path = artifact_path(project, stage)
    if not path.is_file():
        return [issue('error', 'milestone_missing', '缺少{}'.format(path.name))]
    text = path.read_text(encoding='utf-8-sig')
    requirements = {
        'concept': [('方案A', 24), ('方案B', 24), ('方案C', 24), ('唯一推荐', 10)],
        'bible': [('核心一句话', 14), ('主角', 22), ('对手', 22), ('季度终局承诺', 14)],
        'opening': [('方案A', 48), ('推荐与原因', 12), ('最终开场锁定', 12)],
    }
    errors = []
    for section, minchars in requirements[stage]:
        content = section_content(text, section)
        if visible_chars(content) < minchars:
            errors.append(issue('error', 'milestone_unfilled', '{}.md 的“{}”未有足够真实内容（至少{}可见字符）'.format(stage, section, minchars)))
    if re.search(r'【\s*(?:待定|待写|填写|真实|角色)|(?m:^\s*(?:TODO|TBD)\b)', text):
        errors.append(issue('error', 'milestone_placeholder', '{}含待填写模板标记'.format(path.name)))
    if stage == 'concept':
        concepts = [re.sub(r'\s+', '', section_content(text, '方案' + k)) for k in 'ABC']
        if len(set(concepts)) < 3:
            errors.append(issue('error', 'concept_duplicate', '三个题材方向不可全文相同'))
    return errors


def check_outline(project: Path, episode_count: int = 15) -> list:
    path = project / 'outline.md'
    if not path.is_file():
        return [issue('error', 'outline_missing', '缺少{}'.format(path))]
    rows = []
    for lno, line in enumerate(path.read_text(encoding='utf-8').splitlines(), start=1):
        if not line.lstrip().startswith('|'):
            continue
        cells = [x.strip() for x in line.strip().strip('|').split('|')]
        if cells and re.fullmatch(r'\d+', cells[0]):
            rows.append((int(cells[0]), cells, lno))
    errors = []
    indices = [r[0] for r in rows]
    if sorted(indices) != list(range(1, episode_count + 1)):
        errors.append(issue('error', 'outline_indices', '必须有各一行第1至{}集，实际{}'.format(episode_count, indices)))
    for n, cells, lno in rows:
        if len(cells) < 10:
            errors.append(issue('error', 'outline_columns', '{}行至少10列'.format(lno)))
            continue
        if any(v in INVALID_CELL or '【待' in v or '[待' in v for v in cells[1:10]):
            errors.append(issue('error', 'outline_unfilled', '第{}集有未填字段'.format(n)))
        if len(cells) >= 11 and (not re.fullmatch(r'\d+', cells[10]) or int(cells[10]) <= 0):
            errors.append(issue('warning', 'outline_budget', '第{}集预算非正整数'.format(n)))
    return errors


def check_episode(project: Path, episode: int, target_total: int = 35000,
                  episode_count: int = 15, min_chars: int = 900) -> tuple:
    path = artifact_path(project, 'episode:{:02d}'.format(episode))
    if not path.is_file():
        return [issue('error', 'episode_missing', '缺少{}'.format(path))], 0
    txt = path.read_text(encoding='utf-8-sig')
    count, lines, problems = visible_chars(txt), txt.splitlines(), []
    if re.search(r'【[^】]+】|此处略|略去后续|相似情节省略', txt):
        problems.append(issue('error', 'episode_placeholder', '正文含模板占位符或省略语'))
    heads = list(EP_HEAD.finditer(txt))
    if len(heads) != 1 or int(heads[0].group(1)) != episode:
        problems.append(issue('error', 'episode_heading', '缺少唯一的第{}集标题'.format(episode)))
    scenes = []
    for idx, line in enumerate(lines):
        m = SCENE.fullmatch(line.strip())
        if m:
            scenes.append((idx, int(m.group(1)), int(m.group(2)), m.group(3)))
    if not scenes:
        problems.append(issue('error', 'scene_missing', '缺少编号场次'))
    else:
        nums = []
        for idx, pref, n, head in scenes:
            nums.append(n)
            if pref != episode:
                problems.append(issue('error', 'scene_episode_mismatch', '第{}行编号错误'.format(idx + 1)))
            if not re.search(r'内景|外景|/内|/外', head):
                problems.append(issue('error', 'scene_int_ext', '第{}行缺内外景'.format(idx + 1)))
            if not re.search(r'早|晨|午|下午|傍晚|黄昏|晚|夜|凌晨|日|两小时后|次日', head):
                problems.append(issue('warning', 'scene_time', '第{}行缺时间'.format(idx + 1)))
        if nums != list(range(1, len(nums) + 1)):
            problems.append(issue('error', 'scene_sequence', '场次须从1连续递增'))
        for i, (idx, _, n, _) in enumerate(scenes):
            end = scenes[i + 1][0] if i + 1 < len(scenes) else len(lines)
            body = [x.strip() for x in lines[idx + 1:end] if x.strip() and not END.fullmatch(x.strip())]
            actions = [x for x in body if x.startswith('△')]
            cast_line = next((x[3:].strip() for x in body if x.startswith('人物：')), '')
            cast_names = set(re.split(r'[、，,；;\s]+', cast_line))
            dialogue = [x for x in body if DIALOGUE.match(x) and
                        x.split('：', 1)[0].split('（', 1)[0] in cast_names]
            if not any(re.match(r'^人物：\s*\S+', x) for x in body):
                problems.append(issue('error', 'scene_cast', '场{}缺出场人物标识'.format(n)))
            if not actions:
                problems.append(issue('error', 'scene_action', '场{}缺可拍动作'.format(n)))
            if not dialogue:
                reason = next((x.split('：', 1)[1].strip() for x in body if x.startswith('无对白理由：')), '')
                if len(actions) < 2 or sum(visible_chars(x) for x in actions) < 44 or visible_chars(reason) < 8:
                    problems.append(issue('error', 'silent_scene_unsupported',
                                          '场{}无对白须有>=2段总计44可见字符动作，并有>=8字无对白理由'.format(n)))
    if not any((m := END.fullmatch(l.strip())) and int(m.group(1)) == episode for l in lines):
        problems.append(issue('error', 'episode_footer', '缺少第{}集收尾'.format(episode)))
    if count < min_chars:
        problems.append(issue('warning', 'episode_short', '本集{}可见字符，少于提示阈值{}'.format(count, min_chars)))
    estimated = round(target_total / episode_count) if episode_count else 0
    if estimated and count > estimated * 2:
        problems.append(issue('warning', 'episode_long', '本集{}可见字符，高于均值两倍'.format(count)))
    return problems, count


def artifact_status(project: Path, state: dict, key: str) -> dict:
    current = digest(artifact_path(project, key))
    checkpoint = state.get('checkpoints', {}).get(key)
    approval = state.get('approvals', {}).get(key)
    stale_deps = []
    if isinstance(checkpoint, dict):
        for dep, expected in checkpoint.get('dependencies', {}).items():
            if digest(artifact_path(project, dep)) != expected:
                stale_deps.append(dep)
    recorded = isinstance(checkpoint, dict) and checkpoint.get('sha256') == current and current != 'MISSING'
    approved = (recorded and isinstance(approval, dict) and approval.get('sha256') == current
                and not stale_deps and approval.get('user_confirmed') is True
                and approval.get('dependencies') == checkpoint.get('dependencies'))
    return {'artifact': key, 'exists': current != 'MISSING', 'current_sha256': current,
            'checkpoint_current': recorded, 'stale_dependencies': stale_deps,
            'current_version_approved': approved,
            'status': ('current_version_approved' if approved else
                       'requires_upstream_review' if stale_deps else
                       'needs_checkpoint' if not recorded else 'content_pending_review')}


def project_status(project: Path) -> dict:
    state = load_state(project)
    keys = set(state.get('checkpoints', {})) | set(state.get('approvals', {}))
    keys.update('episode:{:02d}'.format(x) for x in state.get('completed_episodes', []) if isinstance(x, int))
    results = [artifact_status(project, state, key) for key in sorted(keys)]
    return {'artifacts': results, 'legacy_unbound_approval_present':
            bool(any(state.get('approved', {}).values()) or state.get('approved_episodes', [])) and not bool(state.get('approvals')),
            'continuity_issues': check_continuity(project),
            'note': '旧版布尔批准不含哈希，不能证明现版本获批准；此处不代表作品内容审查'}


def impact(project: Path, changed: str | None = None, fact_id: str | None = None) -> dict:
    if fact_id:
        errors = check_continuity(project)
        if errors:
            raise ValueError('连续性账存在错误，无法安全定位事实影响：{}'.format(errors[0]['code']))
        ledger = json.loads((project / 'continuity.json').read_text(encoding='utf-8'))
        found = next((fact for fact in ledger['facts'] if fact['id'] == fact_id), None)
        if found is None:
            raise ValueError('未找到fact-id：{}'.format(fact_id))
        return {'fact_id': fact_id, 'statement': found['statement'], 'review_if_changed': found['review_if_changed'],
                'action': '依据作者登记的依赖建议人工复核，未自动改写；账本引用不等于穷尽实际影响'}
    state = load_state(project)
    n = state['format']['episode_count']
    if changed not in STAGE_FILES and not re.fullmatch(r'episode:\d{2}', changed):
        raise ValueError('--changed使用concept/bible/outline/opening/episode:01等')
    if changed.startswith('episode:') and int(changed.split(':')[1]) > n:
        raise ValueError('集数超出项目范围')
    targets = ['concept', 'bible', 'outline', 'opening'] + ['episode:{:02d}'.format(i) for i in range(1, n + 1)]
    affected, propagated = [], {changed}
    for key in targets:
        if key == changed:
            continue
        if any(parent in propagated for parent in upstream(key)):
            propagated.add(key)
            if artifact_path(project, key).exists():
                affected.append(key)
    return {'changed': changed, 'existing_downstream_to_review': affected,
            'action': '标记复核建议；不自动修改下游文件或批准记录',
            'state': [artifact_status(project, state, x) for x in affected if x in state.get('checkpoints', {})]}


def check_project(project: Path, mode: str, episode: int | None = None, min_chars: int = 900) -> dict:
    state = load_state(project)
    n = state['format']['episode_count']
    total = state['format']['target_total_visible_characters']
    problems = check_continuity(project)
    counts = {}
    if mode in {'outline', 'final'}:
        problems.extend(check_outline(project, n))
    if mode == 'episode':
        if episode is None or not 1 <= episode <= n:
            raise ValueError('episode模式须带--episode 1至{}'.format(n))
        found, count = check_episode(project, episode, total, n, min_chars)
        problems.extend(found)
        counts['EP{:02d}'.format(episode)] = count
    elif mode == 'final':
        for ep in range(1, n + 1):
            found, count = check_episode(project, ep, total, n, min_chars)
            problems.extend(found)
            counts['EP{:02d}'.format(ep)] = count
        if total and sum(counts.values()) and abs(sum(counts.values()) - total) / total > .15:
            problems.append(issue('warning', 'season_character_budget', '整季字符偏离目标超过15%，请人工核对时长'))
        if not check_continuity(project) and not json.loads((project / 'continuity.json').read_text(encoding='utf-8')).get('facts'):
            problems.append(issue('warning', 'continuity_empty', '没有登记事实；不能据此宣称连续性审完'))
    return {'ok': not any(x['level'] == 'error' for x in problems),
            'format_valid': not any(x['level'] == 'error' for x in problems),
            'mode': mode, 'issues': problems, 'counts': counts,
            'visible_character_total': sum(counts.values()),
            'content_review': 'not_performed', 'audience_validation': 'not_performed',
            'approval_status': 'see status command for per-version hashes',
            'note': 'PASS仅表示结构与JSON结构校验；不等于剧情终审、现版本批准或合规验收'}


def init_project(project: Path) -> str:
    if project.exists() and any(project.iterdir()):
        raise ValueError('拒绝覆盖非空目录：{}'.format(project))
    project.mkdir(parents=True, exist_ok=True)
    (project / 'episodes').mkdir(exist_ok=True)
    for source, dest in SOURCE_PATHS.items():
        shutil.copyfile(ASSETS / source, project / dest)
    return '已初始化 {}；均为模板，尚无有效稿件、完成或批准记录'.format(project)


def append_handoff(project: Path, line: str, next_action: str) -> None:
    with (project / 'HANDOFF.md').open('a', encoding='utf-8') as out:
        out.write('\n\n## 自动检查点\n- {}\n- 下一动作：{}\n'.format(line, next_action))


def record(project: Path, state: dict, event: dict, handoff: str) -> None:
    state.setdefault('history', []).append(event)
    state['last_checkpoint'] = event['at']
    atomically_write_json(project / 'project_state.json', state)
    try:
        append_handoff(project, handoff, state.get('next_action', '按当前确认稿继续'))
    except OSError as e:
        # Status has been safely committed; never claim the whole operation failed.
        print('WARNING: project_state已保存，但HANDOFF追加失败：{}'.format(e), file=sys.stderr)


def checkpoint(project: Path, stage: str, episode: int | None, note: str) -> str:
    state = load_state(project)
    n = state['format']['episode_count']
    if stage not in {'concept', 'bible', 'outline', 'opening', 'episode', 'review'}:
        raise ValueError('stage不支持')
    key = stage_key(stage, episode)
    if episode is not None and not 1 <= episode <= n:
        raise ValueError('集数须为1到{}'.format(n))
    if stage in STAGE_FILES:
        errors = check_milestone(project, stage, n)
    else:
        errors, _ = check_episode(project, episode, state['format']['target_total_visible_characters'], n, 0)
    errors.extend(check_continuity(project))
    if any(x['level'] == 'error' for x in errors):
        raise ValueError('里程碑未通过格式/结构检查：{}'.format('; '.join(i['code'] for i in errors if i['level'] == 'error')))
    path = artifact_path(project, key)
    current = digest(path)
    deps = capture_dependencies(project, key)
    state.setdefault('checkpoints', {})[key] = {'sha256': current, 'at': now_utc(), 'dependencies': deps}
    if stage == 'episode' and episode not in state.setdefault('completed_episodes', []):
        state['completed_episodes'].append(episode)
        state['completed_episodes'].sort()
    state['stage'] = stage
    if stage == 'episode':
        state['next_action'] = ('复核第{}集的内容，批准后续写第{}集'.format(episode, episode + 1)
                                if episode < n else '复核全季内容及制作限制')
    else:
        state['next_action'] = {'concept': '复核方向并建立故事圣经', 'bible': '复核设定并建立全季大纲',
                                'outline': '设计第一集开头或直接写EP01', 'opening': '写第一集正文',
                                'review': '人工确认当前版本并决定是否返修'}.get(stage, '继续')
    event = {'at': now_utc(), 'action': 'checkpoint', 'stage': stage, 'artifact': key,
             'sha256': current, 'dependencies': deps, 'note': note or '存档', 'approved_by_user': False}
    record(project, state, event, '{} 已存档 {} sha256={}（未经批准）'.format(event['at'], key, current[:12]))
    return '已登记{}当前文件哈希；内容待审，旧批准若不匹配自动失效'.format(key)


def approve(project: Path, stage: str, episode: int | None, note: str, confirmed: bool) -> str:
    if not confirmed:
        raise ValueError('必须有用户明确确认，才允许 --user-confirmed')
    state = load_state(project)
    if stage not in {'concept', 'bible', 'outline', 'opening', 'episode'}:
        raise ValueError('只能批准concept/bible/outline/opening/episode')
    key = stage_key(stage, episode)
    st = artifact_status(project, state, key)
    if not st['checkpoint_current']:
        raise ValueError('当前版本尚未checkpoint；旧版完成标记不构成依据')
    if st['stale_dependencies']:
        raise ValueError('上游设定变更，必须先复核并重新checkpoint：{}'.format(st['stale_dependencies']))
    if stage in STAGE_FILES:
        errors = check_milestone(project, stage, state['format']['episode_count'])
    else:
        errors, _ = check_episode(project, episode, min_chars=0)
    errors.extend(check_continuity(project))
    if any(i['level'] == 'error' for i in errors):
        raise ValueError('当前文件结构验证失败，拒绝批准')
    at = now_utc()
    state.setdefault('approvals', {})[key] = {'sha256': st['current_sha256'], 'at': at,
                                             'dependencies': state['checkpoints'][key]['dependencies'].copy(),
                                             'user_confirmed': True, 'note': note or '用户明确确认'}
    # Compatibility flags are written for old readers but are never authoritative.
    if stage in STAGE_FILES:
        state.setdefault('approved', {})[stage] = True
    elif episode not in state.setdefault('approved_episodes', []):
        state['approved_episodes'].append(episode)
        state['approved_episodes'].sort()
    event = {'at': at, 'action': 'approve', 'stage': stage, 'artifact': key,
             'sha256': st['current_sha256'], 'note': note or '用户明确确认', 'approved_by_user': True}
    record(project, state, event, '{} 用户批准{} sha256={}'.format(at, key, st['current_sha256'][:12]))
    return '已绑定批准{} sha256={}（只对当前文件版本有效）'.format(key, st['current_sha256'][:12])


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='cmd', required=True)
    ini = sub.add_parser('init', help='初始化新作品，拒绝覆盖')
    ini.add_argument('--project', type=Path, required=True)
    val = sub.add_parser('validate', help='结构/JSON校验，不做语义审稿')
    val.add_argument('--project', type=Path, required=True)
    val.add_argument('--mode', choices=['outline', 'episode', 'continuity', 'final'], required=True)
    val.add_argument('--episode', type=int)
    val.add_argument('--min-chars', type=int, default=900)
    val.add_argument('--json', action='store_true')
    for command in ('checkpoint', 'approve'):
        item = sub.add_parser(command)
        item.add_argument('--project', type=Path, required=True)
        item.add_argument('--stage', required=True, choices=(['concept', 'bible', 'outline', 'opening', 'episode', 'review']
                                                          if command == 'checkpoint' else
                                                          ['concept', 'bible', 'outline', 'opening', 'episode']))
        item.add_argument('--episode', type=int)
        item.add_argument('--note', default='')
        if command == 'approve':
            item.add_argument('--user-confirmed', action='store_true')
    st = sub.add_parser('status', help='逐文件报告检查点哈希/旧批准/上游复核')
    st.add_argument('--project', type=Path, required=True)
    imp = sub.add_parser('impact', help='仅列出变更后的下游复核范围，不修改文件')
    imp.add_argument('--project', type=Path, required=True)
    group = imp.add_mutually_exclusive_group(required=True)
    group.add_argument('--changed')
    group.add_argument('--fact-id')
    args = parser.parse_args(argv)
    try:
        if args.cmd == 'init':
            print(init_project(args.project))
        elif args.cmd == 'checkpoint':
            print(checkpoint(args.project, args.stage, args.episode, args.note))
        elif args.cmd == 'approve':
            print(approve(args.project, args.stage, args.episode, args.note, args.user_confirmed))
        elif args.cmd in {'status', 'impact'}:
            print(json.dumps(project_status(args.project) if args.cmd == 'status' else
                             impact(args.project, args.changed, args.fact_id), ensure_ascii=False, indent=2))
        else:
            if args.min_chars < 0:
                raise ValueError('min-chars不得为负数')
            result = check_project(args.project, args.mode, args.episode, args.min_chars)
            if args.json:
                print(json.dumps(result, ensure_ascii=False, indent=2))
            else:
                print('{} {}，计数{}；内容评审与用户批准未由此执行'.format(
                    'PASS' if result['ok'] else 'FAIL', args.mode, result['visible_character_total']))
                for it in result['issues']:
                    print('[{}] {}: {}'.format(it['level'], it['code'], it['detail']))
                print(result['note'])
            return 0 if result['ok'] else 1
        return 0
    except (ValueError, OSError, KeyError, TypeError) as e:
        print('ERROR: {}'.format(e), file=sys.stderr)
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
