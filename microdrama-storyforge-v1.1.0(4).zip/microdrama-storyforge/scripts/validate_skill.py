#!/usr/bin/env python3
"""Lightweight local packaging and frontmatter validation; not official skills-ref."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parent.parent
SKILL = ROOT / 'SKILL.md'

def validate(root=ROOT):
    errors = []
    p = root / 'SKILL.md'
    if not p.is_file():
        return ['SKILL.md不存在']
    body = p.read_text(encoding='utf-8-sig')
    f = re.match(r'\A---\n(.*?)\n---\n', body, flags=re.S)
    if not f:
        return ['SKILL.md缺少正确的YAML frontmatter']
    fields = {}
    for line in f.group(1).splitlines():
        mat = re.fullmatch(r'^([A-Za-z][\w-]*):\s*(.*)$', line)
        if mat:
            fields[mat.group(1)] = mat.group(2).strip().strip('"')
    name = fields.get('name', '')
    description = fields.get('description', '')
    if not re.fullmatch(r'[a-z0-9]+(?:-[a-z0-9]+)*', name) or len(name) > 64:
        errors.append(f'Skill name无效：{name!r}')
    if root.name != name:
        errors.append('Skill目录名必须与name一致')
    if not (0 < len(description) <= 1024):
        errors.append('description应为1—1024字符')
    for ref in re.findall(r'`((?:assets|scripts|references)/[a-zA-Z0-9_.-]+)`', body):
        if not (root / ref).is_file():
            errors.append(f'引用文件不存在：{ref}')
    return errors

if __name__ == '__main__':
    failures = validate()
    for e in failures:
        print('FAIL', e)
    if not failures:
        print('PASS local Agent Skills format and referenced files')
    raise SystemExit(bool(failures))
