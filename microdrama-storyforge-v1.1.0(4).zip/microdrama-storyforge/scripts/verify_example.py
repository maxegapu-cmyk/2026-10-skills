#!/usr/bin/env python3
"""Verify recovery handoff assertions against EP01/EP02 and continuity IDs.

Checks a deliberately small finite contract, not artistic merit or all semantic facts.
"""
from pathlib import Path
import json
import re
import sys

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / 'scripts'))
from project_cli import check_continuity, check_outline, check_episode, load_state, artifact_status


def verify(root=None):
    project = root or ROOT / 'examples' / 'laundry-47'
    errors = []
    if check_continuity(project):
        errors.append('continuity.json结构不合格')
        return errors
    if any(x['level'] == 'error' for x in check_outline(project, 15)):
        errors.append('15集大纲结构不合格')
    texts = {}
    for ep in (1, 2):
        issues, count = check_episode(project, ep, min_chars=0)
        if any(x['level'] == 'error' for x in issues):
            errors.append('EP{:02d}结构不合格'.format(ep))
        if count < 600:
            errors.append('EP{:02d}字数不足以作为完整样例'.format(ep))
        texts[ep] = (project / 'episodes' / 'EP{:02d}.md'.format(ep)).read_text(encoding='utf-8')
    ledger = json.loads((project / 'continuity.json').read_text(encoding='utf-8'))
    facts = {x['id']: x for x in ledger['facts']}
    expected = {'PROP47', 'THREAD3', 'SECRET_BAG', 'PROMISE_17', 'BELIEF_HIDDEN'}
    if set(facts) != expected:
        errors.append('事实ID数量或名称被意外修改')
    for fact in ledger['facts']:
        locs = [fact['established']] + [event['at'] for event in fact['changed_by']]
        for loc in locs:
            ep, scene = loc['episode'], loc['scene']
            if ep not in texts or not re.search(r'^{}-{}\s'.format(ep, scene), texts[ep], re.M):
                errors.append('事实{}引用不存在的场次{}-{}'.format(fact['id'], ep, scene))
        for pointer in fact['review_if_changed']:
            match = re.fullmatch(r'EP(\d{2}):(\d+)-(\d+)', pointer)
            if match:
                ep, prefix, scene = map(int, match.groups())
                if ep not in texts or ep != prefix or not re.search(r'^{}-{}\s'.format(ep, scene), texts[ep], re.M):
                    errors.append('review_if_changed存在不存在的场次{}'.format(pointer))
    tests = [
        ('角色知情-梁姨', '梁姨' in facts['SECRET_BAG']['knowledge']['knows']),
        ('秘密揭示场', any(x['at'] == {'episode': 2, 'scene': 2} for x in facts['SECRET_BAG']['changed_by'])),
        ('旧蓝线仍在', '三道蓝' in texts[2] and '口袋' in texts[2]),
        ('袋中衣服已找回', '白礼服' in texts[2] and '灰布袋' in texts[2]),
        ('承诺未等于衣服修复', any(x['id'] == 'PROMISE_17' and '尚未' in x['status'] for x in ledger['unresolved_problems'])),
        ('handoff明确样例非用户批准', '未获用户批准' in (project / 'HANDOFF.md').read_text(encoding='utf-8')),
    ]
    for title, value in tests:
        if not value:
            errors.append('无法恢复：{}'.format(title))
    state = load_state(project)
    if set(state.get('completed_episodes', [])) != {1, 2}:
        errors.append('状态文件未登记连续两集')
    for ep in (1, 2):
        st = artifact_status(project, state, 'episode:{:02d}'.format(ep))
        if not st['checkpoint_current'] or st['current_version_approved']:
            errors.append('样例须已存档且未被误批准EP{}'.format(ep))
    return errors


if __name__ == '__main__':
    failures = verify()
    print('PASS example recovery contract' if not failures else '\n'.join('FAIL ' + e for e in failures))
    raise SystemExit(bool(failures))
