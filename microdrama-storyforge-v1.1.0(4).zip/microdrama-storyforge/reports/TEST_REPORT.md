# 测试与发布验收记录｜Microdrama Storyforge v1.1.0

## 实测环境和版本

- 执行日期：2026-10-23；Linux x86_64；Python 3.13.5；`unittest`、`pathlib`、`hashlib`等标准库。测试辅助 `parso` 在此机器上可用，**不是Skill的运行依赖**。
- Python 3.9 **未安装**。尝试 `uv python install 3.9`，因容器内DNS无法解析GitHub下载域名而失败。`parso`按3.9语法解析：原版 `scripts/project_cli.py` 报1处问题，修改版所有 `scripts/*.py` 报0处；这**不是**Python3.9解释器实跑，不声称3.9运行已通过。
- 原包 SHA-256: `11833ec2480d297fcabc745a5db64be7e1116fca1fbf89449617062ead7b94f8`；在独立目录解压，未覆盖。

## 原版对照（真实执行）

- 在正确目录名下运行 `python tests/run_tests.py`：**15/15 PASS**。
- 额外手动负面测试：原版空白的 `concepts.md`、`story_bible.md`、`opening.md` 各自仍可checkpoint；已批准单集的正文被修改后 `approved_episodes:[1]` 保持不变；`continuity.json` 换成 `NOT_JSON` 仍返回单集ok。上述问题不是原版15项测试覆盖到的。
- 语法：原版单独用 `parso.load_grammar(version='3.9')` 解析，1条issue（f-string引号嵌套）；不是原版整体无法在3.13运行。

## 修改版实际运行的命令

```bash
python scripts/validate_skill.py
python tests/run_tests.py
python scripts/verify_example.py
python scripts/project_cli.py validate --project examples/laundry-47 --mode outline
python scripts/project_cli.py validate --project examples/laundry-47 --mode episode --episode 1 --min-chars 0
python scripts/project_cli.py validate --project examples/laundry-47 --mode episode --episode 2 --min-chars 0
python scripts/project_cli.py validate --project examples/laundry-47 --mode continuity
python scripts/project_cli.py status --project examples/laundry-47
python scripts/project_cli.py impact --project examples/laundry-47 --fact-id PROP47
```

- 修改目录内38项 `unittest`：**38 PASS，0 FAIL，0 ERROR，0 SKIP**（当前环境parso可用）；其中新增空白/占位、当前哈希批准、上游影响、坏JSON、无对白场正反例、样例恢复、示例事实影响等回归。
- `validate_skill.py`：PASS；示例 `verify_example.py`：PASS；15集大纲结构：PASS；EP01结构：PASS（1045非空白字符）；EP02结构：PASS（1123非空白字符）；连续性schema：PASS。
- 样例 `status`：已完成存档的是EP01和EP02，`current_version_approved=false`；不虚构真人用户批准。
- 测试样例片长3—5分钟未经录音/演出核验；这两集的字符量**并未达到**默认整季35000字符的单集均值，不可据此宣称15集量产已实测完成。

## 发布包复验

发布时从**压缩包**解压到新临时目录、从其公开 `SKILL.md` 根路径及脚本入口重新运行 `sha256sum -c MANIFEST.sha256`、`python tests/run_tests.py`、`python scripts/validate_skill.py`、`python scripts/verify_example.py`、CLI单集/事实影响/状态检查；使用 `PYTHONDONTWRITEBYTECODE=1` 以防产生缓存污染。外层成品包SHA-256在最终答复给出，以免写进包内形成自引用哈希循环。

结果：**上述重新解压复验通过**。此段只指工程验收；不代替真实创作效果评测。

## 测试边界及未覆盖

- Python3.9**真实运行缺失**（原因：无本地3.9解释器，下载DNS失败）；仅语法兼容检查+3.13运行。其它操作系统/宿主Skill自动发现是否正确未测试。
- 未运行同模型普通提示词/v1/v1.1的A/B/C作品生成比较；`evaluation/`交付可执行方案及空结果表。
- 未发生真人编审/实拍/真实观众盲评，不能证实商业效果、吸引力、片长或某平台审核通过。
- `verify_example.py` 是**预置有限断言**，不是能理解所有剧情的模型；连续性`review_if_changed`是手工登记的依赖建议，可能有遗漏。
- 审批CLI只有 `--user-confirmed` 意向标记，不具备真实身份认证；操作者不得伪造用户批准。
- 状态与HANDOFF分开写盘：如果HANDOFF追加失败，会明确发出WARNING，`project_state.json`仍是已写入的权威状态；没有跨两个文件的事务原子性。已确认的手工编辑不会被CLI自动重写。
