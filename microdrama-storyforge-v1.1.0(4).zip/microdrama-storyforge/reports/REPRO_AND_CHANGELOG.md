# 失效路径复现与修复定位（2026-10-23）

原始 `microdrama-storyforge-v1.0.0.zip` 在**单独目录**解压检测，保留原文件SHA-256于总测试报告；没有把审稿人的线索当成事先确认的Bug。以下前三个问题在原包上实际触发：

| 路径 | v1复现证据 | v1.1修改文件 / 复验 |
|---|---|---|
| Python3.9语法 | 原 `project_cli.py` 存在 `f'...{note or '存档'}...'` 的嵌套引号；`parso.load_grammar(version='3.9')` 报1处Issue | `scripts/project_cli.py`换为3.9友好格式拼接；新的3.9 grammar 0 Issue，`tests/test_python39_parso_grammar_when_available`通过。**3.9解释器不可用，真实运行未检。** |
| 空白里程碑假完成 | 把`concepts.md`、`story_bible.md`、`opening.md`替换为`# 空白成品`，v1三个`checkpoint`均返回成功 | `check_milestone()`按必需章节、有意义正文、占位与重复内容拒绝；`test_empty_milestone_checkpoint_rejected`和`test_nonempty_milestones_checkpoint`通过 |
| 批准脱离稿件版本 | v1批准EP01后编辑其正文，state中`approved_episodes: [1]`仍存在且没有版本核验 | `checkpoints`/`approvals`记录SHA-256和上游依赖；`status`只有`current_version_approved`代表当前稿；`test_approval_bound_to_hash_edited_draft_becomes_unapproved`通过 |
| 连续性JSON无效仍允许存档 | v1把`continuity.json`写为`NOT_JSON`，单集`check_project()`依然`ok: true` | `check_continuity()`检查文件/JSON根类型/事实字段；`test_continuity_invalid_json`、`test_continuity_bad_schema`通过 |
| 上游变更不提示下游 | v1仅有已批准布尔值和里程碑日志，不捕获上游文件哈希 | checkpoint保存上下游文件SHA-256依赖快照；`impact`列出已存在的后续稿；`test_change_upstream_flags_existing_downstream`通过。任何`checkpoint`后旧批准也须比对当时的上游依赖快照，防止未经重新批准自动恢复 |
| final与内容终审混淆 | v1 final只返回`ok`与“静态不代表版权”；无法按文件展示当前批准 | `check_project()`新增`format_valid`、`content_review:not_performed`、`audience_validation:not_performed`和限制说明；`test_final_structural_pass_is_not_approval`通过 |
| 保护人工和历史记录 | v1初始化能保护非空目录，但异常后的结果状态未形成更强验证 | 保留不可覆盖初始化，异常验前不修改历史或HANDOFF；`test_failure_does_not_create_false_history`、`test_init_safe_no_overwrite`通过；checkpoint/approve保留全部历史 |
| 写作规则矫正过度 | v1每场对白硬性要求，静默动作戏一定被判错 | 放行经过可拍动作+简短无对白理由标识的场次；`test_silent_scene_with_visual_logic_allowed`、负例测试通过。`references/creative-exceptions.md`给出目的/条件/正反例 |

> 注意：上述复现属于局部可复现路径，不说明原版其它未列功能一定有问题。空白概念或剧本即便有少量具体文字也不代表文学质量高；新规则是最低格式防线，未声称“自动识别好剧本”。

## 六类增强对应位置

- 工程可靠性：`scripts/project_cli.py`、`tests/run_tests.py`、`scripts/verify_example.py`。
- 创作弹性与可保留特质：`references/creative-exceptions.md`、`references/script-craft.md`、`references/story-engine.md`、`references/quality-gates.md`、`SKILL.md`。
- 连续性可追溯：`assets/continuity.template.json`、`references/continuity-ledger.md`、`examples/laundry-47/continuity.json`。
- 受众与生产约束：`assets/audience_brief.template.md`、`references/genre-audience.md`、`SKILL.md`。
- 原创贯穿案例：`examples/laundry-47/` 的两集正文、故事圣经、完整15集纲、HANDOFF、事实账。
- 实验比较：`evaluation/benchmark_case.md`、`protocol.md`、`blind_judge_sheet.md`、`results_template.csv`。
