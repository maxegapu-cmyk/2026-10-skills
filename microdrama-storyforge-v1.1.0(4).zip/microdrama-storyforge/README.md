# Microdrama Storyforge v1.1.0｜十三职能原创短剧 Skill

**用途**：给一个模型/创作团队提供短剧构思、剧本、审稿、工程状态和连续性核验的**工作流**，不是自动跑13个独立代理，也不是“保证爆款”软件。默认15集、全季约35000**非空白可见字符**、按集交付；项目作者明确改规格时以作者定稿为准。场次格式延续 `第X集`、`X-1 地点 时间/内外景`、`人物：`、`△`、`角色（动作）：对白`、`（第X集 完）`。

## 这次真正修改了什么

- **工程信任修复**：完成里程碑不再以文件“存在”算完成；空白、待定、模板占位会被拒。`checkpoint` 按正文SHA-256落盘，`approve --user-confirmed`把用户明确批准绑定具体哈希和上游版本；正文或设定变化旧批准不再适用于当前作品。
- **连续性更可追溯**：`continuity.json`增加 `facts[]`：集场来源、客观/误认、谁知情、变化事件、下游复核引用；保留旧人物/道具/时间线。`impact --changed bible`查设定变更、`impact --fact-id SECRET_BAG`查具体事实影响，**只提示复核，不自动重写**。
- **创作方法避免过拟合**：旧“每场必须对白/反转必改策略/每胜必罚/反派不能失手/场场提速”等改成带适用范围、可判断的例外和正反例；增加重大返修时最长四行的特色保护。
- **题材与制作条件**：`audience_brief.md`把抽象“平台/下沉用户”落到观看情境、类型、情绪承诺、时长、预算和保留/禁用元素；不把设计假设伪装成市场数据。
- **实物测试资料**：`examples/laundry-47/` 含15集大纲、故事圣经、连续两集完整原创正文、有人物/证物/秘密/承诺的账本和HANDOFF；`evaluation/`为普通提示词/v1.0.0/v1.1.0对照盲评提供统一素材与表格，**尚未做真实A/B/C生成实验**。

保留用户原13个职能（`ag_001`～`ag_013`），不混入其他私有系统。原始用户文字仅作为资料保存在 `source/original-user-material.txt`，未经授权不应公开该文件。

## 安装与版本边界

将ZIP里的 **`microdrama-storyforge/`** 放到支持Skill目录的宿主路径下；其内应有 `SKILL.md`、`scripts/`、`references/`、`assets/`。Python工具只依赖标准库，源码按Python3.9语法编写；**目前验证是Python3.13真实运行 + parso的3.9语法解析；无Python3.9解释器，因此不宣称3.9运行验证通过**。

## 操作示例（在Skill根目录）

```bash
python scripts/project_cli.py init --project ./my-drama
# 根据创作素材填写 audience_brief.md、concepts.md、story_bible.md、outline.md 等
python scripts/project_cli.py validate --project ./my-drama --mode outline
python scripts/project_cli.py checkpoint --project ./my-drama --stage outline --note "大纲草稿落盘"
python scripts/project_cli.py status --project ./my-drama
# 仅当真人用户明确批准这一稿时：
python scripts/project_cli.py approve --project ./my-drama --stage outline --user-confirmed --note "用户明确批准当前大纲"

# 剧本写入 my-drama/episodes/EP01.md 后：
python scripts/project_cli.py validate --project ./my-drama --mode episode --episode 1
python scripts/project_cli.py checkpoint --project ./my-drama --stage episode --episode 1
python scripts/project_cli.py impact --project ./my-drama --changed bible
python scripts/project_cli.py impact --project ./my-drama --fact-id PROP47
python scripts/project_cli.py validate --project ./my-drama --mode continuity
python scripts/project_cli.py validate --project ./my-drama --mode final
python tests/run_tests.py
python scripts/verify_example.py
```

`impact --fact-id PROP47`适用于样例；个人项目须使用自己账本里的ID。`--mode final` **PASS只说明工程结构检查通过**，不表示内容审稿、权利审查、批准、时长验证或观众验证通过。`status`里的 `current_version_approved` 是唯一当前版批准提示；旧 `approved` 或 `approved_episodes` 布尔/数字列表只是兼容历史，不能作为当前审批依据。脚本不会主动抽取自然语言剧情事实，账本由作者或模型在核对正文后维护。

## 用样例验证跨会话接手

只给接手者 `examples/laundry-47/`，先读其中 `HANDOFF.md`，对照 `continuity.json` 的 `PROP47`/`SECRET_BAG`/`PROMISE_17` 和 `episodes/EP01.md`、`EP02.md`，再续写EP03。脚本 `verify_example.py`检查可解析结构与有限的关键场次/证物锚点；**没有在一个真正独立的下一次会话里重新让模型完成EP03，这部分仍待实测**。

## 验收证据

- `reports/REPRO_AND_CHANGELOG.md`：原版能复现的问题、修法及对应源码/回归测试。
- `reports/TEST_REPORT.md`：真实环境/命令/通过/失败/跳过/未覆盖和重新解包发布测试。
- `reports/SIX_DIMENSIONS.md`：六维“已证实到哪一层”，不是营销自评分。
- `evaluation/protocol.md`：可复现的外部A/B/C盲评操作步骤和明确尚未运行的边界。

## 重要迁移事项

**先备份旧项目，再迁移。** 旧 `continuity.json` 没有 `facts[]` 时需手工加 `"facts": []` 并升级为 `schema_version: "1.1"`；再次阅读和checkpoint现有文件。旧批准缺少具体哈希，**不会被自动认证**。用户可重新明确批准。新工具不会替换原包或偷偷修订旧稿。
