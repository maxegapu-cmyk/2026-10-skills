# 设定考据与故事边界

以下资料于 2026-10-23 检索。游戏中所有角色台词、战斗场景、守城选择、撤离数字均为同人原创，不能用来当作暴雪官方设定。

## A. 官方确认的核心事件（取材于官方游戏/手册及其资料汇编）

1. **阿尔萨斯弑父，并率天灾蹂躏洛丹伦**。暴雪《魔兽世界经典版》英文手册概述其利用霜之哀伤、杀死泰瑞纳斯和乌瑟尔、将洛丹伦陷于天灾。原始手册 PDF：https://us.media.blizzard.com/manuals/wow/wow-classic-manual-enUS.pdf
2. **亡灵战役第一关的开场文字说明瘟疫扩散到王城及郊区，王国军队因国王死去而陷于惊恐与分散**。资料：https://warcraft.wiki.gg/wiki/Trudging_through_the_Ashes_(WC3_Undead)
3. **法瑞克（Falric）与马维恩（Marwyn）是阿尔萨斯原部下，后成为死亡骑士，参与对王城居民的屠戮。**资料条目引《Arthas: Rise of the Lich King》（小说）并有《魔兽世界》「映像大厅」冒险指南信息：https://warcraft.wiki.gg/wiki/Falric ；https://warcraft.wiki.gg/wiki/Marwyn
4. **乌瑟尔护卫泰瑞纳斯的骨灰瓮，最终在安多哈尔一带被阿尔萨斯杀害，骨灰瓮被夺走**。这发生在《混乱之治》亡灵战役第二关「Digging up the Dead」：https://warcraft.wiki.gg/wiki/Digging_up_the_Dead_(WC3_Undead)
5. **洛丹伦的抵抗不是与泰瑞纳斯死亡同时、全域瞬间消失**，可参考王城/王国后续抵抗者与难民历史：https://warcraft.wiki.gg/wiki/Capital_City 和 https://warcraft.wiki.gg/wiki/Lordaeron_(kingdom)

## B. 合理推断，但没有精确军史可证

- 不可能用弑父画面直接推出「所有王城卫队在同一分钟内被消灭」；原作亦没有给出如此结论。
- 洛丹伦陷落叙事可以用「战前瘟疫破坏人口与基层治理 + 地下教派潜伏 + 王权中枢遭突然斩首 + 内应与亡灵复活的滚雪球 + 城市和外部要塞被逐个击破」解释。这是基于多项已确认要素的**因果综合**，不是官方公布的完整战役年表。
- 数十万守军的估值目前没有可靠官方明确军队编制资料支撑；不能把玩家猜测作为已知。
- 游戏中的五章之间不存在官方确认的精确时长，章节名是戏剧结构，并非历法上的逐日回放。

## C. 已找到、可额外游玩的《魔兽争霸 III》模组（不是本项目）

- *Return of the King*：假设泰瑞纳斯幸存的 **IF 线**，有乌瑟尔等可玩角色。2025 年 HiveWorkshop 作品：https://www.hiveworkshop.com/threads/return-of-the-king.364559/
- *Scourge of Lordaeron: Reborn*：2026 年上线的《混乱之治》人类战役**扩展重讲**，主要集中阿尔萨斯堕落之前，不等于完整的弑父后「王城守军军事报告」：https://www.hiveworkshop.com/threads/scourge-of-lordaeron-reborn-v1-1.373046/
