# UE5 Niagara VFX Forge v1.0.0

> 外发纯净版 · UE5 游戏特效 Skill · 2026-10-22

**这是什么**：专为 UE5 Niagara 游戏特效建立的 *AI 代理 Skill + 离线特效规格编译器 + Unreal Editor 资产复制桥接工具*。重点不是套话，而是有时间轴、有粒子层、有变量契约、有蓝图落地、有性能预算、有验证出口。

**适用**：Codex / Claude Code / 其他支持 SKILL.md 的本地代理；UE 5.4～5.8 以文档层面的方案兼容为目标，当前基线 UE 5.8。引擎真实 API/资产效果仍须在用户项目验证。

## 最快使用：三个步骤（不会动 UE 项目）

将解压出的 `ue5-niagara-vfx-forge` 文件夹复制到你项目的 `.agents/skills/`（如果你的代理不扫描该位置，按对应客户端文档放进 Skills 目录），然后在 Codex/Claude Code 直接说：

> 使用 ue5-niagara-vfx-forge 帮我做一个 UE5 的二段式雷电斩击，要求 Niagara 可做、同步 AnimNotify、有爆发和尾迹、适配 60FPS 的第三人称战斗，生成可执行施工单，不能动原资产。

或者不用 AI，打开终端运行：

```bash
python scripts/forge.py presets
python scripts/forge.py new --preset arcane_impact --name demo_impact --out demo_impact.json
python scripts/forge.py build demo_impact.json --out build/demo_impact_v1
```

输出：

- `PLAN.md`：每层开始时间、结束时间、发射模式、粒子数/寿命/速度、材质、User 参数、蓝图触发。
- `UE_STEPS.md`：UE5 编辑器操作与安全复制已有模板的方法。
- `QA.md`：实机验收表。
- `INSTALL_MANIFEST.json`：供 Unreal Editor Python 读取的安全克隆数据。
- `SOURCE_SPEC.json`：源规格快照。

**这并不等于一键生成完整 Niagara `.uasset`**。完整模块图需要在 UE 项目内完成；脚本只负责离线方案生成和 UE Editor 内复制已有 Niagara System，不会假称已自动生成所有节点。

## 真正落入 UE5 项目

1. 打开目标 `.uproject`，启用 **Niagara**；若要用桥接工具再启用 **Python Editor Script Plugin**、**Editor Scripting Utilities**，按提示重启。
2. 在 Content Browser 中创建一个 Niagara System 空白底座（例如 `NS_SeedMagic`），设置上述 JSON 里的 `seed_system` 为 `/Game/VFX/NS_SeedMagic`，重新 `build` 到**新目录**。
3. 在 Unreal Editor Python Console 中先运行：

```python
import os
os.environ['UE_VFX_MANIFEST'] = r'C:\absolute\path\build\demo_impact_v2\INSTALL_MANIFEST.json'
os.environ['UE_VFX_DRY_RUN'] = '1'  # 先干跑，确认 source/destination
```

4. Unreal Editor 中 `Tools > Execute Python Script` 选择压缩包内 `unreal/ue_bridge.py`，核对打印 `DRY_RUN`。然后 `os.environ['UE_VFX_DRY_RUN']='0'` 再执行一次，才真实复制目标 Niagara 资产。**目标已存在则立刻拒绝，不覆盖**。
5. 双击新生成的 `NS_demo_impact`，按 `PLAN.md` 编辑 Emitter/Modules/Renderer；在 System Parameters 创建并**绑定** User 参数。根据 `UE_STEPS.md` 将效果接入蓝图。
6. 完成 PIE 与打包测试，再记录 Unreal Insights / Niagara Debugger 数据填 `QA.md`。

## 十种内置配方

`arcane_impact`（命中）、`sword_slash`（刀剑）、`fireball_cast`（火球）、`sci_fi_explosion`（爆炸）、`muzzle_flash`（枪口火焰）、`lightning_strike`（落雷）、`teleport_gate`（传送门）、`energy_shield`（护盾）、`forest_fireflies`（环境萤火）、`healing_spell`（治疗）。都是方便修改的设计起点，没有外部图包依赖。

## 随包附赠：能直接导入 UE5 的原创粒子贴图

`assets/generated-textures/` 有 5 张可直接导入 Content Browser 的 RGBA PNG（`SoftDisc` 柔光、`ShockRing` 冲击环、`Spark` 星芒、`SlashArc` 刀弧、`SmokeMask` 烟雾）。**这是可用素材，不是完整材质或 Niagara Graph。**

如果要用不同分辨率生成新版本，在包目录运行：

```bash
python scripts/make_textures.py --out my_masks --size 512
```

UE 手动导入时直接拖 PNG 进 Content Browser 即可。若用 Editor Python **批量且不覆盖**地导入，先在 UE Python Console 设置：

```python
import os
os.environ['UE_VFX_TEXTURES_DIR'] = r'C:\absolute\path\ue5-niagara-vfx-forge\assets\generated-textures'
os.environ['UE_VFX_TEXTURES_DST'] = '/Game/VFXForge/Textures'
os.environ['UE_VFX_DRY_RUN'] = '1'
```

用 `Tools > Execute Python Script` 运行 `unreal/ue_import_textures.py`，检查 Dry Run 列表；确认目录是自己项目的新目录，再设 `UE_VFX_DRY_RUN='0'` 重跑。系统会拒绝覆盖同名 Texture。接着在 UE5 内创建 `M_` 材质，使用 Mask 的 **Alpha 通道** 控制透明/发光；PNG 作为原始贴图并不等于已经接好了材质。

## 性能数据对照

```bash
python scripts/forge.py audit assets/presets/arcane_impact.json examples/measured_example.json
```

该示例包含**故意超标**的模拟量测，用来展示 `FAIL` 分支。并非真实引擎基准。真实项目测量一定要填引擎版本、硬件、分辨率、效果实例数和采集记录。

## 常见错误

- `ERROR: seed_system...`：手工建立合法 Niagara System，填 `/Game/...` 资源路径，再 build。
- `EditorAssetLibrary missing`：检查 Editor Scripting Utilities 插件是否启用并重启。
- `UE_VFX_MANIFEST`：路径应是 `INSTALL_MANIFEST.json` 的绝对文件路径；Windows 用 Python `r'...'`。
- `Destination asset already exists`：禁止直接重复执行，应使用新 `id` 或在人工确认后完成版本迁移。
- `build 目录已有文件`：用新目录，例如 `build/demo_impact_v2`，保护旧成果。
- `Niagara 没有视觉变化`：复制的只是模板副本。只有按 PLAN 施工并保存，效果才会改变。

## 权限、许可证与外部资源

本包脚本和原创文字采用 MIT License。参考文档列有官方 Epic 文档、GitHub 社区示例，但没有从外部搬运 `.uasset`、素材贴图、收费案例或他人完整 Skill 内容。Epic 示例包若使用须自行通过相应官方渠道取得并遵守其许可。

## 发布边界

验证完成：Python 语法、JSON 规格、CLI 构建、覆盖保护、模拟 Unreal 编辑器 API 合约测试。**未完成**：真实 UE5 Editor 引擎运行与 Niagara Graph 自动创建、渲染画面视觉验收、移动端/主机打包验证（当前环境无 UE5）。
