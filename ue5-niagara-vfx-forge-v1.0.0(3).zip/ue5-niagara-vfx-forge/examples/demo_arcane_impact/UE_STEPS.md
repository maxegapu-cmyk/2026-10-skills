# UE5 实机落地步骤 — 奥术命中 / Arcane Impact

当前 `seed_system=null`，桥接脚本会拒绝资产复制，这是安全的。先在 UE 内创建一个 Niagara System 模板并填写其 `/Game/...` 路径，再执行 `forge.py build`。

## 先配置

1. 在 UE5 项目中开启 **Niagara**；若运行 Python，再开启 **Python Editor Script Plugin** 和 **Editor Scripting Utilities**（重启编辑器）。
2. 打开 UE Content Browser，确认目标工程中能找到所有需要的 Seed、材质和贴图资源。
3. 外部执行 `python scripts/forge.py build <SPEC.json> --out <输出目录>`，生成包含 `INSTALL_MANIFEST.json` 的文件夹。
4. UE 菜单 `Tools > Execute Python Script` 打开包内 `unreal/ue_bridge.py` 前，在 Python Console 设置环境变量：

```python
import os
os.environ['UE_VFX_MANIFEST'] = r'C:\absolute\path\to\INSTALL_MANIFEST.json'
```

5. 运行 Python 脚本：UE 菜单 Tools > Execute Python Script > `ue_bridge.py`，或者编辑器 Python Console 执行：

```python
exec(compile(open(r'C:\path\to\unreal\ue_bridge.py', encoding='utf-8').read(), r'C:\path\to\unreal\ue_bridge.py', 'exec'))
```

**重要**：桥接程序仅安全复制现有 Niagara 资产（不会重建其 Emitter/Module 图），遇到同名目标会停止；必须在 UE 中按 `PLAN.md` 完成图层改造。复制成功不等于视觉或性能达标。

## 真正搭出效果

- 打开 `/Game/VFXForge/NS_arcane_impact`，在 Niagara System Overview 添加/调整各图层对应的 Emitter。
- `Emitter Spawn/Update` 管控制器生成；`Particle Spawn/Update` 管每粒出生、运动和衰减；Renderer 管最终表现。
- Sprite/Mesh/Ribbon 选择合适 Renderers；Decal/Light 可用材质/单独组件实现，并非任意 Niagara 版本都有同名 Renderer。
- 参数统一在 Niagara System Parameters 中创建 `User.*`，再绑定模块输入；Runtime 中由 Blueprint 传值。
- 材质按 `references/materials-and-techniques.md` 使用 Unlit、Masked/Additive/Translucent，避免过绘和曝光失控。
- 逐层 Solo 观察出生点、方向、寿命、Z fighting、法线、遮挡关系和层次顺序。
- 正式进入关卡和游戏时再叠加 Niagara Effect Type/Scalability/Culling/Pooling。

## 出错时

- `UE_VFX_MANIFEST` 未设置：在同一 Unreal Editor Python 进程里设置到实际生成路径（绝对路径）。
- Seed 不存在：Content Browser 复制真实路径，修改源 JSON 的 `seed_system`，重建 manifest。
- 目标已存在：不覆盖；更换 `id` 或手动决定该版本的迁移/回滚。
- Python API 缺失：核对插件并重启；查 `references/ue5-compatibility.md`。
- 视觉看不出变化：这是预期，bridge 只复制底座资产；Niagara 内仍须实际修改 Renderer/Emitter/Modules。
