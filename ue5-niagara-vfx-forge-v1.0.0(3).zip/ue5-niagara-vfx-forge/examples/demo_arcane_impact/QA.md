# QA 记录 — 奥术命中 / Arcane Impact

**状态：UNTESTED — 尚无实机证据。** 填完后再确定 PASS/FAIL。

- UE 完整版号：_____；目标平台/硬件：_____
- 场景/光照/相机：_____；打包模式：_____
- 分辨率/屏幕百分比：_____；Scalability：_____
- 粒子平均/峰值：_____ / _____（预算：150）
- 实例数：1 / 8 / 实战压力测试
- Niagara CPU/GT：_____ ms（规划：≤0.18 ms）
- Niagara GPU：_____ ms（规划：≤0.35 ms）
- 时序、大小、视角、材质、对比度、受击可读性：PASS / FAIL
- 编辑器编译 + PIE + Shipping/Development 构建检查：PASS / FAIL
- 问题复现步骤、修法、二次测量：_____

可用 `python scripts/forge.py audit <spec.json> <measured.json>` 运行保守阈值对照；示例在 `examples/measured_example.json`。工具检测不了 Niagara 真正画面是否漂亮。
