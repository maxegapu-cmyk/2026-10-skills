# 奥术命中 / Arcane Impact — Niagara 生产施工单

> 这是按规格生成的设计/制作指令，不是已经生成的 Niagara Graph 或已通过 UE 实机验收的效果。

- UE 目标版：5.8；模式：gameplay；平台：pc
- 总时长：1.05 秒；一次性；设计尺度：150 cm；目标 FPS：60
- Niagara 路径：`/Game/VFXForge/NS_arcane_impact`
- 视觉目标：0.08 秒内识别撞击点、脉冲半径与发射方向；尾部 0.9 秒消散
- 一眼可读标准：将镜头拉远 10 米并关闭 Bloom，仍能辨别打击点与受击方向

## 一、节奏与图层（逐层可执行）

### 1. ContactFlash — 接触瞬时高亮，不可遮盖目标轮廓
- 窗口：0–0.1 秒；Renderer：sprite；模拟：stateless
- Spawn：burst，数量 1
- 寿命：0.05–0.1 s；尺寸：25–55 cm；初速度：0–0 cm/s
- 模块搜索词（按所在阶段放置，名称可能因版本略有变化）：Initialize Particle, Scale Sprite Size, Scale Color
- 材质：先用临时 Debug Material，不依赖缺失的外部素材
- 施工提醒：先钉住 Impact Normal，使用柔和边缘。

### 2. RadialShards — 环状火花与断裂短线
- 窗口：0.018–0.45 秒；Renderer：sprite；模拟：cpu
- Spawn：burst，数量 22
- 寿命：0.15–0.39 s；尺寸：2–8 cm；初速度：180–650 cm/s
- 模块搜索词（按所在阶段放置，名称可能因版本略有变化）：Initialize Particle, Add Velocity, Drag, Scale Color
- 材质：先用临时 Debug Material，不依赖缺失的外部素材
- 施工提醒：速度沿半球法线分布，统一暗尾。

### 3. ShockRing — 薄环外扩、快速变淡
- 窗口：0.025–0.28 秒；Renderer：sprite；模拟：stateless
- Spawn：burst，数量 1
- 寿命：0.22–0.28 s；尺寸：30–200 cm；初速度：0–0 cm/s
- 模块搜索词（按所在阶段放置，名称可能因版本略有变化）：Initialize Particle, Scale Sprite Size, Scale Color
- 材质：先用临时 Debug Material，不依赖缺失的外部素材
- 施工提醒：应使用环状材质，Sprite size 由曲线驱动，而不是试图用速度移动整个平面。

### 4. Afterglow — 弱残光与极少尘粒
- 窗口：0.15–1.05 秒；Renderer：sprite；模拟：cpu
- Spawn：burst，数量 12
- 寿命：0.4–0.85 s；尺寸：4–14 cm；初速度：12–55 cm/s
- 模块搜索词（按所在阶段放置，名称可能因版本略有变化）：Initialize Particle, Drag, Scale Color
- 材质：先用临时 Debug Material，不依赖缺失的外部素材
- 施工提醒：控制透明面积；中远景应先消失。

## 二、User 参数契约（必须在 Niagara System 中真实创建并绑定）

| Niagara 参数 | 类型 | 初始值 | 使用约定 |
|---|---|---|---|
| `User.Intensity` | Float | `1.0` | 由击中强度或技能等级控制；需绑定到大小/发射量输入 |
| `User.Tint` | LinearColor | `[0.3, 0.7, 1.0, 1.0]` | 统一视觉主题；应连接材质/颜色模块 |

## 三、关卡/蓝图触发

- 事件：OnGameplayHit
- 出生方式：at_location
- 触发位置：HitResult.ImpactPoint
- 多人语义：cosmetic_local（注意不要让视觉特效改变权威游戏逻辑）

1. Content Browser 中右键创建 Niagara System，基于 Empty/Minimal 或已有合法模板。
2. 在 System Overview 按施工单创建 Emitter 或添加 stateless emitter；逐层验证单独渲染正确，再合成。
3. 用 User 参数链接颜色/强度/尺寸等，绑定到所需模块输入；仅声明参数而未绑定不会生效。
4. 通过蓝图 `Spawn System at Location` 或 `Spawn System Attached` 调用，保存返回的 Niagara Component，根据类型调用 `Set Niagara Variable ...`。
5. 仅在目标平台的 PIE 和打包构建中确认视觉、材质、碰撞、绑定与性能。

## 四、性能预算（规划上限，未测量）

- 单实例 Niagara GT/CPU 目标：≤ 0.18 ms；GPU 目标：≤ 0.35 ms
- 预估同时存活粒子建议上限：150；场景内同时激活实例：8
- 以上数值是用户可调整的初始预算，不是保证值。测试以 Unreal Insights / Niagara Debugger 为准，统计峰值与重复触发。

## 五、常见失败与反查

- 强发光面积过大：先压低亮区面积、改用局部主高光，再调 Emissive，避免整体白屏。
- 光效跟不上游戏动作：先核对事件时间、Socket/ImpactPoint 空间、世界/局部坐标，再查粒子速度。
- 手机或 VR 渲染爆炸：检查 Translucency 过绘、双面材质、GPU 模块支持、分辨率和后处理。
- 重复触发掉帧：测真实多实例峰值，必要时合并到 Data Channel 或使用 Effect Type Cull。

## 六、封板门槛

- [ ] Gameplay 时序匹配：击中、受击、死亡/受击反馈时点清晰，不被光污染遮挡。
- [ ] 单一特效/8 个实例/场景复杂工况分别截屏或录屏，有证据可回放。
- [ ] 近距离、远距离、背光、亮背景均可读；必要时做不同颜色主题与无后处理检查。
- [ ] 粒子上限、消失/循环、Pooling、Bounds、Cull、打包后资源无丢失。
- [ ] 记录真实 CPU/GPU 帧耗时及设备/分辨率/扩展性等级；不以口头“流畅”代替。
- [ ] UE 编辑器内 Asset 打开、Niagara 编译无错误、PIE 与目标打包无阻断。
