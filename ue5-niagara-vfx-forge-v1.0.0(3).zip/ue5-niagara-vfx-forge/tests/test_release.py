"""Offline regression tests. No fake claim that actual Unreal Editor is tested."""
import copy
import importlib.util
import json
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def load_module(name, location):
    spec = importlib.util.spec_from_file_location(name, ROOT / location)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

forge = load_module('forge', 'scripts/forge.py')
bridge = load_module('bridge', 'unreal/ue_bridge.py')
texgen = load_module('texgen', 'scripts/make_textures.py')
teximport = load_module('teximport', 'unreal/ue_import_textures.py')

class FakeNiagaraSystem: pass

class FakeLibrary:
    def __init__(self):
        self.store = {'/Game/Seeds/NS_Base': FakeNiagaraSystem()}
        self.dirs = {'/Game/Seeds'}
        self.saved = []
        self.fail_save = False
        self.writes = 0
    def does_asset_exist(self, path): return path in self.store
    def load_asset(self, path): return self.store.get(path)
    def does_directory_exist(self, path): return path in self.dirs
    def make_directory(self, path): self.writes += 1; self.dirs.add(path); return True
    def duplicate_asset(self, src, dst):
        self.writes += 1
        self.store[dst] = FakeNiagaraSystem()
        return self.store[dst]
    def save_asset(self, path, only_if_is_dirty=False):
        self.writes += 1
        self.saved.append(path)
        return not self.fail_save

class FakeUnreal:
    NiagaraSystem = FakeNiagaraSystem
    def __init__(self): self.EditorAssetLibrary = FakeLibrary()

class ForgeSpecTests(unittest.TestCase):
    def setUp(self):
        self.s = forge.load_json(ROOT / 'assets/presets/arcane_impact.json')
    def test_every_preset_is_valid(self):
        files = sorted((ROOT / 'assets/presets').glob('*.json'))
        self.assertEqual(len(files), 10)
        for file in files:
            with self.subTest(file=file.name):
                forge.validate(forge.load_json(file))
    def test_plan_contains_critical_contract(self):
        doc=forge.to_md(self.s)
        for key in ('ContactFlash', 'RadialShards', 'User.Intensity', '性能预算', '未测量'):
            self.assertIn(key,doc)
    def test_build_non_destructive_and_all_files(self):
        with tempfile.TemporaryDirectory() as td:
            dest=Path(td)/'output'
            forge.build(ROOT/'assets/presets/arcane_impact.json',dest)
            self.assertEqual(len(list(dest.iterdir())),5)
            m=json.loads((dest/'INSTALL_MANIFEST.json').read_text())
            self.assertEqual(m['destination_system'],'/Game/VFXForge/NS_arcane_impact')
            with self.assertRaises(forge.SpecError): forge.build(ROOT/'assets/presets/arcane_impact.json',dest)
    def test_parameter_name_case_duplicate(self):
        s=copy.deepcopy(self.s)
        s['user_parameters'].append(dict(name='user.Intensity',type='Float',default=1.0))
        with self.assertRaises(forge.SpecError): forge.validate(s)
    def test_unsafe_destination_blocked(self):
        s=copy.deepcopy(self.s); s['output_directory']='/Engine/Bad'
        with self.assertRaises(forge.SpecError): forge.validate(s)
    def test_no_recursive_self_clone(self):
        s=copy.deepcopy(self.s); s['seed_system']='/Game/VFXForge/NS_arcane_impact'
        with self.assertRaises(forge.SpecError): forge.validate(s)
    def test_invalid_timing_blocked(self):
        s=copy.deepcopy(self.s); s['layers'][0]['timing']['end_s']=1.6
        with self.assertRaises(forge.SpecError): forge.validate(s)
    def test_missing_param_binding_typing(self):
        s=copy.deepcopy(self.s); s['user_parameters'][0]['default']='strong'
        with self.assertRaises(forge.SpecError): forge.validate(s)
    def test_nan_fails(self):
        s=copy.deepcopy(self.s); s['budget']['max_gpu_ms']=float('nan')
        with self.assertRaises(forge.SpecError): forge.validate(s)
    def test_presets_cli(self):
        self.assertEqual(forge.cli(['presets']),0)
    def test_new_refuses_overwrite(self):
        with tempfile.TemporaryDirectory() as td:
            target=Path(td)/'effect.json'
            self.assertEqual(forge.cli(['new','--preset','sword_slash','--name','new_sword','--out',str(target)]),0)
            self.assertEqual(forge.load_json(target)['id'],'new_sword')
            self.assertEqual(forge.cli(['new','--preset','sword_slash','--name','new_sword','--out',str(target)]),2)
    def test_audit_fail_synthetic(self):
        s=self.s
        m=forge.load_json(ROOT/'examples/measured_example.json')
        result=forge.audit(s,m)
        self.assertEqual(result['status'],'FAIL')
        self.assertTrue(any('gpu_ms' in f for f in result['failures']))
    def test_audit_pass_is_self_reported(self):
        m=forge.load_json(ROOT/'examples/measured_example.json')
        m.update(cpu_ms=0.05,gpu_ms=0.10,peak_alive_particles=55,visual_pass=True,packaged_pass=True)
        self.assertIn('self-reported',forge.audit(self.s,m)['status'])

class UnrealBridgeTests(unittest.TestCase):
    def setUp(self):
        self.m={'manifest_version':'1.0','operation':'duplicate_seed_only','non_destructive':True,
                'source_system':'/Game/Seeds/NS_Base','destination_system':'/Game/VFXForge/NS_New','engine_target':'5.8'}
        self.ue=FakeUnreal()
    def run_bridge(self, dry=False):
        with tempfile.TemporaryDirectory() as td:
            path=Path(td)/'manifest.json'; path.write_text(json.dumps(self.m))
            return bridge.execute(self.ue,str(path),dry_run=dry)
    def test_dry_run_is_read_only(self):
        result=self.run_bridge(dry=True)
        self.assertEqual(result['status'],'DRY_RUN')
        self.assertEqual(self.ue.EditorAssetLibrary.writes,0)
    def test_actual_clones_without_deletion(self):
        result=self.run_bridge()
        self.assertEqual(result['status'],'CREATED')
        self.assertIn('/Game/Seeds/NS_Base',self.ue.EditorAssetLibrary.store)
        self.assertIn('/Game/VFXForge/NS_New',self.ue.EditorAssetLibrary.store)
        self.assertEqual(self.ue.EditorAssetLibrary.saved,['/Game/VFXForge/NS_New'])
    def test_existing_target_never_touched(self):
        old=FakeNiagaraSystem()
        self.ue.EditorAssetLibrary.store['/Game/VFXForge/NS_New']=old
        with self.assertRaises(FileExistsError): self.run_bridge()
        self.assertIs(self.ue.EditorAssetLibrary.store['/Game/VFXForge/NS_New'],old)
        self.assertEqual(self.ue.EditorAssetLibrary.writes,0)
    def test_missing_seed_fails_before_write(self):
        self.m['source_system']='/Game/Missing/NS_None'
        with self.assertRaises(FileNotFoundError): self.run_bridge()
        self.assertEqual(self.ue.EditorAssetLibrary.writes,0)
    def test_bad_manifest_path_fails(self):
        self.m['destination_system']='/Game/../../Engine/Replace'
        with self.assertRaises(ValueError): self.run_bridge()
        self.assertEqual(self.ue.EditorAssetLibrary.writes,0)
    def test_save_failures_are_visible(self):
        self.ue.EditorAssetLibrary.fail_save=True
        with self.assertRaises(RuntimeError): self.run_bridge()
        self.assertIn('/Game/VFXForge/NS_New',self.ue.EditorAssetLibrary.store)
    def test_wrong_asset_type_fails(self):
        self.ue.EditorAssetLibrary.store['/Game/Seeds/NS_Base']=object()
        with self.assertRaises(TypeError): self.run_bridge()

class TextureTests(unittest.TestCase):
    def test_png_structure_and_no_overwrite(self):
        with tempfile.TemporaryDirectory() as td:
            self.assertEqual(texgen.generate(td,64),5)
            for p in Path(td).glob('*.png'):
                b=p.read_bytes()
                self.assertTrue(b.startswith(b'\x89PNG\r\n\x1a\n'))
                self.assertGreater(len(b),500)
            with self.assertRaises(FileExistsError): texgen.generate(td,64)
    def test_non_power_two_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            with self.assertRaises(ValueError): texgen.generate(td,250)
    def test_ue_import_preflight(self):
        with tempfile.TemporaryDirectory() as td:
            (Path(td)/'T_VFXForge_Test.png').write_bytes(b'fake')
            ue=FakeUnreal()
            res=teximport.import_textures(ue,td,'/Game/Textures/VFX',dry_run=True)
            self.assertEqual(len(res),1)
            self.assertEqual(ue.EditorAssetLibrary.writes,0)
            with self.assertRaises(ValueError): teximport.import_textures(ue,td,'/Engine/Bad',dry_run=True)
            ue.EditorAssetLibrary.store['/Game/Textures/VFX/T_VFXForge_Test']=object()
            with self.assertRaises(FileExistsError): teximport.import_textures(ue,td,'/Game/Textures/VFX',dry_run=False)

if __name__ == '__main__': unittest.main(verbosity=2)
