# -*- coding: utf-8 -*-
"""UE Editor Python: optional import original PNG masks to a NEW /Game location.

Required:
UE_VFX_TEXTURES_DIR=<absolute folder with T_VFXForge_*.png>
UE_VFX_TEXTURES_DST=/Game/VFXForge/Textures
Optional:
UE_VFX_DRY_RUN=1
"""
import os
import re
from pathlib import Path


def import_textures(unreal_api, source_dir, dst, dry_run=False):
    if not re.fullmatch(r'/Game(?:/[A-Za-z0-9_]+)+', dst):
        raise ValueError('Destination must be a /Game/child content directory')
    folder = Path(source_dir)
    if not folder.is_dir():
        raise FileNotFoundError('Source texture directory does not exist: '+str(folder))
    files = sorted(folder.glob('T_VFXForge_*.png'))
    files = [f for f in files if re.fullmatch(r'T_VFXForge_[A-Za-z0-9_]+\.png', f.name) and f.is_file()]
    if not files:
        raise ValueError('No matching T_VFXForge_*.png files')
    editor = unreal_api.EditorAssetLibrary
    # Atomic preflight: no asset import until *all* target names are free.
    for src in files:
        out_asset = dst + '/' + src.stem
        if editor.does_asset_exist(out_asset):
            raise FileExistsError('Refusing to replace existing Unreal texture: ' + out_asset)
    if dry_run:
        return ['DRY_RUN: ' + dst + '/' + f.stem for f in files]
    if not editor.does_directory_exist(dst) and not editor.make_directory(dst):
        raise RuntimeError('Cannot create destination in Content Browser: '+dst)
    tools = unreal_api.AssetToolsHelpers.get_asset_tools()
    imported = []
    for src in files:
        task = unreal_api.AssetImportTask()
        task.set_editor_property('filename', str(src.resolve()))
        task.set_editor_property('destination_path', dst)
        task.set_editor_property('destination_name', src.stem)
        task.set_editor_property('automated', True)
        task.set_editor_property('save', True)
        task.set_editor_property('replace_existing', False)
        tools.import_asset_tasks([task])
        target = dst + '/' + src.stem
        if not editor.does_asset_exist(target):
            raise RuntimeError('Import did not create expected texture: '+target)
        imported.append(target)
    return imported


def main():
    import unreal
    source = os.environ.get('UE_VFX_TEXTURES_DIR', '')
    dst = os.environ.get('UE_VFX_TEXTURES_DST', '/Game/VFXForge/Textures')
    result = import_textures(unreal, source, dst, dry_run=os.environ.get('UE_VFX_DRY_RUN', '0')=='1')
    print('[UE-VFX-TEXTURE-IMPORT] '+repr(result))
    return result

if __name__ == '__main__':
    main()
