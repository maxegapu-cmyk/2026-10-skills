# -*- coding: utf-8 -*-
"""UE Editor Python read-only Niagara project probe (never modifies assets)."""
import json

def main():
    import unreal
    problems = []
    result = {'engine': 'unavailable', 'niagara_type': hasattr(unreal, 'NiagaraSystem'),
              'editor_asset_library': hasattr(unreal, 'EditorAssetLibrary'), 'problems': problems}
    try:
        result['engine'] = unreal.SystemLibrary.get_engine_version()
    except Exception as exc:
        problems.append('Unable to read version: ' + str(exc))
    if not result['niagara_type']:
        problems.append('Niagara plugin or Python interface unavailable')
    if not result['editor_asset_library']:
        problems.append('Editor Scripting Utilities missing')
    print('[UE-VFX-PROBE] ' + json.dumps(result, ensure_ascii=False, indent=2))
    return result

if __name__ == '__main__':
    main()
