# -*- coding: utf-8 -*-
"""UE EDITOR ONLY. Safe, non-destructive Niagara seed duplicator.

Usage in Unreal Editor Python console:
    import os
    os.environ['UE_VFX_MANIFEST'] = r'C:\\absolute\\output\\INSTALL_MANIFEST.json'
    exec(compile(open(r'C:\\path\\ue_bridge.py', encoding='utf-8').read(), r'C:\\path\\ue_bridge.py', 'exec'))

Dry run: set UE_VFX_DRY_RUN=1. NEVER silently overwrites assets.
"""
from __future__ import print_function
import json
import os
import re


def execute(unreal_api, manifest_file, dry_run=False):
    """Unreal API injected so logic can be contract-tested offline."""
    with open(manifest_file, 'r', encoding='utf-8') as stream:
        manifest = json.load(stream)
    if manifest.get('manifest_version') != '1.0' or manifest.get('operation') != 'duplicate_seed_only':
        raise ValueError('Unsupported manifest; refusing all asset changes')
    if manifest.get('non_destructive') is not True:
        raise ValueError('Manifest must be marked non_destructive')
    src = manifest.get('source_system')
    dst = manifest.get('destination_system')
    pat = re.compile(r'^/Game(?:/[A-Za-z0-9_]+)+$')
    if not isinstance(src, str) or not pat.fullmatch(src):
        raise ValueError('No valid source_system. In UE create/select a Niagara seed; set spec.seed_system; rebuild.')
    if not isinstance(dst, str) or not pat.fullmatch(dst):
        raise ValueError('Invalid destination asset; must be /Game/...')
    if src == dst:
        raise ValueError('Source and destination cannot be identical')
    lib = getattr(unreal_api, 'EditorAssetLibrary', None)
    if lib is None:
        raise RuntimeError('EditorAssetLibrary missing: enable Editor Scripting Utilities & restart UE')
    if not hasattr(unreal_api, 'NiagaraSystem'):
        raise RuntimeError('NiagaraSystem Python type missing: enable Niagara plugin & restart UE')
    if not lib.does_asset_exist(src):
        raise FileNotFoundError('Seed Niagara System not found in current UE project: ' + src)
    seed_asset = lib.load_asset(src)
    if seed_asset is None or not isinstance(seed_asset, unreal_api.NiagaraSystem):
        raise TypeError('seed_system exists but is not NiagaraSystem: ' + src)
    if lib.does_asset_exist(dst):
        raise FileExistsError('Destination asset already exists; refusing to overwrite: ' + dst)
    info = {'status': 'DRY_RUN' if dry_run else 'CREATED', 'seed': src, 'destination': dst,
            'note': 'Cloned base Niagara asset ONLY. Emitter/Renderer/parameter editing not automated.'}
    if dry_run:
        return info
    parent = dst.rsplit('/', 1)[0]
    if not lib.does_directory_exist(parent) and not lib.make_directory(parent):
        raise RuntimeError('Cannot create Unreal content folder: ' + parent)
    result = lib.duplicate_asset(src, dst)
    if result is None or not lib.does_asset_exist(dst):
        raise RuntimeError('Engine returned failure when duplicating Niagara asset: ' + dst)
    if not lib.save_asset(dst, only_if_is_dirty=False):
        # Do not delete partial destination automatically; it may be needed to diagnose.
        raise RuntimeError('Asset duplicated but save failed; inspect project Content Browser: ' + dst)
    return info


def main():
    manifest_path = os.environ.get('UE_VFX_MANIFEST', '').strip().strip('"')
    if not manifest_path or not os.path.isfile(manifest_path):
        raise RuntimeError('Set UE_VFX_MANIFEST to absolute path of the generated INSTALL_MANIFEST.json')
    try:
        import unreal
    except ImportError as exc:
        raise RuntimeError('This script must run inside Unreal Editor Python, not system Python') from exc
    dry = os.environ.get('UE_VFX_DRY_RUN', '0') == '1'
    report = execute(unreal, manifest_path, dry_run=dry)
    message = '[UE-VFX-FORGE] ' + json.dumps(report, ensure_ascii=False)
    print(message)
    try:
        unreal.log(message)
    except AttributeError:
        pass
    return report


if __name__ == '__main__':
    main()
