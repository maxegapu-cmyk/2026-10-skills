#!/usr/bin/env python3
"""UE5 Niagara VFX Forge: stdlib-only specification validator and build planner.

Produces a human-executable Niagara authoring plan + an optional, non-destructive
Unreal Editor asset-cloning manifest. Does not claim to author Niagara graph nodes.
"""
from __future__ import annotations
import argparse
import copy
import json
import math
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PRESETS = ROOT / 'assets' / 'presets'
RE_ID = re.compile(r'^[a-z][a-z0-9_]{2,47}$')
RE_LAYER = re.compile(r'^[A-Za-z][A-Za-z0-9_]{1,47}$')
RE_ASSET = re.compile(r'^/Game(?:/[A-Za-z0-9_]+)+$')
RE_USER = re.compile(r'^User\.[A-Za-z][A-Za-z0-9_]*$')
RE_TYPES = {'Float', 'Int', 'Bool', 'LinearColor', 'Vector3'}
RE_RENDERERS = {'sprite', 'mesh', 'ribbon', 'decal', 'light'}
RE_SIMS = {'cpu', 'gpu', 'stateless', 'material_only'}
RE_PLATFORMS = {'pc', 'console', 'mobile', 'vr'}
RE_MODES = {'gameplay', 'cinematic', 'environment', 'ui'}

class SpecError(ValueError):
    pass

def load_json(path):
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except (OSError, json.JSONDecodeError) as exc:
        raise SpecError('无法读取 JSON：%s（%s）' % (path, exc)) from exc

def _number(value, label, *, lower=None, upper=None):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise SpecError('%s 必须是有限数字' % label)
    if lower is not None and value < lower:
        raise SpecError('%s 不得小于 %s' % (label, lower))
    if upper is not None and value > upper:
        raise SpecError('%s 不得大于 %s' % (label, upper))

def _range(value, label, *, lower=0):
    if not isinstance(value, list) or len(value) != 2:
        raise SpecError('%s 需要双元素数组 [min,max]' % label)
    for v in value:
        _number(v, label, lower=lower)
    if value[0] > value[1]:
        raise SpecError('%s 最小值不可超过最大值' % label)

def validate(spec):
    if not isinstance(spec, dict):
        raise SpecError('顶层必须是 JSON 对象')
    if spec.get('schema_version') != '1.0':
        raise SpecError('schema_version 必须为 1.0')
    identifier = spec.get('id')
    if not isinstance(identifier, str) or not RE_ID.fullmatch(identifier):
        raise SpecError('id 必须匹配 ^[a-z][a-z0-9_]{2,47}$')
    if not isinstance(spec.get('display_name'), str) or not spec['display_name'].strip():
        raise SpecError('display_name 不可为空')
    if spec.get('mode') not in RE_MODES:
        raise SpecError('mode 可选 ' + ', '.join(sorted(RE_MODES)))
    if spec.get('platform') not in RE_PLATFORMS:
        raise SpecError('platform 可选 ' + ', '.join(sorted(RE_PLATFORMS)))
    if not isinstance(spec.get('ue_version'), str) or not re.fullmatch(r'5\.[4-8]', spec['ue_version']):
        raise SpecError('ue_version 支持 5.4~5.8 的设计基线，实际 API 仍需在目标引擎验证')
    for key in ('duration_s', 'fps_target', 'scale_cm'):
        _number(spec.get(key), key, lower=0.001)
    if spec['duration_s'] > 120:
        raise SpecError('duration_s 超出 120s；长驻特效用分段或循环设计')
    if spec.get('loop') not in (True, False) or not isinstance(spec.get('loop'), bool):
        raise SpecError('loop 必须是布尔值')
    if not isinstance(spec.get('output_directory'), str) or not RE_ASSET.fullmatch(spec['output_directory']):
        raise SpecError('output_directory 必须是 /Game/子目录，不能是引擎或插件目录')
    seed = spec.get('seed_system')
    if seed is not None and (not isinstance(seed, str) or not RE_ASSET.fullmatch(seed)):
        raise SpecError('seed_system 必须为 /Game/.../NS_Name，或 null')
    target = spec['output_directory'].rstrip('/') + '/NS_' + identifier
    if seed == target:
        raise SpecError('seed_system 与目标路径相同，会造成非法自复制')
    params = spec.get('user_parameters')
    if not isinstance(params, list):
        raise SpecError('user_parameters 必须是数组')
    unique_params = set()
    for i, param in enumerate(params):
        p = 'user_parameters[%d]' % i
        if not isinstance(param, dict) or not isinstance(param.get('name'), str) or not RE_USER.fullmatch(param['name']):
            raise SpecError(p + '.name 必须是 User.XXX')
        if param['name'].lower() in unique_params:
            raise SpecError('重复参数名：' + param['name'])
        unique_params.add(param['name'].lower())
        typ = param.get('type')
        if typ not in RE_TYPES:
            raise SpecError(p + '.type 不支持：' + str(typ))
        val = param.get('default')
        if typ == 'Bool' and not isinstance(val, bool):
            raise SpecError(p + '.default 应为布尔值')
        if typ == 'Int' and (isinstance(val, bool) or not isinstance(val, int)):
            raise SpecError(p + '.default 应为整数')
        if typ == 'Float':
            _number(val, p + '.default')
        if typ in ('LinearColor', 'Vector3'):
            cnt = 4 if typ == 'LinearColor' else 3
            if not isinstance(val, list) or len(val) != cnt:
                raise SpecError(p + '.default 必须为长度 %s 的数字数组' % cnt)
            for v in val:
                _number(v, p + '.default')
    layers = spec.get('layers')
    if not isinstance(layers, list) or not 1 <= len(layers) <= 16:
        raise SpecError('layers 必须有 1~16 层（不是建议全部叠满）')
    names = set()
    for i, layer in enumerate(layers):
        x = 'layers[%d]' % i
        if not isinstance(layer, dict):
            raise SpecError(x + ' 必须是对象')
        name = layer.get('name')
        if not isinstance(name, str) or not RE_LAYER.fullmatch(name):
            raise SpecError(x + '.name 不合法')
        if name.lower() in names:
            raise SpecError('layers 名称重复：' + name)
        names.add(name.lower())
        if layer.get('renderer') not in RE_RENDERERS or layer.get('simulation') not in RE_SIMS:
            raise SpecError(x + ': renderer 或 simulation 不支持')
        if layer['simulation'] == 'material_only' and layer['renderer'] not in {'decal', 'light'}:
            raise SpecError(x + ': material_only 当前仅规划 decal/light')
        if layer.get('simulation') == 'stateless' and spec['ue_version'] == '5.4':
            # 5.4 has lightweight, but may differ. Not an error.
            pass
        for label in ('visual', 'modules', 'notes'):
            if label not in layer:
                raise SpecError(x + '.' + label + ' 缺失')
        if not isinstance(layer['visual'], str) or not layer['visual'].strip():
            raise SpecError(x + '.visual 不能为空')
        if not isinstance(layer['modules'], list) or not all(isinstance(m, str) for m in layer['modules']):
            raise SpecError(x + '.modules 必须为字符串数组')
        timing = layer.get('timing', {})
        if not isinstance(timing, dict):
            raise SpecError(x + '.timing 必须为对象')
        for timing_key in ('start_s', 'end_s'):
            _number(timing.get(timing_key), x + '.timing.' + timing_key, lower=0)
        if timing['end_s'] <= timing['start_s']:
            raise SpecError(x + '.timing.end_s 必须大于 start_s')
        if not spec['loop'] and timing['end_s'] > spec['duration_s'] + 1e-6:
            raise SpecError(x + ' 结束时间超出总时长')
        spawn = layer.get('spawn', {})
        if not isinstance(spawn, dict) or spawn.get('mode') not in {'burst', 'rate', 'none'}:
            raise SpecError(x + '.spawn.mode 可选 burst/rate/none')
        _number(spawn.get('count'), x + '.spawn.count', lower=0)
        if spawn.get('mode') == 'burst' and not float(spawn['count']).is_integer():
            raise SpecError(x + ' burst count 必须为整数')
        if layer['simulation'] == 'material_only' and (spawn['mode'] != 'none' or spawn['count'] != 0):
            raise SpecError(x + ' material_only 层不可发射粒子')
        _range(layer.get('lifetime_s'), x + '.lifetime_s')
        _range(layer.get('size_cm'), x + '.size_cm')
        _range(layer.get('speed_cm_s'), x + '.speed_cm_s')
        material = layer.get('material')
        if material is not None and (not isinstance(material, str) or not RE_ASSET.fullmatch(material)):
            raise SpecError(x + '.material 必须是 /Game/... 资源路径或 null')
    if not isinstance(spec.get('gameplay'), dict) or not spec['gameplay'].get('event'):
        raise SpecError('gameplay.event 缺失')
    for key in ('visual_goal', 'readability_test', 'failure_modes'):
        if key not in spec or not spec[key]:
            raise SpecError(key + ' 不可为空')
    if not isinstance(spec['failure_modes'], list):
        raise SpecError('failure_modes 必须为数组')
    budget = spec.get('budget')
    if not isinstance(budget, dict):
        raise SpecError('budget 缺失')
    for key in ('max_cpu_ms', 'max_gpu_ms', 'max_alive_particles', 'max_concurrent_instances'):
        _number(budget.get(key), 'budget.' + key, lower=0.00001)
    if spec['fps_target'] not in (30, 60, 90, 120, 144):
        raise SpecError('fps_target 必须为 30/60/90/120/144（这是目标，不是测量结果）')
    return []

def to_md(spec):
    lines = [f"# {spec['display_name']} — Niagara 生产施工单", '',
             '> 这是按规格生成的设计/制作指令，不是已经生成的 Niagara Graph 或已通过 UE 实机验收的效果。', '',
             f"- UE 目标版：{spec['ue_version']}；模式：{spec['mode']}；平台：{spec['platform']}",
             f"- 总时长：{spec['duration_s']} 秒；{'循环' if spec['loop'] else '一次性'}；设计尺度：{spec['scale_cm']} cm；目标 FPS：{spec['fps_target']}",
             f"- Niagara 路径：`{spec['output_directory']}/NS_{spec['id']}`", 
             f"- 视觉目标：{spec['visual_goal']}", f"- 一眼可读标准：{spec['readability_test']}", '',
             '## 一、节奏与图层（逐层可执行）', '']
    for i, l in enumerate(sorted(spec['layers'], key=lambda item: item['timing']['start_s']), start=1):
        spawn = l['spawn']
        lines += [f"### {i}. {l['name']} — {l['visual']}",
                  f"- 窗口：{l['timing']['start_s']}–{l['timing']['end_s']} 秒；Renderer：{l['renderer']}；模拟：{l['simulation']}",
                  f"- Spawn：{spawn['mode']}，{'数量' if spawn['mode']=='burst' else '速率(个/秒)' if spawn['mode']=='rate' else '无'} {spawn['count']}",
                  f"- 寿命：{l['lifetime_s'][0]}–{l['lifetime_s'][1]} s；尺寸：{l['size_cm'][0]}–{l['size_cm'][1]} cm；初速度：{l['speed_cm_s'][0]}–{l['speed_cm_s'][1]} cm/s",
                  f"- 模块搜索词（按所在阶段放置，名称可能因版本略有变化）：{', '.join(l['modules']) or '按材质或 Renderer 实现'}",
                  f"- 材质：`{l['material']}`" if l['material'] else '- 材质：先用临时 Debug Material，不依赖缺失的外部素材',
                  f"- 施工提醒：{l['notes']}", '']
    lines += ['## 二、User 参数契约（必须在 Niagara System 中真实创建并绑定）', '',
              '| Niagara 参数 | 类型 | 初始值 | 使用约定 |', '|---|---|---|---|']
    for p in spec['user_parameters']:
        lines.append(f"| `{p['name']}` | {p['type']} | `{json.dumps(p['default'], ensure_ascii=False)}` | {p.get('purpose','游戏事件动态驱动')} |")
    lines += ['', '## 三、关卡/蓝图触发', '',
              f"- 事件：{spec['gameplay']['event']}",
              f"- 出生方式：{spec['gameplay'].get('spawn','at_location')}",
              f"- 触发位置：{spec['gameplay'].get('location','Hit Location / Socket Transform')}",
              f"- 多人语义：{spec['gameplay'].get('network','cosmetic_local')}（注意不要让视觉特效改变权威游戏逻辑）", '',
              """1. Content Browser 中右键创建 Niagara System，基于 Empty/Minimal 或已有合法模板。
2. 在 System Overview 按施工单创建 Emitter 或添加 stateless emitter；逐层验证单独渲染正确，再合成。
3. 用 User 参数链接颜色/强度/尺寸等，绑定到所需模块输入；仅声明参数而未绑定不会生效。
4. 通过蓝图 `Spawn System at Location` 或 `Spawn System Attached` 调用，保存返回的 Niagara Component，根据类型调用 `Set Niagara Variable ...`。
5. 仅在目标平台的 PIE 和打包构建中确认视觉、材质、碰撞、绑定与性能。""", '',
              '## 四、性能预算（规划上限，未测量）', '',
              f"- 单实例 Niagara GT/CPU 目标：≤ {spec['budget']['max_cpu_ms']} ms；GPU 目标：≤ {spec['budget']['max_gpu_ms']} ms",
              f"- 预估同时存活粒子建议上限：{spec['budget']['max_alive_particles']}；场景内同时激活实例：{spec['budget']['max_concurrent_instances']}",
              '- 以上数值是用户可调整的初始预算，不是保证值。测试以 Unreal Insights / Niagara Debugger 为准，统计峰值与重复触发。', '',
              '## 五、常见失败与反查', '']
    lines += ['- ' + f for f in spec['failure_modes']]
    lines += ['', '## 六、封板门槛', '',
              '- [ ] Gameplay 时序匹配：击中、受击、死亡/受击反馈时点清晰，不被光污染遮挡。',
              '- [ ] 单一特效/8 个实例/场景复杂工况分别截屏或录屏，有证据可回放。',
              '- [ ] 近距离、远距离、背光、亮背景均可读；必要时做不同颜色主题与无后处理检查。',
              '- [ ] 粒子上限、消失/循环、Pooling、Bounds、Cull、打包后资源无丢失。',
              '- [ ] 记录真实 CPU/GPU 帧耗时及设备/分辨率/扩展性等级；不以口头“流畅”代替。',
              '- [ ] UE 编辑器内 Asset 打开、Niagara 编译无错误、PIE 与目标打包无阻断。']
    return '\n'.join(lines) + '\n'

def steps_md(spec):
    destination = f"{spec['output_directory']}/NS_{spec['id']}"
    seed = spec.get('seed_system')
    intro = (f"当前 seed：`{seed}`。可选运行 `unreal/ue_bridge.py` 复制这个真实的 Niagara System，结果放在 `{destination}`。"
             if seed else '当前 `seed_system=null`，桥接脚本会拒绝资产复制，这是安全的。先在 UE 内创建一个 Niagara System 模板并填写其 `/Game/...` 路径，再执行 `forge.py build`。')
    return f"""# UE5 实机落地步骤 — {spec['display_name']}

{intro}

## 先配置

1. 在 UE5 项目中开启 **Niagara**；若运行 Python，再开启 **Python Editor Script Plugin** 和 **Editor Scripting Utilities**（重启编辑器）。
2. 打开 UE Content Browser，确认目标工程中能找到所有需要的 Seed、材质和贴图资源。
3. 外部执行 `python scripts/forge.py build <SPEC.json> --out <输出目录>`，生成包含 `INSTALL_MANIFEST.json` 的文件夹。
4. UE 菜单 `Tools > Execute Python Script` 打开包内 `unreal/ue_bridge.py` 前，在 Python Console 设置环境变量：

```python
import os
os.environ['UE_VFX_MANIFEST'] = r'C:\\absolute\\path\\to\\INSTALL_MANIFEST.json'
```

5. 运行 Python 脚本：UE 菜单 Tools > Execute Python Script > `ue_bridge.py`，或者编辑器 Python Console 执行：

```python
exec(compile(open(r'C:\\path\\to\\unreal\\ue_bridge.py', encoding='utf-8').read(), r'C:\\path\\to\\unreal\\ue_bridge.py', 'exec'))
```

**重要**：桥接程序仅安全复制现有 Niagara 资产（不会重建其 Emitter/Module 图），遇到同名目标会停止；必须在 UE 中按 `PLAN.md` 完成图层改造。复制成功不等于视觉或性能达标。

## 真正搭出效果

- 打开 `{destination}`，在 Niagara System Overview 添加/调整各图层对应的 Emitter。
- `Emitter Spawn/Update` 管控制器生成；`Particle Spawn/Update` 管每粒出生、运动和衰减；Renderer 管最终表现。
- Sprite/Mesh/Ribbon 选择合适 Renderers；Decal/Light 可用材质/单独组件实现，并非任意 Niagara 版本都有同名 Renderer。
- 参数统一在 Niagara System Parameters 中创建 `User.*`，再绑定模块输入；Runtime 中由 Blueprint 传值。
- 材质按 `references/materials-and-techniques.md` 使用 Unlit、Masked/Additive/Translucent，避免过绘和曝光失控。
- 逐层 Solo 观察出生点、方向、寿命、Z fighting、法线、遮挡关系和层次顺序。
- 正式进入关卡和游戏时再叠加 Niagara Effect Type/Scalability/Culling/Pooling。

## 出错时

- `UE_VFX_MANIFEST` 未设置：在同一 Unreal Editor Python 进程里设置到实际生成路径（绝对路径）。
- Seed 不存在：Content Browser 复制真实路径，修改源 JSON 的 `seed_system`，重建 manifest。
- 目标已存在：不覆盖；更换 `id` 或手动决定该版本的迁移/回滚。
- Python API 缺失：核对插件并重启；查 `references/ue5-compatibility.md`。
- 视觉看不出变化：这是预期，bridge 只复制底座资产；Niagara 内仍须实际修改 Renderer/Emitter/Modules。
"""

def qa_md(spec):
    return f"""# QA 记录 — {spec['display_name']}

**状态：UNTESTED — 尚无实机证据。** 填完后再确定 PASS/FAIL。

- UE 完整版号：_____；目标平台/硬件：_____
- 场景/光照/相机：_____；打包模式：_____
- 分辨率/屏幕百分比：_____；Scalability：_____
- 粒子平均/峰值：_____ / _____（预算：{spec['budget']['max_alive_particles']}）
- 实例数：1 / {spec['budget']['max_concurrent_instances']} / 实战压力测试
- Niagara CPU/GT：_____ ms（规划：≤{spec['budget']['max_cpu_ms']} ms）
- Niagara GPU：_____ ms（规划：≤{spec['budget']['max_gpu_ms']} ms）
- 时序、大小、视角、材质、对比度、受击可读性：PASS / FAIL
- 编辑器编译 + PIE + Shipping/Development 构建检查：PASS / FAIL
- 问题复现步骤、修法、二次测量：_____

可用 `python scripts/forge.py audit <spec.json> <measured.json>` 运行保守阈值对照；示例在 `examples/measured_example.json`。工具检测不了 Niagara 真正画面是否漂亮。
"""

def manifest(spec):
    # manifest is data, not a claim of generated Niagara graphs.
    return {'manifest_version': '1.0', 'effect_id': spec['id'],
            'source_system': spec.get('seed_system'),
            'destination_system': f"{spec['output_directory']}/NS_{spec['id']}",
            'engine_target': spec['ue_version'], 'operation': 'duplicate_seed_only',
            'non_destructive': True, 'user_parameters': spec['user_parameters'],
            'status': 'requires_unreal_editor_and_manual_layer_authoring'}

def build(spec_path, out):
    spec = load_json(spec_path)
    validate(spec)
    out = Path(out).expanduser()
    out.mkdir(parents=True, exist_ok=True)
    # Refuse overwriting any existing user output; use a new directory/version.
    planned = ('PLAN.md', 'UE_STEPS.md', 'QA.md', 'INSTALL_MANIFEST.json', 'SOURCE_SPEC.json')
    collisions = [str(out / f) for f in planned if (out / f).exists()]
    if collisions:
        raise SpecError('为避免覆盖已有成果，请选择新目录：' + ', '.join(collisions))
    (out / 'PLAN.md').write_text(to_md(spec), encoding='utf-8')
    (out / 'UE_STEPS.md').write_text(steps_md(spec), encoding='utf-8')
    (out / 'QA.md').write_text(qa_md(spec), encoding='utf-8')
    (out / 'INSTALL_MANIFEST.json').write_text(json.dumps(manifest(spec), ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    (out / 'SOURCE_SPEC.json').write_text(json.dumps(spec, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    return out

def audit(spec, measured):
    validate(spec)
    if not isinstance(measured, dict):
        raise SpecError('实测文件必须是 JSON 对象')
    required = ('engine_version', 'platform', 'resolution', 'scalability', 'capture', 'cpu_ms', 'gpu_ms', 'peak_alive_particles', 'max_concurrent_instances', 'visual_pass', 'packaged_pass')
    for key in required:
        if key not in measured:
            raise SpecError('实测缺项：' + key)
    for key in ('cpu_ms','gpu_ms','peak_alive_particles','max_concurrent_instances'):
        _number(measured[key], 'measured.'+key, lower=0)
    if not measured['capture']:
        raise SpecError('capture 必须有 Insights/Debugger/记录文件路径或备注')
    failures = []
    for metric, cap in (('cpu_ms','max_cpu_ms'),('gpu_ms','max_gpu_ms'),('peak_alive_particles','max_alive_particles'),('max_concurrent_instances','max_concurrent_instances')):
        if measured[metric] > spec['budget'][cap]:
            failures.append(f'{metric}: 实测 {measured[metric]} > 预算 {spec["budget"][cap]}')
    if measured['visual_pass'] is not True: failures.append('人工视觉验收未通过')
    if measured['packaged_pass'] is not True: failures.append('目标打包版本验收未通过')
    if not str(measured['engine_version']).startswith(spec['ue_version']):
        failures.append('版本不一致：设计 '+spec['ue_version']+'，实测 '+str(measured['engine_version']))
    if measured['platform'] != spec['platform']:
        failures.append('平台不一致：设计 '+spec['platform']+'，实测 '+str(measured['platform']))
    return {'status': 'PASS (self-reported metrics; not independently verified)' if not failures else 'FAIL',
            'failures': failures, 'metrics': measured, 'limits': spec['budget']}

def cli(argv=None):
    parser = argparse.ArgumentParser(description='UE5 Niagara VFX Forge v1.0.0')
    sub = parser.add_subparsers(dest='cmd', required=True)
    sub.add_parser('presets', help='列出预设')
    new = sub.add_parser('new', help='基于预设生成可编辑 JSON')
    new.add_argument('--preset', required=True)
    new.add_argument('--name', required=True, help='英文 snake_case id')
    new.add_argument('--out', required=True)
    v = sub.add_parser('validate', help='本地检查参数设计')
    v.add_argument('spec')
    b = sub.add_parser('build', help='生成 Niagara 施工交付包')
    b.add_argument('spec')
    b.add_argument('--out', required=True)
    a = sub.add_parser('audit', help='把真实测量值与预算作比较')
    a.add_argument('spec'); a.add_argument('measured')
    args = parser.parse_args(argv)
    try:
        if args.cmd == 'presets':
            print('\n'.join(x.stem for x in sorted(PRESETS.glob('*.json'))))
        elif args.cmd == 'new':
            if not RE_ID.fullmatch(args.name):
                raise SpecError('name 必须为 3~48 位英文小写 snake_case，以字母开头')
            src = PRESETS / (args.preset + '.json')
            if not src.is_file() or src.parent.resolve() != PRESETS.resolve():
                raise SpecError('预设不存在，请先执行 presets')
            spec = copy.deepcopy(load_json(src))
            spec['id'] = args.name
            validate(spec)
            out = Path(args.out)
            out.parent.mkdir(parents=True, exist_ok=True)
            with out.open('x', encoding='utf-8') as f:
                json.dump(spec, f, ensure_ascii=False, indent=2)
                f.write('\n')
            print('已生成：', out)
        elif args.cmd == 'validate':
            validate(load_json(args.spec)); print('PASS：JSON 规格与值域检查通过（不是 UE 实机测试）')
        elif args.cmd == 'build':
            print('已生成交付包：', build(args.spec, args.out))
        elif args.cmd == 'audit':
            report = audit(load_json(args.spec), load_json(args.measured))
            print(json.dumps(report, indent=2, ensure_ascii=False))
            return 0 if report['status'].startswith('PASS') else 2
    except (SpecError, FileExistsError, PermissionError, OSError) as exc:
        print('ERROR:', exc, file=sys.stderr)
        return 2
    return 0

if __name__ == '__main__':
    raise SystemExit(cli())
