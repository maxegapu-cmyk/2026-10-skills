#!/usr/bin/env python3
"""Create original, dependency-free procedural RGBA PNG particle masks.

These are intentionally simple production starting points, not branded assets.
"""
import argparse
import math
import struct
import zlib
from pathlib import Path

SIZE = 256
NAMES = ('T_VFXForge_SoftDisc', 'T_VFXForge_ShockRing', 'T_VFXForge_Spark',
         'T_VFXForge_SlashArc', 'T_VFXForge_SmokeMask')


def clamp(v):
    return max(0.0, min(1.0, v))


def noise(x, y):
    # Deterministic smooth-valued noise without external RNG or dependencies.
    return (math.sin(x * 12.9898 + y * 78.233) * 43758.5453) % 1.0


def smooth(t):
    t = clamp(t)
    return t * t * (3 - 2 * t)


def value_noise(x, y):
    xi, yi = math.floor(x), math.floor(y)
    fx, fy = smooth(x - xi), smooth(y - yi)
    a = noise(xi, yi); b = noise(xi + 1, yi)
    c = noise(xi, yi + 1); d = noise(xi + 1, yi + 1)
    return (a * (1-fx) + b * fx)*(1-fy) + (c * (1-fx) + d * fx)*fy


def pixel(name, u, v):
    x, y = (u - 0.5) * 2, (v - 0.5) * 2
    radius = math.hypot(x, y)
    theta = math.atan2(y, x)
    if name.endswith('SoftDisc'):
        a = (1 - smooth((radius - 0.05) / 0.85)) ** 1.65
    elif name.endswith('ShockRing'):
        a = math.exp(-((radius - 0.62) / 0.065) ** 2) * (1 - smooth((radius - 0.72) / 0.20))
    elif name.endswith('Spark'):
        # High contrast center + narrow directional spikes.
        core = math.exp(-(radius / 0.16) ** 2)
        horizontal = math.exp(-((y / 0.028) ** 2 + (x / 0.85) ** 2))
        vertical = math.exp(-((x / 0.028) ** 2 + (y / 0.85) ** 2))
        diagonal = 0.3 * math.exp(-((((x-y)/0.05)**2) + ((x+y)/0.8)**2))
        a = clamp(0.95*core + 0.65*horizontal + 0.65*vertical + diagonal)
    elif name.endswith('SlashArc'):
        # Curved slash on the right side of the texture, with tapered endpoints.
        r_target = 0.70 + 0.06 * math.sin(theta * 2.0)
        arc = math.exp(-((radius - r_target) / 0.045) ** 2)
        angle_weight = smooth((theta + 1.25) / 0.37) * (1 - smooth((theta - 1.25) / 0.28))
        a = arc * angle_weight
    elif name.endswith('SmokeMask'):
        n = (value_noise(4.2*u,4.2*v)*0.55 + value_noise(9.0*u,9.0*v)*0.3 + value_noise(16.0*u,16.0*v)*0.15)
        shape = 1 - smooth((radius - 0.20 + (n-0.5)*0.25) / 0.65)
        a = clamp(shape * (0.5 + 0.55*n))
    else:
        raise ValueError(name)
    return round(255 * clamp(a))


def png_chunk(name, data):
    return struct.pack('>I', len(data)) + name + data + struct.pack('>I', zlib.crc32(name + data) & 0xffffffff)


def rgba_png(name, size=SIZE):
    raw = bytearray()
    for iy in range(size):
        raw.append(0)  # PNG filter 0
        v = (iy+0.5)/size
        for ix in range(size):
            alpha = pixel(name, (ix+0.5)/size, v)
            raw.extend((255, 255, 255, alpha))
    signature = b'\x89PNG\r\n\x1a\n'
    ihdr = struct.pack('>IIBBBBB', size, size, 8, 6, 0, 0, 0)
    return signature + png_chunk(b'IHDR', ihdr) + png_chunk(b'IDAT', zlib.compress(raw, 9)) + png_chunk(b'IEND', b'')


def generate(out, size=SIZE):
    if not (64 <= size <= 1024 and size & (size-1) == 0):
        raise ValueError('size must be power of 2, 64..1024')
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    for name in NAMES:
        path = out / (name+'.png')
        # Exclusive write prevents accidental replacement of edited originals.
        with path.open('xb') as f:
            f.write(rgba_png(name, size))
    return len(NAMES)


def main(argv=None):
    parser = argparse.ArgumentParser(description='Generate original Niagara alpha-mask PNG assets')
    parser.add_argument('--out', required=True)
    parser.add_argument('--size', type=int, default=SIZE)
    args = parser.parse_args(argv)
    print('Generated %d original textures in %s' % (generate(args.out, args.size), args.out))

if __name__ == '__main__':
    main()
