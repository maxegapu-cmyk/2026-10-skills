# JSON 规格字段说明（用 scripts/forge.py 验证）

这份格式是本 Skill 自定义的**中间设计规格**，不是 Epic Unreal 官方 Niagara 的 JSON 导入格式；不能把它直接拖进 UE 当作 Niagara System。

## 顶层字段

- `schema_version`：固定 `"1.0"`。
- `id`：英语小写 snake_case，3–48 字符；生成目标为 `NS_<id>`。
- `display_name`：中英文可读名字。
- `ue_version`：当前工具允许 `5.4` 到 `5.8`；具体项目接口仍看引擎完整小版本。
- `mode`：`gameplay` / `cinematic` / `environment` / `ui`。
- `platform`：`pc` / `console` / `mobile` / `vr`。
- `fps_target`：30/60/90/120/144（目标，不代表已达到）。
- `scale_cm`：设计特效约略空间尺度，按 UE 默认 cm。粒子长度 `size_cm` 仍以 cm 填写。
- `duration_s`：时间轴计划长度。场景持续特效可以 `loop=true`。
- `seed_system`：已有 `/Game/.../NS_` Niagara System 资产路径；不明确时 `null`。要通过桥接器生成新系统副本必须提供真实 Seed。
- `output_directory`：计划生成新的 `/Game/` 子目录，不能指向 `/Engine/` 或 `/Plugin/`。
- `visual_goal`：意图和主要形体。
- `readability_test`：眼睛第一时间应该识别什么。
- `failure_modes`：实际现象对应的可执行诊断建议数组。
- `gameplay`：`event` / `spawn` / `location` / `network`，作为蓝图/程序接入契约文字信息。
- `budget`：`max_cpu_ms/max_gpu_ms/max_alive_particles/max_concurrent_instances`，**均为每个项目自行设定的规划预算**。
- `user_parameters`：名字 `User.X`，类型支持 `Float` / `Int` / `Bool` / `LinearColor` / `Vector3`。

## 图层字段

```json
{
  "name": "ContactFlash",
  "visual": "接触短闪",
  "renderer": "sprite",
  "simulation": "stateless",
  "timing": {"start_s": 0, "end_s": 0.1},
  "spawn": {"mode": "burst", "count": 1},
  "lifetime_s": [0.05, 0.1],
  "size_cm": [25, 55],
  "speed_cm_s": [0, 0],
  "modules": ["Initialize Particle", "Scale Color"],
  "material": null,
  "notes": "短暂，不盖住目标"
}
```

- `renderer`：`sprite` / `mesh` / `ribbon` / `decal` / `light`。其中 `decal/light` 通常需要非 Niagara 独立组件，谨慎按当前 UE 编辑器配置实现。
- `simulation`：`cpu` / `gpu` / `stateless` / `material_only`。`material_only` 用于 decal/light 无粒子发射描述。
- `timing` 是**期望的表现/活动窗口**，不等于已经设置的 Emitter 停止条件。真实物理消散时间取决于 burst/rate 方式、Spawn 结束时刻和 Particle Lifetime；**在引擎里要将可见结束时间和计划窗口逐帧对齐**。循环环境效果尤其注意尾部粒子可越过一轮 8s 边界。
- `spawn.count`：`burst` 表示粒子个数（整数）；`rate` 表示预定的粒子/秒；`none` 必须为 0。
- `lifetime_s/size_cm/speed_cm_s` 为闭区间，需在 UE 中选合适的 Uniform Range 或曲线生成。
- `modules` 仅供 UE System Overview 中搜索与施工导航，**不是“脚本自动调用这些模块”**，具体堆栈上下文必须由技术美术确认。
- `material` 可为 `/Game/...` 资源路径或 `null`；`null` 用原始占位材质，不会自动生成发光贴图或 Shader。

## 版本迁移注意

改效果之后递增 `id` 或改输出目录版本，不要对已交付包直接 build 覆盖。强制重建请明确删除生成目录（这是用户可见的文件操作），工具不会替你删除。
