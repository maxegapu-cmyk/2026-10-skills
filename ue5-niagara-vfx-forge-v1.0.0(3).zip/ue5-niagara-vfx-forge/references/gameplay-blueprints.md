# UE 蓝图 / Gameplay 接入与变量契约

## 典型 A：命中世界位置

事件链条（蓝图节点标识写英文）：

`Weapon/Projectile Hit` → `Break Hit Result` 得到 `Impact Point` 与 `Impact Normal` → `Make Rot from Z` （用于贴地环/法线对齐场景；有些粒子需要面朝相机或别的坐标轴）→ `Spawn System at Location`（选择目标 `NS_...`）→ 获得 `Niagara Component` → 设置 `Set Niagara Variable...` 对应 User 参数。

要注意：**`Set Niagara Variable...` 必须作用于返回的 Niagara Component，变量名与 Niagara 内真实 User 参数完全一致**。检查参数类型（Float / LinearColor / Vector 等）并验证改变参数确实产生肉眼变化。部分 Spawn 会自动 Activate，参数在首次粒子 Spawn 后设置可能来不及影响 Burst：可选择预先放置 Niagara Component 并先设参数后 Activate，或使用版本适配的 Spawn 参数输入方式；在项目里验证。

## 典型 B：武器 Socket

`AnimNotify_Fire` → `Get Mesh / Get Socket Transform (Muzzle)` → `Spawn System Attached` 到武器/枪口组件（注意 Attach Location Type）→ 设置 `User.Intensity` / `User.Tint`。枪口 Mesh 的 Forward Axis 可能是 X/Y，枪口火焰 Mesh/材质要对齐；Character 动画保持同步。

真正的刀光不只是在 Socket 处 Spawn 1 张 Sprite，需每帧或 Ribbon 相关模块读取刀尖位置（Tip Socket）与 Root Socket 的变化，构造连续轨迹。不要依赖帧率固定步进生成宽度，否则 30 和 120 FPS 的条带密度不同。

## 典型 C：火球/飞行物

施法：`OnAbilityStart` → Spawn `NS_CastCharge` Attached to Hand；释放：Stop/Deactivate Charge → Projectile Actor Spawn → Projectile Movement。飞行期 Niagara System Attached to Projectile；命中：在 `OnHit` 中 Spawn 单独 `NS_FireballImpact` at Impact Point，然后销毁 Projectile / 启动 Pooling。

**反例**：用一条固定 1.2 秒的 System 时间轴假设任何目标都会在 0.8 秒命中，会导致“还没碰到敌人先爆炸”。只有线性影视预演才能假定撞击绝对时间。

## 典型 D：GAS / GameplayCue

若项目已使用 Gameplay Ability System，可让 GameplayCue 在预测/确认阶段产生视觉组件，并确保恢复/取消时 Deactivate。不要为了特效绕过伤害、归属、预测或权限系统；**视觉是 Cosmetic 结果而非服务端真源**。

## 网络游戏

权威伤害/攻击判定由 gameplay/服务器完成；VFX 可按项目预测策略在本地触发。对客户端预测效果，设计取消、确认与重复触发去重。不要对每一个火花粒子进行网络复制，而应复制必要的事件/位置/种子数据，客户端本地渲染。重复触发前先确认项目已有框架。

## 声音/镜头/灯光

音效通常由 gameplay 事件/Notify/MetaSound 或 Audio Component 驱动；灯光通常采用短时独立组件或 Niagara Light Renderer 的实际能力，避免同屏大量动态 shadow-casting lights。后处理镜头震动等不应绑定在粒子数上，并需 UI/accessibility 开关。

## 高风险问题核对

- Burst 发射后才 Set User 参数，第一帧仍用旧值。
- 挂点错（武器枪口与角色骨架坐标轴不同）。
- 近战特效跟随角色转身而在地表滑动。
- Niagara Local Space 与材质 World Position 输入混用。
- Server 上 Spawn Cosmetic 而没有按网络策略驱动客户端。
- Gameplay 事件到视觉的 RTT 造成命中晚一拍，靠纯放大光效掩盖不同步。
