# UE5.4～5.8 兼容、版本事实与可用工程资源

> 检查日期：2026-10-22。范围是 UE5 Niagara 工具链的*设计适配*，不是在所有版本完成测试。实际以用户当前 UE 项目的 Python API 文档与插件状态为准。

## 对齐原则

- **Niagara System/Emitter/Module/User 参数**：跨版本稳定的基本概念，但具体模块名称、可见选项、参数类型、脚本暴露程度均可能不同。
- **Niagara Lightweight/Stateless Emitters**：Epic 文档指出从 UE5.4 引入；具体模块支持与 GUI 因版本而异，不能将传统 Niagara Graph 的每一步照搬给 stateless。
- **Niagara Data Channels / Effect Types**：成熟功能路线，需要按版本验证 Blueprint API 与使用场景。
- **Niagara Fluids**：是可选依赖；不要把体积流体方案作为所有平台无条件的默认。
- **Editor Python**：Epic 官方仍注明 Experimental；脚本的合法调用取决于插件是否启用以及 UE 具体版本。UE Python 仅 Editor 时工具链，**不能作为打包后游戏运行脚本依赖**。
- **编译/性能**：必须在用户当前版本跑通，不能用 README 的绿灯代替 UE log 和实机截图。

## 为什么桥接只做 Seed Clone 而不宣称完整图自动生成

Niagara 核心由 Emitter Graph、参数绑定、Stack / Renderers 组合而成，UE Python API 对 Graph/Template 创建的可调用接口并不等同于普通节点生成。官方 5.8 有 `NiagaraSystemFactoryNew`，但仅用该 Factory `create_asset` 无法可靠证明生成了用户指定的完整粒子行为，且不具有跨版本保证。因此本工具使用文档明确支持的 `EditorAssetLibrary.duplicate_asset`，克隆已存在的**真实 Niagara System**。这一步确实会生成一个新 `.uasset`，但仍需要按 PLAN 手工/代理在 UE 内编辑 Graph。

如用户拥有成熟 Niagara Seed/共享 Emitter，克隆+小范围修改往往比每次从零新建更符合生产实践。

## 官方资料与社区参考（链接不意味着本包包含其素材/源码）

1. Epic Niagara overview（System/Emitter/Module）： https://dev.epicgames.com/documentation/en-us/unreal-engine/overview-of-niagara-effects-for-unreal-engine
2. Epic Niagara 官方快速入门： https://dev.epicgames.com/documentation/en-us/unreal-engine/quick-start-for-niagara-effects-in-unreal-engine
3. Epic Niagara Module Reference： https://dev.epicgames.com/documentation/en-us/unreal-engine/system-and-emitter-module-reference-for-niagara-effects-in-unreal-engine
4. Epic Editor Python 运行方式： https://dev.epicgames.com/documentation/en-us/unreal-engine/scripting-the-unreal-editor-using-python
5. Epic Python `NiagaraSystemFactoryNew`： https://dev.epicgames.com/documentation/en-us/unreal-engine/python-api/class/NiagaraSystemFactoryNew
6. Epic `EditorAssetLibrary::DuplicateAsset`： https://dev.epicgames.com/documentation/en-us/unreal-engine/API/Plugins/EditorScriptingUtilities/UEditorAssetLibrary/DuplicateAsset
7. Epic Niagara Examples Pack（2026-01；通过 Fab / Epic 渠道自行取得；资产权利归对应持有人）： https://www.fab.com/listings/0e188eca-4e54-4fb2-a9ed-d8b8a565e600
8. Epic Niagara Examples 学习课程： https://dev.epicgames.com/community/learning/courses/qXe/unreal-engine-niagara-examples-pack
9. GitHub 开源 Skill 示例（只作知识框架对照，本项目没有复制其内容）： https://github.com/gamedev-skills/awesome-gamedev-agent-skills/blob/main/skills/unreal/unreal-niagara/SKILL.md
10. GitHub Packt 官方图书样例仓库（使用应遵循其许可证，未被打包）： https://github.com/PacktPublishing/Build-Stunning-Real-time-VFX-with-Unreal-Engine-5
11. Epic 资产导入任务： https://dev.epicgames.com/documentation/en-us/unreal-engine/API/Editor/UnrealEd/UAssetImportTask
12. Agent Skills 官方格式： https://agentskills.io/specification

## 建议引擎探测

在 UE Editor 中打开 `Tools > Execute Python Script`，运行本包 `unreal/ue_probe.py`，只读输出 `engine`、Niagara Python 类型与 EditorAssetLibrary 是否存在。

升级一个小版本之前，请先复制测试项目并验证：重要 Niagara Systems 正常编译、Emitter 模块引用/自定义 Scratch Pad 没断、Shader compile、PIE 正常、Cook 后无软引用丢失、性能未退化。
