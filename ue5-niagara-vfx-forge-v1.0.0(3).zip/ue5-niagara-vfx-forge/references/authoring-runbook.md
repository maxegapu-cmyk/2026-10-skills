# Niagara 实施运行手册：从口头要求到 UE 运行资产

## 1. 定义特效的角色（先于节点）

采集：画面类型/游戏风格、技能行为、触发位置和法线、动作持续、实际碰撞判定时间、目标平台、摄像机距离、单场景最高同时实例数、是否会多次循环、参考表现。对缺少的字段，先用安全默认值做**规划**并清楚标记，不擅自覆盖项目既有设定。

为每个特效写一条中心叙述：`谁在何处因什么触发，第一瞬间观众看到什么，随后如何运动，何时消失`。例如“冲击命中 0–80ms 的接触闪光，80–280ms 冲击波，后 1s 稀薄尾尘”。带互动的效果应拥有清楚的响应点，不能把华丽程度当成命中反馈。

## 2. 直接映射成 UE5 资产结构

约定资产命名：`NS_` Niagara System，`NE_` 共享 Emitter，`M_` 材质主资产，`MI_` 材质实例，`MF_` Material Function，`T_` Texture，`SM_` Static Mesh，`BP_` 蓝图 Actor。默认路径 `/Game/VFXForge/`，若项目已有命名规范优先继承。

每一层有唯一责任（JSON 时间轴仅描述预期活动窗口；Emitter 停止发射和最后粒子的结束时间需在 UE 内分别设置/测量）：

| 功能 | 推荐做法 | 高频错误 |
|---|---|---|
| 瞬间冲击 | Sprite + 环形贴图/曲线，小于 0.15s | 一秒以上的大亮白光污染 |
| 火花碎屑 | 少量 Sprite/小 Mesh，Burst + Velocity + Drag | 所有火花同速度同方向 |
| 刀光/拖尾 | Weapon Socket 路径采样 / Ribbon / 弧形 Mesh | 只拉长 Sprite 但不跟武器 |
| 冲击圆环 | 环状 Shader + 尺寸曲线 | 直接用一整片半透明贴图挡人 |
| 烟雾体积 | 低频噪声 Sprite/Flipbook，GPU 需核验 | 透明贴片叠太多导致过绘 |
| 能量波面 | Mesh + 材质，在受击点传 World Position | 世界/局部变换不一致、穿模 |
| 地面冲击纹 | Decal 或紧贴地表 Mesh | 角度和 Surface Normal 错、Z fighting |
| 关卡环境 | GPU/Stateless 简化+Effect Type Cull | 无限常驻、Bounds 不正确 |

Niagara 常见堆栈阶段：System Spawn / System Update / Emitter Spawn / Emitter Update / Particle Spawn / Particle Update / Render。Burst 通常在 Emitter Update 或可用的 Spawn 模块；粒子初始尺寸/寿命/速度在 Particle Spawn；生命周期变化在 Particle Update；视觉图元在 Renderer。**搜索具体模块名称时要根据用户 UE 版本实际菜单确认。**

## 3. 施工顺序（有效防止堆叠返工）

第一遍：只创建**主层**，黑灰环境下确认时序、位置、长度、方向。第二遍：加命中瞬态与次级粒子。第三遍：设置色彩统一、材质、User 变量。第四遍：接入真实 gameplay。第五遍：设成本控制和质量分档。

每遍都必须回到主镜头和游戏距离看一次。多方向镜头上，Ribbon/弧形 Mesh 的透视读数可能不一致，不仅看 Niagara 编辑器默认的斜前方静态相机。

## 4. 游戏交互适配要点

- **先获取 Gameplay 时点**：`AnimNotify` 用于动作时刻，`HitResult` 决定真实位置与法线，Gameplay Ability 的 Cue 可承接表现层；不同项目优先沿用现有架构。
- **重投射**：移动中的发射器可以 Attached to Weapon Socket；命中地面通常是在 World Space 放置（避免角色继续走时火花跟着移动）。
- **本地偏移**：从 Actor 的 muzzle forward 方向生成，不是固定世界 X 轴；技能改朝向后仍能正确跟随。
- **瞬时效果**：尽可能 Auto Destroy / Pooling；不要在 Tick 中每帧无条件 Spawn 新 System。
- **衰减**：Emitter Loop / System Loop、固定 Bounds 和 Cull 合理设置；先验证系统到期真正停止发射与销毁。
- **共享冲击**：频繁同类命中可研究 Niagara Data Channels，将许多小 Burst 汇到共享模拟；版本支持和调度顺序要实际测试。

## 5. 何时用 lightweight/stateless

简单 Sprite 的短 Burst、可预计算的基础轻粒子可尝试 lightweight emitter。依赖复杂粒子事件、特殊 Data Interface、动态碰撞或 GPU 逻辑时应保留传统 emitter，先比较支持模块，再比较实测数字。不能只因“lightweight 新”就宣称全平台通用/一定更快。

## 6. 输出最小集合

1. `NS_...` 真正的 Niagara 资产，且资产编译无错误。
2. 参数契约：每个 `User.*` 类型、默认值、蓝图赋值节点、消费它的模块/Material 位置。
3. 触发链条图：哪个事件产生位置、朝向、规模，何时 Spawn/Deactivate。
4. 运行截图/录像（近、中、远、暗/亮场景）+ UE profiler 的数值记录。
5. 升级/迁移策略：不覆盖原资产；若要改已有 asset，先做副本和 diff，对引用关系提前列清楚。
