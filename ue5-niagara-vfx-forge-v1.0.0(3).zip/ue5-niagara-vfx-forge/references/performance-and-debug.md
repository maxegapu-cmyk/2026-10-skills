# Niagara 性能测试与故障排查路线

## 先选正确量测问题

60FPS 的整帧预算是 16.67ms；120FPS 的整帧预算是 8.33ms。VFX 没有独占整帧的资格。性能预算取决于目标设备、同屏效果数量和画面其它系统负载。预设里的 `max_cpu_ms/max_gpu_ms` 是**假设性的单效果规划阈值**，必须自行调整，不是 Epic 官方推荐值，也非实测结果。

**采集一定写清**：UE 完整版本、构建版本（Editor PIE/Standalone/打包 Development/Shipping）、CPU/GPU、分辨率、屏幕百分比、品质等级、镜头、场景、效果数量（1/8/最高并发）、采样次数与 P95/峰值。不要把在空测试关卡 1 个效果的耗时推广到真实多人战斗。

## 第一层：确认瓶颈

1. 用 `stat unit` 看 Game / Draw / GPU 的相对峰值，不用它直接归因单 Niagara。
2. 打开 Niagara Debugger 查看活跃实例、模拟状态、Scalability 是否裁剪、particle counts。
3. Unreal Insights 带 Niagara 命名事件时可用 `-StatNamedEvents` 临时采集以识别具体 System 的线程耗时（命名事件有额外开销，之后进行对照无标记采集）。
4. 目标是**找造成当前高峰的真实 System/Emitter/材质**，而非先全场调低粒子数。
5. GPU overdraw 主要看大的 Translucent 层覆盖屏幕像素次数，材质与 Draw Calls。静态截图可能掩盖高速镜头下的峰值。

## 第二层：按来源对症下药

- **Game Thread**：Emitter/系统实例过多、参数更新、频繁生成/销毁；尝试 Pooling、批处理、限制同时实例数、Effect Type cull、NDC。
- **Niagara VM/模拟**：复杂逐粒子运算、频繁事件、复杂采样；尝试简单 emitter、降低不重要更新、stateless（条件支持）、减掉非必要 collision。
- **GPU/材质**：全屏半透明烟、折射、高材质指令量、昂贵动态光、分辨率高；缩小占屏面积与透明层数、Flipbook/Bake 或更简洁 Shader。
- **GPU 粒子**：GPU 模拟不是免费；检查 Collision、Data Interface、Compute 工作量及显存/平台限制。
- **移动/VR**：双眼渲染、移动端材质、透明 overdraw、可用 GPU Niagara 功能须明确验证；优先 Sprite/轻量模型的退化方案。

## 第三层：不可避免的质量损失说明

每次优化都写：变化前后镜头相同、P95 帧耗时变化、同时实例数是否相同、画面牺牲了什么。某一层被裁剪后若技能攻击方向丢失，属于高代价退化，不应仅凭毫秒收益就接受。

## 错误分类最短路径

**完全无显示** → Niagara System 是否选择正确、Renderer 是否禁用、Emitter 是否 active、Bound/Visibility/Cull、材质/Alpha 是否为 0、出生时参数是否设置过晚。

**编译红字** → 看 Stack 的错误模块/版本迁移、丢失函数/材质资源；若他人 Skill 给出不存在的节点名称，要按当前 UE API 搜索替代。

**跑偏** → Show Debug Axis/Socket/Impact Normal，分别验证组件 Attach、Local vs World、Particle Position、Mesh Pivot。

**断带** → Ribbon 绑定与顺序、同个 Ribbon ID、Socket 采样率、生命周期、系统固定 Bounds。

**瞬间卡顿** → 首次资源载入与 Shader Compile、Pool warmup、实例突增、GPU 大 Overdraw 分别排查。

**打包失效** → 插件运行态依赖、Cook References、Asset Manager 软引用、路径大小写、目标平台 Renderer/Shader 可用性。

## 官方证据

- Niagara profiling： https://dev.epicgames.com/documentation/en-us/unreal-engine/measuring-performance-in-niagara
- Niagara Effect Types / Scalability： https://dev.epicgames.com/documentation/en-us/unreal-engine/performance-budgeting-using-effect-types-in-niagara-for-unreal-engine
- Data Channels： https://dev.epicgames.com/documentation/en-us/unreal-engine/niagara-data-channels-overview
- Lightweight Emitters： https://dev.epicgames.com/documentation/en-us/unreal-engine/niagara-lightweight-emitters-overview
