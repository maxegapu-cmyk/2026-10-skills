# 材质、形体和复合特效手法

## 视觉优先级

第一关注：**主要形体的外轮廓与方向**；第二关注：亮暗分层和时间冲击；第三关注：小碎光、细节、局部噪声。判断标准不是编辑器特写最漂亮，而是游戏主镜头中是否能瞬间识别。

## Sprite/Mesh/Ribbon 工作分工

- **Sprite**：快速做冲击、火花、烟、细尘、光圈；UV 与透明贴图决定形态，切忌一片纯白。软粒子/Depth Fade 需实际材质节点验证，防止表面硬切。
- **Mesh**：几何护盾、火球核心、刀锋月牙、薄环、传送门面。先验证 Pivot、法线、Two Sided、摄像机角度和 scale 对象维度。复杂 Mesh 可能增加三角形/DrawCall/材质成本。
- **Ribbon**：斩击轨迹、魔法线、尾焰；检查粒子顺序、Ribbon ID、Trail 跟随路径和跳帧断带。对于特别稳定的刀锋形状，静态弧形 Mesh 也可能比 Ribbon 更稳。
- **Decal / Light**：按引擎版本确认实际渲染路径。有时更合适的是 Blueprint Spawn Decal / 动态材质/独立 Light Component，而不是硬找 “Decal Renderer”。

## 材质原则

1. 发光粒子通常可以尝试 Unlit + Additive，增加氛围；但 Additive 不能呈现黑烟和遮挡感，且过大面积会冲掉背景对比。
2. 烟尘应考虑 Alpha Blend/Translucent/Masked 方案和场景灯光。Translucent 的 overdraw 随覆盖面积、层数、屏幕像素变化。Masked 与 Dither 方案需要评估边缘质量。
3. 不要把“更亮”仅等同于增加 Emissive 倍率。曝光、Bloom、Tonemapper 与玩家场景底色会改变最终颜色。中性灰/亮白/暗背景下都审查。
4. 噪声设计按大小顺序：低频扭动确定大形，中频刻画破碎，少量高频做边缘质感。所有层同时强噪声会让形体乱。
5. Material Instance 动态参数用于多色皮肤；Niagara `User.*` 参数通过 Dynamic Material Parameters / Particle Color 等**真实绑定路径**驱动。
6. 地表法阵、圆环需考虑 Ground Normal 与深度偏置；过大的地面光斑容易穿模或浮空。

## 结构参考：冲击帧（格斗类）

在游戏时间 0–60ms 做 Contact Flash、低粒子数量的极短高对比主形；60–240ms 用扩张环和方向性碎屑；240ms 后只保留少量灰尘和细火花。对 30FPS 游戏一次 33.3ms 帧间隔，0.03 秒的光效可能在视觉上只占单帧，要在目标帧率真实预览并按需要延展可见时长。

## 结构参考：魔法大招

蓄能/预告阶段——给玩家预判空间，防止和普通伤害一样；爆发阶段——控制核心强度和遮挡面积，短而集中；后效阶段——逐层消散留下方向/结果证据。对多人战斗，强制设置同屏视觉竞争上限，尤其是瞄准线与敌方 Telegraphed Attack 不应被遮蔽。

## 模型差异与退路

- **Niagara Fluids**：适合需要体积感的烟火模拟，但插件、GPU、兼容性和可打包能力须项目验证；移动/VR 不默认启用。低成本退路为 Flipbook 烟片或手制 Mesh。
- **Niagara Data Channels**：适合大量重复 Impact/Footstep 等集中处理；要设计数据负载和更新顺序，不能将独立系统简单改成单个 System 就假定语义相同。
- **Lightweight/Stateless**：减少某些模拟开销，须先核对模块支持列表；复杂行为或事件依赖退回传统 CPU/GPU emitter。
- **Flipbook/Baker**：昂贵效果可 Bake 成 sprite sheets 做 LOD，但角度变化和灯光交互会下降；要保证授权/素材来源清晰。
