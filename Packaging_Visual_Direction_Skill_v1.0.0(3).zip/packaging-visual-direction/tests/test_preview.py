"""Tests for the distribution artifact, no external dependencies."""
from copy import deepcopy
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
MODULE_PATH = ROOT / "scripts" / "preview.py"
SPEC = importlib.util.spec_from_file_location("packaging_preview", MODULE_PATH)
preview = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(preview)
DEMO = json.loads((ROOT / "examples" / "demo-directions.json").read_text(encoding="utf-8"))


class PreviewTests(unittest.TestCase):
    def test_demo_data_valid(self):
        self.assertIs(preview.validate(DEMO), DEMO)

    def test_output_contains_three_directions_and_surfaces(self):
        page = preview.render(DEMO)
        self.assertEqual(page.count('<article class="direction'), 3)
        self.assertEqual(page.count('class="outer-box"'), 3)
        self.assertEqual(page.count('class="inner-box"'), 3)
        self.assertEqual(page.count('class="manual-box"'), 3)
        for direction in DEMO["directions"]:
            self.assertIn(direction["name"], page)
        self.assertIn('name="viewport"', page)
        self.assertNotIn('<script', page)
        self.assertNotIn('https://fonts.googleapis.com', page)

    def test_invalid_color_fails(self):
        case = deepcopy(DEMO)
        case["directions"][0]["palette"][0]["hex"] = "red; background:url(x)"
        with self.assertRaisesRegex(ValueError, "HEX"):
            preview.validate(case)

    def test_missing_important_copy_fails(self):
        case = deepcopy(DEMO)
        del case["directions"][2]["manual_title"]
        with self.assertRaisesRegex(ValueError, "manual_title"):
            preview.validate(case)

    def test_unsupported_layout_fails(self):
        case = deepcopy(DEMO)
        case["directions"][0]["layout"] = "random"
        with self.assertRaisesRegex(ValueError, "layout"):
            preview.validate(case)

    def test_too_many_directions_fails(self):
        case = deepcopy(DEMO)
        case["directions"].append(deepcopy(case["directions"][0]))
        with self.assertRaisesRegex(ValueError, "1–3"):
            preview.validate(case)

    def test_escape_user_content(self):
        case = deepcopy(DEMO)
        case["meta"]["brand"] = '<img src=x onerror="alert(1)">'
        case["directions"][0]["tagline"] = '</article><script>alert("x")</script>'
        result = preview.render(case)
        self.assertNotIn('<img src=x', result)
        self.assertNotIn('<script>alert(', result)
        self.assertIn('&lt;img src=x', result)
        self.assertIn('&lt;/article&gt;&lt;script&gt;', result)

    def test_contrast_ratio(self):
        self.assertAlmostEqual(preview.contrast_ratio("#FFFFFF", "#000000"), 21.0)
        self.assertAlmostEqual(preview.contrast_ratio("#222222", "#222222"), 1.0)

    def test_cli_success_and_bad_json(self):
        with tempfile.TemporaryDirectory() as tmp:
            output = Path(tmp) / "sub" / "board.html"
            result = subprocess.run(
                [sys.executable, str(MODULE_PATH), str(ROOT / "examples" / "demo-directions.json"), "-o", str(output)],
                capture_output=True, text=True
            )
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertTrue(output.is_file())
            self.assertIn("产品包装视觉方向", output.read_text(encoding="utf-8"))
            invalid = Path(tmp) / "invalid.json"
            invalid.write_text('{"meta":', encoding="utf-8")
            bad = subprocess.run([sys.executable, str(MODULE_PATH), str(invalid)], capture_output=True, text=True)
            self.assertNotEqual(bad.returncode, 0)
            self.assertIn("生成失败", bad.stderr)


if __name__ == "__main__":
    unittest.main()
