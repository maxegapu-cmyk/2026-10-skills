#!/usr/bin/env python3
"""Render a standalone concept-board HTML for packaging visual directions.

Usage: python scripts/preview.py examples/demo-directions.json -o visual-directions.html
Python stdlib only. Deliberately *not* a production packaging dieline generator.
"""
from __future__ import annotations

import argparse
from html import escape
import json
from pathlib import Path
import re
import sys

HEX_RE = re.compile(r"^#[0-9A-Fa-f]{6}$")
LAYOUTS = {"offset", "stripe", "split"}


def required_str(obj: dict, field: str, where: str) -> str:
    value = obj.get(field)
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{where}.{field}: 需要非空文本")
    if len(value) > 360:
        raise ValueError(f"{where}.{field}: 文本过长，建议先精简")
    return value.strip()


def validate(data: object) -> dict:
    if not isinstance(data, dict):
        raise ValueError("根节点必须是 JSON 对象")
    meta = data.get("meta")
    if not isinstance(meta, dict):
        raise ValueError("meta 必须是对象")
    for field in ("product", "brand", "note"):
        required_str(meta, field, "meta")
    directions = data.get("directions")
    if not isinstance(directions, list) or not 1 <= len(directions) <= 3:
        raise ValueError("directions 必须包含 1–3 条方向")
    for i, d in enumerate(directions, start=1):
        prefix = f"directions[{i}]"
        if not isinstance(d, dict):
            raise ValueError(f"{prefix} 必须是对象")
        for field in (
            "id", "name", "tagline", "layout", "headline", "detail", "inner_label",
            "manual_title", "manual_step", "typography", "anchor", "outer",
            "inner", "manual", "suitable", "risk",
        ):
            required_str(d, field, prefix)
        if d["layout"] not in LAYOUTS:
            raise ValueError(f"{prefix}.layout 只能是 offset / stripe / split")
        palette = d.get("palette")
        if not isinstance(palette, list) or not 3 <= len(palette) <= 5:
            raise ValueError(f"{prefix}.palette 需包含3–5个色块，按背景/文字/识别/点缀排列")
        for j, swatch in enumerate(palette, start=1):
            if not isinstance(swatch, dict):
                raise ValueError(f"{prefix}.palette[{j}] 需要对象")
            for field in ("name", "role", "hex", "share"):
                required_str(swatch, field, f"{prefix}.palette[{j}]")
            if not HEX_RE.fullmatch(swatch["hex"]):
                raise ValueError(f"{prefix}.palette[{j}].hex 必须为六位十六进制 HEX，例如 #203040")
    return data


def luminance(color: str) -> float:
    c = [int(color[pos:pos + 2], 16) / 255.0 for pos in (1, 3, 5)]
    linear = [x / 12.92 if x <= 0.04045 else ((x + 0.055) / 1.055) ** 2.4 for x in c]
    return sum(x * weight for x, weight in zip(linear, (0.2126, 0.7152, 0.0722)))


def contrast_ratio(a: str, b: str) -> float:
    hi, lo = sorted((luminance(a), luminance(b)), reverse=True)
    return (hi + 0.05) / (lo + 0.05)


def h(value: object) -> str:
    return escape(str(value), quote=True)


def direction_markup(d: dict, brand: str, product: str) -> str:
    palette = d["palette"]
    ground, ink, key = (p["hex"].upper() for p in palette[:3])
    accent = palette[3]["hex"].upper() if len(palette) > 3 else key
    swatches = "\n".join(
        f'<div class="swatch"><span class="swatch-fill" style="background:{h(s["hex"])}"></span>'
        f'<span class="swatch-name">{h(s["name"])}</span>'
        f'<span class="swatch-meta">{h(s["role"])} · {h(s["share"])}</span>'
        f'<code>{h(s["hex"].upper())}</code></div>'
        for s in palette
    )
    layout = h(d["layout"])
    return f'''
    <article class="direction layout-{layout}" style="--ground:{ground};--ink:{ink};--key:{key};--accent:{accent}">
      <div class="direction-heading">
        <div class="heading-row"><span class="num">DIRECTION / {h(d["id"])}</span><span class="mini-label">视觉方向 · 非比例示意</span></div>
        <h2>{h(d["name"])}</h2>
        <p class="tagline">{h(d["tagline"])}</p>
      </div>
      <section class="visual-stage" aria-label="外箱、内包装和说明书概念预览">
        <div class="stage-note">PACKAGING STUDY<span> / </span>{h(product)}</div>
        <div class="outer-box">
          <div class="box-topline">{h(brand)}<span>PRODUCT / {h(d["id"])}</span></div>
          <div class="outer-decor" aria-hidden="true"><i></i><b></b></div>
          <div class="box-message"><strong>{h(d["headline"])}</strong><small>{h(d["detail"])}</small></div>
          <div class="box-bottomline">DESIGN / CONCEPT <span>↗</span></div>
        </div>
        <div class="inner-box">
          <span class="mini-brand">{h(brand)}</span><div class="inner-graphic" aria-hidden="true"></div>
          <strong>{h(d["inner_label"])}</strong><small>INNER PACK</small>
        </div>
        <div class="manual-box">
          <small class="manual-brand">{h(brand)} / GUIDE</small>
          <div class="manual-graphic" aria-hidden="true">01 <span>02</span><span>03</span></div>
          <strong>{h(d["manual_title"])}</strong><span class="manual-step">{h(d["manual_step"])}</span>
          <small class="manual-bottom">USER MANUAL</small>
        </div>
        <div class="caption-over">OUTER BOX</div><div class="caption-inner">INNER</div><div class="caption-manual">MANUAL</div>
      </section>
      <div class="direction-body">
        <div class="palette-heading"><h3>COLOUR SYSTEM</h3><span>HEX / 可视面积占比建议</span></div>
        <div class="swatches">{swatches}</div>
        <div class="notes">
          <div><span class="eyebrow">01 / 外箱排版</span><p>{h(d["outer"])}</p></div>
          <div><span class="eyebrow">02 / 内包装</span><p>{h(d["inner"])}</p></div>
          <div><span class="eyebrow">03 / 说明书</span><p>{h(d["manual"])}</p></div>
          <div><span class="eyebrow">视觉识别锚点</span><p>{h(d["anchor"])}</p></div>
        </div>
        <div class="bottom-box"><p><b>字体与质感</b>{h(d["typography"])}</p><p><b>更适合</b>{h(d["suitable"])}</p><p><b>小心</b>{h(d["risk"])}</p></div>
      </div>
    </article>'''


CSS = r"""
:root{font-family:Arial,'PingFang SC','Microsoft YaHei',sans-serif;color:#17202b;background:#eeeef0;font-synthesis:none}
*{box-sizing:border-box}body{margin:0}.page{max-width:1460px;margin:0 auto;padding:60px 50px 100px}
.overline{font-size:12px;letter-spacing:2.4px;font-weight:800;color:#496071}
.title-row{display:flex;justify-content:space-between;align-items:end;gap:30px;border-bottom:1px solid #b6bbc1;padding:16px 0 32px}
h1{font-size:clamp(42px,6vw,76px);letter-spacing:-2.8px;line-height:1.03;font-weight:850;margin:12px 0 12px}.sub{font-size:15px;color:#5b6874;line-height:1.8;max-width:460px}.date-token{white-space:nowrap;color:#64717b;font-size:12px;letter-spacing:1.5px}.directions{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:22px;margin-top:32px;align-items:stretch}
.direction{background:#fff;min-width:0;overflow:hidden;box-shadow:0 13px 32px rgba(26,35,49,.055);display:flex;flex-direction:column}
.direction-heading{padding:28px 26px 22px;min-height:174px}.heading-row{display:flex;justify-content:space-between;gap:8px;align-items:center}.num{letter-spacing:2px;font-size:11px;color:#667381;font-weight:800}.mini-label{font-size:10px;color:#90989d}.direction h2{font-size:34px;letter-spacing:-1.2px;margin:17px 0 7px;line-height:1.12}.tagline{font-size:13px;color:#6d7680;margin:0;line-height:1.75}
.visual-stage{height:450px;position:relative;overflow:hidden;background:color-mix(in srgb,var(--ground) 45%,#ffffff);border-top:1px solid #f1f1f1;border-bottom:1px solid #ececec}.stage-note{position:absolute;z-index:4;top:17px;left:24px;font-size:10px;letter-spacing:.8px;color:var(--ink);opacity:.66}.stage-note span{opacity:.5}
.outer-box,.inner-box,.manual-box{position:absolute;box-shadow:9px 18px 25px rgba(10,13,15,.19);overflow:hidden;background:var(--ground);color:var(--ink)}
.outer-box{width:54%;height:67%;left:9%;top:14%;padding:16px 15px 13px;display:flex;flex-direction:column;border:1px solid rgba(0,0,0,.05);isolation:isolate}
.box-topline,.box-bottomline{display:flex;justify-content:space-between;align-items:center;font-size:9px;letter-spacing:1.2px;font-weight:800;z-index:2;position:relative}.box-topline span{font-size:7px;opacity:.7}.box-bottomline{margin-top:auto;font-size:8px;letter-spacing:1px}.box-bottomline span{font-size:16px}
.box-message{margin:auto 0;z-index:2;display:flex;flex-direction:column;gap:7px;position:relative}.box-message strong{font-size:clamp(28px,3.3vw,48px);letter-spacing:-2px;line-height:1;font-weight:800}.box-message small{font-size:12px;font-weight:750;letter-spacing:.9px}
.outer-decor{position:absolute;z-index:1;right:0;bottom:0;width:60%;height:72%;overflow:hidden}.outer-decor i{display:block;position:absolute;width:170px;height:170px;bottom:-30px;right:-33px;background:var(--key);border-radius:50% 4% 40% 10%;transform:rotate(-23deg)}.outer-decor b{display:block;position:absolute;width:95px;height:95px;bottom:21px;right:5px;border:2px solid var(--accent);border-radius:50%;opacity:.6}
.inner-box{width:39%;height:23%;left:48%;top:58%;padding:11px 10px;display:flex;flex-direction:column;z-index:3;border:1px solid rgba(0,0,0,.07)}.mini-brand{font-size:10px;font-weight:800;letter-spacing:1px}.inner-box strong{margin-top:auto;z-index:1;font-size:11px;letter-spacing:0}.inner-box small{margin:3px 0 0;font-size:7px;letter-spacing:1px;opacity:.6}.inner-graphic{width:48%;height:100%;position:absolute;top:0;right:0;background:var(--key);opacity:.92;clip-path:polygon(26% 0%,100% 0,100% 100%,0 100%)}
.manual-box{width:28%;height:34%;left:66%;top:30%;z-index:2;transform:rotate(6deg);padding:11px 9px;display:flex;flex-direction:column;border:1px solid rgba(0,0,0,.08)}.manual-brand{font-size:7px;letter-spacing:.8px;font-weight:700}.manual-graphic{font-size:25px;font-weight:850;letter-spacing:-2px;color:var(--key);margin:auto 0 4px;display:flex;gap:6px;align-items:baseline}.manual-graphic span{font-size:9px;color:var(--accent);font-weight:700;letter-spacing:0}.manual-box strong{font-size:14px;letter-spacing:.1px}.manual-step{margin-top:4px;font-size:8px;opacity:.8}.manual-bottom{margin-top:auto;font-size:7px;letter-spacing:.3px;opacity:.65}.caption-over,.caption-inner,.caption-manual{position:absolute;bottom:20px;font-weight:800;letter-spacing:1px;font-size:8px;color:var(--ink);opacity:.63}.caption-over{left:10%}.caption-inner{left:50%}.caption-manual{right:7%}
.layout-offset .outer-box{left:9%;top:15%}.layout-offset .box-message{align-self:start;margin:49px 0 auto}.layout-offset .box-message strong{font-family:Georgia,'Songti SC',serif;font-weight:600}.layout-offset .outer-decor i{right:-25px;bottom:-18px;width:166px;height:170px}.layout-offset .manual-box{top:34%}
.layout-stripe .outer-box{padding-left:60px}.layout-stripe .outer-box:before{content:'02 / FIELD NOTES';position:absolute;left:0;top:0;width:21%;height:100%;background:var(--key);color:#fff;writing-mode:vertical-rl;text-orientation:mixed;font-size:10px;font-weight:900;letter-spacing:3px;text-align:center;padding:16px 7px}.layout-stripe .box-message{margin:auto 0 25px}.layout-stripe .box-message strong{font-size:clamp(26px,2.5vw,36px);letter-spacing:-1px;overflow-wrap:anywhere}.layout-stripe .outer-decor i{background:var(--ink);transform:rotate(0);width:104px;height:104px;border-radius:0;bottom:-4px;right:-27px;opacity:.16}.layout-stripe .inner-graphic{clip-path:none;width:17%;left:0;right:auto}.layout-stripe .inner-box{padding-left:33px}.layout-stripe .manual-box:before{content:'';position:absolute;left:0;top:0;width:20px;height:100%;background:var(--key)}.layout-stripe .manual-box{width:32%;left:62%;padding-left:27px;transform:rotate(5deg)}.layout-stripe .manual-graphic{font-size:20px}.layout-stripe .outer-box{top:13%}
.layout-split .outer-box{background:linear-gradient(90deg,var(--ground) 0 58%,var(--key) 58% 100%)}.layout-split .box-message{width:57%;margin:80px 0 auto}.layout-split .box-message strong{font-family:Georgia,'Songti SC',serif;font-weight:650}.layout-split .outer-decor{right:0;top:7%;height:88%;width:40%;bottom:auto}.layout-split .outer-decor i{width:110px;height:190px;border-radius:60% 0 60% 0;transform:rotate(-34deg);background:var(--ground);right:-35px;bottom:10px;opacity:.65}.layout-split .outer-decor b{width:60px;height:60px;border:8px solid var(--ink);right:6px;bottom:50px;opacity:.36}.layout-split .inner-graphic{width:45%;clip-path:ellipse(43% 46% at 81% 50%)}.layout-split .manual-graphic{font-family:Georgia,serif}
.direction-body{padding:27px 26px 32px;display:flex;flex-direction:column;flex:1}.palette-heading{display:flex;justify-content:space-between;align-items:baseline;gap:6px}.palette-heading h3{font-size:12px;letter-spacing:1.6px;margin:0 0 15px}.palette-heading span{color:#8a9298;font-size:9px}.swatches{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px}.swatch{display:flex;flex-direction:column;min-width:0}.swatch-fill{height:54px;display:block;border:1px solid rgba(0,0,0,.07)}.swatch-name{font-size:12px;font-weight:800;margin-top:9px}.swatch-meta{font-size:9px;color:#697178;margin-top:3px;white-space:nowrap}.swatch code{font-size:10px;margin-top:6px;color:#26313b;font-family:ui-monospace,Consolas,monospace}
.notes{display:grid;grid-template-columns:1fr 1fr;gap:16px 15px;margin:30px 0 0}.notes>div{border-top:1px solid #e5e7e8;padding-top:12px}.eyebrow{color:#68737d;font-size:10px;letter-spacing:.5px;font-weight:800}.notes p{font-size:12px;line-height:1.75;margin:7px 0 0;color:#26333c}.bottom-box{margin-top:auto;padding-top:22px}.bottom-box p{margin:9px 0 0;font-size:11px;line-height:1.7;color:#5f6870}.bottom-box b{display:inline-block;color:#2c363f;margin-right:8px;min-width:58px}.page-footer{border-top:1px solid #c4c6c8;color:#59646c;display:flex;justify-content:space-between;gap:25px;padding-top:23px;margin-top:38px;font-size:11px;line-height:1.8}
@media(max-width:1200px){.directions{grid-template-columns:repeat(2,minmax(0,1fr))}.visual-stage{height:420px}}@media(max-width:800px){.page{padding:28px 16px 58px}.directions{grid-template-columns:1fr}.title-row{align-items:start;flex-direction:column}.visual-stage{height:430px}.outer-box{max-width:295px}.swatches{grid-template-columns:repeat(4,minmax(0,1fr))}.page-footer{flex-direction:column}.direction-heading{min-height:auto}.date-token{white-space:normal}}@media(max-width:390px){.swatches{gap:5px}.swatch-meta{font-size:8px}.swatch code{font-size:9px}.visual-stage{height:390px}.box-message strong{font-size:30px}}
@media print{body{background:#fff}.page{max-width:none;padding:0}.directions{display:block}.direction{break-inside:avoid;box-shadow:none;margin:0 0 26px;border:1px solid #ddd}.visual-stage{height:390px}h1{font-size:44px}}
"""


def render(data: dict) -> str:
    validate(data)
    brand, product, note = (h(data["meta"][x]) for x in ("brand", "product", "note"))
    cards = "\n".join(direction_markup(d, data["meta"]["brand"], data["meta"]["product"]) for d in data["directions"])
    heading = "包装的三种表情" if len(data["directions"]) == 3 else "包装视觉方向提案"
    issue = f"VISUAL EXPLORATION / 01—{len(data["directions"]):02d}"
    return f'''<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>{brand} / 产品包装视觉方向</title><style>{CSS}</style></head>
<body><main class="page"><div class="overline">CREATIVE DIRECTION / PACKAGING SYSTEM</div>
<header class="title-row"><div><h1>{heading}<span style="color:#798791">.</span></h1><div class="sub">{brand} · {product}<br>视觉探索重点：排版、配色、风格气质，及外盒 / 内包装 / 说明书之间的统一。</div></div><span class="date-token">{issue}</span></header>
<div class="directions">{cards}</div><footer class="page-footer"><span>{note}</span><span>仅供方向沟通 · 抽象产品形状占位 · 非生产刀模、非法律合规或印刷打样</span></footer></main></body></html>'''


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="从JSON生成产品包装视觉方向 HTML 草图")
    parser.add_argument("json_file", help="方向方案数据，参见 examples/demo-directions.json")
    parser.add_argument("-o", "--output", default="visual-directions.html", help="生成的HTML路径")
    args = parser.parse_args(argv)
    try:
        data = json.loads(Path(args.json_file).read_text(encoding="utf-8"))
        document = render(data)
        output = Path(args.output)
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(document, encoding="utf-8")
        for i, d in enumerate(data["directions"], start=1):
            p = d["palette"]
            ratio = contrast_ratio(p[0]["hex"], p[1]["hex"])
            if ratio < 4.5:
                print(f"注意: 方案{i}背景/主字色对比度约{ratio:.1f}:1；正文需另行检查可读性", file=sys.stderr)
        print(f"已生成：{output.resolve()}（{len(data['directions'])}个方向，离线HTML）")
        return 0
    except (OSError, json.JSONDecodeError, UnicodeError, ValueError) as exc:
        print(f"生成失败：{exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
