import contextlib
import importlib.util
import io
import subprocess
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
VALIDATOR = ROOT / "tools" / "validate_prompt.py"
spec = importlib.util.spec_from_file_location("t2v_validator", VALIDATOR)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
check = module.check_prompt
BASE = ("integrated_multimodal_description: [Shot 1] Live-action, a single adult walks "
        "through the open doorway and stops by the window.\n"
        "overall_soundscape: Footsteps on the wooden floor and light wind.\n"
        "non_diegetic_music: N/A\n")


class ValidatorTests(unittest.TestCase):
    def assertFails(self, content, msg=None, duration=8):
        errors, _ = check(content, duration)
        self.assertTrue(errors, f"Expected error, got none: {msg or content}")
        if msg:
            self.assertTrue(any(msg.lower() in x.lower() for x in errors), errors)

    def test_all_examples(self):
        for path in sorted((ROOT / "examples").glob("*.txt")):
            duration = int(path.stem.split("-")[-1].rstrip("s"))
            with self.subTest(path=path.name):
                errors, warnings = check(path.read_text(encoding="utf-8"), duration)
                self.assertEqual([], errors)
                self.assertEqual([], warnings)

    def test_valid_minimal(self):
        self.assertEqual(check(BASE)[0], [])

    def test_empty(self):
        self.assertFails("", "empty")

    def test_wrong_order(self):
        self.assertFails(BASE.replace("overall_soundscape:", "X:").replace(
            "non_diegetic_music:", "overall_soundscape:").replace("X:", "non_diegetic_music:"), "order")

    def test_missing_field(self):
        self.assertFails(BASE.split("non_diegetic_music:")[0], "3 fields")

    def test_duplicate_field(self):
        self.assertFails(BASE + "overall_soundscape: Again\n", "3 fields")

    def test_preamble_not_allowed(self):
        self.assertFails("Here is your result:\n" + BASE, "start directly")

    def test_empty_section(self):
        self.assertFails(BASE.replace("light wind.", " ").replace("Footsteps on the wooden floor and", ""), "empty field")

    def test_wrong_first_shot(self):
        self.assertFails(BASE.replace("[Shot 1]", "[Shot 2]"), "shot 1")

    def test_unordered_shot_numbers(self):
        self.assertFails(BASE.replace("walks", "walks [Shot 3] At 00:05.000, the camera cuts to a chair and"), "sequential")

    def test_first_shot_timestamp(self):
        self.assertFails(BASE.replace("[Shot 1]", "[Shot 1] At 00:00.000,"), "start timestamp")

    def test_bad_cut_format(self):
        self.assertFails(BASE.replace("stops by the window.",
                     "stops by the window. [Shot 2] At five seconds, the camera cuts to a chair."), "timestamp")

    def test_cut_transition_needed(self):
        self.assertFails(BASE.replace("stops by the window.",
                     "stops. [Shot 2] At 00:05.000, the sky is blue."), "transition")

    def test_cut_out_of_duration(self):
        self.assertFails(BASE.replace("stops by the window.",
                     "stops by the window. [Shot 2] At 00:09.000, the camera cuts to a chair."), "outside")

    def test_unordered_cuts(self):
        self.assertFails(BASE.replace("stops by the window.",
                     "stops. [Shot 2] At 00:06.000, the camera cuts to the door. "
                     "[Shot 3] At 00:05.000, the camera cuts to the window."), "increase")

    def test_invalid_seconds(self):
        self.assertFails(BASE.replace("stops by the window.",
                     "stops. [Shot 2] At 00:65.000, the camera cuts to the window."), "invalid seconds", 80)

    def test_picture_tag(self):
        self.assertFails(BASE.replace("Live-action", "<Picture 1> Live-action"), "reference")

    def test_image_alignment(self):
        self.assertFails(BASE.replace("Live-action", "reference pictures align. Live-action"), "reference")

    def test_unmatched_dialogue(self):
        self.assertFails(BASE.replace("walks", "(S1) says <d>[English] Hello walks"), "unmatched")

    def test_missing_dialogue_language(self):
        self.assertFails(BASE.replace("walks", "(S1) says <d>Hello</d> and walks"), "language label")

    def test_missing_speaker_id(self):
        self.assertFails(BASE.replace("walks", "says <d>[English] Hello</d> and walks"), "speaker")

    def test_silent_with_dialogue(self):
        self.assertFails(BASE.replace("walks", "(S1) says <d>[English] Hello</d> and walks")
                         .replace("Footsteps on the wooden floor and light wind.", "N/A"), "conflicts")

    def test_silent_without_dialogue(self):
        self.assertEqual(check(BASE.replace("Footsteps on the wooden floor and light wind.", "N/A"))[0], [])

    def test_duration_too_short(self):
        self.assertFails(BASE, "duration", duration=3)

    def test_duration_too_long(self):
        self.assertFails(BASE, "duration", duration=16)

    def test_warning_not_failure(self):
        e, w = check(BASE.replace("walks", "no bad hands, walks"))
        self.assertEqual(e, [])
        self.assertTrue(w)

    def test_offscreen_warning(self):
        e, w = check(BASE.replace("walks", "(S1) says in an off-screen voiceover: "
                             "<d>[English] Home</d>, then walks"))
        self.assertEqual(e, [])
        self.assertTrue(any("voiceover" in x for x in w))

    def test_cli_pass(self):
        p = ROOT / "examples" / "tattoo-detail-8s.txt"
        proc = subprocess.run([sys.executable, str(VALIDATOR), str(p), "--duration", "8"],
                              capture_output=True, text=True)
        self.assertEqual(proc.returncode, 0, proc.stdout + proc.stderr)
        self.assertIn("PASS", proc.stdout)

    def test_cli_missing_file(self):
        proc = subprocess.run([sys.executable, str(VALIDATOR), str(ROOT / "not-found.txt")],
                              capture_output=True, text=True)
        self.assertEqual(proc.returncode, 2)


if __name__ == "__main__":
    unittest.main()
