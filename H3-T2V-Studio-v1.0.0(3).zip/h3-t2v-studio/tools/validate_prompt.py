#!/usr/bin/env python3
"""Offline MiniMax H3 T2VA prompt linter. Does not call a video model.

Exit 0: no blocking errors (warnings may remain).
Exit 1: blocking errors.
Exit 2: input / usage error.
"""
from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path
from typing import List, Tuple

FIELDS = (
    "integrated_multimodal_description",
    "overall_soundscape",
    "non_diegetic_music",
)
HEADER = re.compile(r"(?m)^([A-Za-z][A-Za-z0-9_]*)\s*:")
SHOTS = re.compile(r"\[Shot (\d+)\]")
TIMESTAMP = re.compile(r"At\s+(\d{2}):(\d{2})\.(\d{3})\b")
DIALOG = re.compile(r"<d>\s*\[([A-Za-z][A-Za-z -]*)\]\s*([^<>]*?)\s*</d>", re.S)


def check_prompt(raw: str, duration: float = 8.0) -> Tuple[List[str], List[str]]:
    errors: List[str] = []
    warnings: List[str] = []
    text = raw.strip().lstrip("\ufeff")
    if not 4 <= duration <= 15:
        errors.append("Duration must be in the H3 T2VA 4–15 second target range.")
    if not text:
        errors.append("Empty prompt.")
        return errors, warnings

    hits = list(HEADER.finditer(text))
    names = [m.group(1) for m in hits]
    if names != list(FIELDS):
        errors.append(f"Expected exactly 3 fields in order {list(FIELDS)}; found {names}.")
    if not text.startswith(FIELDS[0] + ":"):
        errors.append("The prompt must start directly with integrated_multimodal_description:.")
    if len(hits) < 3 or names != list(FIELDS):
        return errors, warnings
    segments = {
        key: text[h.end():hits[i + 1].start() if i + 1 < len(hits) else len(text)].strip()
        for i, (key, h) in enumerate(zip(FIELDS, hits))
    }
    for key, val in segments.items():
        if not val:
            errors.append(f"Empty field: {key}.")

    body = segments[FIELDS[0]]
    ambience = segments[FIELDS[1]]
    music = segments[FIELDS[2]]
    shot_hits = list(SHOTS.finditer(body))
    if not shot_hits or not body.startswith("[Shot 1]"):
        errors.append("Visual description must start with [Shot 1].")
    nums = [int(m.group(1)) for m in shot_hits]
    if nums != list(range(1, len(nums) + 1)):
        errors.append(f"Shot numbers must be sequential from 1, found {nums}.")
    cut_seconds = []
    for i, sh in enumerate(shot_hits):
        end = shot_hits[i + 1].start() if i + 1 < len(shot_hits) else len(body)
        content = body[sh.end():end]
        if i == 0:
            if TIMESTAMP.search(content[:70]) or re.search(r"\bAt\s+00:00(?:\.000)?", content[:70]):
                errors.append("Do not add a start timestamp to [Shot 1].")
        else:
            match = TIMESTAMP.search(content[:80])
            if not match:
                errors.append(f"[Shot {i+1}] needs a cut timestamp like At 00:05.000.")
            elif not re.search(r"(?:camera|shot) (?:cuts to|transitions to|changes to|switches to)|cross[ -]dissolv|fade|wipe", content[:180], flags=re.I):
                errors.append(f"[Shot {i+1}] needs an explicit cut/transition after the timestamp.")
            if match:
                minute, second, milli = map(int, match.groups())
                t = minute * 60 + second + milli / 1000
                if second >= 60:
                    errors.append(f"[Shot {i+1}] has invalid seconds value.")
                if t <= 0 or t >= duration:
                    errors.append(f"[Shot {i+1}] cut {t:g}s lies outside 0–{duration:g}s.")
                if cut_seconds and t <= cut_seconds[-1]:
                    errors.append(f"[Shot {i+1}] cut time must strictly increase.")
                cut_seconds.append(t)
    if len(shot_hits) > 3:
        warnings.append("4+ shots: check whether cuts are needed in this short duration.")

    if any(term in text for term in ("<Picture ", "subject_definitions:", "retention_analysis:",
                                     "reference pictures align", "<Video 1>", "<Audio 1>")):
        errors.append("Reference-image/video syntax detected in a T2VA-only prompt.")

    if body.count("<d>") != body.count("</d>"):
        errors.append("Unmatched <d> dialogue tags.")
    dialogues = DIALOG.findall(body)
    if body.count("<d>") != len(dialogues):
        errors.append("Dialogue must have a language label inside every <d>...</d> block.")
    if dialogues and not re.search(r"\(S\d+(?:,S\d+)*\)", body):
        errors.append("Dialogue found without a stable speaker ID such as (S1).")
    for lang, words in dialogues:
        if not words.strip():
            errors.append(f"Empty dialogue for [{lang}].")
        if lang.lower() == "chinese" and not re.search(r"[\u3400-\u9fff]", words):
            warnings.append("[Chinese] dialogue contains no Han characters; check language choice.")
    if re.search(r"says in an off-screen voiceover", body, flags=re.I) and not re.search(
        r"lips remain (?:completely )?closed", body, flags=re.I
    ):
        warnings.append("Off-screen voiceover: if its speaker is visible, specify closed lips.")
    if ambience.strip() == "N/A" and dialogues:
        errors.append("overall_soundscape: N/A conflicts with audible dialogue. Use it only for complete silence.")
    if re.search(r"\b(no bad hands|no ugly|no deformed|no low quality)\b", text, flags=re.I):
        warnings.append("Vague negative-prompt pile detected; replace with positive shot details.")
    if len(body.split()) > 330:
        warnings.append("Long visual prompt; check action density and redundant adjectives.")
    if re.search(r"\b(?:100% guaranteed|guaranteed perfect)\b", text, flags=re.I):
        warnings.append("Absolute quality promises do not control model behavior.")
    if music.strip().lower() in ("none", "no music", "silent"):
        warnings.append("For no background music use the canonical N/A.")
    return errors, warnings


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="Offline H3 T2VA prompt structure validator")
    parser.add_argument("prompt", type=Path, help="UTF-8 .txt prompt file")
    parser.add_argument("--duration", type=float, default=8.0, help="requested seconds (4–15)")
    args = parser.parse_args(argv)
    try:
        data = args.prompt.read_text(encoding="utf-8")
    except (OSError, UnicodeError) as e:
        print(f"INPUT ERROR: {e}", file=sys.stderr)
        return 2
    errors, warnings = check_prompt(data, args.duration)
    for issue in errors:
        print(f"ERROR: {issue}")
    for issue in warnings:
        print(f"WARN:  {issue}")
    if errors:
        print(f"FAIL ({len(errors)} errors, {len(warnings)} warnings)")
        return 1
    print(f"PASS ({len(warnings)} warnings; structural validation only, no model run)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
