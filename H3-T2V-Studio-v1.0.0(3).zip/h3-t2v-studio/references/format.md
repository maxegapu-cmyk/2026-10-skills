# H3 T2VA 兼容格式（使用手册）

该文件约定本工具输出的三字段约束，而非 MiniMax 的 API 请求参数。H3 官方对 T2VA 的格式是英文主体+三字段；本包仅覆盖纯文字生成声音/视频。

## 最简规范

```text
integrated_multimodal_description: [Shot 1] Live-action, ... The camera ... The subject ... The shot ends as ...
overall_soundscape: ...
non_diegetic_music: N/A
```

字段名和顺序不可更换，不加入 `prompt:`、`negative_prompt:`、`camera:` 作为第四字段。具体视频时长、分辨率、比例等控制项需要按用户的平台界面或 API 填写；正文中的时长词只是创意描述，不保证控制接口参数。

- `[Shot 1]` 没有 `At 00:00.000`；后续 `[Shot N] At 00:SS.mmm, the camera cuts to...`，允许 `00:MM:SS.mmm` 风格？本包采用 `MM:SS.mmm` 的官方示例格式。
- 后续镜头时间戳是**切点**，不是每个动作都要标秒数；一个镜头可连续描述前后变化。
- 切点大于零且小于视频总长度；多切时严格递增。
- 身份 `(S1)` 从首次发声就稳定到结尾；台词块 `<d>[English]...</d>`、`<d>[Chinese]...</d>` 的标签写原语言。
- 声画同步优先用一句话靠近动作主体，如 `He strikes the bell; a single metallic ring begins on contact.` 不把声音塞进配乐字段。
- `overall_soundscape` 正常 1–4 英语句，汇总声音层次；`non_diegetic_music` 正常 1–3 句或 `N/A`。
- 没有台词就不造说话者。不要为了格式而加歌唱/拟人旁白。
- 画面文字用 `a sign reading "原字"`；文字必须在用户真的要求时出现。
- 无参考图模式不要写 `<Picture 1>`、图片对齐句或 `subject_definitions` 等其他模式专用字段。

## 时长与镜头设计

| 时长 | 稳健的建议（非模型硬限制） |
|---|---|
| 4–6 秒 | 一镜、一个明确动作/反应 |
| 7–10 秒 | 以单镜为主，必要时一次切镜 |
| 11–15 秒 | 一镜完整事件，或 2–3 镜每镜清楚改变信息 |
| >15 秒 | 按独立短片生成，最终外部剪辑 |

## 常见误区

1. `overall_soundscape` 反复复述说话内容：会混淆动作声音与发声事件。
2. 音乐说成“史诗般、催泪般”而不给乐器、速度、进入时点：不可检验。
3. 每隔一秒切特写：经常引入角色/道具不连续和无用镜头。
4. 反复 `no CGI, no plastic, no bad hands...`：无足够正向可观察信息。
5. 仅写“纹身保持一致”：没有明确左/右、位置、纹样轮廓，约束无抓手。
6. 不写核心动作的完成时状态：视频缺少落点。
