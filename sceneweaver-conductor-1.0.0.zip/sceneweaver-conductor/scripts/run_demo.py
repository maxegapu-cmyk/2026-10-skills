#!/usr/bin/env python3
"""Create four fictional sample skills outside the installed Skill and run local routing."""
from pathlib import Path
import argparse
import json
import subprocess
import sys


def main():
    parser=argparse.ArgumentParser(description='SceneWeaver sample work order generator')
    parser.add_argument('--out', type=Path, required=True, help='new demo output directory')
    args=parser.parse_args()
    root=Path(__file__).resolve().parents[1]
    out=args.out.resolve()
    if out == root or root in out.parents:
        parser.error('--out must be outside installed skill directory')
    example=out/'sample_skill_collection'
    data=json.loads((root/'assets/demo_skills.json').read_text(encoding='utf8'))
    for item in data:
        folder=example/item['folder']
        folder.mkdir(parents=True,exist_ok=True)
        (folder/'SKILL.md').write_text(item['skill_md'],encoding='utf8')
        (folder/'route_profile.json').write_text(json.dumps(item['route_profile'], ensure_ascii=False,indent=2),encoding='utf8')
    script=out/'sample_screenplay.md'
    script.write_text((root/'assets/demo_script.md').read_text(encoding='utf8'),encoding='utf8')
    command=[sys.executable,str(root/'scripts/conductor.py'),'build','--script',str(script),'--root',str(example),'--out',str(out/'sample_work_order')]
    print('Generating example routing pack with fictional sample skills:')
    print(' '.join(command))
    return subprocess.call(command)

if __name__=='__main__':
    raise SystemExit(main())
