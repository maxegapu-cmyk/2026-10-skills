# 外部研究与工程借鉴（信息截至 2026-10-20）

本项目代码与调度协议重新设计、独立撰写；以下是公开工程模式的对照参考，不意味着集成、复制或依赖这些仓库。

## GitHub 工程对标

1. `MMStudioCreations/skill-router` — 运行时扫描 SKILL.md、意图匹配、前置技能路由，但其文档明确“Route, don't execute”。https://github.com/MMStudioCreations/skill-router
2. `jax-agent/skill-router` — 通过索引、轻量匹配、按需加载来降低上下文开销。https://github.com/jax-agent/skill-router
3. `anthropics/skills` 中 `skill-creator` — Skill 的 YAML 描述、渐进加载、测试迭代。https://github.com/anthropics/skills
4. `SkillMedev/skills/skills/video-storyboard` — 从 narrative beats 到 shot list 的结构化分镜输出思路，原项目偏产品演示。https://github.com/SkillMedev/skills
5. `vercel-labs/skills` — 标准化安装、搜索及多个 agent 客户端适配的工程启发，未嵌入其代码。https://github.com/vercel-labs/skills

## 学术启发（论文结论不等于本项目测评结果）

- **SkillRouter: Retrieve-and-Rerank Skill Selection for LLM Agents at Scale**, 2026-03，https://arxiv.org/abs/2603.22455 ：研究指出全文信息相比只读元数据对于检索有实质增益。这是本系统匹配时读取正文、组包时提供正文证据的理由。
- **Compositional Skill Routing for LLM Agents: Decompose, Retrieve, and Compose**, 2026-06，https://arxiv.org/abs/2606.18051 ：提出先拆任务、再检索组合，并强调任务分解是瓶颈。本系统将剧本按 beat 而非整片统一选择技能。
- **Under the Hood of SKILL.md: Semantic Supply-chain Attacks on AI Agent Skill Registry**, 2026-05，https://arxiv.org/abs/2605.11418 ：研究讨论了技能元数据/正文攻击风险，提示检索对象不应自动获得执行权限。
- **Skill Constellations: Tracing the Supply Chain of Agent Skills on GitHub**, 2026-10，https://arxiv.org/abs/2610.11169 ：说明来源与版本追踪很重要。本系统记录路径和 SHA256 便于人工复核。

其中学术资料作为研究性预印本引用，不将其指标冒充本项目表现。算法没有采用这些论文的神经编码器、FAISS 或跨编码器，因此不得宣称复现其检索精度、延迟或上下文节省百分比。

## 为什么采用这种新架构

- 通用 Router 侧重“从一整句话里选一个技能”；剧本包含多种视觉任务，要转为**分镜局部调度**。
- 只罗列技能名称不够；需要**读取可追溯原文并把技法落实到每镜**。
- 自动执行来源不明 ZIP 有权限风险；设计成**只读扫描**，工作本身交由已经授权的 agent 完成。
- 离线中文/英文混合、零额外依赖比复杂向量数据库更容易落地；但近义词召回与语义理解存在上限，通过显式 `route_profile.json` 和 agent 二次复核弥补。
- 最终以镜头是否能被模型生成、是否服务剧情为标准，而不是“调用了越多技能越强”。
