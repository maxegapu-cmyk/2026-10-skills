# 安装与使用（小白友好 · Windows / macOS / Linux）

## 0. 这到底能自动化什么？

只需将本 Skill 安装一次，在 Claude Code / Codex 这类**可读取本机文件并运行 Python** 的 AI agent 中让它执行“剧本转分镜”。后续它会自动分段、寻找本机目录和 ZIP/.skill 技能、读取命中的 SKILL.md，把技能技法写进每镜的静帧与视频提示词。

注意：`conductor.py` 是**确定性的本地检索器与调度准备器**，不是独立的大语言模型；高质量创意提示词由装有本 Skill 的 AI agent 阅读工作包后生成。浏览器聊天框若无法访问本机，就不能直接自动检索电脑硬盘。

## 1. 安装

把 `sceneweaver-conductor` 整个目录复制进：

- Claude Code（Windows 示例）：`C:\Users\你的用户名\.claude\skills\sceneweaver-conductor`
- Codex（常见共享目录）：`C:\Users\你的用户名\.agents\skills\sceneweaver-conductor`
- 项目内：`项目根目录\.agents\skills\sceneweaver-conductor`（Codex）或 `.claude\skills\sceneweaver-conductor`（Claude Code）。

不要只放 `SKILL.md`，因为调度脚本在 `scripts/`。要求 Python 3.10+，执行 `python --version` 确认。Windows 如果 `python` 未识别，可用 `py -3` 替换。无需 pip 安装、无需 API Key、无需联网。

## 2. 最简单的使用方式

在 agent 对话里直接说：

> 请调用 sceneweaver-conductor，将 `D:\影片\剧本.md` 拆成分镜，自动检索 `D:\AI技能收藏` 中的所有 Skill 文件夹和 ZIP。逐段实际应用技能技法，输出 `D:\影片\分镜产物\shots.json`、`shotlist.md` 和每镜可复制视频提示词，最后跑检查。画幅 16:9，优先每镜 8 秒，不允许改剧情。

Agent 自动调用 Python 并完成真正的写作步骤；不能只给推荐名单。旧技能无需改动即可尝试检索。

## 3. 一条命令先体验虚构样例

```powershell
python .\scripts\run_demo.py --out "D:\sceneweaver-demo"
```

会在指定目录创建四个示例技能，模拟冲击、打斗、叙事和连续性，并输出完整的分段调度工作包。示例仅演示检索与装配；高质量视频提示词仍由 agent 接管撰写。

## 4. 手动操作（PowerShell）

打开 PowerShell；定位解压后的 Skill 根目录：

```powershell
cd "C:\Users\你的用户名\.claude\skills\sceneweaver-conductor"
python .\scripts\conductor.py inspect --root "D:\AI技能收藏"
python .\scripts\conductor.py build --script "D:\影片\剧本.md" --root "D:\AI技能收藏" --out "D:\影片\分镜产物" --aspect "16:9" --seconds 8
```

输出目录中有：`catalog.json`（发现的全部技能摘要）、`route_plan.json`（已选择技能）、`contexts/`（每段对应的技能正文证据）、`AGENT_WORK_ORDER.md`（发给 AI agent 的执行指令）、`shots_TEMPLATE.json`（空白骨架，**不是最终提示词**）。把这个目录交给 Claude Code 或 Codex，让它执行 `AGENT_WORK_ORDER.md` 生成 `shots.json` 和 `shotlist.md`。写完后：

```powershell
python .\scripts\conductor.py check --plan "D:\影片\分镜产物\route_plan.json" --shots "D:\影片\分镜产物\shots.json"
```

结果 `PASS` 意味着字段、节拍覆盖、技能引用形式通过检查；不证明审美优秀或视频模型一定成功。

## 5. 已安装技能自动发现

不传 `--root` 时，会尝试扫描标准用户和项目目录：`.claude/skills`、`.agents/skills`、`.codex/skills`。如收藏夹不在这些目录，必须显式传 `--root`。可以多次使用 `--root` 指定多个位置：

```powershell
python .\scripts\conductor.py inspect --root "D:\AI技能收藏" --root "E:\新收集的Skills.zip"
```

可读普通 `SKILL.md` 和包含 `SKILL.md` 的 ZIP；不执行 ZIP 内程序，也不下载未知仓库。ZIP 应包含合理的目录结构。扫描默认忽略隐藏子目录、链接、node_modules、输出目录、过深嵌套和超限文件，必要时先解压并指明目录。

## 6. 识别不到某技能怎么办？可选 route_profile.json

为“冲击效果”技能所在目录放一个 `route_profile.json`（与它的 `SKILL.md` 同级）：

```json
{
  "capabilities": ["impact", "combat"],
  "triggers": ["冲击针", "命中", "打击停顿", "hit stop"],
  "excludes": ["只讨论恋爱关系"],
  "depends_on": [],
  "conflicts_with": [],
  "priority": 1
}
```

没有配置时也会自动解析名字、描述和正文。若语义意图未被关键词识别，可由 agent 检查 `catalog.json` 后创建 `overrides.json`：

```json
{"S01-B001": ["catalog.json中对应的技能id"], "S01-B003": ["demo-narrative-beats"]}
```

再执行 `build` 并追加 `--overrides "覆盖文件路径"`。同名技能必须使用 id 消除歧义，目标必须已在库中；这是一次有证据的智能复核，而非让 Python 规则自称完全理解复杂剧情。`capabilities` 是**覆盖自动分类**，标签只使用：`impact` 冲击、`combat` 打斗、`dialogue` 对白、`narrative` 叙事、`emotion` 表演、`suspense` 悬念、`camera` 摄影、`lighting` 光影、`audio` 声音、`continuity` 连续性、`texture` 材质、`environment` 环境。

`depends_on` 使用其他技能的 **name**，会在调度顺序中提前插入前置技能；缺失依赖与循环会出现在 `routing_issues`。`conflicts_with` 可排除不能并用的技能。此文件是调度元数据，不会使不可用的 API/模型突然可用。

## 7. 最常见误会

- “把所有 ZIP 给它，它会自动跑里面每个 Python/工具？”**不会**。它不会执行不可信技能程序。它会读取技法文本，并指挥已授权的 agent 完成可执行部分。
- “可以在不运行 Claude/Codex 的情况下自动写出大师级提示词？”**不能**。离线脚本提供证据包、任务拆分和结构化框架；生成质量取决于 AI agent 的能力、原技能质量和原剧本。
- “我有 300 个技能，生成时都要塞进上下文吗？”**不需要**。每个 beat 只加载相关的少量技能上下文（默认最多 3 个主选，另有声明的必要前置依赖）。
- “改剧本后更新？”重新执行 build；原文 SHA256、上下文和路径会更新。为防覆盖旧成品，推荐每次使用新的输出子目录；`build` 会重写 `route_plan.json`、`contexts` 对应文件和 `shots_TEMPLATE.json`，但不会自动覆盖 `shots.json`。
