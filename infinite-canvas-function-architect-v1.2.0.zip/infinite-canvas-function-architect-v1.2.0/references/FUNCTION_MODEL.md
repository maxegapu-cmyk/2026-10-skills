# Function Model

## 1. Why a typed model exists

Most bad feature canvases fail because they place unlike concepts at the same level. “User login,” “Sign-in page,” “PostgreSQL,” “security,” and “increase activation” become five equal sticky notes even though they are five different semantic layers.

This Skill prevents that collapse by typing every important item.

## 2. Node type tests

### goal
Use when the statement describes an outcome, not a capability.
Test: if the system could accomplish it in several different ways, it is probably a goal.

### actor
Use for a person, role, organization, agent, or external party that initiates or receives behavior.

### module
Use for an ownership boundary or coherent business capability domain.
Test: several features can belong to it without sharing a screen.

### feature
Use for a capability someone can invoke or a system can provide.
Test: it can be described as “the system can ...” and has an observable result.

### flow
Use for a stage in an ordered process or journey.

### data
Use for a durable or logically distinct information entity / state source.

### integration
Use for an external system or boundary crossed through API, protocol, import/export, device, or platform.

### constraint
Use for a restriction that shapes implementation or behavior but is not a user capability.

### decision
Use for an unresolved or explicit choice with alternatives.

### risk
Use for a failure mode, uncertainty, exposure, or fragility.

### metric
Use for an observable signal tied to a goal or feature.

## 3. Feature vs implementation

Bad feature: “Use Redis cache.”

Possible true feature: “Search results return within the agreed latency target under expected load.”

Redis may be an implementation decision that supports that capability.

## 4. Feature vs UI

Bad feature: “Settings page.”

Possible true features:

- change notification preferences
- change password
- manage connected accounts
- delete account

The page is presentation. The features are capabilities.

## 5. Priority semantics

`must` — required to satisfy the user’s stated core outcome or a hard dependency of it.

`should` — important but core outcome still exists without it.

`could` — useful enhancement with low dependency pressure.

`later` — intentionally deferred.

`unknown` — insufficient evidence.

Never auto-upgrade `unknown` to a false certainty.

## 6. Assumption semantics

`none` — explicitly stated or directly evidenced.

`low` — strong structural implication with little ambiguity.

`medium` — plausible inference that may change design.

`high` — weak inference; should be shown as a question, not silently implemented.

## 7. Edge semantics

Use `contains` for module membership.
Use `requires` for prerequisite capability/dependency.
Use `triggers` for event initiation.
Use `reads`/`writes` for data interaction.
Use `produces` for outputs/artifacts.
Use `serves` between feature and actor/goal when useful.
Use `measured_by` for metric links.
Use `next` for temporal flow ordering.
Use `blocks` for an active gating relationship.
Use `conflicts` and `alternative_to` sparingly for decisions.

## 8. Sparse-graph principle

A graph with 80 nodes and 260 edges is usually worse than the same model with 90 meaningful edges.

Edges are explanations, not decoration.
