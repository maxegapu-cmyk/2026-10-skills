# QA Checklist

## Model

- [ ] All node IDs are unique.
- [ ] All edge IDs are unique.
- [ ] Every edge source and target exists.
- [ ] Every feature belongs to a module or has an explicit reason not to.
- [ ] Unknown information remains marked unknown.
- [ ] Duplicate capability names were checked semantically, not only textually.
- [ ] `requires` cycles were inspected.
- [ ] Orphans were surfaced.
- [ ] Goal-to-feature coverage was checked.
- [ ] Data ownership/source gaps were checked.

## Visual

- [ ] Main goal is obvious.
- [ ] Major modules are identifiable at default zoom.
- [ ] Text is readable at default zoom.
- [ ] Node types can be distinguished without relying on color alone.
- [ ] Edge labels/types are understandable.
- [ ] Dense regions can be filtered or collapsed.
- [ ] User can fit all content.
- [ ] Search can focus a node.

## Interaction

- [ ] Zoom is pointer-centered.
- [ ] Pan does not move a selected node accidentally.
- [ ] Dragged nodes preserve their world coordinates.
- [ ] Arrows remain attached after node move.
- [ ] Import rejects malformed JSON without destroying the current model.
- [ ] Export round-trips without semantic loss.

## Growth test

Add 20% more nodes to the largest module and re-check:

- label collisions
- edge crossings
- filter usefulness
- layout readability
- performance

## Failure test

Intentionally provide:

- a duplicate ID
- an edge to a missing node
- a `requires` cycle
- a feature with no module

The validator or diagnostic stage must report them.
