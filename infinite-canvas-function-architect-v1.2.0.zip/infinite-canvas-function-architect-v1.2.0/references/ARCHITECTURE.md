# Architecture

## Canonical data flow

The model owns meaning. The renderer owns pixels.

```text
Raw Requirements
      |
      v
Normalizer -> Typed Graph -> Diagnostics -> Layout Adapter -> Renderer
                   |               |              |
                   +--> JSON <-----+--------------+
```

## Separation of concerns

### Requirement normalizer
Produces atomic claims and uncertainty labels.

### Graph builder
Creates stable IDs, nodes, groups, and typed edges.

### Diagnostic engine
Runs structural checks independent from rendering.

### Layout adapter
Converts the graph into X/Y coordinates while retaining semantic data.

### Renderer
Maps nodes/edges to DOM/SVG or framework components.

### Persistence adapter
Loads/saves canonical JSON. UI-specific temporary state should not pollute core semantics.

## Stable ID strategy

Prefer readable opaque IDs such as:

- `mod_identity`
- `feat_password_reset`
- `data_user_account`

If titles change, IDs should normally remain stable.

Never derive the ID solely from the current title after the model has been created.

## Standalone canvas camera

Maintain:

```js
camera = { x, y, scale }
```

World-to-screen transform:

```text
screenX = worldX * scale + x
screenY = worldY * scale + y
```

Pointer-centered zoom must preserve the world coordinate beneath the pointer before/after scale change.

## Edge rendering

For portable HTML:

- one SVG layer inside the same transformed world root as the nodes, or
- one SVG overlay whose path points are calculated in screen space.

The first approach is simpler for pan/zoom because node and edge geometry share the transform.

Recompute a path only when an incident node changes position or dimensions.

## Layout adapters

### Hierarchical feature map
Dagre or deterministic custom columns.

### Nested compound graph
ELK can be considered when cluster routing and nested layouts become difficult.

### Manual review canvas
Retain user X/Y positions, and only auto-layout new/unplaced nodes.

## Persistence

Portable canvas:

- explicit JSON export
- JSON import
- optional localStorage autosave keyed by a stable project id

Product app:

- backend persistence may save canonical graph separately from viewport/user UI preferences.

## Versioning

Model files must include `schema_version`.

When schema changes, migration should be explicit. Do not reinterpret old fields silently.
