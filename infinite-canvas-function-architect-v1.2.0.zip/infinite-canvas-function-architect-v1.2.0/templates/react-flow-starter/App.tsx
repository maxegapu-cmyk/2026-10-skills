import { useMemo } from 'react';
import {
  Background,
  Controls,
  MiniMap,
  ReactFlow,
  type Edge,
  type Node,
} from '@xyflow/react';
import '@xyflow/react/dist/style.css';

export type CanvasModel = {
  nodes: Array<{ id: string; type: string; title: string; summary?: string; position: { x: number; y: number } }>;
  edges: Array<{ id: string; type: string; source: string; target: string; label?: string }>;
};

export function Canvas({ model }: { model: CanvasModel }) {
  const nodes = useMemo<Node[]>(() => model.nodes.map((n) => ({
    id: n.id,
    position: n.position,
    data: { label: n.title, summary: n.summary, semanticType: n.type },
  })), [model]);

  const edges = useMemo<Edge[]>(() => model.edges.map((e) => ({
    id: e.id,
    source: e.source,
    target: e.target,
    label: e.label ?? e.type,
    data: { semanticType: e.type },
  })), [model]);

  return (
    <div style={{ width: '100vw', height: '100vh' }}>
      <ReactFlow nodes={nodes} edges={edges} fitView>
        <Background />
        <MiniMap />
        <Controls />
      </ReactFlow>
    </div>
  );
}
