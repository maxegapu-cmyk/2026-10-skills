#!/usr/bin/env python3
"""Optional real-browser smoke/stress test for the standalone canvas.

Requires: playwright Python package and a Chromium executable. The artifact itself
has no Playwright dependency; this file exists for release QA.
"""
from __future__ import annotations

import json
import os
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
HTML = ROOT / "templates" / "infinite-canvas-standalone.html"
CHROMIUM = os.environ.get("CHROMIUM_PATH", "/usr/bin/chromium")


def make_large_model(count=3000):
    cols = 60
    nodes = [{"id":"module","type":"module","title":"Large module","summary":"stress","position":{"x":0,"y":0}}]
    edges = []
    for i in range(count):
        x=(i%cols)*320; y=(i//cols)*170
        nodes.append({"id":f"n{i}","type":"feature","title":f"Feature {i}","summary":"stress node","position":{"x":x,"y":y},"module_id":"module","acceptance":["ok"]})
        if i:
            edges.append({"id":f"e{i}","type":"requires","source":f"n{i-1}","target":f"n{i}"})
    return {"schema_version":"1.0","title":"Large","nodes":nodes,"edges":edges,"groups":[],"camera":{"x":120,"y":80,"scale":1},"meta":{"created_at":"","updated_at":""}}


def main():
    try:
        from playwright.sync_api import sync_playwright
    except Exception as exc:
        print("SKIP: Playwright unavailable:", exc)
        return 2

    html = HTML.read_text(encoding="utf-8")
    results = []
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True, executable_path=CHROMIUM, args=["--no-sandbox"])
        page = browser.new_page(viewport={"width":1440,"height":900})
        page_errors = []
        page.on("pageerror", lambda err: page_errors.append(str(err)))
        page.set_content(html, wait_until="load")
        page.wait_for_function("window.ICA_CANVAS_STATUS && window.ICA_CANVAS_STATUS.nodes === 4")

        # Drag must not throw InvalidStateError and must actually move the card.
        first = page.locator('.node[data-id="goal"]')
        before = first.get_attribute("style")
        edge_before = page.locator('.edge[data-edge-id="e2"]').get_attribute("d")
        box = first.bounding_box()
        page.mouse.move(box["x"]+30, box["y"]+30); page.mouse.down()
        page.mouse.move(box["x"]+180, box["y"]+120, steps=8); page.mouse.up()
        page.wait_for_timeout(100)
        after = first.get_attribute("style")
        edge_after = page.locator('.edge[data-edge-id="e2"]').get_attribute("d")
        assert before != after, "drag did not move node"
        assert edge_before != edge_after, "incident edge did not follow dragged node"
        assert not page_errors, f"browser errors after drag: {page_errors}"
        results.append("drag/pointer-capture PASS")

        # Wheel zoom should change camera while staying finite.
        cam_before = page.evaluate("window.ICA_CANVAS_STATUS.camera.scale")
        page.mouse.move(700,450); page.mouse.wheel(0,-600); page.wait_for_timeout(100)
        cam_after = page.evaluate("window.ICA_CANVAS_STATUS.camera.scale")
        assert cam_after > cam_before and cam_after <= 3
        results.append("pointer-centered zoom PASS")

        # Invalid import must preserve current model.
        old_nodes = page.evaluate("window.ICA_CANVAS_STATUS.nodes")
        page.once("dialog", lambda d: d.dismiss())
        page.set_input_files("#file", files=[{"name":"bad.json","mimeType":"application/json","buffer":b'{"nodes":"bad"}'}])
        page.wait_for_timeout(150)
        assert page.evaluate("window.ICA_CANVAS_STATUS.nodes") == old_nodes
        assert not page_errors, f"browser errors after bad import: {page_errors}"
        results.append("transactional malformed-import rejection PASS")

        # Valid far-coordinate import proves the render surface is not bounded to a fixed 100k SVG/grid box.
        far = {"schema_version":"1.0","title":"Far","nodes":[
            {"id":"a","type":"feature","title":"A","summary":"","position":{"x":-250000,"y":-250000}},
            {"id":"b","type":"feature","title":"B","summary":"","position":{"x":250000,"y":250000}}
        ],"edges":[{"id":"ab","type":"requires","source":"a","target":"b"}],"groups":[],"camera":{"x":0,"y":0,"scale":1},"meta":{"created_at":"","updated_at":""}}
        payload=json.dumps(far).encode()
        page.set_input_files("#file", files=[{"name":"far.json","mimeType":"application/json","buffer":payload}])
        page.wait_for_function("window.ICA_CANVAS_STATUS.nodes === 2")
        page.wait_for_function("document.querySelector('.edge[data-edge-id=\"ab\"]')?.getAttribute('d')?.length > 0")
        d=page.locator('.edge[data-edge-id="ab"]').get_attribute("d")
        assert "250" in d and d.startswith("M -"), d
        assert not page_errors, f"browser errors after far import: {page_errors}"
        results.append("far-coordinate / non-finite-surface PASS")

        # 3000-node practical stress import. This is a smoke threshold, not an unlimited-scale promise.
        large=make_large_model(3000)
        start=time.perf_counter()
        page.set_input_files("#file", files=[{"name":"large.json","mimeType":"application/json","buffer":json.dumps(large).encode()}])
        page.wait_for_function("window.ICA_CANVAS_STATUS.nodes === 3001", timeout=20000)
        page.wait_for_timeout(250)
        elapsed=time.perf_counter()-start
        status=page.evaluate("window.ICA_CANVAS_STATUS")
        assert status["visible"] < status["nodes"], status
        assert not page_errors, f"browser errors after large import: {page_errors}"
        results.append(f"3000-node viewport-culling stress PASS ({elapsed:.2f}s load-to-ready, {status['visible']}/{status['nodes']} mounted-visible)")

        # Search + Enter must focus and select a specific node.
        page.fill("#search","Feature 2999")
        page.press("#search","Enter")
        page.wait_for_timeout(150)
        assert page.evaluate("window.ICA_CANVAS_STATUS.selected") == "n2999"
        results.append("search-and-focus PASS")

        # Drag on the 3000-node graph must stay error-free and update only local geometry.
        target=page.locator('.node[data-id="n2999"]')
        box=target.bounding_box(); edge_id="e2999"
        edge_before=page.locator(f'.edge[data-edge-id="{edge_id}"]').get_attribute("d")
        page.mouse.move(box["x"]+20,box["y"]+20); page.mouse.down()
        page.mouse.move(box["x"]+140,box["y"]+90,steps=10); page.mouse.up(); page.wait_for_timeout(100)
        edge_after=page.locator(f'.edge[data-edge-id="{edge_id}"]').get_attribute("d")
        assert edge_before != edge_after
        assert not page_errors, f"browser errors after large-graph drag: {page_errors}"
        results.append("3000-node drag + incident-edge update PASS")

        # Export must produce parseable canonical JSON.
        with page.expect_download() as dl:
            page.click("#export")
        download=dl.value
        out=Path(download.path())
        exported=json.loads(out.read_text(encoding="utf-8"))
        assert len(exported["nodes"]) == 3001 and len(exported["edges"]) == 2999
        results.append("export round-trip surface PASS")

        browser.close()

    for r in results: print(r)
    print("BROWSER_SMOKE_PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
