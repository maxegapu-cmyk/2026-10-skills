#!/usr/bin/env python3
"""Browser-level release test: exported HTML really opens, works, and carries data."""
from __future__ import annotations
import json
import os
import tempfile
from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT=Path(__file__).resolve().parents[1]
HTML=ROOT / 'templates' / 'infinite-canvas-standalone.html'
CHROMIUM=os.environ.get('CHROMIUM_PATH','/usr/bin/chromium')


def model(title='Exported & 中文 <test>'):
    return {
        'schema_version':'1.0','title':title,
        'nodes':[
            {'id':'module','type':'module','title':'产品功能地图','summary':'覆盖完整功能 <img src=x onerror=alert(1)>', 'position':{'x':80,'y':80}},
            {'id':'feature','type':'feature','title':'出口 </script><script>window.canvasPwned=true</script>','summary':'read only text', 'position':{'x':420,'y':220},'module_id':'module','acceptance':['accept']}
        ],
        'edges':[{'id':'e1','type':'contains','source':'module','target':'feature'}],
        'groups':[],'camera':{'x':20,'y':30,'scale':1.2},'meta':{'created_at':'','updated_at':''}
    }


def run():
    errors=[]
    with tempfile.TemporaryDirectory() as td, sync_playwright() as p:
        browser=p.chromium.launch(headless=True,executable_path=CHROMIUM,args=['--no-sandbox'])
        page=browser.new_page(accept_downloads=True, viewport={'width':1600,'height':900})
        page.on('pageerror', lambda e: errors.append(str(e)))
        page.set_content(HTML.read_text(encoding='utf-8'),wait_until='load')
        page.wait_for_function('window.ICA_CANVAS_STATUS?.nodes === 4')

        # Invalid paste must not destroy current view.
        page.click('#paste')
        page.locator('#pasteArea').fill('{bad}')
        page.once('dialog',lambda d: d.dismiss())
        page.click('#pasteSubmit')
        assert page.evaluate('window.ICA_CANVAS_STATUS.nodes')==4
        assert page.locator('#pasteDialog').evaluate('(el)=>el.open')

        # A valid pasted object imports and displays correctly.
        raw=json.dumps(model(),ensure_ascii=False)
        page.locator('#pasteArea').fill(raw)
        page.click('#pasteSubmit')
        page.wait_for_function('window.ICA_CANVAS_STATUS?.nodes === 2')
        assert not page.locator('#pasteDialog').evaluate('(el)=>el.open')
        assert page.locator('.node[data-id="feature"] .title').inner_text()=='出口 </script><script>window.canvasPwned=true</script>'
        assert page.evaluate('window.canvasPwned') is None

        # Download a true HTML document containing the full model with safe escaping.
        with page.expect_download() as dl:
            page.click('#exportHtml')
        download=dl.value
        assert download.suggested_filename=='index.html'
        dest=Path(td) / 'index.html'
        download.save_as(dest)
        html=dest.read_text(encoding='utf-8')
        assert html.startswith('<!doctype html>')
        assert '\\u003c/script>' in html
        assert '<script>window.canvasPwned=true</script>' not in html
        assert '<article class="node"' not in html, 'should not serialize live DOM cards'

        # Fresh Chromium document from the exported bytes; this sandbox blocks file:// navigation.
        reloadpage=browser.new_page(accept_downloads=True,viewport={'width':1600,'height':900})
        reloadpage.on('pageerror',lambda e: errors.append('reopen '+str(e)))
        reloadpage.set_content(dest.read_text(encoding='utf-8'),wait_until='load')
        reloadpage.wait_for_function('window.ICA_CANVAS_STATUS?.nodes === 2')
        assert reloadpage.locator('.node[data-id="module"] .title').inner_text()=='产品功能地图'
        assert reloadpage.locator('.node[data-id="feature"] .title').inner_text()=='出口 </script><script>window.canvasPwned=true</script>'
        assert reloadpage.evaluate('window.canvasPwned') is None
        assert reloadpage.locator('.edge[data-edge-id="e1"]').count()==1

        # The exported file stays interactive and can be re-exported without data loss.
        first=reloadpage.locator('.node[data-id="module"]')
        before=first.get_attribute('style')
        box=first.bounding_box()
        reloadpage.mouse.move(box['x']+20,box['y']+20)
        reloadpage.mouse.down()
        reloadpage.mouse.move(box['x']+100,box['y']+50,steps=8)
        reloadpage.mouse.up()
        reloadpage.wait_for_timeout(70)
        assert first.get_attribute('style')!=before
        with reloadpage.expect_download() as dl:
            reloadpage.click('#export')
        out=json.loads(Path(dl.value.path()).read_text(encoding='utf-8'))
        assert out['title']==model()['title']
        assert len(out['nodes'])==2 and len(out['edges'])==1
        assert next(n for n in out['nodes'] if n['id']=='module')['position']!={'x':80,'y':80}
        assert not errors,errors
        print('HTML_EXPORT_E2E_PASS: invalid paste / valid paste / XSS guard / fresh-page standalone load / drag / JSON re-export')

        # Large-graph HTML should contain one copy of graph data, not a clone
        # of thousands of DOM cards. It must render after a full fresh reload.
        from browser_smoke import make_large_model
        large=make_large_model(3000)
        payload=json.dumps(large).encode('utf-8')
        page.set_input_files('#file',files=[{'name':'large.json','mimeType':'application/json','buffer':payload}])
        page.wait_for_function('window.ICA_CANVAS_STATUS?.nodes === 3001',timeout=30000)
        with page.expect_download() as dl:
            page.click('#exportHtml')
        large_path=Path(td)/'large.html'; dl.value.save_as(large_path)
        large_html=large_path.read_text(encoding='utf-8')
        assert '<article class="node"' not in large_html
        assert len(large_html)<len(payload)*2+len(HTML.read_bytes()), 'HTML export duplicated too much live DOM'
        large_page=browser.new_page(viewport={'width':1400,'height':900})
        large_page.on('pageerror',lambda e: errors.append('large '+str(e)))
        large_page.set_content(large_html,wait_until='load')
        large_page.wait_for_function('window.ICA_CANVAS_STATUS?.nodes === 3001',timeout=30000)
        large_page.wait_for_function('window.ICA_CANVAS_STATUS?.edges === 2999',timeout=30000)
        assert not errors,errors
        print(f'LARGE_HTML_EXPORT_PASS: 3001 nodes / 2999 edges / {len(large_html)} bytes')
        browser.close()


if __name__ == '__main__':
    run()
