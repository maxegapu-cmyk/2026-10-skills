# Pressure Test Report — v1.2.0 Export Addendum

Date: 2026-10-14

**New release gate**: `python tests/browser_export_smoke.py`. Covered: malformed-paste transactionality; raw JSON paste; Chinese/HTML-looking data; HTML export; embedded JSON escaping of script delimiters; new independent Chromium page parsing generated HTML bytes; drag interaction inside exported HTML; subsequent JSON re-export with moved positions. All passed in this sandbox.

**Environment limitation**: this Chromium runtime blocks navigation to both `file://` and `http://127.0.0.1` with `ERR_BLOCKED_BY_ADMINISTRATOR`; the test loads the *generated HTML bytes* using Playwright `set_content()` in a fresh Chromium page. This establishes standalone document rendering and behavior, but not navigation-based hosting or double-click semantics in a local desktop browser. No Safari/Firefox QA was performed.

---

# Pressure Test Report — v1.1.0

Date: 2026-10-02

This report records tests actually executed against the release candidate. It does not treat syntax checks as proof of browser behavior.

## Bugs found in v1.0.0 before release hardening

The following failures were reproduced, then fixed:

1. Non-object JSON root caused `AttributeError` traceback.
2. `nodes` with the wrong type caused `AttributeError` traceback.
3. A feature missing `id` caused `KeyError` traceback.
4. A 2,500-node `requires` chain caused `RecursionError`.
5. First node drag in Chromium caused `InvalidStateError` from pointer capture because selection re-rendered and detached the original pointer target.
6. Dragging rebuilt every edge on every pointer event despite the Skill's own large-canvas rule.
7. Node lookup during edge work used repeated linear scans.
8. The visible grid used a finite 100,000px element even though the artifact described itself as an infinite canvas.
9. Standalone import only checked for `nodes` / `edges` arrays and could accept structurally dangerous data before rendering.

All nine items were changed in v1.1.0.

## Automated validator regression

Command:

```bash
pytest -q
```

Result: **11/11 PASS**.

Coverage includes:

- valid reference model
- missing edge target
- root not an object
- `nodes` wrong type
- feature missing ID
- 3,000-node non-cyclic dependency chain
- explicit dependency cycle
- strict-warning release gate
- duplicate JSON object key
- non-finite JSON number
- invalid camera scale

## Validator malformed-input fuzz

Deterministic JSON-shaped fuzz objects: **5,000 cases**.

Result: **PASS — zero validator exceptions**.

This supplements targeted regression tests; it is not a formal proof against every possible malicious input.

## Large graph validator benchmark

Synthetic model:

- 10,001 nodes total
- 10,000 feature nodes
- 9,999 `requires` edges

Result in the release environment:

- exit code: `0`
- elapsed: approximately **0.71s**
- no recursion failure
- one expected “large module” warning

## JSON Schema validation

- Draft 2020-12 schema parses: PASS
- bundled example validates against schema: PASS
- no-dependency validator validates bundled example: PASS (`0 errors / 0 warnings`)

## JavaScript syntax

The standalone `<script>` body was extracted and checked with Node 22 `node --check`.

Result: **PASS**.

## Real Chromium browser smoke/stress

Environment used for release QA:

- headless Chromium
- Playwright Python driver
- 1440×900 viewport

Executed behavior:

- initial render: PASS
- node drag: PASS
- pointer capture: PASS, no `InvalidStateError`
- incident edge follows dragged node: PASS
- pointer-centered wheel zoom: PASS
- malformed import rejected transactionally: PASS
- far-coordinate model at ±250,000 world units: PASS
- search + Enter focus/select: PASS
- JSON export and parse-back: PASS
- browser page errors: none during the test

### 3,000-node practical stress

Synthetic graph:

- 3,001 nodes total
- 2,999 edges

Observed release run:

- load-to-ready: approximately **1.3–1.6s**
- viewport culling active
- large-graph node drag: PASS
- incident edge update after drag: PASS
- no browser page errors

### Additional 10,000-node stress probe

Synthetic graph:

- 10,001 nodes total
- 9,999 edges

Observed release probe:

- load-to-ready: approximately **2.18s**
- only ~2,240 nodes were visible/render-active at fit-view in that run
- search/focus to node 9,999: PASS
- 30-step drag on node 9,999: PASS
- zoom after large import: PASS
- no browser page errors

The 10k test demonstrates headroom on this machine; it is **not** a promise that the DOM lane is appropriate for every 10k-node real product. Heavy custom cards, images, animation, or dense same-viewport layouts can reduce the practical limit sharply.

## Security/robustness properties checked

- user text is inserted with `textContent`, not interpreted as executable HTML
- imported model is validated before the live model is replaced
- node/edge IDs must use a restricted safe pattern
- numeric camera and node coordinates must be finite
- JSON loader rejects duplicate object keys and `NaN` / infinity constants
- standalone artifact loads no third-party scripts

## Release limits

- This is not a collaborative/multiplayer editor.
- Undo/redo is not implemented in the dependency-free reference canvas.
- The standalone DOM lane is intended for reviewable product/system maps, not arbitrarily complex 100k-object CAD scenes.
- For very large or highly interactive production graphs, use the React Flow lane with memoized nodes, collapsed branches and product-specific state management; use more specialized rendering/culling only when profiling proves it is necessary.
- Browser QA covered Chromium here; Safari/Firefox automated runs were not available in this release environment and are therefore not claimed as verified.

## v1.2.0 live export stress extension

Added a large-graph self-contained HTML test after the functional export test: **3,001 nodes, 2,999 edges**, resulting HTML **676,188 bytes**, reloaded in a fresh Chromium document with node and edge counts preserved. The exported HTML contains no serialised live `<article class="node">` elements; it reconstructs from embedded JSON instead. The test ensures the exported file does not duplicate the entire rendered DOM. This remains headless Chromium, not an exhaustive compatibility or public-hosting test.

The inherited `browser_smoke.py` had a timing-dependent assertion on SVG path creation directly after a model import. A wait for the populated path was added to remove that false failure; the renderer itself was unchanged.
