# Infinite Canvas Function Architect v1.2.0

A clean-room Skill for turning messy requirements into a structured infinite canvas and functional architecture map.

## What it does

This package is built around one idea: a useful infinite canvas is not “boxes on a huge surface.” It is a **graph-backed product model** with a visual editor on top.

The skill can:

- extract atomic capabilities from rough notes
- separate goals, actors, modules, features, flows, data, integrations, constraints, risks, and decisions
- cluster features by functional ownership
- build typed relationships
- surface missing prerequisites and failure paths
- detect orphans, duplicates, cycles, ownership overlap, and hidden data gaps
- create an MVP boundary without flattening the whole roadmap
- render a portable, dependency-free HTML canvas or guide a React Flow implementation
- preserve stable node IDs across iterations
- export/import one canonical JSON model
- **export a complete, deployable `index.html` with the current canvas embedded**
- **paste JSON code directly to load a canvas without saving an intermediate file**


## 快速上手（Windows / 零编程）

**你拿到的是 JSON 代码时：**

1. 双击 `templates/infinite-canvas-standalone.html`，使用 **Chrome 或 Edge** 打开。这时看到的是示例画布。
2. 如果有一大段 JSON **文字**：点顶部 `Paste JSON · 粘贴代码`，把完整 JSON 粘贴进去，再点 `导入画布`。
3. 如果已经存为 `.json` **文件**：点 `Import JSON · 文件`，选择对应文件。
4. 检查是不是你的节点/连接线。再点 **`Export HTML · 可部署`**，浏览器会下载 **`index.html`**。
5. 双击下载的 `index.html`，选择 **Chrome 或 Edge**。不用安装 Node、Python、VS Code，不用联网。
6. 要发布为网站时，把 `index.html` 放进一个空文件夹，上传到支持静态 HTML 的网站托管服务（如 Netlify Drop）；得到的网址可供别人打开。

**特别注意**：`Export JSON · 数据备份` 只导出画布数据，不能直接变成网页；`Export HTML · 可部署` 才是能直接打开或部署的网页。HTML 是**生成时的快照**；别人在线修改后不会自动写回你的服务器。要保存改动，需要重新导出 JSON 或 HTML。

本工具只接受符合包内 `schema/canvas-model.schema.json` 的标准图模型。**其他白板软件导出的任意 JSON 可能格式不一致**，需要先转换，不能保证直接粘贴成功。

## v1.2.0 — Deployable export

- Standalone app now embeds the live graph in a self-contained `index.html` and can import it back on reload.
- Paste-in JSON workflow for people who only received code text, without a saved file.
- Reopen/re-export and security tests verify output is an executable graph view, not just JSON text.
- Export cleans transient DOM and encodes unsafe text before embedding as script data; no CDN or runtime build step is required.

## Reliability hardening in v1.1.0

This release was stress-tested as a real artifact rather than only reviewed as prompt text. It includes:

- crash-safe validation for malformed JSON-shaped data
- iterative dependency-cycle detection that does not blow Python recursion on long chains
- transactional import: bad files do not replace the current canvas
- real Chromium drag/zoom/search/import/export smoke tests
- viewport culling and semantic zoom for larger maps
- indexed node lookup and incident-edge-only updates during drag
- unbounded world coordinates instead of a fixed-size fake "infinite" surface
- an optional strict validator gate for CI/release use

See `PRESSURE_TEST.md` for the exact failures found, fixes applied, test sizes, measured release-environment timings, and remaining limits.

### Release verification

```bash
python scripts/validate_canvas.py examples/saas-feature-map.canvas.json
python scripts/validate_canvas.py --strict examples/saas-feature-map.canvas.json
pytest -q
python tests/browser_smoke.py   # optional: requires Playwright + Chromium
python tests/browser_export_smoke.py   # new: paste JSON -> HTML -> fresh-page render -> edit -> export + 3000-node stress
```

The portable HTML lane is intentionally dependency-free. For very large production graphs, treat the 10k browser probe as headroom evidence, not an unlimited-scale guarantee. Complex custom cards, images, animation, or thousands of simultaneously visible nodes can require a framework/virtualized renderer.

## Package layout

- `SKILL.md` — main behavior contract
- `schema/canvas-model.schema.json` — canonical model schema
- `scripts/validate_canvas.py` — no-dependency structural validator
- `templates/infinite-canvas-standalone.html` — dependency-free interactive reference canvas
- `templates/react-flow-starter/` — small React Flow starter pattern
- `examples/saas-feature-map.canvas.json` — valid example model
- `tests/` — validator regression tests
- `references/` — deeper design and QA rules
- `research/OPEN_SOURCE_NOTES.md` — public-source research notes and license cautions

## Fastest use

Give an agent this package plus raw notes and ask:

> Use Infinite Canvas Function Architect. Turn these notes into a canonical function model, diagnose gaps, and generate a single-file infinite canvas I can open locally. Preserve uncertainty instead of inventing missing requirements.

## Recommended implementation choice

- Reviewable / shareable map: single-file HTML.
- Product feature graph or workflow editor: React Flow.
- Freehand whiteboard: Excalidraw.
- Executable typed-node workflow: Rete.js.

See `research/OPEN_SOURCE_NOTES.md` before selecting third-party SDKs for production.
